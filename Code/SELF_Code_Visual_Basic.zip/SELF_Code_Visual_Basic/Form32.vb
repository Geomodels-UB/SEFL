﻿
Public Class Form32
    Private valor As Integer = 0
    Private value As Integer



    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        dlg.Title = "Load Fractures File"
        dlg.Filter = "txt text files (*.txt)|*.txt|All files(*.*)|*.*"
        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            infoReader1 = My.Computer.FileSystem.GetFileInfo(dlg.FileName)
            logbytes = infoReader1.Length
            CSV_FileName1 = dlg.FileName().ToString
            If stateUM = False Then TextBox1.Text = dlg.SafeFileName
            readCSVPoints1()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        dlg.Title = "Load Planes Position Points File"
        dlg.Filter = "txt text files (*.txt)|*.txt|All files(*.*)|*.*"
        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            infoReader1 = My.Computer.FileSystem.GetFileInfo(dlg.FileName)
            logbytes = infoReader1.Length
            CSV_FileName2 = dlg.FileName().ToString
            TextBox2.Text = dlg.SafeFileName
            readCSVPoints2()
        End If
    End Sub

    Private Sub Form32_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Button1.Enabled = True
        Button2.Enabled = True

        Dim ig As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox3.Text = Format(ig, "0.000000")
        TextBox4.Text = Format(j, "0.000000")
        TextBox5.Text = Format(k, "0.000000")

        azi = Me.NumericUpDown4.Value
        di = Me.NumericUpDown5.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox11.Text = Format(ig, "0.000000")
        TextBox12.Text = Format(j, "0.000000")
        TextBox13.Text = Format(k, "0.000000")


    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Label45.Text = "Calculate Scanlines (1/3)"
        Label45.Refresh()
        cal_Punt_mitg()
        ProgressBar1.Value = 100
        opcio = True
        seleccionarfracturesSL()
        Label45.Text = "Completed Process"
        opcio = False
    End Sub

    Private Sub NumericUpDown1_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown1.ValueChanged
        Dim ig As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox3.Text = Format(ig, "0.000000")
        TextBox4.Text = Format(j, "0.000000")
        TextBox5.Text = Format(k, "0.000000")
    End Sub

    Private Sub NumericUpDown2_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown2.ValueChanged
        Dim ig As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox3.Text = Format(ig, "0.000000")
        TextBox4.Text = Format(j, "0.000000")
        TextBox5.Text = Format(k, "0.000000")
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub NumericUpDown4_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown4.ValueChanged
        Dim ig As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown4.Value
        di = Me.NumericUpDown5.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox11.Text = Format(ig, "0.000000")
        TextBox12.Text = Format(j, "0.000000")
        TextBox13.Text = Format(k, "0.000000")
    End Sub

    Private Sub NumericUpDown5_ValueChanged(sender As Object, e As EventArgs) Handles NumericUpDown5.ValueChanged
        Dim ig As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown4.Value
        di = Me.NumericUpDown5.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        ig = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((ig * ig) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            ig = 0
            j = 0
            k = 0
        End If
        TextBox11.Text = Format(ig, "0.00000")
        TextBox12.Text = Format(j, "0.00000")
        TextBox13.Text = Format(k, "0.00000")
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        'registrer
        Dim temp As Integer
        If value = 0 Or value = -1 Then
            Dim arrlist As String
            arrlist = TextBox7.Text + "  " + TextBox8.Text + "  " + TextBox9.Text + "  " + TextBox10.Text + "  " + CStr(NumericUpDown4.Value) + "  " + CStr(NumericUpDown5.Value) + "  " + TextBox11.Text + "  " + TextBox12.Text + "  " + TextBox13.Text
            ListBox1.Items.Add(arrlist)
            valor += 1
        Else
            ' ListBox1.Items.Add(TextBox7.Text + "  " + TextBox8.Text + "  " + TextBox9.Text + "  " + TextBox10.Text + "  " + CStr(NumericUpDown4.Value) + "  " + CStr(NumericUpDown5.Value) + "  " + TextBox11.Text + "  " + TextBox12.Text + "  " + TextBox13.Text)
            ' ListBox1.Items.Add("Inserted Item")
            temp = value
            ListBox1.Items.Remove(ListBox1.Items(value))
            ListBox1.Items.Insert(temp, TextBox7.Text + "  " + TextBox8.Text + "  " + TextBox9.Text + "  " + TextBox10.Text + "  " + CStr(NumericUpDown4.Value) + "  " + CStr(NumericUpDown5.Value) + "  " + TextBox11.Text + "  " + TextBox12.Text + "  " + TextBox13.Text)

        End If

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListBox1.SelectedIndexChanged
        'select
        value = ListBox1.SelectedIndex()
        TextBox6.Text = value
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        'delete
        If value <> -1 Then
            ListBox1.Items.Remove(ListBox1.Items(value))
        End If
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'edit
        Dim lastNonEmpty As Integer = 0
        If ListBox1.Items(value).Contains(" ") Then
            myPoints = ListBox1.Items(value).Split
            lastNonEmpty += 1
            TextBox7.Text = myPoints(0)
            TextBox8.Text = myPoints(2)
            TextBox9.Text = myPoints(4)
            TextBox10.Text = myPoints(6)
            NumericUpDown4.Value = myPoints(8)
            NumericUpDown5.Value = myPoints(10)
            TextBox11.Text = myPoints(12)
            TextBox12.Text = myPoints(14)
            TextBox13.Text = myPoints(16)
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        'save
        ' Dim item1, item2, item3, item4, item5, item6, item7, item8, item9 As String
        FileOpen(2, Form10.TextBox1.Text + "Mechanical_Unit_Properties.txt", OpenMode.Output) 'sortida
        For n = 0 To ListBox1.Items.Count - 1
            ' myPoints = ListBox1.Items(value).Split
            '   item1 = myPoints(0)
            '   item2 = myPoints(2)
            '   item3 = myPoints(4)
            '   item4 = myPoints(6)
            '   item5 = myPoints(8)
            '   item6 = myPoints(10)
            '   item7 = myPoints(12)
            '   item8 = myPoints(14)
            '   item9 = myPoints(16)
            PrintLine(2, ListBox1.Items(n))
        Next
        FileClose(2)
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        stateUM = True
        dlg.Title = "Load Mechanical Units Planes File"
        dlg.Filter = "txt text files (*.txt)|*.txt|All files(*.*)|*.*"
        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            infoReader1 = My.Computer.FileSystem.GetFileInfo(dlg.FileName)
            logbytes = infoReader1.Length
            CSV_FileName2 = dlg.FileName().ToString
            'TextBox2.Text = dlg.SafeFileName
            readCSVPoints2()
        End If
        TextBox7.Text = PointsName.Item(0)
        TextBox8.Text = Pointscx.Item(0)
        TextBox9.Text = Pointscy.Item(0)
        TextBox10.Text = Pointscz.Item(0)
        NumericUpDown4.Value = PointsAzi.Item(0)
        NumericUpDown5.Value = PointsBed.Item(0)
        TextBox11.Text = Pointsi.Item(0)
        TextBox12.Text = Pointsj.Item(0)
        TextBox13.Text = Pointsk.Item(0)
        stateUM = False


    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        Me.Close()
        Form9.Show()
    End Sub
End Class