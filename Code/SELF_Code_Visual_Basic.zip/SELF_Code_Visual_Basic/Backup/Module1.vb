Module Module1
    Public logbytes As Integer
    Public num As Integer
    Public inscrit(360, 90, 24) As Boolean
    Public bprop3() As Double
    Public bkapa() As Double
    Public bseleccio() As Double
    Public numeropunts As Integer
    Public x() As Double
    Public y() As Double
    Public z() As Double
    Public inten() As Double
    Public R() As Integer
    Public G() As Integer
    Public V() As Integer
    Public vect1() As Double
    Public vect2() As Double
    Public vect3() As Double
    Public orientacio() As Double
    Public pendent() As Double
    Public apte() As Boolean
    Public amplex As Double
    Public ampley As Double
    Public amplez As Double
    Public maxx As Double
    Public maxy As Double
    Public maxz As Double
    Public minx As Double
    Public miny As Double
    Public minz As Double
    Public redu As Double
    Public redux As Double
    Public reduy As Double
    Public reduz As Double
    Public contadomax()()() As Integer
    Public refer()()()() As Integer
    Public mult As Double
    Public numero As Integer

    Sub llegirpunts()
        Dim e As String = "a"
        Dim a As Double
        Dim b As Double
        Dim c As Double
        Dim d As Double
        Dim vec1 As Double
        Dim vec2 As Double
        Dim vec3 As Double
        'Dim numero As Integer
        Dim n As Integer
        Dim param As Double
        'Dim position1 As Integer
        'Dim position2 As Integer
        'Dim position3 As Integer
        'Dim position4 As Integer
        'Dim position5 As Integer
        'Dim position6 As Integer
        'Dim position7 As Integer
        'Dim position8 As Integer
        'Dim position9 As Integer
        'Dim position10 As Integer
        'Dim position11 As Integer
        'Dim position12 As Integer
        'Dim position13 As Integer
        ' Dim user As DialogResult
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form1.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form1.OpenFileDialog1.ShowDialog()
        ' If user = DialogResult.Cancel Then openFileDialog1.
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form1.OpenFileDialog1.FileName)
        'MsgBox("File is " & infoReader.Length & " bytes.")
        FileOpen(1, Form1.OpenFileDialog1.FileName, OpenMode.Input)
        numeropunts = -1
        'solament xyz
        If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 27.5))) * 50
            Loop
        End If
        If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                'Input(1, d)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 30.5))) * 50
            Loop
        End If
        If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                'Input(1, d)
                'Input(1, d)
                'Input(1, d)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 37.5))) * 50
            Loop
        End If
        If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                'Input(1, vec1)
                'Input(1, vec2)
                'Input(1, vec3)
                'Input(1, param)
                'Input(1, param)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 150.5))) * 50
            Loop
        End If
        If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                'Input(1, vec1)
                'Input(1, vec2)
                'Input(1, vec3)
                'Input(1, param)
                'Input(1, param)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 161.5))) * 50
            Loop
        End If
        If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'Input(1, a)
                'Input(1, b)
                'Input(1, c)
                'Input(1, vec1)
                'Input(1, vec2)
                'Input(1, vec3)
                'Input(1, param)
                'Input(1, param)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                'Input(1, n)
                Form1.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 190))) * 50
            Loop
        End If
        FileClose(1)
        ReDim Preserve x(numeropunts)
        ReDim Preserve y(numeropunts)
        ReDim Preserve z(numeropunts)
        ReDim Preserve inten(numeropunts)
        ReDim Preserve R(numeropunts)
        ReDim Preserve G(numeropunts)
        ReDim Preserve V(numeropunts)
        ReDim Preserve vect1(numeropunts)
        ReDim Preserve vect2(numeropunts)
        ReDim Preserve vect3(numeropunts)
        ReDim Preserve orientacio(numeropunts)
        ReDim Preserve pendent(numeropunts)
        ReDim Preserve bprop3(numeropunts)
        ReDim Preserve bkapa(numeropunts)
        ReDim Preserve bseleccio(numeropunts)
        ReDim Preserve apte(numeropunts)

        'MsgBox(numeropunts)
        FileOpen(1, Form1.OpenFileDialog1.FileName, OpenMode.Input)
        numero = numeropunts
        numeropunts = -1
        If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                'afegit
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                x(numeropunts) = e.Substring(0, position2)
                y(numeropunts) = e.Substring(position2, position1 - position2)
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                'fi afegit
                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                Form1.ProgressBar1.Value = 0.5 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                'afegit
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                x(numeropunts) = e.Substring(0, position3)
                y(numeropunts) = e.Substring(position3, position2 - position3)
                z(numeropunts) = e.Substring(position2, position1 - position2)
                inten(numeropunts) = e.Substring(position1, e.Length - position1)
                'fi afegit
                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                'Input(1, inten(numeropunts))
                Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = False Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                x(numeropunts) = e.Substring(0, position5)
                y(numeropunts) = e.Substring(position5, position4 - position5)
                z(numeropunts) = e.Substring(position4, position3 - position4)
                R(numeropunts) = e.Substring(position3, position2 - position3)
                G(numeropunts) = e.Substring(position2, position1 - position2)
                V(numeropunts) = e.Substring(position1, e.Length - position1)
                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                'Input(1, R(numeropunts))
                'Input(1, G(numeropunts))
                'Input(1, V(numeropunts))
                Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'inici
                e = Trim(e) : position1 = InStrRev(e, " ")
                bseleccio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bkapa(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bprop3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                pendent(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                orientacio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect2(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect1(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                y(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                x(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                'Input(1, vect1(numeropunts))
                'Input(1, vect2(numeropunts))
                'Input(1, vect3(numeropunts))
                'Input(1, orientacio(numeropunts))
                'Input(1, pendent(numeropunts))
                'Input(1, bprop3(numeropunts))
                'Input(1, bkapa(numeropunts))
                'Input(1, bseleccio(numeropunts))
                apte(numeropunts) = False
                Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                e = Trim(e) ' elimina el punt final
                position1 = InStrRev(e, " ") 'busca el primer espai
                inten(numeropunts) = e.Substring(position1, e.Length - position1) 'agafa el primer numero
                e = Left(e, position1) 'retalla la cadena
                'inici
                e = Trim(e) : position1 = InStrRev(e, " ")
                bseleccio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bkapa(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bprop3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                pendent(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                orientacio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect2(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect1(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                y(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                x(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)

                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                'Input(1, vect1(numeropunts))
                'Input(1, vect2(numeropunts))
                'Input(1, vect3(numeropunts))
                'Input(1, orientacio(numeropunts))
                'Input(1, pendent(numeropunts))
                'Input(1, bprop3(numeropunts))
                'Input(1, bkapa(numeropunts))
                'Input(1, bseleccio(numeropunts))
                'Input(1, inten(numeropunts))
                apte(numeropunts) = False
                Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                'inici
                e = Trim(e) : position1 = InStrRev(e, " ")
                V(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                G(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                R(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bseleccio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bkapa(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                bprop3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                pendent(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                orientacio(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect3(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect2(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                vect1(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                y(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                x(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)

                'Input(1, x(numeropunts))
                'Input(1, y(numeropunts))
                'Input(1, z(numeropunts))
                'Input(1, vect1(numeropunts))
                'Input(1, vect2(numeropunts))
                'Input(1, vect3(numeropunts))
                'Input(1, orientacio(numeropunts))
                'Input(1, pendent(numeropunts))
                'Input(1, bprop3(numeropunts))
                'Input(1, bkapa(numeropunts))
                'Input(1, bseleccio(numeropunts))
                'Input(1, R(numeropunts))
                'Input(1, G(numeropunts))
                'Input(1, V(numeropunts))
                apte(numeropunts) = False
                Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        FileClose(1)
        ' MsgBox("N�mero de punts " & x.Length)
        dimensionarmodel()
        Exit Sub
ErrorHandler:

    End Sub
    Sub dimensionarmodel()
        Dim n As Integer
        'Dim maxx As Double
        'Dim maxy As Double
        'Dim maxz As Double
        redux = (1 / Form1.NumericUpDown1.Value)
        reduy = (1 / Form1.NumericUpDown1.Value)
        reduz = (1 / Form1.NumericUpDown1.Value)
        For n = 0 To (x.Length - 1)
            If n = 0 Then
                maxx = x(n)
                maxy = y(n)
                maxz = z(n)
                minx = x(n)
                miny = y(n)
                minz = z(n)
            Else
                If x(n) >= maxx Then maxx = x(n)
                If x(n) <= minx Then minx = x(n)
                If y(n) >= maxy Then maxy = y(n)
                If y(n) <= miny Then miny = y(n)
                If z(n) >= maxz Then maxz = z(n)
                If z(n) <= minz Then minz = z(n)
            End If
        Next n
        amplex = Int(((maxx - minx) * redux) + 1)
        ampley = Int(((maxy - miny) * reduy) + 1)
        amplez = Int(((maxz - minz) * reduz) + 1)
        'amplex = Int(((Int(maxx) - Int(minx)) + 1) * redux)
        'ampley = Int(((Int(maxy) - Int(miny)) + 1) * reduy)
        'amplez = Int(((Int(maxz) - Int(minz)) + 1) * reduz)
        Form1.Label17.Text = maxx - minx
        Form1.Label18.Text = maxy - miny
        Form1.Label19.Text = maxz - minz
        mult = amplex * ampley * amplez
        Form1.Label8.Text = amplex
        Form1.Label9.Text = ampley
        Form1.Label10.Text = amplez
        Form1.Label12.Text = mult
        Form1.Label21.Text = x.Length
        'MsgBox(amplex & " Voxels a l'eix X  " & ampley & " Voxels a l'eix Y  " & amplez & " Voxels a l'eix Z" & " total: " & mult)
        'MsgBox(maxx & " maxim x  " & minx & " minim x  " & maxy & " maxim y  " & miny & " minim y  " & maxz & " maxim z  " & minz & " minim z  ")
    End Sub
    Sub carregarmodel()
        Dim ad As Integer
        Dim d As Integer
        Dim AA As Double
        Dim BB As Double
        Dim CC As Double
        ReDim contadomax(amplex)
        ReDim refer(amplex)
        For ad = 0 To amplex
            refer(ad) = New Integer(ampley)()() {}
            contadomax(ad) = New Integer(ampley)() {}
            For d = 0 To ampley
                refer(ad)(d) = New Integer(amplez)() {}
                contadomax(ad)(d) = New Integer(amplez) {}
            Next d
        Next ad
        For d = 0 To (x.Length - 1)
            'Form1.ProgressBar1.Value = (d * 100) / (x.Length - 1)
            AA = x(d) - minx
            AA = Int(AA * redux)
            BB = y(d) - miny
            BB = Int(BB * reduy)
            CC = z(d) - minz
            CC = Int(CC * reduz)
            ' CC = Int((Int(CC)) * redu) funciona
            ' N�mero de centroides per cada voxel Refer(x,y,z)
            contadomax(AA)(BB)(CC) = contadomax(AA)(BB)(CC) + 1
            ad = contadomax(AA)(BB)(CC)
            ReDim Preserve refer(AA)(BB)(CC)(ad - 1)
            refer(AA)(BB)(CC)(ad - 1) = d
        Next d
        If Form1.CheckBox1.Checked = True Then MsgBox("Coarse Block Loaded")
        'MsgBox("Carregat")
    End Sub
    Sub transformar()
        Dim xt As Double
        Dim yt As Double
        Dim zt As Double
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        Dim a1 As Double
        Dim b1 As Double
        'Dim fo As Integer
        Dim intent As Double
        '***eliminem les traces horiztontals***
        Dim openFileDialog2 As New OpenFileDialog()
        ' Form1.OpenFileDialog2.ShowDialog()
        ' FileOpen(1, Form1.OpenFileDialog2.FileName, OpenMode.Input)
        'FileOpen(2, "C:\Dades\Projecte120\prova6.txt", OpenMode.Output)
        Do Until EOF(1)
            If Form1.RadioButton1.Checked = True Then
                Input(1, xt)
                Input(1, yt)
                Input(1, zt)
                Input(1, at)
                Input(1, bt)
                Input(1, ct)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, seleccio)
            End If
            If Form1.RadioButton3.Checked = True Then
                Input(1, xt)
                Input(1, yt)
                Input(1, zt)
                Input(1, at)
                Input(1, bt)
                Input(1, ct)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, seleccio)
                Input(1, intent)
            End If
            '   If Form1.RadioButton6.Checked = True Then
            Input(1, xt)
            Input(1, yt)
            Input(1, zt)
            Input(1, at)
            Input(1, bt)
            Input(1, ct)
            Input(1, prop3)
            Input(1, kapa)
            Input(1, seleccio)
            Input(1, R)
            Input(1, G)
            Input(1, V)
            'End If
            If at = 0 And bt = 0 Then   '***la tra�a �s horitzontal***
                a1 = 0
                b1 = 0
                GoTo line100
            End If
            '***calculem dip i dip direction***
            b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
            b1 = (b1 * 180) / Math.PI

            If bt <> 0 Then
                a1 = Math.Atan(at / bt)
                a1 = (a1 * 180) / Math.PI
            Else
                If at < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                    a1 = -90
                Else
                    a1 = 90
                End If
            End If

            If bt < 0 Then
                a1 = 180 + a1
            Else
                If at < 0 Then
                    a1 = 360 + a1
                Else
                End If
            End If

line100:
            If Form1.RadioButton1.Checked = True Then PrintLine(2, xt, yt, zt, a1, b1, prop3, kapa, seleccio)
            If Form1.RadioButton3.Checked = True Then PrintLine(2, xt, yt, zt, a1, b1, prop3, kapa, seleccio, intent)
            '  If Form1.RadioButton6.Checked = True Then PrintLine(2, xt, yt, zt, a1, b1, prop3, kapa, seleccio, R, G, V)
        Loop
        FileClose(1)
        FileClose(2)
    End Sub
    Sub continuitat()
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim ac As Integer
        Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim pap As Double
        Dim pep As Double
        Dim pip As Double
        Dim puntsacceptats As Double
        ac = 0
        esp = Int(Form4.NumericUpDown1.Value) + 1
        FileOpen(1, Form10.TextBox1.Text + "Filtercontinuity.txt", OpenMode.Output)
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' N�mero de centroides per cada voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides
                        For l = 1 To ab
                            puntsacceptats = 0
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim el primer centroide
                            'Print #1, eixx, eixy, eixz, l, n
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 40
                                For dify = -esp To esp
                                    eixy2 = eixy + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 30
                                    For difz = -esp To esp
                                        eixz2 = eixz + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 20
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1)
                                                pep = Math.Sqrt(Math.Pow(orientacio(n) - orientacio(m), 2))
                                                If pep > 180 Then pep = 360 - pep
                                                If pep <= Form4.NumericUpDown2.Value Then
                                                    pip = Math.Sqrt(Math.Pow(pendent(n) - pendent(m), 2))
                                                    If pip <= Form4.NumericUpDown3.Value Then
                                                        pap = Math.Sqrt(((x(n) - x(m)) ^ 2) + ((y(n) - y(m)) ^ 2) + ((z(n) - z(m)) ^ 2))
                                                        If pap < Form4.NumericUpDown1.Value And pap <> 0 Then
                                                            If bprop3(n) > Form4.NumericUpDown4.Value And bprop3(n) < Form4.NumericUpDown5.Value Then
                                                                If bkapa(n) > Form4.NumericUpDown6.Value And bkapa(n) < Form4.NumericUpDown7.Value Then
                                                                    If bseleccio(n) > Form4.NumericUpDown8.Value And bseleccio(n) < Form4.NumericUpDown9.Value Then
                                                                        puntsacceptats = puntsacceptats + 1
                                                                        If puntsacceptats = Form4.NumericUpDown11.Value Then
                                                                            If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                                                                            If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
                                                                            If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))
                                                                            ac = ac + 1
                                                                            puntsacceptats = 0
                                                                            ' ReDim Preserve ref(ac) As Long
                                                                            'ref(ac) = n
                                                                            l2 = ad : difz = esp : dify = esp : difx = esp ': l = ab
                                                                        End If
                                                                    End If
                                                                End If
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            Next l2
                                        End If
20:                                 Next difz
30:                             Next dify
40:                         Next difx
                        Next l

                    End If
                Next eixz
            Next eixy
        Next eixx
        FileClose(1)
        'porc = (ac * 100) / cont
        'Form3.Label7.Caption = porc
        'pathnamexit = "pol3.txt"
        MsgBox("Filter by Continuity Completed")
    End Sub
    Sub continuitat2()
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim ac As Integer
        Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim pap As Double
        Dim pep As Double
        'Dim pip As Double
        Dim puntsacceptats As Double
        Dim porc As Double
        ac = 0
        puntsacceptats = 0
        esp = Int(Form4.NumericUpDown1.Value) + 1
        FileOpen(1, Form10.TextBox1.Text + "Filtercontinuity.txt", OpenMode.Output)
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' N�mero de centroides per cada voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides
                        For l = 1 To ab
                            puntsacceptats = 0
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim el primer centroide
                            'Print #1, eixx, eixy, eixz, l, n
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 40
                                For dify = -esp To esp
                                    eixy2 = eixy + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 30
                                    For difz = -esp To esp
                                        eixz2 = eixz + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 20
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1)
                                                pep = Math.Acos(((vect1(n) * vect1(m)) + (vect2(n) * vect2(m)) + (vect3(n) * vect3(m))) / (Math.Sqrt((vect1(n) * vect1(n)) + (vect2(n) * vect2(n)) + (vect3(n) * vect3(n)))) * (Math.Sqrt((vect1(m) * vect1(m)) + (vect2(m) * vect2(m)) + (vect3(m) * vect3(m)))))
                                                pep = (pep * 180) / Math.PI
                                                'Es calcula el producte vectorial
                                                If pep <= Form4.NumericUpDown10.Value Then 'Es mira si cumpleix l'angle
                                                    ' Es calcula la dist�ncia
                                                    pap = Math.Sqrt(((x(n) - x(m)) ^ 2) + ((y(n) - y(m)) ^ 2) + ((z(n) - z(m)) ^ 2))
                                                    If pap < Form4.NumericUpDown1.Value And pap <> 0 Then 'Es comprova la dist�ncia
                                                        If bprop3(n) > Form4.NumericUpDown4.Value And bprop3(n) < Form4.NumericUpDown5.Value Then 'Es comprova la M
                                                            If bkapa(n) > Form4.NumericUpDown6.Value And bkapa(n) < Form4.NumericUpDown7.Value Then 'Es comprova la K
                                                                If bseleccio(n) > Form4.NumericUpDown8.Value And bseleccio(n) < Form4.NumericUpDown9.Value Then 'Es comprova la n
                                                                    puntsacceptats = puntsacceptats + 1
                                                                    If puntsacceptats = Form4.NumericUpDown11.Value Then
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))
                                                                        ac = ac + 1
                                                                        puntsacceptats = 0
                                                                        l2 = ad : difz = esp : dify = esp : difx = esp ': l = ab
                                                                    End If 'puntsacceptats
                                                                End If 'bseleccio
                                                            End If 'bkapa
                                                        End If 'bprop3
                                                    End If 'pap
                                                End If 'pep
                                            Next l2
                                        End If
20:                                 Next difz
30:                             Next dify
40:                         Next difx
                        Next l

                    End If
                Next eixz
            Next eixy
        Next eixx
        FileClose(1)
        porc = (ac * 100) / numeropunts
        Form4.Label11.Text = Format(porc, "##.###")
        'pathnamexit = "pol3.txt"
        MsgBox("Filter by Continuity Completed")
    End Sub
    Sub scanline()
        Dim azi As Double
        Dim pendi As Double
        Dim n As Integer
        Dim no As Integer
        Dim numpunts As Integer
        Dim D As Double
        Dim cont As Integer
        Dim t As Double
        Dim t1 As Double
        Dim t2 As Double
        Dim openFileDialog1 As New OpenFileDialog()
        Dim puntcontactex As Double
        Dim puntcontactey As Double
        Dim puntcontactez As Double
        Dim distx As Double
        Dim disty As Double
        Dim distz As Double
        Dim distfinal As Double
        Form14.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form14.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "scanline.txt", OpenMode.Output)
        numpunts = 0
        Do Until EOF(1)
            numpunts = numpunts + 1
            ReDim Preserve x(numpunts)
            ReDim Preserve y(numpunts)
            ReDim Preserve z(numpunts)
            ReDim Preserve escollits(numpunts)
            Input(1, x(numpunts))
            Input(1, y(numpunts))
            Input(1, z(numpunts))
            Input(1, n)
            Input(1, no)
            Input(1, no)
            Input(1, no)
            Input(1, no)
            Input(1, no)
            seleccio = numpunts
            escollits(seleccio) = numpunts
            If x(numpunts) = 0 And y(numpunts) = 0 And z(numpunts) = 0 Then cont = n
            If x(numpunts) = 0 And y(numpunts) = 0 And z(numpunts) = 0 And numpunts > Form14.NumericUpDown12.Value Then 'final
                numpunts = numpunts - 1
                seleccio = seleccio - 1
                escollits(seleccio) = numpunts
                If Form14.CheckBox1.Checked = True Then 'enviat a calcular vectors aa
                    calculvectors()
                    'insert
                    If AA = 0 And BB = 0 Then   '***la tra�a �s horitzontal***
                        azi = 0
                        pendi = 0
                        GoTo 10
                    End If
                    '***calculem dip i dip direction***
                    pendi = Math.Atan(Math.Sqrt((AA * AA) + (BB * BB)) / CC)
                    pendi = (pendi * 180) / Math.PI

                    If BB <> 0 Then
                        azi = Math.Atan(AA / BB)
                        azi = (azi * 180) / Math.PI
                    Else
                        If AA < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                            azi = -90
                        Else
                            azi = 90
                        End If
                    End If

                    If BB < 0 Then
                        azi = 180 + azi
                    Else
                        If AA < 0 Then
                            azi = 360 + azi
                        Else
                        End If
                    End If
10:                 'insert
                    AA = Form14.NumericUpDown9.Value
                    BB = Form14.NumericUpDown10.Value
                    CC = Form14.NumericUpDown11.Value
                Else 'aa
                    calculvectors()
                    A = AA
                    B = BB
                    C = CC
                    calculpendent()
                    If a1 < 0 Then a1 = 360 + a1
                End If 'aa
                D = -(AA * xmean) - (BB * ymean) - (CC * zmean)
                t1 = -D - (AA * Form14.NumericUpDown1.Value) - (BB * Form14.NumericUpDown2.Value) - (CC * Form14.NumericUpDown3.Value)
                t2 = (AA * (Form14.NumericUpDown4.Value - Form14.NumericUpDown1.Value)) + (BB * (Form14.NumericUpDown5.Value - Form14.NumericUpDown2.Value)) + (CC * (Form14.NumericUpDown6.Value - Form14.NumericUpDown3.Value))
                t = t1 / t2
                puntcontactex = Form14.NumericUpDown1.Value + (t * (Form14.NumericUpDown4.Value - Form14.NumericUpDown1.Value))
                puntcontactey = Form14.NumericUpDown2.Value + (t * (Form14.NumericUpDown5.Value - Form14.NumericUpDown2.Value))
                puntcontactez = Form14.NumericUpDown3.Value + (t * (Form14.NumericUpDown6.Value - Form14.NumericUpDown3.Value))
                distx = Form14.NumericUpDown1.Value - puntcontactex
                disty = Form14.NumericUpDown2.Value - puntcontactey
                distz = Form14.NumericUpDown3.Value - puntcontactez
                distfinal = Math.Sqrt(Math.Pow(distx, 2) + Math.Pow(disty, 2) + Math.Pow(distz, 2))
                ' If numpunts > numpunts > Form14.NumericUpDown12.Value Then
                PrintLine(2, cont, Format(puntcontactex, "#.###"), Format(puntcontactey, "#.###"), Format(puntcontactez, "#.###"), Format(distfinal, "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), numpunts)
                'End If
                numpunts = 0

            Else
                If x(numpunts) = 0 And y(numpunts) = 0 And z(numpunts) = 0 Then numpunts = 0
            End If
        Loop
        ' Per l'ultim cluster
        numpunts = numpunts - 1
        calculvectors()
        D = -(AA * xmean) - (BB * ymean) - (CC * zmean)
        t1 = -D - (AA * Form14.NumericUpDown1.Value) - (BB * Form14.NumericUpDown2.Value) - (CC * Form14.NumericUpDown3.Value)
        t2 = (AA * (Form14.NumericUpDown4.Value - Form14.NumericUpDown1.Value)) + (BB * (Form14.NumericUpDown5.Value - Form14.NumericUpDown2.Value)) + (CC * (Form14.NumericUpDown6.Value - Form14.NumericUpDown3.Value))
        t = t1 / t2
        puntcontactex = Form14.NumericUpDown1.Value + (t * (Form14.NumericUpDown4.Value - Form14.NumericUpDown1.Value))
        puntcontactey = Form14.NumericUpDown2.Value + (t * (Form14.NumericUpDown5.Value - Form14.NumericUpDown2.Value))
        puntcontactez = Form14.NumericUpDown3.Value + (t * (Form14.NumericUpDown6.Value - Form14.NumericUpDown3.Value))
        distx = Form14.NumericUpDown1.Value - puntcontactex
        disty = Form14.NumericUpDown2.Value - puntcontactey
        distz = Form14.NumericUpDown3.Value - puntcontactez
        distfinal = Math.Sqrt(Math.Pow(distx, 2) + Math.Pow(disty, 2) + Math.Pow(distz, 2))
        calculvectors()
        A = AA
        B = BB
        C = CC
        calculpendent()
        If a1 < 0 Then a1 = 360 + a1
        PrintLine(2, cont, Format(puntcontactex, "#.###"), Format(puntcontactey, "#.###"), Format(puntcontactez, "#.###"), Format(distfinal, "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), numpunts)




        FileClose(1)
        FileClose(2)





errorhandler:
        Exit Sub
    End Sub

End Module