﻿Imports System.IO
Module Topografia2
    Public Image1 As Bitmap
    Sub PointCloudRGB()
        'Obrir la imatge
        Dim dummy1 As Integer
        Dim midapixel As Double
        Dim oripixelx As Double
        Dim oripixely As Double
        Dim returnvalue As Color
        Dim R As Integer
        Dim G As Integer
        Dim B As Integer
        Dim primeradireccio As String
        Dim segonadireccio As String
        Form1.OpenFileDialog1.Title = "Open Orthoimage"
        Form1.OpenFileDialog1.ShowDialog()
        Image1 = Image.FromFile(Form1.OpenFileDialog1.FileName, True)
        segonadireccio = Right(Form1.OpenFileDialog1.FileName, 3)
        primeradireccio = Left(Form1.OpenFileDialog1.FileName, Len(Form1.OpenFileDialog1.FileName) - 3)
        If segonadireccio = "jpg" Then
            segonadireccio = primeradireccio + "jgw"
        Else
            segonadireccio = primeradireccio + "tfw"
        End If

        FileOpen(1, segonadireccio, OpenMode.Input)
        Input(1, midapixel)
        Input(1, dummy1)
        Input(1, dummy1)
        Input(1, dummy1)
        Input(1, oripixelx)
        Input(1, oripixely)
        Dim inputRecord As String = Nothing
        Dim myPoints() As String = Nothing
        Dim myPoints2(3) As String
        Dim LastNonEmpty As Integer = -1
        Dim coordx As Double
        Dim coordy As Double
        Dim coordz As Double
        Dim aaa As Integer
        Dim bbb As Integer
        Form1.OpenFileDialog1.Title = "Open PointCloud"
        Form1.OpenFileDialog1.ShowDialog()
        FileOpen(2, "c:\pointcloudRGB.txt", OpenMode.Output)
        Dim imReader1 As StreamReader = File.OpenText(Form1.OpenFileDialog1.FileName) 'afegit
        inputRecord = imReader1.ReadLine()
        While (inputRecord IsNot Nothing)
            myPoints = inputRecord.Split
            For i As Integer = 0 To myPoints.Length - 1
                If myPoints(i) <> "" Then
                    LastNonEmpty += 1
                    myPoints2(LastNonEmpty) = myPoints(i)
                End If
            Next i
            LastNonEmpty = -1
            'Lectura nuvol de punts
            coordx = CDbl(myPoints2(0).Trim)
            coordy = CDbl(myPoints2(1).Trim)
            coordz = CDbl(myPoints2(2).Trim)
            ' dummy1 = CDbl(myPoints2(3).Trim)
            aaa = CDec((coordx - oripixelx) / midapixel)
            bbb = Math.Abs(CDec((coordz - oripixely)) / midapixel) '****Modificado 1-Nov-2015 Coordinada coordy por coordz
            ' If aaa <= Image1.Width And bbb <= Image1.Height Then
            If coordx > oripixelx And coordx < (oripixelx + (Image1.Width * midapixel)) Then
                If coordz > (oripixely - (Image1.Height * midapixel)) And coordz < oripixely Then '****Modificado 1-Nov-2015 Coordinada coordy por coordz
                    If aaa < Image1.Width And bbb < Image1.Height Then
                        returnvalue = Image1.GetPixel(aaa, bbb) 'falta arreglar el canvi de coordenades
                        R = returnvalue.R
                        G = returnvalue.G
                        B = returnvalue.B
                        PrintLine(2, Format(coordx, "##.###"), Format(coordy, "##.###"), Format(coordz, "##.###"), R, G, B)
                        ' inputRecord = imReader1.ReadLine()
                    Else
                        ' inputRecord = imReader1.ReadLine()
                    End If
                End If
            End If
            inputRecord = imReader1.ReadLine()
        End While
        imReader1.Close()
        FileClose(2)
        MsgBox("PointCloud Orthoimage completed")
    End Sub
    Sub Reduction2()
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim xvox(), yvox(), zvox(), intenvox() As Double
        Dim Rvox(), Gvox(), Bvox() As Integer
        Dim ac As Integer
        ' Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim n As Integer
        Dim chiv0 As Boolean = False
        Dim chiv1 As Boolean = False
        Dim chiv2 As Boolean = False
        Dim puntsacceptats As Double
        ac = 0
        ' esp = Int(Form4.NumericUpDown1.Value) + 1 '''''problema********************************************************
        FileOpen(1, Form10.TextBox1.Text + "Reduction.txt", OpenMode.Output)
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' Número de centroides per cada voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides
                        ReDim xvox(ab - 1), yvox(ab - 1), zvox(ab - 1), intenvox(ab - 1), Rvox(ab - 1), Gvox(ab - 1), Bvox(ab - 1)

                        For l = 1 To ab
                            puntsacceptats = 0
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim el primer centroide
                            xvox(l - 1) = x(n) : yvox(l - 1) = y(n) : zvox(l - 1) = z(n)
                            ' If Form1.RadioButton1.Checked = True Then
                            If Form1.RadioButton2.Checked = True Then intenvox(l - 1) = inten(n)
                            If Form1.RadioButton3.Checked = True Then Rvox(l - 1) = R(n) : Gvox(l - 1) = G(n) : Bvox(l - 1) = V(n)
                        Next l
                        ' Per promitg
                        If Form1.CheckBox5.Checked = True Then
                            If Form1.RadioButton1.Checked = True Then PrintLine(1, xvox.Average, yvox.Average, zvox.Average)
                            If Form1.RadioButton2.Checked = True Then PrintLine(1, xvox.Average, yvox.Average, zvox.Average, intenvox.Average)
                            If Form1.RadioButton3.Checked = True Then PrintLine(1, xvox.Average, yvox.Average, zvox.Average, Rvox.Average, Gvox.Average, Bvox.Average)
                            If ab = 1 Then chiv0 = True
                        End If
                        Select Case chiv0
                            Case 0
                                ' Minimum Z
                                If Form1.CheckBox4.Checked = True Then
                                    Dim valorn As Integer
                                    valorn = Array.IndexOf(zvox, zvox.Min)
                                    If Form1.RadioButton1.Checked = True Then PrintLine(1, xvox(valorn), yvox(valorn), zvox(valorn))
                                    If Form1.RadioButton2.Checked = True Then PrintLine(1, xvox(valorn), yvox(valorn), zvox(valorn), intenvox(valorn))
                                    If Form1.RadioButton3.Checked = True Then PrintLine(1, xvox(valorn), yvox(valorn), zvox(valorn), Rvox(valorn), Gvox(valorn), Bvox(valorn))
                                    If ab = 1 Then chiv1 = True
                                End If
                                Select Case chiv1
                                    Case 0
                                        If Form1.CheckBox6.Checked = True Then
                                            Dim valorm As Integer
                                            valorm = Array.IndexOf(zvox, zvox.Max)
                                            If Form1.RadioButton1.Checked = True Then PrintLine(1, xvox(valorm), yvox(valorm), zvox(valorm))
                                            If Form1.RadioButton2.Checked = True Then PrintLine(1, xvox(valorm), yvox(valorm), zvox(valorm), intenvox(valorm))
                                            If Form1.RadioButton3.Checked = True Then PrintLine(1, xvox(valorm), yvox(valorm), zvox(valorm), Rvox(valorm), Gvox(valorm), Bvox(valorm))
                                        End If
                                End Select
                        End Select
                        If Form1.RadioButton4.Checked = True Then
                            Dim valo As Integer
                            valo = Form1.NumericUpDown2.Value
                            If valo > ab Then valo = ab
                            For l = 1 To valo
                                If Form1.RadioButton1.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1))
                                If Form1.RadioButton2.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1), intenvox(l - 1))
                                If Form1.RadioButton3.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1), Rvox(l - 1), Gvox(l - 1), Bvox(l - 1))
                            Next
                        End If
                        If Form1.RadioButton5.Checked = True Then
                            Dim valo, valo1, valo2, valo3 As Integer
                            valo = Form1.NumericUpDown3.Value
                            valo1 = (valo * ab) / 100
                            valo2 = Math.Floor(valo1)
                            If valo2 = 0 Then valo2 = ab
                            If valo2 > ab Or ab = 1 Then valo2 = ab
                            For l = 1 To ab Step ab / valo2
                                If Form1.RadioButton1.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1))
                                If Form1.RadioButton2.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1), intenvox(l - 1))
                                If Form1.RadioButton3.Checked = True Then PrintLine(1, xvox(l - 1), yvox(l - 1), zvox(l - 1), Rvox(l - 1), Gvox(l - 1), Bvox(l - 1))
                            Next
                        End If
                        chiv0 = False
                        chiv1 = False
                        ' ara s´han de buscar tots els del voltant
                        ' If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                        ' If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
                        ' If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))
                        Array.Resize(xvox, 0)
                        Array.Resize(yvox, 0)
                        Array.Resize(zvox, 0)
                        Array.Resize(intenvox, 0)
                        Array.Resize(Rvox, 0)
                        Array.Resize(Gvox, 0)
                        Array.Resize(Bvox, 0)
                    End If
                Next eixz
            Next eixy
        Next eixx
        FileClose(1)
        'porc = (ac * 100) / cont
        'Form3.Label7.Caption = porc
        'pathnamexit = "pol3.txt"
        MsgBox("Reduction Completed")
    End Sub
End Module
