Public Class Form3
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Form1.CheckBox1.Checked = True
        If CheckBox1.Checked = True Then filtrardip()
        If CheckBox2.Checked = True Then filtrardip3()
        If CheckBox3.Checked = True Then filtrardip2()
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub NumericUpDown5_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown5.ValueChanged

    End Sub

    Private Sub ProgressBar1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProgressBar1.Click

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = NumericUpDown1.Value
        di = NumericUpDown3.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        i = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            i = 0
            j = 0
            k = 0
        End If
        TextBox1.Text = i
        TextBox2.Text = j
        TextBox3.Text = k

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim a1 As Double
        Dim b1 As Double
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        at = TextBox1.Text
        bt = TextBox2.Text
        ct = TextBox3.Text
        If at = 0 And bt = 0 Then   '***la tra�a �s horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
500:
        NumericUpDown1.Value = a1
        NumericUpDown3.Value = b1
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        family = 1
        polygon()
        'Button5.Text = My.Computer.FileSystem.GetName(file)
        TextBox4.Visible = True
        Label13.Visible = True
        Button6.Enabled = True
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        family = 2
        polygon()
        'Button6.Text = My.Computer.FileSystem.GetName(file)
        TextBox5.Visible = True
        Label14.Visible = True
        Button7.Enabled = True
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        family = 3
        polygon()
        'Button7.Text = My.Computer.FileSystem.GetName(file)
        TextBox6.Visible = True
        Label15.Visible = True
        Button8.Enabled = True
    End Sub

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        family = 4
        polygon()
        Button8.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox7.Visible = True
        Label16.Visible = True
        Button9.Enabled = True
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        family = 5
        polygon()
        Button9.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox8.Visible = True
        Label17.Visible = True
        Button10.Enabled = True
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        family = 6
        polygon()
        Button10.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox9.Visible = True
        Label18.Visible = True
        Button11.Enabled = True
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        family = 7
        polygon()
        Button11.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox10.Visible = True
        Label19.Visible = True
        Button12.Enabled = True
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        family = 8
        polygon()
        Button12.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox11.Visible = True
        Label20.Visible = True
        Button13.Enabled = True
    End Sub

    Private Sub Label20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label20.Click

    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        family = 9
        polygon()
        Button13.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox12.Visible = True
        Label21.Visible = True
        Button14.Enabled = True
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        family = 10
        polygon()
        Button14.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox13.Visible = True
        Label22.Visible = True
        Button15.Enabled = True
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        family = 11
        polygon()
        Button15.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox14.Visible = True
        Label23.Visible = True
        Button16.Enabled = True
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub Label13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label13.Click

    End Sub

    Private Sub Label14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label14.Click

    End Sub

    Private Sub Label15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label15.Click

    End Sub

    Private Sub Label16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label16.Click

    End Sub

    Private Sub Label17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label17.Click

    End Sub

    Private Sub Label18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label18.Click

    End Sub

    Private Sub Label19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label19.Click

    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        family = 12
        polygon()
        Button16.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox15.Visible = True
        Label24.Visible = True
        Button17.Enabled = True
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        family = 13
        polygon()
        Button17.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox16.Visible = True
        Label25.Visible = True
        Button18.Enabled = True
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        family = 14
        polygon()
        Button18.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox17.Visible = True
        Label26.Visible = True
        Button19.Enabled = True
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        family = 15
        polygon()
        Button19.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox18.Visible = True
        Label27.Visible = True
        Button20.Enabled = True
    End Sub

    Private Sub TextBox18_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox18.TextChanged

    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button25.Click
        family = 21
        polygon()
        Button25.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox24.Visible = True
        Label33.Visible = True
        Button25.Enabled = True
    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button27.Click
        family = 23
        polygon()
        Button27.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox26.Visible = True
        Label35.Visible = True
        Button27.Enabled = True
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        family = 16
        polygon()
        Button20.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox19.Visible = True
        Label28.Visible = True
        Button20.Enabled = True
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        family = 17
        polygon()
        Button21.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox20.Visible = True
        Label29.Visible = True
        Button21.Enabled = True
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        family = 18
        polygon()
        Button22.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox21.Visible = True
        Label30.Visible = True
        Button22.Enabled = True
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        family = 19
        polygon()
        Button23.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox22.Visible = True
        Label31.Visible = True
        Button23.Enabled = True
    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        family = 20
        polygon()
        Button24.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox23.Visible = True
        Label32.Visible = True
        Button24.Enabled = True
    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button26.Click
        family = 22
        polygon()
        Button26.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox25.Visible = True
        Label34.Visible = True
        Button26.Enabled = True
    End Sub

    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button28.Click
        family = 24
        polygon()
        Button28.Text = My.Computer.FileSystem.GetName(rfile)
        TextBox27.Visible = True
        Label36.Visible = True
        Button28.Enabled = True
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            CheckBox2.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            CheckBox1.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            CheckBox1.Checked = False
            CheckBox2.Checked = False
        End If
    End Sub
End Class