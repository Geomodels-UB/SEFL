﻿Public Class Form15

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        atributecluster()
        If CheckBox2.Checked = True Then exportts()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim sad As Double
        sad = Math.Acos(Math.Abs(((A * 1) + (B * 0) + (C * 0)) / (Math.Sqrt((A * A) + (B * B) + (C * C)) * Math.Sqrt((1 * 1) + (0 * 0) + (0 * 0)))))
        MsgBox(sad)
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Form15_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class