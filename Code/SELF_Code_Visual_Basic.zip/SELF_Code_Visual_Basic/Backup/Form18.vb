﻿Public Class Form18

    Private Sub Form18_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Form18_click(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.Click
        Me.Close()
        Form9.Show()
    End Sub
End Class