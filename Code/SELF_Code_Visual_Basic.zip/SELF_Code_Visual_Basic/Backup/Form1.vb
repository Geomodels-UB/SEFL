
Imports System
Imports System.IO


Public Class Form1
    Public dlg As New System.Windows.Forms.OpenFileDialog()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'llegirpunts()

        'inici de la nova
        Dim infoReader As System.IO.FileInfo
        Dim CSV_FileName As String = Nothing
        'Dim dlg As New System.Windows.Forms.OpenFileDialog()
        dlg.InitialDirectory = Form10.TextBox1.Text
        dlg.Title = "Open File"
        dlg.Filter = "txt text files (*.txt)|*.txt|All files(*.*)|*.*"
        If dlg.ShowDialog() = Windows.Forms.DialogResult.OK Then
            infoReader = My.Computer.FileSystem.GetFileInfo(dlg.FileName)
            logbytes = infoReader.Length
            CSV_FileName = dlg.FileName().ToString
            readCSVPoints(CSV_FileName)
        End If
        'final de la nova


        GroupBox1.Enabled = True
        ac = 1


    End Sub

    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = Form10.TextBox1.Text + "plans"
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        carregarmodel()
        GroupBox2.Enabled = True
        GroupBox4.Enabled = True
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        transformar()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Hide()
        Form9.Show()
    End Sub

    Private Sub DomainUpDown2_SelectedItemChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Label7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label7.Click

    End Sub

    Private Sub ContextMenuStrip1_Opening(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub ContextMenuStrip1_Opening_1(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        dimensionarmodel()
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            RadioButton1.Checked = False
            RadioButton3.Checked = False

        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If RadioButton3.Checked = True Then
            RadioButton1.Checked = False
            RadioButton2.Checked = False

        End If
    End Sub


    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            RadioButton2.Checked = False
            RadioButton3.Checked = False

        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        pendents()
        If CheckBox3.Checked = True Then
            FileOpen(5, Me.TextBox1.Text + "log.txt", OpenMode.Output)

            Dim infoReader As System.IO.FileInfo
            infoReader = My.Computer.FileSystem.GetFileInfo(TextBox1.Text + ".txt")
            PrintLine(5, "File Input Name: " + dlg.FileName)
            'PrintLine(5, "File Input Name: " + OpenFileDialog1.FileName)
            PrintLine(5, "File output Name: " + infoReader.FullName)
            PrintLine(5, "Creation time: " + infoReader.CreationTime)
            PrintLine(5, "Ending time: " + infoReader.LastWriteTime)
            PrintLine(5, "Length: " + Str(infoReader.Length))
            PrintLine(5, "Coarse blocks Side: " + Str(Me.NumericUpDown1.Value))
            PrintLine(5, "Number of Coarse blocks: X: " + Label8.Text + "  Y: " + Label9.Text + "  Z: " + Label10.Text)
            PrintLine(5, "Total Number of coarse blocks: " + Label12.Text)
            PrintLine(5, "Minimum Range: " + Str(NumericUpDown4.Value) + "   Maximum Range: " + Str(NumericUpDown6.Value))
            PrintLine(5, "Maximum K: " + Str(NumericUpDown8.Value) + "  Minimum M: " + Str(NumericUpDown9.Value))
            PrintLine(5, "Number of points: " + Str(numeropunts))
            PrintLine(5, "Number of accepted points: " + Str(coco))
            FileClose(5)
        End If
        MsgBox("Model completed")
    End Sub

    Private Sub NumericUpDown6_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown6.ValueChanged

    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub RadioButton6_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub RadioButton8_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click

        ' MsgBox("Computer's available physical memory: " & My.Computer.Info.TotalPhysicalMemory)


    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        estadistica2()
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ReduceFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub ByNormalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub ByContinuityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub ChangeCoordinatesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub StatisticsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        estadistica2()
    End Sub

    Private Sub FromVectorToAzimuthToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        transformar()
    End Sub

    Private Sub OpenFileDialog2_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs)

    End Sub

    Private Sub ReducePlanesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form8.Show()
        Me.Hide()
    End Sub

    Private Sub FiltersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CreateBoxToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        GroupBox1.Enabled = True
    End Sub

    Private Sub CheckBox1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        SaveFileDialog1.ShowDialog()
        TextBox1.Text = SaveFileDialog1.FileName
    End Sub

    Private Sub GroupBox3_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub TextBox1_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Label21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label21.Click

    End Sub

    Private Sub Button7_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Reduction2()
    End Sub
End Class
