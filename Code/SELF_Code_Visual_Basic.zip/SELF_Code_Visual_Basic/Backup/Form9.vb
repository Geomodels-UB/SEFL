﻿Public Class Form9
    Private Sub Form9_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Form10.TextBox1.Text = My.Computer.FileSystem.CurrentDirectory + "\WORKSPACE\"
        My.Computer.FileSystem.CreateDirectory(My.Computer.FileSystem.CurrentDirectory + "\Documentation")
        My.Computer.FileSystem.CreateDirectory(Form10.TextBox1.Text)
        Dim thisdate As Date
        'If My.Computer.Name <> "ANNADAVID" Then Me.Close() 'en majuscules o minuscules
        thisdate = Today
        If thisdate > "31/12/2021" Then
            MsgBox("License expired")
            Me.Close() 'en majuscules o minuscules
        End If
    End Sub

    Private Sub CreateBoxToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateBoxToolStripMenuItem.Click

    End Sub

    Private Sub LoadModelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ByNormalToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub ByContinuityToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub FiltersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FiltersToolStripMenuItem.Click

    End Sub

    Private Sub FileToolsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileToolsToolStripMenuItem.Click

    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub AutotrackingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AutotrackingToolStripMenuItem.Click
        Form5.Show()
        Me.Hide()
    End Sub

    Private Sub SaveClustersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveClustersToolStripMenuItem.Click
        Form7.Show()
        Me.Hide()
    End Sub

    Private Sub ReduceFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReduceFileToolStripMenuItem.Click
        Form3.Show()
        Me.Hide()
    End Sub

    Private Sub ReducePlanesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReducePlanesToolStripMenuItem.Click
        Form8.Show()
        Me.Hide()
    End Sub

    Private Sub StatisticsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StatisticsToolStripMenuItem.Click
        Form11.Show()
        Me.Hide()
    End Sub

    Private Sub ChangeCoordinatesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChangeCoordinatesToolStripMenuItem.Click
        Form2.Show()
        Me.Hide()
    End Sub

    Private Sub FromVectorToAzimuthToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ByContinuityToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ByContinuityToolStripMenuItem.Click
        Form4.Show()
        Me.Hide()
    End Sub

    Private Sub FilterByAToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterByAToolStripMenuItem.Click
        Form6.Show()
        Me.Hide()
    End Sub

    Private Sub VectorizedPointCloudToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VectorizedPointCloudToolStripMenuItem.Click
        Form1.GroupBox3.Text = "Point Cloud Files"
        Form1.Button1.Text = "Select file and load point cloud"
        Form1.Button2.Text = "Generate coarse cells and assign points to blocks"
        Form1.Text = "Compute planar regressions from point cloud"
        Form1.GroupBox2.Visible = True
        Form1.Show()
        Form1.CheckBox1.Checked = False
        Form1.Text = "Compute planar regressions from point cloud"
        Me.Hide()
    End Sub

    Private Sub LoadModelToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadModelToolStripMenuItem1.Click
        FiltersToolStripMenuItem.Enabled = True
        Form1.Show()
        Form1.CheckBox1.Checked = True
        Form1.GroupBox4.Visible = False
        Form1.GroupBox2.Visible = False
        Form1.GroupBox3.Text = "Select and load planar regression file"
        Form1.Button1.Text = "Select and load planar regression file"
        Form1.Button2.Text = "Accept and load planar regression file"
        Form1.Text = "Load planar regression"
    End Sub

    Private Sub PropeToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub OptionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OptionsToolStripMenuItem.Click
        Form10.Show()
        Me.Hide()
    End Sub

    Private Sub StereoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StereoToolStripMenuItem.Click
        Form17.Show()
        'Form13.Show()
        Me.Hide()
    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub ScanLineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanLineToolStripMenuItem.Click
        Form14.Show()
        Me.Hide()
    End Sub

    Private Sub ClusterAttributesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClusterAttributesToolStripMenuItem.Click
    End Sub

    Private Sub ColorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BlackWhiteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AboutProjecte120ToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutProjecte120ToolStripMenuItem.Click
        Form18.Show()
        Me.Hide()
    End Sub

    Private Sub PlanesProjectionOnALineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form19.Show()
        Me.Hide()
    End Sub
    Private Sub CreateMorphologyFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateMorphologyFileToolStripMenuItem.Click
        Form15.Show()
        Me.Hide()
    End Sub

    Private Sub PlanesPToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlanesPToolStripMenuItem.Click
        Form19.Show()
        Me.Hide()
    End Sub

    Private Sub GroupsProjectionToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ExportTotsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExportTotsToolStripMenuItem.Click
        exportts()
    End Sub

    Private Sub HelpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpToolStripMenuItem.Click
    End Sub

    Private Sub HelpPDFToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpPDFToolStripMenuItem.Click
        If My.Computer.FileSystem.DirectoryExists("C:\archivos de programa") = True Then
            For Each foundFile As String In My.Computer.FileSystem.GetFiles("C:\archivos de programa", FileIO.SearchOption.SearchAllSubDirectories, "AcroRD32.exe")
                Shell(foundFile + " " + My.Computer.FileSystem.CurrentDirectory + "\documentation\MANUAL PROJECTE120 VERSION 5_0_Eng.pdf", AppWinStyle.MaximizedFocus)
            Next
        End If
        If My.Computer.FileSystem.DirectoryExists("C:\program file") = True Then
            For Each foundFile As String In My.Computer.FileSystem.GetFiles("C:\program file", FileIO.SearchOption.SearchAllSubDirectories, "AcroRD32.exe")
                Shell(foundFile + " " + My.Computer.FileSystem.CurrentDirectory + "\documentation\MANUAL PROJECTE120 VERSION 5_0_Eng.pdf", AppWinStyle.MaximizedFocus)
            Next
        End If
        If My.Computer.FileSystem.DirectoryExists("C:\program file") = True Then
            For Each foundFile As String In My.Computer.FileSystem.GetFiles("C:\program file (x86)", FileIO.SearchOption.SearchAllSubDirectories, "AcroRD32.exe")
                Shell(foundFile + " " + My.Computer.FileSystem.CurrentDirectory + "\documentation\MANUAL PROJECTE120 VERSION 5_0_Eng.pdf", AppWinStyle.MaximizedFocus)
            Next
        End If
        If My.Computer.FileSystem.DirectoryExists("C:\program files (x86)") = True Then
            For Each foundFile As String In My.Computer.FileSystem.GetFiles("C:\program files (x86)", FileIO.SearchOption.SearchAllSubDirectories, "AcroRD32.exe")
                Shell(foundFile + " " + My.Computer.FileSystem.CurrentDirectory + "\documentation\MANUAL PROJECTE120 VERSION 5_0_Eng.pdf", AppWinStyle.MaximizedFocus)
            Next
        End If

    End Sub

    Private Sub AttributeProjectedOnAPlaneToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AttributeProjectedOnAPlaneToolStripMenuItem.Click
        Form20.Show()
        Me.Hide()
    End Sub

    Private Sub FilterMorphologyFilesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterMorphologyFilesToolStripMenuItem.Click
        Form21.Show()
        Me.Hide()
    End Sub

    Private Sub IndividualizeClusterFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub FromClusterToIndivualizedFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FromClusterToIndivualizedFileToolStripMenuItem.Click
        Form22.Show()
        Me.Hide()
    End Sub

    Private Sub MeasurementsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MeasurementsToolStripMenuItem.Click
        Form23.Show()
        Me.Hide()
    End Sub

    Private Sub FilterPointsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterPointsToolStripMenuItem.Click
        Form24.Show()
        Me.Hide()
    End Sub

    Private Sub CalculateDifferencesToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Form25.Show()
        Me.Hide()
    End Sub

    Private Sub FilterDifferencesFileToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilterDifferencesFileToolStripMenuItem.Click
        Form25.Show()
        Me.Hide()
    End Sub

    Private Sub ScaleToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScaleToolStripMenuItem.Click
        Form26.Show()
        Me.Hide()
    End Sub

    Private Sub MatchingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MatchingToolStripMenuItem.Click
        Match()
    End Sub

    Private Sub SpacingToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SpacingToolStripMenuItem.Click
        Form27.Show()
        Me.Hide()
    End Sub

    Private Sub FractureAbundanceMeasuresToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FractureAbundanceMeasuresToolStripMenuItem.Click
    
    End Sub

    Private Sub DistributionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DistributionsToolStripMenuItem.Click
        Distribution()

    End Sub

    Private Sub LASCCToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LASCCToolStripMenuItem.Click
        ReaderLAS()
    End Sub

    Private Sub RGBTOPointCloudToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RGBTOPointCloudToolStripMenuItem.Click
        PointCloudRGB()
    End Sub

    Private Sub FracturesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FracturesToolStripMenuItem.Click
        Form28.Show()
        Me.Hide()
    End Sub

    Private Sub MechanicalUnitsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MechanicalUnitsToolStripMenuItem.Click
        Form31.Show()
        Me.Hide()
    End Sub
End Class