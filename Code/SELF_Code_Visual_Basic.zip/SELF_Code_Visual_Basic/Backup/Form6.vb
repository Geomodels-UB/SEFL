Public Class Form6

    Dim infoReader As System.IO.FileInfo
    Dim openFileDialog4 As New OpenFileDialog()
    Dim openFileDialog5 As New OpenFileDialog()
    Dim file As String

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.openFileDialog4.InitialDirectory = Form10.TextBox1.Text
        Me.openFileDialog4.ShowDialog()
        On Error GoTo errorhandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Me.openFileDialog4.FileName)
Errorhandler:
        Exit Sub
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim px As Double
        Dim py As Double
        Dim pz As Double
        Dim iz As Double
        Dim jz As Double
        Dim kz As Double
        Dim oriz As Double
        Dim penz As Double
        Dim pint As Integer
        Dim pr As Integer
        Dim pg As Integer
        Dim pv As Integer
        Dim pm As Double
        Dim pk As Double
        Dim pn As Double
        Dim rug As Double
        Dim wei As Double
        Dim hei As Double
        Dim area As Double
        Dim fa As String = "sa"
        'afegit
        For Each file In Me.openFileDialog5.FileNames
            'FileOpen(1, file, OpenMode.Input)
            'fi afegit
            'solament xyz
            FileOpen(2, Me.openFileDialog4.FileName, OpenMode.Append)
            If RadioButton1.Checked = True And CheckBox3.Checked = True Then
                'afegit
                FileOpen(1, file, OpenMode.Input)
                'fi afegit
                'FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    'Form1.ProgressBar1.Value = ((numeropunts * 1800) / infoReader.Length)
                    PrintLine(2, px, py, pz)
                Loop
                FileClose(2)
            End If
            If RadioButton2.Checked = True And CheckBox3.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                ' FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, pint)
                    PrintLine(2, px, py, pz, pint)
                    ' Form1.ProgressBar1.Value = ((numeropunts * 1522) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            If RadioButton3.Checked = True And CheckBox3.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                'FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, pr)
                    Input(1, pg)
                    Input(1, pv)
                    PrintLine(2, px, py, pz, pr, pg, pv)
                    ' Form1.ProgressBar1.Value = ((numeropunts * 1522) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            If RadioButton1.Checked = True And CheckBox1.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                'FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, iz)
                    Input(1, jz)
                    Input(1, kz)
                    Input(1, oriz)
                    Input(1, penz)
                    Input(1, pm)
                    Input(1, pk)
                    Input(1, pn)
                    PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn)
                    'Form1.ProgressBar1.Value = ((numeropunts * 4285) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            If RadioButton2.Checked = True And CheckBox1.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                'FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, iz)
                    Input(1, jz)
                    Input(1, kz)
                    Input(1, oriz)
                    Input(1, penz)
                    Input(1, pm)
                    Input(1, pk)
                    Input(1, pn)
                    Input(1, pint)
                    PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pint)
                    'Form1.ProgressBar1.Value = ((numeropunts * 6550) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            If RadioButton3.Checked = True And CheckBox1.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                'FileOpen(1, Me.openFileDialog5.FileName, OpenMode.Input)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, iz)
                    Input(1, jz)
                    Input(1, kz)
                    Input(1, oriz)
                    Input(1, penz)
                    Input(1, pm)
                    Input(1, pk)
                    Input(1, pn)
                    Input(1, pr)
                    Input(1, pg)
                    Input(1, pv)
                    PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pr, pg, pv)
                    'Form1.ProgressBar1.Value = ((numeropunts * 3394) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            If CheckBox2.Checked = True Then
                FileOpen(1, file, OpenMode.Input)
                Input(1, fa)
                Do Until EOF(1)
                    Input(1, px)
                    Input(1, py)
                    Input(1, pz)
                    Input(1, iz)
                    Input(1, jz)
                    Input(1, kz)
                    Input(1, oriz)
                    Input(1, penz)
                    Input(1, pm)
                    Input(1, pk)
                    Input(1, pn)
                    Input(1, pr)
                    Input(1, rug)
                    Input(1, wei)
                    Input(1, hei)
                    Input(1, area)
                    Input(1, fa)
                    PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pr, rug, wei, hei, area, fa)
                    'Form1.ProgressBar1.Value = ((numeropunts * 3394) / infoReader.Length)
                Loop
                FileClose(2)
            End If
            FileClose(1)
        Next file
        MsgBox("Files Merged")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.openFileDialog5.InitialDirectory = Form10.TextBox1.Text
        Me.openFileDialog5.Multiselect = True
        Me.openFileDialog5.ShowDialog()
        On Error GoTo errorhandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Me.openFileDialog5.FileName)
Errorhandler:
        Exit Sub
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Form6_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            CheckBox1.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            CheckBox2.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            CheckBox1.Checked = False
            CheckBox2.Checked = False
        End If
    End Sub
End Class