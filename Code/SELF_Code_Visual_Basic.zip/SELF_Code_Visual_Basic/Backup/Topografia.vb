﻿Module Topografia
    Public contadomax2(,)
    Public refer2()()() As Integer
    Public difetopo() As Double
    Sub llegirpuntstopografia()
        Dim e As String = "a"
        Dim a As Double
        Dim b As Double
        Dim c As Double
        Dim d As Double
        Dim vec1 As Double
        Dim vec2 As Double
        Dim vec3 As Double
        Dim numero As Integer
        Dim n As Integer
        Dim param As Double

        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form1.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form1.OpenFileDialog1.ShowDialog()
        ' If user = DialogResult.Cancel Then openFileDialog1.
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form1.OpenFileDialog1.FileName)
        'MsgBox("File is " & infoReader.Length & " bytes.")
        FileOpen(1, Form1.OpenFileDialog1.FileName, OpenMode.Input)
        numeropunts = -1
        'solament xyz
        If Form24.RadioButton1.Checked Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                Form24.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 27.5))) * 50
            Loop
        End If
        If Form24.RadioButton2.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                Form24.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 30.5))) * 50
            Loop
        End If
        If Form24.RadioButton3.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                Form24.ProgressBar1.Value = (((numeropunts) / (infoReader.Length / 37.5))) * 50
            Loop
        End If
        FileClose(1)
        ReDim Preserve x(numeropunts)
        ReDim Preserve y(numeropunts)
        ReDim Preserve z(numeropunts)
        ReDim Preserve inten(numeropunts)
        ReDim Preserve R(numeropunts)
        ReDim Preserve G(numeropunts)
        ReDim Preserve V(numeropunts)
        ReDim Preserve difetopo(numeropunts)
        'ReDim Preserve vect1(numeropunts)
        'ReDim Preserve vect2(numeropunts)
        'ReDim Preserve vect3(numeropunts)
        'ReDim Preserve orientacio(numeropunts)
        'ReDim Preserve pendent(numeropunts)
        'ReDim Preserve bprop3(numeropunts)
        'ReDim Preserve bkapa(numeropunts)
        'ReDim Preserve bseleccio(numeropunts)
        'ReDim Preserve apte(numeropunts)

        'MsgBox(numeropunts)
        FileOpen(1, Form1.OpenFileDialog1.FileName, OpenMode.Input)
        numero = numeropunts
        numeropunts = -1
        If Form24.RadioButton1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                'afegit
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                If Form24.CheckBox2.Checked = True Then
                    position3 = InStrRev(e, " ", position2 - 1)
                    x(numeropunts) = e.Substring(0, position3)
                    y(numeropunts) = e.Substring(position3, position2 - position3)
                    z(numeropunts) = e.Substring(position2, position1 - position2)
                    difetopo(numeropunts) = e.Substring(position1, e.Length - position1)
                Else
                    x(numeropunts) = e.Substring(0, position2)
                    y(numeropunts) = e.Substring(position2, position1 - position2)
                    z(numeropunts) = e.Substring(position1, e.Length - position1)
                End If
                Form24.ProgressBar1.Value = 0.5 + ((numeropunts * 50) / numero) + 50
            Loop
        End If
        If Form24.RadioButton2.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                'e = LineInput(1)
                'position1 = InStrRev(e, " ")
                'position2 = InStrRev(e, " ", position1 - 1)
                'position3 = InStrRev(e, " ", position2 - 1)
                'x(numeropunts) = e.Substring(0, position3)
                'y(numeropunts) = e.Substring(position3, position2 - position3)
                'z(numeropunts) = e.Substring(position2, position1 - position2)
                'inten(numeropunts) = e.Substring(position1, e.Length - position1)
                '***************inici alternativa
                e = LineInput(1)


                If Form24.CheckBox2.Checked = True Then
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    difetopo(numeropunts) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                End If
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                inten(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                y(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                x(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                '***************final alternativa
                Form24.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        If Form24.RadioButton3.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                e = LineInput(1)
                If Form24.CheckBox2.Checked = True Then
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    difetopo(numeropunts) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                End If
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                V(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                G(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                R(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                z(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                y(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                x(numeropunts) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                '***************final alternativa


                'position1 = InStrRev(e, " ")
                ' position2 = InStrRev(e, " ", position1 - 1)
                ' position3 = InStrRev(e, " ", position2 - 1)
                ' position4 = InStrRev(e, " ", position3 - 1)
                ' position5 = InStrRev(e, " ", position4 - 1)
                ' x(numeropunts) = e.Substring(0, position5)
                ' y(numeropunts) = e.Substring(position5, position4 - position5)
                ' z(numeropunts) = e.Substring(position4, position3 - position4)
                ' R(numeropunts) = e.Substring(position3, position2 - position3)
                ' G(numeropunts) = e.Substring(position2, position1 - position2)
                ' V(numeropunts) = e.Substring(position1, e.Length - position1)
                Form24.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
            Loop
        End If
        FileClose(1)
        Form24.Label2.Text = numeropunts
        dimensionarmodeltopografic()
        Exit Sub
ErrorHandler:

    End Sub
    Sub dimensionarmodeltopografic()
        Dim n As Integer
        'Dim maxx As Double
        'Dim maxy As Double
        'Dim maxz As Double
        redux = (1 / Form24.NumericUpDown1.Value)
        reduy = (1 / Form24.NumericUpDown1.Value)
        For n = 0 To (x.Length - 1)
            If n = 0 Then
                maxx = x(n)
                maxy = y(n)
                maxz = z(n)
                minx = x(n)
                miny = y(n)
                minz = z(n)
            Else
                If x(n) >= maxx Then maxx = x(n)
                If x(n) <= minx Then minx = x(n)
                If y(n) >= maxy Then maxy = y(n)
                If y(n) <= miny Then miny = y(n)
                If z(n) >= maxz Then maxz = z(n)
                If z(n) <= minz Then minz = z(n)
            End If
        Next n
        amplex = Int(((maxx - minx) * redux) + 1)
        ampley = Int(((maxy - miny) * reduy) + 1)
        'amplez = Int(((maxz - minz) * reduz) + 1)
        Form24.Label17.Text = maxx - minx
        Form24.Label18.Text = maxy - miny
        'Form24.Label19.Text = maxz - minz
        mult = amplex * ampley
        Form24.Label8.Text = amplex
        Form24.Label9.Text = ampley
        'Form24.Label10.Text = amplez
        Form24.Label12.Text = mult
        'Form24.Label21.Text = x.Length
    End Sub
    Sub carregarmodeltopografic()
        Dim ad As Integer
        Dim d As Integer
        Dim AA As Double
        Dim BB As Double
        ' Dim CC As Double
        ReDim contadomax2(amplex, ampley)
        ReDim refer2(amplex)
        For ad = 0 To amplex
            refer2(ad) = New Integer(ampley)() {}
        Next ad
        ad = 0
        ' For d = 0 To numeropunts
        For d = 0 To (x.Length - 1)
            AA = x(d) - minx
            AA = Int(AA * redux)
            BB = y(d) - miny
            BB = Int(BB * reduy)
            'CC = z(d) - minz
            'CC = Int((Int(CC)) * redu)
            ' Número de centroides per cada voxel Refer(x,y,z)
            contadomax2(AA, BB) = contadomax2(AA, BB) + 1
            ad = contadomax2(AA, BB)
            ReDim Preserve refer2(AA)(BB)(ad - 1)
            refer2(AA)(BB)(ad - 1) = d
        Next d
        MsgBox("Coarse Block Loaded")
        Form24.GroupBox3.Enabled = True
        Form24.GroupBox4.Enabled = True
        Form24.GroupBox5.Enabled = True
    End Sub
    Sub filtrarztopografic()
        Dim d As Integer
        Dim coorzminim As Double
        Dim puntsfinal As Double
        Dim tot As Integer
        FileOpen(1, Form10.TextBox1.Text + "Topographyparamenter.txt", OpenMode.Output)
        If Form24.RadioButton4.Checked = True Then
            For AA = 0 To amplex
                For BB = 0 To ampley
                    If contadomax2(AA, BB) <> Nothing Then
                        For ad = 1 To contadomax2(AA, BB)
                            d = refer2(AA)(BB)(ad - 1)
                            If ad = 1 Then
                                coorzminim = d
                            Else
                                If z(d) < z(coorzminim) Then coorzminim = d
                            End If
                        Next ad
                        If Form24.RadioButton1.Checked = True Then
                            PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton2.Checked = True Then
                            PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim), inten(coorzminim))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton3.Checked = True Then
                            PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim), R(coorzminim), G(coorzminim), V(coorzminim))
                            puntsfinal = puntsfinal + 1
                        End If
                    End If
                Next BB
            Next AA
        End If
        Dim meanx As Double = 0
        Dim meany As Double = 0
        Dim meanz As Double = 0
        If Form24.RadioButton8.Checked = True Then
            For AA = 0 To amplex
                For BB = 0 To ampley
                    If contadomax2(AA, BB) <> Nothing Then
                        For ad = 1 To contadomax2(AA, BB)
                            d = refer2(AA)(BB)(ad - 1)
                            meanx = meanx + x(d)
                            meany = meany + y(d)
                            meanz = meanz + z(d)
                            If ad = contadomax2(AA, BB) Then
                                meanx = meanx / ad
                                meany = meany / ad
                                meanz = meanz / ad
                            End If
                        Next ad
                        If Form24.RadioButton1.Checked = True Then
                            PrintLine(1, Format(meanx, "##.##"), Format(meany, "##.##"), Format(meanz, "##.##"))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton2.Checked = True Then
                            PrintLine(1, meanx, meany, meanz, inten(d))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton3.Checked = True Then
                            PrintLine(1, meanx, meany, meanz, R(d), G(d), V(d))
                            puntsfinal = puntsfinal + 1
                        End If
                    End If
                Next BB
            Next AA
        End If
        FileClose(1)
        tot = ((puntsfinal * 100) / numeropunts)
        MsgBox("Process Completed")
    End Sub
    Sub pendentstopografia()
        Dim cont As Integer
        Dim pap As Double
        Dim esp As Double
        Dim difx As Double
        Dim dify As Double
        Dim eixx As Integer : Dim eixy As Integer
        Dim eixx2 As Integer : Dim eixy2 As Integer
        Dim ac As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim porc As Integer
        esp = Int(Form24.NumericUpDown1.Value) + 1
        FileOpen(1, Form10.TextBox1.Text + "Topographyslope.txt", OpenMode.Output)
        'copiada
        ac = 0
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                ' Número de punts per cada voxel Refer(x,y,z)
                If contadomax2(eixx, eixy) <> Nothing Then  'Si hi han punts al voxel busca continuïtat
                    ab = contadomax2(eixx, eixy) 'numero de centroides al voxel
                    For l = 1 To ab
                        n = refer2(eixx)(eixy)(l - 1) 'aqui tenim la referencia del primer punt
                        ' ara s´han de buscar tots els del voltant
                        cont = 0
                        For difx = -esp To esp
                            eixx2 = eixx + difx
                            If eixx2 < 0 Or eixx2 > amplex Then GoTo line40
                            For dify = -esp To esp
                                eixy2 = eixy + dify
                                If eixy2 < 0 Or eixy2 > ampley Then GoTo line30
                                If contadomax2(eixx2, eixy2) Then
                                    ad = contadomax2(eixx2, eixy2)
                                    For l2 = 1 To ad
                                        m = refer2(eixx2)(eixy2)(l2 - 1)
                                        'Cumpleix la distància?
                                        pap = Math.Sqrt(Math.Pow(x(n) - x(m), 2) + Math.Pow(y(n) - y(m), 2) + Math.Pow(z(n) - z(m), 2))
                                        If pap < Form24.NumericUpDown3.Value And pap <> 0 Then
                                            ' calcul del vector
                                            A = x(n) - x(m)
                                            B = y(n) - y(m)
                                            C = z(n) - z(m)
                                            'Calcular orientacio i pendent a la funció
                                            If (90 - calculpendent()) < Form24.NumericUpDown2.Value Then
                                                cont = cont + 1
                                                If cont = Form24.NumericUpDown4.Value Then
                                                    If Form24.RadioButton1.Checked = True Then
                                                        PrintLine(1, x(n), y(n), z(n))
                                                    End If
                                                    If Form24.RadioButton2.Checked = True Then
                                                        PrintLine(1, x(n), y(n), z(n), inten(n))
                                                    End If
                                                    If Form24.RadioButton3.Checked = True Then
                                                        PrintLine(1, x(n), y(n), z(n), R(n), G(n), V(n))
                                                    End If

                                                    l2 = ad : difx = esp : dify = esp : l = ab : cont = 0
                                                End If 'de cont
                                            End If 'de calclpendent
                                        End If ' de pap
                                    Next l2
                                End If
line30:                     Next dify
line40:                 Next difx
                    Next l
                End If
            Next eixy
        Next eixx
        FileClose(1)
        porc = (cont * 100) / numeropunts
        MsgBox("Process Completed")
        Form24.GroupBox3.Enabled = True
        Form24.GroupBox4.Enabled = True
    End Sub
    Sub differencestopografic()
        Dim intena As Integer
        Dim ra, ga, va As Integer
        Dim xa, ya, za As Double
        Dim xf, yf, zf As Double
        Dim cont As Integer
        Dim pap As Double
        Dim pep As Double
        Dim esp As Double
        Dim difx As Double
        Dim dify As Double
        Dim xx As Double : Dim yy As Double
        Dim eixx As Integer : Dim eixy As Integer
        Dim eixx2 As Integer : Dim eixy2 As Integer
        Dim ac As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim porc As Integer
        Dim positiu As Integer
        Dim distanciaminima As Double
        Dim recordminim As Double
        Dim selects As Integer

        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form1.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form1.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form1.OpenFileDialog1.FileName)
        FileOpen(2, Form1.OpenFileDialog1.FileName, OpenMode.Input)

        esp = Int(Form24.NumericUpDown5.Value) + 1
        FileOpen(1, Form10.TextBox1.Text + "Differences.txt", OpenMode.Output)

        '****inici

        Do Until EOF(2)
            If Form24.RadioButton1.Checked = True Then
                positiu = 0
                e = LineInput(2)
                e = Trim(e) : position1 = InStrRev(e, " ")
                za = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ya = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                xa = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If

            If Form24.RadioButton2.Checked = True Then
                positiu = 0
                e = LineInput(2)
                e = Trim(e) : position1 = InStrRev(e, " ")
                intena = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                za = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ya = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                xa = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If

            If Form24.RadioButton3.Checked = True Then
                positiu = 0
                e = LineInput(2)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                va = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ga = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ra = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                za = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ya = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                xa = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            '* Primer s'ha de buscar el voxel de cada punt del fitxer obert
            If xa > maxx Or xa < minx Or ya > maxy Or ya < miny Then GoTo line50
            xx = xa - minx
            eixx = Int(xx * redux)
            yy = ya - miny
            eixy = Int(yy * reduy)
            pep = 0
            'distanciaminima = Form24.NumericUpDown5.Value
            ac = 0
            'If xa > maxx Or xa < minx Or ya > maxy Or ya < miny Then GoTo line50
            'For eixx = 0 To amplex                                                                  '*************eliminar
            'For eixy = 0 To ampley                                                                  '*************eliminar
            ' Número de punts per cada voxel Refer(x,y,z)
            If contadomax2(eixx, eixy) <> Nothing Then  'Si hi han punts al voxel busca continuïtat  
                ab = contadomax2(eixx, eixy) 'numero de centroides al voxel                          
                'For l = 1 To ab                                                                      '*************eliminar
                'n = refer2(eixx)(eixy)(l - 1) 'aqui tenim la referencia del primer punt          '*************eliminar
                ' ara s´han de buscar tots els del voltant
                cont = 0                                                                         '*************eliminar
                For difx = -esp To esp
                    eixx2 = eixx + difx
                    If eixx2 < 0 Or eixx2 > amplex Then GoTo line40
                    For dify = -esp To esp
                        eixy2 = eixy + dify
                        If eixy2 < 0 Or eixy2 > ampley Then GoTo line30
                        If contadomax2(eixx2, eixy2) <> Nothing Then
                            ad = contadomax2(eixx2, eixy2)
                            For l2 = 1 To ad
                                m = refer2(eixx2)(eixy2)(l2 - 1)
                                'Cumpleix la distància?
                                pap = Math.Sqrt(Math.Pow(xa - x(m), 2) + Math.Pow(ya - y(m), 2))
                                If pap <= Form24.NumericUpDown5.Value And pap <> 0 Then
                                    pep = za - z(m)
                                    If cont = 0 Then
                                        recordminim = pap
                                        selects = m
                                        cont = 1
                                        If Form24.CheckBox1.Checked = True Then
                                            If pep < Form24.NumericUpDown6.Value And pep > Form24.NumericUpDown7.Value Then
                                                xf = xa
                                                yf = ya
                                                zf = za
                                                pep = za - z(m)
                                                positiu = 1
                                            End If
                                        Else
                                            xf = xa
                                            yf = ya
                                            zf = za
                                            pep = za - z(m)
                                            positiu = 1
                                        End If
                                    Else
                                        If pap < recordminim Then recordminim = pap
                                        selects = m
                                        If Form24.CheckBox1.Checked = True Then
                                            If pep < Form24.NumericUpDown6.Value And pep > Form24.NumericUpDown7.Value Then
                                                xf = xa
                                                yf = ya
                                                zf = za
                                                pep = za - z(m)
                                                positiu = 1
                                            End If
                                        Else
                                            xf = xa
                                            yf = ya
                                            zf = za
                                            pep = za - z(m)
                                            positiu = 1
                                        End If
                                    End If
                                End If
                            Next l2
                        End If
line30:             Next dify
line40:         Next difx
                'Next l
            End If
            ' Next eixy
            ' Next eixx
            If positiu = 1 Then
                If Form24.RadioButton7.Checked = True Then
                    PrintLine(1, xf, yf, zf, Format(pep, "#.#####"))
                End If
                If Form24.RadioButton6.Checked = True Then
                    PrintLine(1, xf, yf, zf, intena, Format(pep, "#.#####"))
                End If
                If Form24.RadioButton5.Checked = True Then
                    PrintLine(1, xf, yf, zf, ra, ga, va, Format(pep, "#.#####"))
                End If
            End If
line50: Loop
        FileClose(1)
        FileClose(2)
        porc = (cont * 100) / numeropunts
        MsgBox("Process Completed")
        Form24.GroupBox3.Enabled = True
        Form24.GroupBox4.Enabled = True
        Exit Sub
ErrorHandler:
    End Sub
    Sub filtrartopo()
        Dim differfilter As Double
        Dim clau As Boolean
        Dim intena As Integer
        Dim ra, ga, va As Integer
        Dim xa, ya, za As Double
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form1.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form1.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form1.OpenFileDialog1.FileName)
        FileOpen(1, Form1.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "Differencesfilter.txt", OpenMode.Output)
        FileOpen(3, Form10.TextBox1.Text + "Differencesfilter2.txt", OpenMode.Output)

        Do Until EOF(1)
            numeropunts = numeropunts + 1
            e = LineInput(1)
            e = Trim(e) : position1 = InStrRev(e, " ")
            differfilter = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            If Form25.RadioButton2.Checked = True Then
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                intena = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            If Form25.RadioButton3.Checked = True Then
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                va = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ga = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                ra = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            za = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            ya = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            xa = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            If differfilter = Nothing Then differfilter = 0.01
            Select Case Form25.CheckBox2.Checked
                Case False
                    If differfilter < Form25.NumericUpDown6.Value And differfilter > Form25.NumericUpDown7.Value Then
                        clau = True
                    End If
                Case True
                    If differfilter > Form25.NumericUpDown6.Value Or differfilter < Form25.NumericUpDown7.Value Then
                        clau = True
                    End If
            End Select
            'If differfilter < Form25.NumericUpDown6.Value And differfilter > Form25.NumericUpDown7.Value Then
            If clau = True Then
                clau = False
                If Form25.RadioButton1.Checked = True Then
                    If Form25.CheckBox1.Checked = True Then
                        PrintLine(2, xa, ya, Format(differfilter, "#.####"))
                        PrintLine(3, xa, ya, "0.00")
                    Else
                        PrintLine(2, xa, ya, za, Format(differfilter, "#.####"))
                    End If
                End If
                If Form25.RadioButton2.Checked = True Then
                    If Form25.CheckBox1.Checked = True Then
                        PrintLine(2, xa, ya, Format(differfilter, "#.####"))
                        PrintLine(3, xa, ya, "0.00")
                    Else
                        PrintLine(2, xa, ya, za, intena, Format(differfilter, "#.####"))
                    End If
                End If
                If Form25.RadioButton3.Checked = True Then
                    If Form25.CheckBox1.Checked = True Then
                        PrintLine(2, xa, ya, Format(differfilter, "#.####"))
                        PrintLine(3, xa, ya, "0.00")
                    Else
                        PrintLine(2, xa, ya, za, ra, ga, va, Format(differfilter, "#.####"))
                    End If
                End If
            End If
        Loop
        MsgBox("Process Completed")
        FileClose(1)
        FileClose(2)
        FileClose(3)
        Exit Sub
ErrorHandler:
    End Sub
    Sub filtrarztopografic2()
        Dim d As Integer
        ' Dim coorzminim As Double
        Dim puntsfinal As Double
        Dim tot As Integer
        FileOpen(1, Form10.TextBox1.Text + "Topographyparamenter.txt", OpenMode.Output)
        If Form24.RadioButton4.Checked = True Then
            For AA = 0 To amplex
                For BB = 0 To ampley
                    If contadomax2(AA, BB) <> Nothing Then
                        Dim dif As Double
                        Dim zmed As Double = 0
                        Dim zmed1(contadomax2(AA, BB) - 1) As Double
                        Dim zmed2(contadomax2(AA, BB) - 1) As Double
                        For ad = 1 To contadomax2(AA, BB)
                            d = refer2(AA)(BB)(ad - 1)
                            Select Case z(d)
                                Case Form24.NumericUpDown9.Value To Form24.NumericUpDown8.Value
                                    zmed1(ad - 1) = z(d)
                                    zmed = z(d) + zmed
                                Case Else

                            End Select

                        Next ad
                        'comprobació
                        Array.Copy(zmed1, zmed2, zmed1.Count)
                        Array.Sort(zmed2)
                        For ad = 0 To contadomax2(AA, BB) - 1
                            dif = (zmed2(ad) - zmed2.Average)
                            Select Case dif
                                Case -Form24.NumericUpDown10.Value To Form24.NumericUpDown10.Value

                                Case Else
                                    zmed2(ad) = zmed2.Average
                            End Select

                        Next ad

                        'fi comprobació
                        zmed = zmed2.Average
                        For ad = 1 To contadomax2(AA, BB)
                            If z(refer2(AA)(BB)(ad - 1)) < (zmed + Form24.NumericUpDown11.Value) Then
                                If z(refer2(AA)(BB)(ad - 1)) > (zmed - Form24.NumericUpDown11.Value) Then
                                    PrintLine(1, x(refer2(AA)(BB)(ad - 1)), y(refer2(AA)(BB)(ad - 1)), z(refer2(AA)(BB)(ad - 1)), inten(refer2(AA)(BB)(ad - 1)))
                                End If
                            End If
                        Next ad
                        ' If Form24.RadioButton1.Checked = True Then
                        ' PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim))
                        ' puntsfinal = puntsfinal + 1
                        ' End If
                        ' If Form24.RadioButton2.Checked = True Then
                        ' PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim), inten(coorzminim))
                        ' puntsfinal = puntsfinal + 1
                        ' End If
                        ' If Form24.RadioButton3.Checked = True Then
                        ' PrintLine(1, x(coorzminim), y(coorzminim), z(coorzminim), R(coorzminim), G(coorzminim), V(coorzminim))
                        '  puntsfinal = puntsfinal + 1
                        ' End If
                    End If
                Next BB
            Next AA
        End If
        Dim meanx As Double = 0
        Dim meany As Double = 0
        Dim meanz As Double = 0
        If Form24.RadioButton8.Checked = True Then
            For AA = 0 To amplex
                For BB = 0 To ampley
                    If contadomax2(AA, BB) <> Nothing Then
                        For ad = 1 To contadomax2(AA, BB)
                            d = refer2(AA)(BB)(ad - 1)
                            meanx = meanx + x(d)
                            meany = meany + y(d)
                            meanz = meanz + z(d)
                            If ad = contadomax2(AA, BB) Then
                                meanx = meanx / ad
                                meany = meany / ad
                                meanz = meanz / ad
                            End If
                        Next ad
                        If Form24.RadioButton1.Checked = True Then
                            PrintLine(1, Format(meanx, "##.##"), Format(meany, "##.##"), Format(meanz, "##.##"))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton2.Checked = True Then
                            PrintLine(1, meanx, meany, meanz, inten(d))
                            puntsfinal = puntsfinal + 1
                        End If
                        If Form24.RadioButton3.Checked = True Then
                            PrintLine(1, meanx, meany, meanz, R(d), G(d), V(d))
                            puntsfinal = puntsfinal + 1
                        End If
                    End If
                Next BB
            Next AA
        End If
        FileClose(1)
        tot = ((puntsfinal * 100) / numeropunts)
        MsgBox("Process Completed")
    End Sub
End Module
