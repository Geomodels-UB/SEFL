Module Module2
    Public puntcontactex(), puntcontactey(), puntcontactez() As Double
    Public t As Double
    Public puntorigen(6) As Double
    Public rfile As String
    Dim at As Double
    Dim bt As Double
    Dim ct As Double
    Sub Autotracking()

        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim pap As Double
        Dim pep As Double
        Dim puntx As Double
        Dim punty As Double
        Dim puntz As Double
        Dim escollit As Integer
        Dim puntsacceptats As Integer
        Dim ordretracking() As Integer
        Dim ddd As Integer
        Dim asa As Integer
        Dim espx As Integer
        Dim espy As Integer
        Dim espz As Integer
        Dim primera As Integer
        Dim response As MsgBoxResult
        Dim sumatorivect1 As Double
        Dim sumatorivect2 As Double
        Dim sumatorivect3 As Double
        Dim resultvect1 As Double
        Dim resultvect2 As Double
        Dim resultvect3 As Double
        Dim resultatvect1 As Double
        Dim resultatvect2 As Double
        Dim resultatvect3 As Double
        Dim sumadesvstan1 As Double
        Dim sumadesvstan2 As Double
        Dim sumadesvstan3 As Double
        Dim desvstan1 As Double
        Dim desvstan2 As Double
        Dim desvstan3 As Double
        Dim ruta As String
        'No esta activat per Dip Direction and Dip

        'No hi ha cap ocupat

        For asa = 1 To numeropunts
            apte(asa) = False
        Next asa

        'Llegeix el punt original

        FileOpen(1, "C:\Dades\Projecte100\autotracking.txt", OpenMode.Input)
        Input(1, puntx)
        Input(1, punty)
        Input(1, puntz)
        FileClose(1)

        ' Obre el fitxer per enmagatzemar els punts

        FileOpen(1, Form10.TextBox1.Text + "autotracking.txt", OpenMode.Output)

        'Busca el voxel
        primera = 1
        eixx = puntx - minx
        eixx = Int(eixx * redux)
        eixy = punty - miny
        eixy = Int(eixy * reduy)
        eixz = puntz - minz
        eixz = Int(eixz * reduz)

        'Busca el punt m�s proper
        esp = Int(Form5.NumericUpDown10.Value) + 1
        espx = esp / Form1.NumericUpDown1.Value
        espy = esp / Form1.NumericUpDown1.Value
        espz = esp / Form1.NumericUpDown1.Value
        For difx = -espx To espx
            eixx = eixx + difx
            If eixx < 0 Or eixx > amplex Then GoTo 3
            For dify = -espy To espy
                eixy = eixy + dify
                If eixy < 0 Or eixy > ampley Then GoTo 2
                For difz = -espz To espz
                    eixz = eixz + difz
                    If eixz < 0 Or eixz > amplez Then GoTo 1
                    If contadomax(eixx)(eixy)(eixz) = Nothing Then GoTo 1
                    ab = contadomax(eixx)(eixy)(eixz) ' ab es el n�mero de punts 
                    For l = 1 To ab
                        n = refer(eixx)(eixy)(eixz)(l - 1) 'primer centroide
                        pap = Math.Sqrt(((x(n) - puntx) ^ 2) + ((y(n) - punty) ^ 2) + ((z(n) - puntz) ^ 2))
                        If primera = 1 Then pap = pep
                        primera = 2
                        If pap <= pep Then escollit = ab
                    Next l
1:              Next difz
2:          Next dify
3:      Next difx

        'punt escollit com el m�s proper

        n = refer(eixx)(eixy)(eixz)(escollit - 1) ' centroide escollit com a punt original
        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))

        puntsacceptats = 1
        apte(n) = True
        ReDim Preserve ordretracking(puntsacceptats)
        ordretracking(puntsacceptats) = n

        'informa del vector escollit

        response = MsgBox("Normal Vector " & Chr(13) & "i: " & vect1(n) & Chr(13) & "j: " & vect2(n) & Chr(13) & "k: " & vect3(n) & Chr(13) & "Azimuth: " & orientacio(n) & Chr(13) & "Dip: " & pendent(n) & Chr(13) & "M: " & bprop3(n) & Chr(13) & "K: " & bkapa(n), MsgBoxStyle.OkCancel, "Autotracking")
        If response = MsgBoxResult.Ok Then
            ddd = 0
        Else : GoTo 50
        End If

        'Busca els del voltant

5:      ddd = ddd + 1
        n = ordretracking(ddd)

        eixx = x(n) - minx
        eixx = Int(eixx * redux)
        eixy = y(n) - miny
        eixy = Int(eixy * reduy)
        eixz = z(n) - minz
        eixz = Int(eixz * reduz)

        For difx = -espx To espx 'esp, en funci� de la dist�ncia mira els voxels propers
            eixx2 = eixx + difx
            If eixx2 < 0 Or eixx2 > amplex Then GoTo 40 'si arriba al final
            For dify = -espy To espy
                eixy2 = eixy + dify
                If eixy2 < 0 Or eixy2 > ampley Then GoTo 30 'si arriba al final
                For difz = -espz To espz
                    eixz2 = eixz + difz
                    If eixz2 < 0 Or eixz2 > amplez Then GoTo 20 'si arriba al final
                    If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                        ad = contadomax(eixx2)(eixy2)(eixz2)
                        For l2 = 1 To ad
                            m = refer(eixx2)(eixy2)(eixz2)(l2 - 1)
                            If apte(m) = True Then GoTo 10
                            pep = Math.Acos(Math.Abs(((vect1(n) * vect1(m)) + (vect2(n) * vect2(m)) + (vect3(n) * vect3(m))) / (Math.Sqrt((vect1(m) ^ 2) + (vect2(m) ^ 2) + (vect3(m) ^ 2))) * (Math.Sqrt((vect1(n) ^ 2) + (vect2(n) ^ 2) + (vect3(n) ^ 2)))))
                            pep = (pep * 180) / Math.PI
                            'Es calcula el producte vectorial
                            If pep <= Form5.NumericUpDown3.Value Then 'Es mira si cumpleix l'angle
                                ' Es calcula la dist�ncia
                                pap = Math.Sqrt(((x(n) - x(m)) ^ 2) + ((y(n) - y(m)) ^ 2) + ((z(n) - z(m)) ^ 2))
                                If pap < Form5.NumericUpDown10.Value And pap <> 0 Then 'Es comprova la dist�ncia
                                    If bprop3(n) > Form5.NumericUpDown4.Value And bprop3(n) < Form5.NumericUpDown5.Value Then 'Es comprova la M
                                        If bkapa(n) > Form5.NumericUpDown6.Value And bkapa(n) < Form5.NumericUpDown7.Value Then 'Es comprova la K
                                            If bseleccio(n) >= Form5.NumericUpDown8.Value And bseleccio(n) < Form5.NumericUpDown9.Value Then 'Es comprova la n
                                                puntsacceptats = puntsacceptats + 1
                                                'If puntsacceptats = Form5.NumericUpDown11.Value Then
                                                apte(m) = True
                                                ReDim Preserve ordretracking(puntsacceptats)
                                                ordretracking(puntsacceptats) = m
                                                If Form5.CheckBox4.Checked = True Then
                                                    If Form5.NumericUpDown12.Value < Math.Sqrt(((puntx - x(m)) ^ 2) + ((punty - y(m)) ^ 2) + ((puntz - z(m)) ^ 2)) Then
                                                        GoTo 10
                                                    End If
                                                End If
                                                If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                                                If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))
                                                If Form5.CheckBox3.Checked = True And puntsacceptats = Form5.NumericUpDown11.Value Then
                                                    response = MsgBox("Continued?", MsgBoxStyle.OkCancel, "Autotracking limit")
                                                    If response = MsgBoxResult.Cancel Then
                                                        l2 = ad : difz = espz : dify = espy : difx = espx : ddd = puntsacceptats
                                                    End If
                                                End If
                                            End If 'bseleccio
                                        End If 'bkapa
                                    End If 'bprop3
                                End If 'pap
                            End If 'pep
10:                     Next l2
                    End If
20:             Next difz
30:         Next dify
40:     Next difx
        Form5.ProgressBar1.Value = (ddd * 100) / puntsacceptats
        If ddd < puntsacceptats Then GoTo 5

        'Calcular estad�stiques
        For l = 1 To puntsacceptats
            n = ordretracking(l)
            sumatorivect1 = sumatorivect1 + vect1(n)
            sumatorivect2 = sumatorivect2 + vect2(n)
            sumatorivect3 = sumatorivect2 + vect3(n)
        Next l
        resultvect1 = sumatorivect1 / puntsacceptats
        resultvect2 = sumatorivect2 / puntsacceptats
        resultvect3 = sumatorivect3 / puntsacceptats

        For l = 1 To puntsacceptats
            n = ordretracking(l)
            sumadesvstan1 = (resultatvect1 - vect1(n)) ^ 2
            sumadesvstan2 = (resultatvect2 - vect2(n)) ^ 2
            sumadesvstan3 = (resultatvect3 - vect3(n)) ^ 2
        Next l
        desvstan1 = Math.Sqrt(sumadesvstan1 / puntsacceptats)
        desvstan2 = Math.Sqrt(sumadesvstan2 / puntsacceptats)
        desvstan3 = Math.Sqrt(sumadesvstan3 / puntsacceptats)

        response = MsgBox("i = " & resultvect1 & " desv: " & desvstan1 & Chr(13) & "j = " & resultvect2 & " desv: " & desvstan2 & Chr(13) & "k = " & resultvect3 & " desv: " & desvstan3 & Chr(13) & "             N�mero de punts: " & puntsacceptats, MsgBoxStyle.OkCancel, "Resultats de l'Autotracking")
        If response = MsgBoxResult.Ok Then
            ruta = Form10.TextBox1.Text + "Autotracking" + Str(ac) + ".txt"
            FileOpen(2, ruta, OpenMode.Output)
            For l = 1 To puntsacceptats
                m = ordretracking(l)
                If Form1.RadioButton1.Checked = True Then PrintLine(2, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                If Form1.RadioButton2.Checked = True Then PrintLine(2, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                If Form1.RadioButton3.Checked = True Then PrintLine(2, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))

            Next l
            FileClose(2)
            ac = ac + 1
        End If
50:     FileClose(1)
        'MsgBox("Acabat Autotracking")
    End Sub

    Sub savclusters()
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim eixx3 As Double : Dim eixy3 As Double : Dim eixz3 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim pap As Double
        Dim puntsacceptats As Integer
        Dim item As Integer
        Dim cluster() As Integer
        Dim maxp As Integer
        Dim ac As Integer
        Dim pep As Double
        Dim pip As Double
        maxp = 0
        ' La idea es identificar un punt i comen�ar a buscar punts al seu 
        ' voltant, si l'identifica es marca com escollit i continua
        puntsacceptats = 0
        item = 1 'primer cluster
        ac = 0
        esp = Int(Form7.NumericUpDown1.Value) + 1 'dist�ncia m�xima de b�squeda
        'esp = 0.5 + 1 'dist�ncia m�xima de b�squeda
        FileOpen(1, Form10.TextBox1.Text + "clusters.txt", OpenMode.Output) 'sortida
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' N�mero de centroides en el primer voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then ' si hi han centroides, veure quants s�n
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides
                        For l = 1 To ab
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim el primer centroide
                            'comprovaci� de que estigui lliure
                            If apte(n) = True Then GoTo 50
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 40
                                For dify = -esp To esp
                                    eixy2 = eixy + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 30
                                    For difz = -esp To esp
                                        eixz2 = eixz + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 20
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1) 'punts al voltant 
                                                'comprovacio de punt ja utilitzat
                                                If apte(m) = True Then GoTo 20
                                                'comen�a amb els angles (2 if)
                                                pep = Math.Sqrt(Math.Pow(orientacio(n) - orientacio(m), 2))
                                                If pep > 180 Then pep = 360 - pep
                                                If pep <= Form7.NumericUpDown2.Value Then
                                                    pip = Math.Sqrt(Math.Pow(pendent(n) - pendent(m), 2))
                                                    If pip <= Form7.NumericUpDown3.Value Then
                                                        'acava els angles
                                                        'comen�a les distancies
                                                        pap = Math.Sqrt(((x(n) - x(m)) ^ 2) + ((y(n) - y(m)) ^ 2) + ((z(n) - z(m)) ^ 2))
                                                        If pap < Form7.NumericUpDown1.Value And pap <> 0 Then
                                                            If bprop3(n) > Form7.NumericUpDown4.Value And bprop3(n) < Form7.NumericUpDown5.Value Then
                                                                If bkapa(n) > Form7.NumericUpDown6.Value And bkapa(n) < Form7.NumericUpDown7.Value Then 'b
                                                                    ' If bseleccio(n) > Form4.NumericUpDown8.Value And bseleccio(n) < Form4.NumericUpDown9.Value Then
                                                                    puntsacceptats = puntsacceptats + 1
                                                                    If puntsacceptats > maxp Then maxp = puntsacceptats 'registre de punt acceptat
                                                                    apte(n) = True
                                                                    apte(m) = True
                                                                    ReDim Preserve cluster(puntsacceptats)
                                                                    cluster(0) = n
                                                                    cluster(puntsacceptats) = m
                                                                    If puntsacceptats = 1 Then 'aa
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0)
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0, 0)
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0, 0, 0, 0)
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))
                                                                        'If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                                                                        'If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n), n, apte(n))
                                                                        'If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), vect1(n), vect2(n), vect3(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n), R(n), G(n), V(n))

                                                                        item = item + 1
                                                                    End If 'aa
                                                                    If puntsacceptats >= 1 Then 'a
                                                                        'If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        'If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m), m, apte(m))
                                                                        'If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m), R(m), G(m), V(m))
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))

                                                                    End If 'a
                                                                    ac = ac + 1
                                                                    l = ab
                                                                End If 'b
                                                                'End If
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            Next l2
                                        End If
20:                                 Next difz
30:                             Next dify
40:                         Next difx
50:                     Next l ' solament interessa el primer punt i el primer m
                        '
                        '*****segona part*******
                        '
                        If puntsacceptats >= 1 Then 'i
                            'b�squeda de punts al voltant dels punts m
                            n = -1
55:                         n = n + 1
                            'For n = 1 To puntsacceptats
                            ' primer coneixer el seu voxel
                            'Busca el voxel
                            eixx3 = x(cluster(n)) - minx
                            eixx3 = Int(eixx3 * redux)
                            eixy3 = y(cluster(n)) - miny
                            eixy3 = Int(eixy3 * reduy)
                            eixz3 = z(cluster(n)) - minz
                            eixz3 = Int(eixz3 * reduz)
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx3 + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 80
                                For dify = -esp To esp
                                    eixy2 = eixy3 + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 70
                                    For difz = -esp To esp
                                        eixz2 = eixz3 + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 60
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then 'h
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1) 'punts al voltant 
                                                'If apte(m) = False Then 'g
                                                pep = Math.Sqrt(Math.Pow(orientacio(cluster(n)) - orientacio(m), 2))
                                                If pep > 180 Then pep = 360 - pep
                                                If pep <= Form7.NumericUpDown2.Value Then 'f
                                                    pip = Math.Sqrt(Math.Pow(pendent(cluster(n)) - pendent(m), 2))
                                                    If pip <= Form7.NumericUpDown3.Value Then 'e
                                                        pap = Math.Sqrt(((x(cluster(n)) - x(m)) ^ 2) + ((y(cluster(n)) - y(m)) ^ 2) + ((z(cluster(n)) - z(m)) ^ 2))
                                                        If pap < Form7.NumericUpDown1.Value And pap <> 0 Then 'd
                                                            If bprop3(cluster(n)) > Form7.NumericUpDown4.Value And bprop3(cluster(n)) < Form4.NumericUpDown5.Value Then 'c
                                                                If bkapa(cluster(n)) > Form7.NumericUpDown6.Value And bkapa(cluster(n)) < Form4.NumericUpDown7.Value Then 'b
                                                                    'If bseleccio(cluster(n)) > Form7.NumericUpDown8.Value And bseleccio(cluster(n)) < Form4.NumericUpDown9.Value Then 'a
                                                                    If apte(m) = False Then

                                                                        puntsacceptats = puntsacceptats + 1
                                                                        ReDim Preserve cluster(puntsacceptats)
                                                                        cluster(puntsacceptats) = m
                                                                        'If puntsacceptats = Form4.NumericUpDown11.Value Then ' s'acceptan tots
                                                                        ' If apte(m) = False Then
                                                                        apte(m) = True

                                                                        'If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        'If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m), m, apte(m))
                                                                        'If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), vect1(m), vect2(m), vect3(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))

                                                                    End If
                                                                    ' l = ab
                                                                    'eixx = amplex : eixy = ampley : eixz = amplez
                                                                    'l2 = ad : difz = esp : dify = esp : difx = esp : l = ab
                                                                    'l es el n�mero de centroides en el primer voxel max es ab
                                                                    'l2 es el n�mero de centroides el seg�ents voxels
                                                                    'End If del form4.updown11
                                                                    ' End If 'a
                                                                End If 'b
                                                            End If 'c
                                                        End If 'd
                                                    End If 'e
                                                End If 'f
                                                ' End If 'g
                                            Next l2
                                        End If 'h
60:                                 Next difz
70:                             Next dify
80:                         Next difx
                            'Next
                            '                        End If 'i
                            If n <> puntsacceptats Then GoTo 55
                            puntsacceptats = 0
                        End If 'i
                        '
                        '*** final de la segona part ****
                    End If
                    ReDim cluster(0)
                Next eixz
            Next eixy
        Next eixx
        FileClose(1)
        'porc = (ac * 100) / cont
        'Form3.Label7.Caption = porc
        'pathnamexit = "pol3.txt"
        Form7.Label12.Text = item - 1
        MsgBox("Clusters Completed")


    End Sub
    Sub savclusters2()
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim eixx3 As Double : Dim eixy3 As Double : Dim eixz3 As Double
        Dim difx As Double : Dim dify As Double : Dim difz As Double
        Dim esp As Integer
        Dim ab As Integer
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim pap As Double
        Dim puntsacceptats As Integer
        Dim comprovats As Integer
        Dim item As Integer
        Dim cluster() As Long
        Dim maxp As Integer
        Dim preferent As Double
        Dim xx As Double
        Dim yy As Double
        Dim zz As Double
        Dim preferent2 As Double
        Dim preferent3 As Double
        Dim preferent4 As Double
        Dim preferent5 As Double

        maxp = 0
        ' La idea es identificar un punt i comen�ar a buscar punts al seu 
        ' voltant, si l'identifica es marca com escollit i continua
        puntsacceptats = 0
        item = 1 'primer cluster
        Dim ac As Integer
        Dim pep As Double
        ac = 0
        esp = Int(Form7.NumericUpDown1.Value) + 1 'dist�ncia m�xima de b�squeda
        'esp = 0.5 + 1 'dist�ncia m�xima de b�squeda
        FileOpen(1, Form10.TextBox1.Text + "clusters.txt", OpenMode.Output) 'sortida
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' N�mero de centroides en el primer voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then ' si hi han centroides, veure quants s�n
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides
                        For l = 1 To ab
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim el primer centroide
                            'comprovaci� de que estigui lliure
                            If apte(n) = True Then GoTo 50
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 40
                                For dify = -esp To esp
                                    eixy2 = eixy + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 30
                                    For difz = -esp To esp
                                        eixz2 = eixz + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 20
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1) 'punts al voltant 
                                                'comen�a amb els angles 
                                                pep = Math.Acos(Math.Abs(((vect1(n) * vect1(m)) + (vect2(n) * vect2(m)) + (vect3(n) * vect3(m))) / (Math.Sqrt((vect1(n) * vect1(n)) + (vect2(n) * vect2(n)) + (vect3(n) * vect3(n)))) * (Math.Sqrt((vect1(m) * vect1(m)) + (vect2(m) * vect2(m)) + (vect3(m) * vect3(m))))))
                                                pep = (pep * 180) / Math.PI
                                                If pep <= Form7.NumericUpDown8.Value Then
                                                    'acava els angles
                                                    pap = Math.Sqrt(((x(n) - x(m)) ^ 2) + ((y(n) - y(m)) ^ 2) + ((z(n) - z(m)) ^ 2))
                                                    ' dist�ncia
                                                    If pap < Form7.NumericUpDown1.Value And pap <> 0 Then
                                                        If bprop3(n) > Form7.NumericUpDown4.Value And bprop3(n) < Form7.NumericUpDown5.Value Then
                                                            If bkapa(n) > Form7.NumericUpDown6.Value And bkapa(n) < Form7.NumericUpDown7.Value Then
                                                                xx = x(n) - x(m)
                                                                yy = y(n) - y(m)
                                                                zz = z(n) - z(m)
                                                                preferent = Math.Acos(Math.Abs(((vect1(n) * xx) + (vect2(n) * yy) + (vect3(n) * zz)) / (Math.Sqrt((vect1(n) * vect1(n)) + (vect2(n) * vect2(n)) + (vect3(n) * vect3(n)))) * (Math.Sqrt((xx * xx) + (yy * yy) + (zz * zz)))))
                                                                preferent = (preferent * 180) / Math.PI
                                                                If Form7.CheckBox2.Checked = False Then preferent = 0
                                                                If (90 - preferent) <= Form7.NumericUpDown9.Value Then
                                                                    ' If bseleccio(n) > Form4.NumericUpDown8.Value And bseleccio(n) < Form4.NumericUpDown9.Value Then
                                                                    puntsacceptats = puntsacceptats + 1
                                                                    If puntsacceptats > maxp Then maxp = puntsacceptats
                                                                    apte(n) = True
                                                                    apte(m) = True
                                                                    ReDim Preserve cluster(puntsacceptats)
                                                                    cluster(0) = n
                                                                    cluster(puntsacceptats) = m
                                                                    If puntsacceptats = 1 Then
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0)
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0, 0)
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, 0, 0, 0, item, 0, 0, 0, 0, 0, 0, 0)
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), inten(n))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(n), y(n), z(n), orientacio(n), pendent(n), bprop3(n), bkapa(n), bseleccio(n), R(n), G(n), V(n))

                                                                        item = item + 1
                                                                        Form7.Label12.Text = item - 1
                                                                    End If
                                                                    If puntsacceptats >= 1 Then
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))
                                                                    End If
                                                                    ac = ac + 1
                                                                    l = ab
                                                                End If
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                                ' End If
                                            Next l2
                                        End If
20:                                 Next difz
30:                             Next dify
40:                         Next difx
50:                     Next l ' solament interessa el primer
                        '
                        '*****segona part*******
                        '
                        If puntsacceptats >= 1 Then 'i
                            'b�squeda de punts al voltant dels punts m
                            comprovats = 0
55:                         comprovats = comprovats + 1
                            'For n = 1 To puntsacceptats
                            ' primer coneixer el seu voxel
                            'Busca el voxel
                            eixx3 = x(cluster(comprovats)) - minx
                            eixx3 = Int(eixx3 * redux)
                            eixy3 = y(cluster(comprovats)) - miny
                            eixy3 = Int(eixy3 * reduy)
                            eixz3 = z(cluster(comprovats)) - minz
                            eixz3 = Int(eixz3 * reduz)
                            ' ara s�han de buscar tots els del voltant
                            For difx = -esp To esp
                                eixx2 = eixx3 + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo 80
                                For dify = -esp To esp
                                    eixy2 = eixy3 + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo 70
                                    For difz = -esp To esp
                                        eixz2 = eixz3 + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo 60
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then 'g
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1) 'punts al voltant d'n
                                                If apte(m) = False Then 'f
                                                    pep = Math.Acos(Math.Abs(((vect1(comprovats) * vect1(m)) + (vect2(comprovats) * vect2(m)) + (vect3(comprovats) * vect3(m))) / (Math.Sqrt((vect1(comprovats) * vect1(comprovats)) + (vect2(comprovats) * vect2(comprovats)) + (vect3(comprovats) * vect3(comprovats)))) * (Math.Sqrt((vect1(m) * vect1(m)) + (vect2(m) * vect2(m)) + (vect3(m) * vect3(m))))))
                                                    pep = (pep * 180) / Math.PI
                                                    If pep <= Form7.NumericUpDown8.Value Then 'e
                                                        pap = Math.Sqrt(((x(cluster(comprovats)) - x(m)) ^ 2) + ((y(cluster(comprovats)) - y(m)) ^ 2) + ((z(cluster(comprovats)) - z(m)) ^ 2))
                                                        If pap < Form7.NumericUpDown1.Value And pap <> 0 Then 'd
                                                            If bprop3(cluster(comprovats)) > Form7.NumericUpDown4.Value And bprop3(cluster(comprovats)) < Form4.NumericUpDown5.Value Then 'c
                                                                If bkapa(cluster(comprovats)) > Form7.NumericUpDown6.Value And bkapa(cluster(comprovats)) < Form4.NumericUpDown7.Value Then 'b
                                                                    xx = x(cluster(comprovats)) - x(m)
                                                                    yy = y(cluster(comprovats)) - y(m)
                                                                    zz = z(cluster(comprovats)) - z(m)
                                                                    ' preferent1 = Math.Acos(Math.Abs(((vect1(n) * xx) + (vect2(n) * yy) + (vect3(n) * zz)) / (Math.Sqrt((vect1(n) * vect1(n)) + (vect2(n) * vect2(n)) + (vect3(n) * vect3(n)))) * (Math.Sqrt((xx * xx) + (yy * yy) + (zz * zz)))))
                                                                    preferent2 = Math.Sqrt((xx * xx) + (yy * yy) + (zz * zz))
                                                                    preferent3 = Math.Sqrt((vect1(n) * vect1(n)) + (vect2(n) * vect2(n)) + (vect3(n) * vect3(n)))
                                                                    preferent4 = ((vect1(n) * xx) + (vect2(n) * yy) + (vect3(n) * zz))
                                                                    preferent5 = Math.Abs(preferent4 / (preferent2 * preferent3))
                                                                    preferent = Math.Acos(preferent5)
                                                                    preferent = 90 - (preferent * 180) / Math.PI
                                                                    If preferent <= Form7.NumericUpDown9.Value Then 'a
                                                                        puntsacceptats = puntsacceptats + 1
                                                                        ReDim Preserve cluster(puntsacceptats)
                                                                        cluster(puntsacceptats) = m
                                                                        'If puntsacceptats = Form4.NumericUpDown11.Value Then ' s'acceptan tots
                                                                        apte(m) = True
                                                                        If Form1.RadioButton1.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m))
                                                                        If Form1.RadioButton2.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), inten(m))
                                                                        If Form1.RadioButton3.Checked = True Then PrintLine(1, x(m), y(m), z(m), orientacio(m), pendent(m), bprop3(m), bkapa(m), bseleccio(m), R(m), G(m), V(m))
                                                                        l = ab
                                                                    End If 'a
                                                                End If 'b
                                                            End If 'c
                                                        End If 'd
                                                    End If 'e
                                                End If 'f
                                            Next l2
                                        End If 'g
60:                                 Next difz
70:                             Next dify
80:                         Next difx
                            If comprovats <> puntsacceptats Then GoTo 55
                            puntsacceptats = 0
                        End If 'i
                        '
                        '*** final de la segona part ****
                    End If
                    ReDim cluster(0)
                Next eixz
            Next eixy
        Next eixx
        FileClose(1)
        'porc = (ac * 100) / cont
        'Form3.Label7.Caption = porc
        'pathnamexit = "pol3.txt"
        Form7.Label12.Text = item - 1
        MsgBox("Clusters Completed")
        For ab = 0 To n
            apte(ab) = False
        Next

    End Sub
    Sub polygon()
        Dim indice As Integer
        Dim segon As Integer
        Dim co As Integer
        Dim ejey As Integer
        Dim ppoly As Double
        Dim ppolx As Double
        Dim comb() As Double
        Dim ordena() As Double
        Dim abcisa() As Double
        Dim pendrecta() As Double
        Dim ca As Double
        Dim but = 1
        Dim infoReader As System.IO.FileInfo
        ' Dim info As System.IO.DirectoryInfo
        Dim openFileDialog2 As New OpenFileDialog()
        Form3.OpenFileDialog2.InitialDirectory = Form10.TextBox1.Text
        'Dim file As String
        '

        '
        Dim inutil As Double
        num = -1
        indice = 0
        'FileOpen(2, "C:\Dades\Projecte90\coorde.txt", OpenMode.Output)

        Form3.OpenFileDialog2.ShowDialog()
        On Error GoTo Errorhandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog2.FileName)
        'afegit
        For Each rfile In Form3.OpenFileDialog2.FileNames
            FileOpen(1, rfile, OpenMode.Input)
            'fi afegit
            ' FileOpen(1, Form3.OpenFileDialog2.FileName, OpenMode.Input)
            Do Until EOF(1)
                num = num + 1
                Input(1, ppolx)
                Input(1, ppoly)
                If Form3.CheckBox4.Checked = True Then
                    Input(1, inutil)
                    Input(1, inutil)
                End If
            Loop
            FileClose(1)
            Select Case but
                Case 1
                    Form3.Button5.Text = My.Computer.FileSystem.GetName(rfile)
                Case 2
                    Form3.Button6.Text = My.Computer.FileSystem.GetName(rfile)
                Case 3
                    Form3.Button7.Text = My.Computer.FileSystem.GetName(rfile)
                Case 4
                    Form3.Button8.Text = My.Computer.FileSystem.GetName(rfile)
                Case 5
                    Form3.Button9.Text = My.Computer.FileSystem.GetName(rfile)
                Case 6
                    Form3.Button10.Text = My.Computer.FileSystem.GetName(rfile)
                Case 7
                    Form3.Button11.Text = My.Computer.FileSystem.GetName(rfile)
                Case 8
                    Form3.Button12.Text = My.Computer.FileSystem.GetName(rfile)
                Case 9
                    Form3.Button13.Text = My.Computer.FileSystem.GetName(rfile)
                Case 10
                    Form3.Button14.Text = My.Computer.FileSystem.GetName(rfile)
                Case 11
                    Form3.Button15.Text = My.Computer.FileSystem.GetName(rfile)
                Case 12
                    Form3.Button16.Text = My.Computer.FileSystem.GetName(rfile)
                Case 13
                    Form3.Button17.Text = My.Computer.FileSystem.GetName(rfile)
                Case 14
                    Form3.Button18.Text = My.Computer.FileSystem.GetName(rfile)
                Case 15
                    Form3.Button19.Text = My.Computer.FileSystem.GetName(rfile)
                Case 16
                    Form3.Button20.Text = My.Computer.FileSystem.GetName(rfile)
                Case 17
                    Form3.Button21.Text = My.Computer.FileSystem.GetName(rfile)
                Case 18
                    Form3.Button22.Text = My.Computer.FileSystem.GetName(rfile)
                Case 19
                    Form3.Button23.Text = My.Computer.FileSystem.GetName(rfile)
                Case 20
                    Form3.Button24.Text = My.Computer.FileSystem.GetName(rfile)
                Case 21
                    Form3.Button25.Text = My.Computer.FileSystem.GetName(rfile)
                Case 22
                    Form3.Button26.Text = My.Computer.FileSystem.GetName(rfile)
                Case 23
                    Form3.Button27.Text = My.Computer.FileSystem.GetName(rfile)
                Case 24
                    Form3.Button28.Text = My.Computer.FileSystem.GetName(rfile)

            End Select
            but = but + 1
            Dim ppolyx(num + 1)
            Dim ppolyy(num + 1)
            num = -1
            'afegit
            FileOpen(1, rfile, OpenMode.Input)
            'fi afegit
            'FileOpen(1, Form3.OpenFileDialog2.FileName, OpenMode.Input)
            Do Until EOF(1)
                num = num + 1
                Input(1, ppolx)
                Input(1, ppoly)
                If Form3.CheckBox4.Checked = True Then
                    Input(1, inutil)
                    Input(1, inutil)
                End If
                ppolyx(num) = Math.Floor(ppolx)
                ppolyy(num) = Math.Floor(ppoly)
            Loop
            FileClose(1)
            ppolyx(num + 1) = ppolyx(0)
            ppolyy(num + 1) = ppolyy(0)
            'crear totes les coordenades. 1 valor absolut
            ReDim abcisa(num)
            ReDim ordena(num)
            ReDim pendrecta(num)
            ReDim comb(num)
            For co = 0 To num
                abcisa(co) = (ppolyx(co) - ppolyx(co + 1))
                ordena(co) = (ppolyy(co) - ppolyy(co + 1))
            Next co
            For co = 0 To num
                If abcisa(co) = 0 Then
                    pendrecta(co) = 0
                Else
                    pendrecta(co) = ordena(co) / abcisa(co)
                End If
            Next co
            For co = 0 To num
                comb(co) = (-1 * (pendrecta(co) * ppolyx(co))) + ppolyy(co)
            Next co
            'disminuci�
            For co = 0 To num
                If ppolyx(co) > ppolyx(co + 1) Then
                    For ca = ppolyx(co) To ppolyx(co + 1) Step -1
                        ejey = (pendrecta(co) * ca) + comb(co)
                        If ca <> ppolyx(co + 1) Then
                            ' PrintLine(2, ca, ejey, 0)
                            If inscrit(ca, ejey, family) = False Then 'activa codificacio 
                                For segon = 0 To ejey
                                    If inscrit(ca, segon, family) = True Then
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If
                                Next segon
                            Else
                                For segon = 0 To ejey
                                    If inscrit(ca, segon, family) = True Then
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If
                                Next segon
                            End If
                        End If
                        'asignar a la matriu area acupada un 1
                        If indice > 0 And indice <> 1 Then ca = ca + 1
                        indice = 1
                    Next ca
                End If
                'augment
                If ppolyx(co) < ppolyx(co + 1) Then 'f
                    For ca = ppolyx(co) To ppolyx(co + 1) 'e
                        'If indice > 0 And indice <> 2 Then ca = ca - 1
                        ejey = (pendrecta(co) * ca) + comb(co)
                        If ca <> ppolyx(co + 1) Then 'd
                            ' PrintLine(2, ca, ejey, 1)
                            If inscrit(ca, ejey, family) = False Then 'c
                                For segon = 0 To ejey 'b
                                    If inscrit(ca, segon, family) = True Then 'a
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If 'a
                                Next segon 'b
                            Else
                                For segon = 0 To ejey 'b
                                    If inscrit(ca, segon, family) = True Then 'a
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If 'a
                                Next segon 'b
                            End If 'c
                        End If 'd
                        'asignar a la matriu area acupada un 1
                        If indice > 0 And indice <> 2 Then ca = ca - 1
                        indice = 2
                    Next ca 'e
                End If 'f
                'igual
                If ppolyx(co) = ppolyx(co + 1) Then
                    If indice > 0 And indice <> 3 Then indice = 0
                    For ca = ppolyx(co) To ppolyx(co + 1) Step -1
                        ejey = (pendrecta(co) * ca) + comb(co)
                        If ca <> ppolyx(co + 1) Then
                            'PrintLine(2, ca, ejey, 2)
                            If inscrit(ca, ejey, family) = False Then
                                For segon = 0 To ejey
                                    If inscrit(ca, segon, family) = True Then
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If
                                Next segon
                            Else

                                For segon = 0 To ejey
                                    If inscrit(ca, segon, family) = True Then
                                        inscrit(ca, segon, family) = False
                                    Else
                                        inscrit(ca, segon, family) = True
                                    End If
                                Next segon
                            End If
                        End If
                        'asignar a la matriu area acupada un 1
                    Next ca
                    indice = 3
                End If

            Next co
            'afegit
            If family = 1 Then
                Form3.Label13.Visible = True
            End If
            If family = 2 Then
                Form3.Label14.Visible = True
                Form3.Button7.Enabled = True
                Form3.TextBox5.Visible = True
            End If
            If family = 3 Then
                Form3.Label15.Visible = True
                Form3.Button8.Enabled = True
                Form3.TextBox6.Visible = True
            End If
            If family = 4 Then
                Form3.Label16.Visible = True
                Form3.Button9.Enabled = True
                Form3.TextBox7.Visible = True
            End If
            If family = 5 Then
                Form3.Label17.Visible = True
                Form3.Button10.Enabled = True
                Form3.TextBox8.Visible = True
            End If
            If family = 6 Then
                Form3.Label18.Visible = True
                Form3.Button11.Enabled = True
                Form3.TextBox9.Visible = True
            End If
            If family = 7 Then
                Form3.Label19.Visible = True
                Form3.Button12.Enabled = True
                Form3.TextBox10.Visible = True
            End If
            If family = 8 Then
                Form3.Label20.Visible = True
                Form3.Button13.Enabled = True
                Form3.TextBox11.Visible = True
            End If
            If family = 9 Then
                Form3.Label21.Visible = True
                Form3.Button14.Enabled = True
                Form3.TextBox12.Visible = True
            End If
            If family = 10 Then
                Form3.Label22.Visible = True
                Form3.Button15.Enabled = True
                Form3.TextBox13.Visible = True
            End If
            If family = 11 Then
                Form3.Label23.Visible = True
                Form3.Button16.Enabled = True
                Form3.TextBox14.Visible = True
            End If
            If family = 12 Then
                Form3.Label24.Visible = True
                Form3.Button17.Enabled = True
                Form3.TextBox15.Visible = True
            End If
            If family = 13 Then
                Form3.Label25.Visible = True
                Form3.Button18.Enabled = True
                Form3.TextBox16.Visible = True
            End If
            If family = 14 Then
                Form3.Label26.Visible = True
                Form3.Button19.Enabled = True
                Form3.TextBox17.Visible = True
            End If
            If family = 15 Then
                Form3.Label27.Visible = True
                Form3.Button20.Enabled = True
                Form3.TextBox18.Visible = True
            End If
            If family = 16 Then
                Form3.Label28.Visible = True
                Form3.Button21.Enabled = True
                Form3.TextBox19.Visible = True
            End If
            If family = 17 Then
                Form3.Label29.Visible = True
                Form3.Button22.Enabled = True
                Form3.TextBox20.Visible = True
            End If
            If family = 18 Then
                Form3.Label30.Visible = True
                Form3.Button23.Enabled = True
                Form3.TextBox21.Visible = True
            End If
            If family = 19 Then
                Form3.Label31.Visible = True
                Form3.Button24.Enabled = True
                Form3.TextBox22.Visible = True
            End If
            If family = 20 Then
                Form3.Label32.Visible = True
                Form3.Button25.Enabled = True
                Form3.TextBox23.Visible = True
            End If
            If family = 21 Then
                Form3.Label33.Visible = True
                Form3.Button26.Enabled = True
                Form3.TextBox24.Visible = True
            End If
            If family = 22 Then
                Form3.Label34.Visible = True
                Form3.Button27.Enabled = True
                Form3.TextBox25.Visible = True
            End If
            If family = 23 Then
                Form3.Label35.Visible = True
                Form3.Button28.Enabled = True
                Form3.TextBox26.Visible = True
            End If
            If family = 24 Then
                Form3.Label36.Visible = True
                'Form3.Button29.Visible = True
                Form3.TextBox27.Visible = True
            End If
            family = family + 1
        Next rfile
        family = family - 1
        'fi afegit
        '        For primer = 0 To 360
        ' For segon = 0 To 90
        ' PrintLine(2, primer, segon, inscrit(primer, segon))
        'Next
        'Next
        'FileClose(2)
Errorhandler:
        Exit Sub
    End Sub
    Sub Reduction()
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Integer
        Dim gf As Integer
        Dim vf As Integer
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d As Integer
        b = 0
        a = 0
        c = 0

        Dim openFileDialog1 As New OpenFileDialog()
        Form8.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form8.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form8.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "reduce.txt", OpenMode.Output)
        d = CSng(Form8.NumericUpDown1.Value)
        Do Until EOF(1)
            If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = False Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
            End If
            If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = False Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, intenf)
            End If
            If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = False Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, gf)
                Input(1, vf)
            End If
            If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = True Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
            End If
            If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = True Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
            End If
            If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = True Then
                a = a + 1
                b = b + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
            End If

            d = CSng(Form8.NumericUpDown1.Value)
            If a = d Then
                If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = False Then PrintLine(2, xf, yf, zf)
                If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = False Then PrintLine(2, xf, yf, zf, intenf)
                If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = False Then PrintLine(2, xf, yf, zf, rf, gf, vf)
                If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = True Then PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf)
                If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = True Then PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, intenf)
                If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = True Then PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, rf, gf, vf)

                c = c + 1
                a = 0
            End If
        Loop
        Form8.Label4.Text = b
        Form8.Label5.Text = c
        FileClose(2)
        FileClose(1)
errorhandler:
        Exit Sub
    End Sub
    Sub inpscanline()
        FileOpen(1, "C:\Dades\Projecte100\scanline.txt", OpenMode.Input)
        Input(1, puntorigen(1))
        Input(1, puntorigen(2))
        Input(1, puntorigen(3))
        Input(1, puntorigen(4))
        Input(1, puntorigen(5))
        Input(1, puntorigen(6))
        FileClose(1)
        Form14.NumericUpDown1.Value = Format(puntorigen(1), "#.###")
        Form14.NumericUpDown2.Value = Format(puntorigen(2), "#.###")
        Form14.NumericUpDown3.Value = Format(puntorigen(3), "#.###")
        Form14.NumericUpDown4.Value = Format(puntorigen(4), "#.###")
        Form14.NumericUpDown5.Value = Format(puntorigen(5), "#.###")
        Form14.NumericUpDown6.Value = Format(puntorigen(6), "#.###")
    End Sub
    Sub projection()
        '*****dimensionament******
        Dim response As MsgBoxResult
        Dim coordx(), coordy(), coordz() As Double
        Dim azimu(), pende() As Double
        Dim C As Double
        Dim intens As Double
        Dim intenso As String
        Dim colineal, coplanar, population, number, rugosity(), weight, height, areas() As Double
        Dim fami, familie, contadorletra As String
        Dim sumax, sumay, sumaz As Double
        Dim i, di, cont As Integer
        ' Dim t, t1, t2 As Double
        Dim t1, t2 As Double
        ' Dim puntcontactex(), puntcontactey(), puntcontactez() As Double
        Dim maxx, maxy, maxz As Double
        Dim distx, disty, distz, distfinal, longitud As Double
        Dim seccio As Integer
        Dim tram() As Double
        Dim rr As Double
        Dim areatram() As Double
        Dim conta As Integer = 1
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        '******Fi dimensionament*********
        seleccio = 1
        '******obrir fitxer morfometria**************
        Form19.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form19.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form19.OpenFileDialog1.FileName, OpenMode.Input)
        Input(1, intenso) ' ****** primera linea de lletres
        Do Until EOF(1)
            ReDim Preserve x(seleccio)
            ReDim Preserve y(seleccio)
            ReDim Preserve z(seleccio)
            ReDim Preserve coordx(seleccio)
            ReDim Preserve coordy(seleccio)
            ReDim Preserve coordz(seleccio)
            ReDim Preserve areas(seleccio)
            ReDim Preserve escollits(seleccio)
            ReDim Preserve azimu(seleccio)
            ReDim Preserve pende(seleccio)
            ReDim Preserve rugosity(seleccio)
            Input(1, coordx(seleccio)) 'x
            Input(1, coordy(seleccio)) 'y
            Input(1, coordz(seleccio)) 'z
            Input(1, x(seleccio)) 'i
            Input(1, y(seleccio)) 'j
            Input(1, z(seleccio)) 'k
            Input(1, azimu(seleccio)) 'azi
            Input(1, pende(seleccio)) 'dip
            Input(1, colineal) 'M
            Input(1, coplanar) 'K
            Input(1, population) 'Population
            Input(1, number) 'Number
            Input(1, rugosity(seleccio)) 'Rugosity
            Input(1, weight) 'Weight
            Input(1, height) 'height
            Input(1, areas(seleccio)) 'Area
            Input(1, fami) 'Family
            If seleccio = 1 Then familie = fami
            If fami <> familie Then
                seleccio = seleccio - 1
                calculvectors() 'mitja dels vectors
                A = Vec1 : B = Vec2 : C = Vec3
                '********* calcul del punt mitj� *********************
                sumax = 0 : sumay = 0 : sumaz = 0
                For i = 1 To seleccio
                    di = escollits(i)
                    sumax = sumax + coordx(di)
                    sumay = sumay + coordy(di)
                    sumaz = sumaz + coordz(di)
                Next i
                xmean = sumax / seleccio
                ymean = sumay / seleccio
                zmean = sumaz / seleccio
                '******** Final calcul del punt mig *********************
                '******** inici informaci� *********************

                'Form19.NumericUpDown13.Value = Vec3
                'Form19.NumericUpDown12.Value = Vec2
                'Form19.NumericUpDown11.Value = Vec1
                'Form19.NumericUpDown10.Value = zmean
                'Form19.NumericUpDown9.Value = ymean
                'Form19.NumericUpDown8.Value = xmean
                at = Vec1
                bt = Vec2
                ct = Vec3
                dipproj()
                'Form19.NumericUpDown14.Value = a1
                'Form19.NumericUpDown15.Value = b1

                '*** inici calcul de vector a dip ****

                '******** Final informaci� *********************
                'If Form19.CheckBox1.Checked = False Or Form19.CheckBox2.Checked = False Then
                If Form19.CheckBox2.Checked = True Then
                    Vec1 = Form19.NumericUpDown11.Value
                    Vec2 = Form19.NumericUpDown12.Value
                    Vec3 = Form19.NumericUpDown13.Value
                End If


                If Form19.CheckBox1.Checked = True Then
                    xmean = Form19.NumericUpDown8.Value
                    ymean = Form19.NumericUpDown9.Value
                    zmean = Form19.NumericUpDown10.Value
                End If
                'response = MsgBox("Modify Point or/and Vector?", MsgBoxStyle.YesNoCancel, "Alert")
                'If response = MsgBoxResult.Yes Then Form19.Focus()
                'If response = MsgBoxResult.No Then Form19.Focus()
                'If response = MsgBoxResult.Cancel Then Form19.Focus()
                'End If
                '******** inici de la projeccio *********************
                minx = xmean : miny = ymean : minz = zmean
                maxx = xmean : maxy = ymean : maxz = zmean
                contadorletra = CStr(conta)
                FileOpen(2, Form10.TextBox1.Text + "projection" + contadorletra + ".txt", OpenMode.Output)
                For cont = 1 To seleccio
                    D = (coordx(cont) * x(cont)) + (coordy(cont) * y(cont)) + (coordz(cont) * z(cont)) ' plano 
                    t = (D - (x(cont) * xmean) - (y(cont) * ymean) - (z(cont) * zmean)) / ((x(cont) * Vec1) + (y(cont) * Vec2) + (z(cont) * Vec3))

                    ReDim Preserve puntcontactex(cont)
                    ReDim Preserve puntcontactey(cont)
                    ReDim Preserve puntcontactez(cont)
                    puntcontactex(cont) = xmean + (t * Vec1)
                    puntcontactey(cont) = ymean + (t * Vec2)
                    puntcontactez(cont) = zmean + (t * Vec3)
                    '********B�squeda d'un extrem*********
                    If puntcontactex(cont) > maxx Then maxx = puntcontactex(cont)
                    If puntcontactey(cont) > maxy Then maxy = puntcontactey(cont)
                    If puntcontactez(cont) > maxz Then maxz = puntcontactez(cont)
                    If puntcontactex(cont) < minx Then minx = puntcontactex(cont)
                    If puntcontactey(cont) < miny Then miny = puntcontactey(cont)
                    If puntcontactez(cont) < minz Then minz = puntcontactez(cont)
                    '********B�squeda d'un extrem*********
                    If Form19.RadioButton1.Checked = True Then
                        PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), azimu(cont))
                    End If
                    If Form19.RadioButton2.Checked = True Then
                        PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), pende(cont))
                    End If
                    If Form19.RadioButton3.Checked = True Then
                        PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), rugosity(cont))
                    End If
                    If Form19.RadioButton4.Checked = True Then
                        PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), areas(cont))
                    End If
                Next cont
                FileClose(2)
                conta = conta + 1
                '******** inici de canvi de familia *********************


                familie = fami
                seleccio = 0
                seccio = 0
                ReDim tram(seccio)
                ReDim areatram(seccio)
                ReDim puntcontactex(seleccio)
                ReDim puntcontactey(seleccio)
                ReDim puntcontactey(seleccio)

                ReDim x(seleccio)
                ReDim y(seleccio)
                ReDim z(seleccio)
                ReDim coordx(seleccio)
                ReDim coordy(seleccio)
                ReDim coordz(seleccio)
                ReDim escollits(seleccio)
                ReDim azimu(seleccio)
                ReDim pende(seleccio)
                '******** Final de canvi de familia *********************
            End If
            escollits(seleccio) = seleccio
            If areas(seleccio) > Form19.NumericUpDown7.Value Then
                If colineal > Form19.NumericUpDown1.Value Then
                    If coplanar < Form19.NumericUpDown2.Value Then
                        If population > Form19.NumericUpDown3.Value Then
                            If rugosity(seleccio) > Form19.NumericUpDown4.Value Then
                                If weight > Form19.NumericUpDown5.Value Then
                                    If height > Form19.NumericUpDown6.Value Then
                                        seleccio = seleccio + 1

                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Loop

        seleccio = seleccio - 1
        calculvectors() 'mitja dels vectors
        A = Vec1 : B = Vec2 : C = Vec3
        '********* calcul del punt mig *********************
        sumax = 0 : sumay = 0 : sumaz = 0
        For i = 1 To seleccio
            di = escollits(i)
            sumax = sumax + coordx(di)
            sumay = sumay + coordy(di)
            sumaz = sumaz + coordz(di)
        Next i
        xmean = sumax / seleccio
        ymean = sumay / seleccio
        zmean = sumaz / seleccio
        '******** Final calcul del punt mig *********************
        '******** inici informaci� *********************
        'Form19.NumericUpDown13.Value = Vec3
        ' Form19.NumericUpDown12.Value = Vec2
        ' Form19.NumericUpDown11.Value = Vec1
        ' Form19.NumericUpDown10.Value = zmean
        ' Form19.NumericUpDown9.Value = ymean
        ' Form19.NumericUpDown8.Value = xmean
        at = Vec1
        bt = Vec2
        ct = Vec3

        '*** inici calcul de vector a dip ****
        dipproj()
        '***calculem dip i dip direction***

        'Form19.NumericUpDown14.Value = a1
        'Form19.NumericUpDown15.Value = b1

        '*** inici calcul de vector a dip ****

        '******** Final informaci� *********************
        'If Form19.CheckBox1.Checked = False Or Form19.CheckBox2.Checked = False Then
        'response = MsgBox("Modify Point or/and Vector?", MsgBoxStyle.YesNoCancel, "Alert")
        'If response = MsgBoxResult.Yes Then Form19.Focus()
        'If response = MsgBoxResult.No Then Form19.Focus()
        'If response = MsgBoxResult.Cancel Then Form19.Focus()
        'End If
        If Form19.CheckBox2.Checked = True Then
            Vec1 = Form19.NumericUpDown11.Value
            Vec2 = Form19.NumericUpDown12.Value
            Vec3 = Form19.NumericUpDown13.Value
        End If
        If Form19.CheckBox1.Checked = True Then
            xmean = Form19.NumericUpDown8.Value
            ymean = Form19.NumericUpDown9.Value
            zmean = Form19.NumericUpDown10.Value
        End If
        '******** inici de la projeccio *********************
        minx = xmean : miny = ymean : minz = zmean
        maxx = xmean : maxy = ymean : maxz = zmean
        contadorletra = CStr(conta)
        FileOpen(2, Form10.TextBox1.Text + "projection" + contadorletra + ".txt", OpenMode.Output)
        For cont = 1 To seleccio
            D = (coordx(cont) * x(cont)) + (coordy(cont) * y(cont)) + (coordz(cont) * z(cont)) ' plano 
            t = (D - (x(cont) * xmean) - (y(cont) * ymean) - (z(cont) * zmean)) / ((x(cont) * Vec1) + (y(cont) * Vec2) + (z(cont) * Vec3))

            ReDim Preserve puntcontactex(cont)
            ReDim Preserve puntcontactey(cont)
            ReDim Preserve puntcontactez(cont)
            puntcontactex(cont) = xmean + (t * Vec1)
            puntcontactey(cont) = ymean + (t * Vec2)
            puntcontactez(cont) = zmean + (t * Vec3)

            '********B�squeda d'un extrem*********
            If puntcontactex(cont) > maxx Then maxx = puntcontactex(cont)
            If puntcontactey(cont) > maxy Then maxy = puntcontactey(cont)
            If puntcontactez(cont) > maxz Then maxz = puntcontactez(cont)
            If puntcontactex(cont) < minx Then minx = puntcontactex(cont)
            If puntcontactey(cont) < miny Then miny = puntcontactey(cont)
            If puntcontactez(cont) < minz Then minz = puntcontactez(cont)
            '********B�squeda d'un extrem*********
            If Form19.RadioButton1.Checked = True Then
                PrintLine(2, Format(puntcontactex(cont), "#.####"), Format(puntcontactey(cont), "#.####"), Format(puntcontactez(cont), "#.####"), Format(a1, "#.####"), Format(b1, "#.####"), Format(azimu(cont), "#.####"), Format(pende(cont), "#.####"), azimu(cont))
            End If
            If Form19.RadioButton2.Checked = True Then
                PrintLine(2, Format(puntcontactex(cont), "#.####"), Format(puntcontactey(cont), "#.####"), Format(puntcontactez(cont), "#.####"), Format(a1, "#.####"), Format(b1, "#.####"), Format(azimu(cont), "#.####"), Format(pende(cont), "#.####"), pende(cont))
            End If
            If Form19.RadioButton3.Checked = True Then
                PrintLine(2, Format(puntcontactex(cont), "#.####"), Format(puntcontactey(cont), "#.####"), Format(puntcontactez(cont), "#.####"), Format(a1, "#.####"), Format(b1, "#.####"), Format(azimu(cont), "#.####"), Format(pende(cont), "#.####"), rugosity(cont))
            End If
            If Form19.RadioButton4.Checked = True Then
                PrintLine(2, Format(puntcontactex(cont), "#.####"), Format(puntcontactey(cont), "#.####"), Format(puntcontactez(cont), "#.####"), Format(a1, "#.####"), Format(b1, "#.####"), Format(azimu(cont), "#.####"), Format(pende(cont), "#.####"), areas(cont))
            End If

        Next cont
        FileClose(2)
        FileClose(1)
        MsgBox("Projection Completed")
errorhandler:
        Exit Sub
    End Sub

    Sub grouping()
        Dim areatram(0) As Double
        Dim compoz, compoy, compox As Double
        Dim valorx, valory, valorz As Double
        Dim cont As Integer
        Dim azimu(0), pende(0) As Double
        Dim azimu2(0), pende2(0) As Double
        Dim areas(0) As Double
        Dim maxx, maxy, maxz As Double
        Dim longitud As Double
        Dim seccio As Integer
        Dim seccio1 As Integer
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        Form19.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form19.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        '  FileOpen(3, Form10.TextBox1.Text + "Agrupament.txt", OpenMode.Output)
        FileOpen(4, Form10.TextBox1.Text + "Fourier.txt", OpenMode.Output)
        FileOpen(1, Form19.OpenFileDialog1.FileName, OpenMode.Input)
        seleccio = 1
        Do Until EOF(1)
            ReDim Preserve x(seleccio)
            ReDim Preserve y(seleccio)
            ReDim Preserve z(seleccio)
            ReDim Preserve azimu(seleccio)
            ReDim Preserve pende(seleccio)
            ReDim Preserve azimu2(seleccio)
            ReDim Preserve pende2(seleccio)
            ReDim Preserve areas(seleccio)
            Input(1, x(seleccio)) 'i
            Input(1, y(seleccio)) 'j
            Input(1, z(seleccio)) 'k
            Input(1, azimu(seleccio)) 'azi
            Input(1, pende(seleccio)) 'dip
            Input(1, azimu2(seleccio)) 'azi
            Input(1, pende2(seleccio)) 'dip
            Input(1, areas(seleccio)) 'Area
            If seleccio = 1 Then
                maxx = x(seleccio)
                maxy = y(seleccio)
                maxz = z(seleccio)
                minx = x(seleccio)
                miny = y(seleccio)
                minz = z(seleccio)
            End If
            If x(seleccio) > maxx Then maxx = x(seleccio)
            If y(seleccio) > maxy Then maxy = y(seleccio)
            If z(seleccio) > maxz Then maxz = z(seleccio)
            If x(seleccio) < minx Then minx = x(seleccio)
            If y(seleccio) < miny Then miny = y(seleccio)
            If z(seleccio) < minz Then minz = z(seleccio)
            seleccio = seleccio + 1
        Loop

        longitud = Math.Sqrt(Math.Pow((maxx - minx), 2) + Math.Pow((maxy - miny), 2) + Math.Pow((maxz - minz), 2))
        seccio1 = Math.Truncate(longitud / Form19.NumericUpDown16.Value) + 1
        compoz = Form19.NumericUpDown16.Value * Math.Cos((pende(1) * Math.PI) / 180)
        compox = Form19.NumericUpDown16.Value * Math.Sin((azimu(1) * Math.PI) / 180)
        compoy = Form19.NumericUpDown16.Value * Math.Cos((azimu(1) * Math.PI) / 180)
        ReDim areatram(seccio1)
        For cont = 1 To seleccio - 1
            longitud = Math.Sqrt(Math.Pow((x(cont) - minx), 2) + Math.Pow((y(cont) - miny), 2) + Math.Pow((z(cont) - minz), 2))
            seccio = Math.Truncate(longitud / Form19.NumericUpDown16.Value) + 1
            areatram(seccio) = areatram(seccio) + areas(cont)
        Next cont
        valorx = minx : valory = miny : valorz = minz
        For cont = 1 To seccio1
            valorx = valorx + compox
            valory = valory + compoy
            valorz = valorz + compoz
            ' PrintLine(3, Format(valorx, "#.###"), Format(valory, "#.###"), Format(valorz, "#.###"), Format(azimu(1), "#.###"), Format(pende(1), "#.###"), Format(azimu(1), "#.###"), Format(pende(1), "#.###"), Format(areatram(cont), "#.###"))
            PrintLine(4, Format(cont * Form19.NumericUpDown16.Value, "#.###"), areatram(cont))
        Next cont
        'FileClose(3)
        FileClose(4)
        FileClose(1)
        MsgBox("Fourier Files Completed")
errorhandler:
        Exit Sub
    End Sub


    Sub dipproj()
        '*** inici calcul de vector a dip ****

        If at = 0 And bt = 0 Then   '***la tra�a �s horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
500:
    End Sub


    Sub grouping2()
        Dim areatram(0) As Double
        Dim compoz, compoy, compox As Double
        Dim valorx, valory, valorz As Double
        Dim cont As Integer
        Dim azimu(0), pende(0) As Double
        Dim azimu2(0), pende2(0) As Double
        Dim areas(0) As Double
        Dim maxx, maxy, maxz As Double
        Dim longitud As Double
        Dim seccio As Integer
        Dim seccio1 As Integer
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        Form19.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form19.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(3, Form10.TextBox1.Text + "Grouping.txt", OpenMode.Output)
        FileOpen(1, Form19.OpenFileDialog1.FileName, OpenMode.Input)
        seleccio = 1
        Do Until EOF(1)
            ReDim Preserve x(seleccio)
            ReDim Preserve y(seleccio)
            ReDim Preserve z(seleccio)
            ReDim Preserve azimu(seleccio)
            ReDim Preserve pende(seleccio)
            ReDim Preserve azimu2(seleccio)
            ReDim Preserve pende2(seleccio)
            ReDim Preserve areas(seleccio)
            Input(1, x(seleccio)) 'i
            Input(1, y(seleccio)) 'j
            Input(1, z(seleccio)) 'k
            Input(1, azimu(seleccio)) 'azi
            Input(1, pende(seleccio)) 'dip
            Input(1, azimu2(seleccio)) 'azi
            Input(1, pende2(seleccio)) 'dip
            Input(1, areas(seleccio)) 'Area
            If seleccio = 1 Then
                maxx = x(seleccio)
                maxy = y(seleccio)
                maxz = z(seleccio)
                minx = x(seleccio)
                miny = y(seleccio)
                minz = z(seleccio)
            End If
            If x(seleccio) > maxx Then maxx = x(seleccio)
            If y(seleccio) > maxy Then maxy = y(seleccio)
            If z(seleccio) > maxz Then maxz = z(seleccio)
            If x(seleccio) < minx Then minx = x(seleccio)
            If y(seleccio) < miny Then miny = y(seleccio)
            If z(seleccio) < minz Then minz = z(seleccio)
            seleccio = seleccio + 1
        Loop

        longitud = Math.Sqrt(Math.Pow((maxx - minx), 2) + Math.Pow((maxy - miny), 2) + Math.Pow((maxz - minz), 2))
        seccio1 = Math.Truncate(longitud / Form19.NumericUpDown16.Value) + 1
        compoz = Form19.NumericUpDown16.Value * Math.Cos((pende(1) * Math.PI) / 180)
        compox = Form19.NumericUpDown16.Value * Math.Sin((azimu(1) * Math.PI) / 180)
        compoy = Form19.NumericUpDown16.Value * Math.Cos((azimu(1) * Math.PI) / 180)
        ReDim areatram(seccio1)
        For cont = 1 To seleccio - 1
            longitud = Math.Sqrt(Math.Pow((x(cont) - minx), 2) + Math.Pow((y(cont) - miny), 2) + Math.Pow((z(cont) - minz), 2))
            seccio = Math.Truncate(longitud / Form19.NumericUpDown16.Value) + 1
            areatram(seccio) = areatram(seccio) + areas(cont)
        Next cont
        valorx = minx : valory = miny : valorz = minz
        For cont = 1 To seccio1
            valorx = valorx + compox
            valory = valory + compoy
            valorz = valorz + compoz
            PrintLine(3, Format(valorx, "#.###"), Format(valory, "#.###"), Format(valorz, "#.###"), Format(azimu(1), "#.###"), Format(pende(1), "#.###"), Format(azimu(1), "#.###"), Format(pende(1), "#.###"), Format(areatram(cont), "#.###"))
        Next cont
        FileClose(3)
        FileClose(1)
        MsgBox("Grouping Completed")
errorhandler:
        Exit Sub
    End Sub
End Module
