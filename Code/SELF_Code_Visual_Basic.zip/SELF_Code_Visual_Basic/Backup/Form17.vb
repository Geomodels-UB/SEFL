﻿
Public Class Form17
    Public escollit As Integer
    Public coordenadax() As Integer
    Public coordenaday() As Integer
    Dim novcoorx As Integer
    Dim novcoory As Integer
    Dim state As Byte = 0
    Dim contador1 As Integer = 0
    Public zoomx As Integer = 250
    Public zoomy As Integer = 50
    Public radi As Integer = 600
    Public radi2 As Single
    Public pas As Boolean
    Dim formGraphics As System.Drawing.Graphics
    Dim formeGraphics As System.Drawing.Graphics
    Dim curvepoint As Point()
    Private m_points As New List(Of Point)
    Private ejx As Integer = 360
    Private ejy As Integer = 91
    Private maxvalue As Single
    Private minvalue As Single
    Private marc(360, 91) As Integer
    Public aper As Boolean
    Public conta As Integer
    Dim poi As Point
    Public prval2 As Boolean = True
    Public azi As Double
    Public di As Double
    Public i As Double
    Public j As Double
    Public k As Double
    Dim con As Integer
    Dim ss1 As Brush
    Dim points As Point
    Dim con2 As Integer
    Dim ps1 As Integer = 5
    Dim ps2 As Integer = 5
    Dim difere As Single
    Dim pasos As Integer
    Dim nx As Double
    Dim ny As Double
    Dim x1 As Double
    Dim y1 As Double
    Dim z1 As Double
    Dim ta As Double
    Dim td As Double
    Dim maxvalue2 As Single
    Public coord As New List(Of Point)
    Public lista As Point()
    Dim numfam As Integer = 0
    Dim res1 As Double
    Dim res2 As Double
    Dim res3 As Double
    Dim res4 As Double
    Dim pintarfamilies As Boolean
    Dim azi2 As Double
    Dim di2 As Double
    Dim r As Integer = 7
    Private Sub Form17_doubleclick(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.DoubleClick
        'tancar el poly
        'state=0 normal
        'state=1 pintar
        'state=2 editar
        'State=3
        Select Case state
            Case 1
                Button2.Enabled = True
                state = 0
                'If state = 1 Then
                formGraphics = Me.CreateGraphics()
                Dim llista(0 To coord.Count - 1) As Point
                coord.CopyTo(llista)
                If numfam = 1 Then formGraphics.DrawPolygon(Pens.Black, llista)
                If numfam = 2 Then formGraphics.DrawPolygon(Pens.DimGray, llista)
                If numfam = 3 Then formGraphics.DrawPolygon(Pens.White, llista)
                If numfam = 4 Then formGraphics.DrawPolygon(Pens.Maroon, llista)
                If numfam = 5 Then formGraphics.DrawPolygon(Pens.Firebrick, llista)
                If numfam = 6 Then formGraphics.DrawPolygon(Pens.LightCoral, llista)
                If numfam = 7 Then formGraphics.DrawPolygon(Pens.Tomato, llista)
                If numfam = 8 Then formGraphics.DrawPolygon(Pens.Sienna, llista)
                If numfam = 9 Then formGraphics.DrawPolygon(Pens.SandyBrown, llista)
                If numfam = 10 Then formGraphics.DrawPolygon(Pens.DarkGoldenrod, llista)
                If numfam = 11 Then formGraphics.DrawPolygon(Pens.YellowGreen, llista)
                If numfam = 12 Then formGraphics.DrawPolygon(Pens.Olive, llista)
                If numfam = 13 Then formGraphics.DrawPolygon(Pens.DarkKhaki, llista)
                If numfam = 14 Then formGraphics.DrawPolygon(Pens.OliveDrab, llista)
                If numfam = 15 Then formGraphics.DrawPolygon(Pens.DarkSeaGreen, llista)
                If numfam = 16 Then formGraphics.DrawPolygon(Pens.ForestGreen, llista)
                If numfam = 17 Then formGraphics.DrawPolygon(Pens.LimeGreen, llista)
                If numfam = 18 Then formGraphics.DrawPolygon(Pens.LightSeaGreen, llista)
                If numfam = 19 Then formGraphics.DrawPolygon(Pens.DarkSlateGray, llista)
                If numfam = 20 Then formGraphics.DrawPolygon(Pens.DeepSkyBlue, llista)
                If numfam = 21 Then formGraphics.DrawPolygon(Pens.MidnightBlue, llista)
                If numfam = 22 Then formGraphics.DrawPolygon(Pens.Violet, llista)
                If numfam = 23 Then formGraphics.DrawPolygon(Pens.DarkMagenta, llista)
                If numfam = 24 Then formGraphics.DrawPolygon(Pens.MediumVioletRed, llista)
                PrintLine(15, res1, res2, res3, res4)
                FileClose(15)
                coord.Clear()
                aper = False
                conta = 0
                Dim sa As String
                numfam = numfam + 1
                If numfam = 1 Then RadioButton1.Checked = True
                If numfam = 2 Then RadioButton2.Checked = True
                If numfam = 3 Then RadioButton3.Checked = True
                If numfam = 4 Then RadioButton4.Checked = True
                If numfam = 5 Then RadioButton5.Checked = True
                If numfam = 6 Then RadioButton6.Checked = True
                If numfam = 7 Then RadioButton7.Checked = True
                If numfam = 8 Then RadioButton8.Checked = True
                If numfam = 9 Then RadioButton9.Checked = True
                If numfam = 10 Then RadioButton10.Checked = True
                If numfam = 11 Then RadioButton11.Checked = True
                If numfam = 12 Then RadioButton12.Checked = True
                If numfam = 13 Then RadioButton13.Checked = True
                If numfam = 14 Then RadioButton14.Checked = True
                If numfam = 15 Then RadioButton15.Checked = True
                If numfam = 16 Then RadioButton17.Checked = True
                If numfam = 17 Then RadioButton18.Checked = True
                If numfam = 18 Then RadioButton19.Checked = True
                If numfam = 19 Then RadioButton20.Checked = True
                If numfam = 20 Then RadioButton21.Checked = True
                If numfam = 21 Then RadioButton22.Checked = True
                If numfam = 22 Then RadioButton23.Checked = True
                If numfam = 23 Then RadioButton24.Checked = True
                If numfam = 24 Then RadioButton25.Checked = True
                sa = numfam
                aper = True
                'FileOpen(15, Form10.TextBox1.Text + "Fam" + sa + ".txt", OpenMode.Output)
            Case 2
                Dim xx As Integer
                Dim dist As Double
                Dim dist2 As Double
                'Dim escollit As Double
                Dim distancia As Double = 1000
                For xx = 1 To contador1
                    dist = Math.Abs(coordenadax(xx) - e.X)
                    dist2 = Math.Abs(coordenaday(xx) - e.Y)
                    dist = Math.Sqrt((dist * dist) + (dist2 * dist2))
                    If dist < distancia Then
                        distancia = dist
                        escollit = xx
                    End If
                Next xx
                formGraphics = Me.CreateGraphics()
                formGraphics.FillEllipse(Brushes.Black, coordenadax(escollit) - 3, coordenaday(escollit) - 3, r + 1, r + 1)
                formGraphics.DrawEllipse(Pens.Black, coordenadax(escollit) - 3, coordenaday(escollit) - 3, r, r)
                state = 4
            Case 4
                Dim sa As String
                Dim lec(0) As Integer
                Dim lec1(0) As Integer
                Dim lec2(0) As Integer
                Dim lec3(0) As Integer
                Dim n As Integer
                'coord.Add(New Point(e.X, e.Y))
                'formGraphics = Me.CreateGraphics()
                'formGraphics.FillEllipse(Brushes.Cyan, e.X - 3, e.Y - 3, 7, 7)
                'formGraphics.DrawEllipse(Pens.Black, e.X - 3, e.Y - 3, 7, 7)
                'Dim cx As Double
                'Dim cx1 As Double
                'Dim cy As Double
                'Dim cy1 As Double
                'cx = ((-1 * e.X) + (zoomx + radi2)) / radi2
                'cy = ((-1 * e.Y) + (zoomy + radi2)) / radi2
                'cx1 = Math.Atan(cy / cx)
                'cx1 = (cx1 * 180) / Math.PI
                'cy1 = 90 - ((Math.Sqrt((cx * cx) + (cy * cy))) * 90)
                'If cx < 0 Then cx1 = 90 + cx1
                'If cx > 0 Then cx1 = cx1 + 270
                'If cy1 < 0 Then cy1 = 0
                'Label8.Text = Format(cx1, " 0.00")
                'Label9.Text = Format(cy1, " 0.00")
                'Label10.Text = 90 - Format(cy1, " 0.00")
                'If cx1 >= 180 Then Label11.Text = Format(-180 + cx1, " 0.00")
                'If cx1 < 180 Then Label11.Text = Format(cx1 + 180, " 0.00")
                contador1 = 0
                sa = numfam
                FileOpen(1, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Input)
                'FileOpen(2, Form10.TextBox1.Text + "Fam" + sa + ".txt", OpenMode.Output)
                Do Until EOF(1)
                    contador1 = contador1 + 1
                    ReDim Preserve lec(contador1)
                    ReDim Preserve lec1(contador1)
                    ReDim Preserve lec2(contador1)
                    ReDim Preserve lec3(contador1)
                    Input(1, lec(contador1))
                    Input(1, lec1(contador1))
                    Input(1, lec2(contador1))
                    Input(1, lec3(contador1))
                Loop
                FileClose(1)
                FileOpen(2, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Output)
                For n = 1 To contador1
                    If n <> escollit Then PrintLine(2, lec(n), lec1(n), lec2(n), lec3(n))
                Next n
                If escollit = 1 Then PrintLine(2, lec(2), lec1(2), lec2(2), lec3(2))
                FileClose(2)
                state = 2
        End Select
        'FileClose(15)
    End Sub
    Private Sub Form17_mousemove(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.MouseMove
        'dona la posicio del cursor
        Dim cx As Double
        Dim cx1 As Double
        Dim cy As Double
        Dim cy1 As Double
        cx = ((-1 * e.X) + (zoomx + radi2)) / radi2
        cy = ((-1 * e.Y) + (zoomy + radi2)) / radi2
        cx1 = Math.Atan(cy / cx)
        cx1 = (cx1 * 180) / Math.PI
        cy1 = 90 - ((Math.Sqrt((cx * cx) + (cy * cy))) * 90)
        If cx < 0 Then cx1 = 90 + cx1
        If cx > 0 Then cx1 = cx1 + 270
        If cy1 < 0 Then cy1 = 0
        'Label8.Text = Format(cx1, "0.00")
        Label9.Text = Format(cy1, "0.00")
        Label10.Text = Format(90 - cy1, "0.00")
        Select Case cx1
            Case Is >= 180
                Label11.Text = Format(-180 + cx1, "0.00")
                Label8.Text = Format(cx1, "0.00")
            Case 90.01 To 180
                Label11.Text = Format(cx1 + 180, "0.00")
                Label8.Text = Format(cx1, "0.00")
            Case 90
                Label11.Text = Format(cx1 + 90, "0.00")
                Label8.Text = Format(cx1 - 90, "0.00")
            Case 0 To 89.99
                Label11.Text = Format(cx1 + 180, "0.00")
                Label8.Text = Format(cx1, "0.00")
            Case -90
                Label11.Text = Format(cx1 + 90, "0.00")
                Label8.Text = Format(cx1 + 270, "0.00")
        End Select
        'If cx1 >= 180 Then Label11.Text = Format(-180 + cx1, "0.00")
        'If cx1 < 180 And cx1 <> -90 Then Label11.Text = Format(cx1 + 180, "0.00")
    End Sub
    Private Sub Form17_click(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.Click
        'traça linea
        Select Case state
            Case 1
                coord.Add(New Point(e.X, e.Y))
                formGraphics = Me.CreateGraphics()
                formGraphics.FillEllipse(Brushes.Cyan, e.X - 3, e.Y - 3, r, r)
                formGraphics.DrawEllipse(Pens.Black, e.X - 3, e.Y - 3, r, r)
                Dim coopoint As New Point 'no se perqué serveix
                Dim cx As Double
                Dim cx1 As Double
                Dim cy As Double
                Dim cy1 As Double
                cx = ((-1 * e.X) + (zoomx + radi2)) / radi2
                cy = ((-1 * e.Y) + (zoomy + radi2)) / radi2
                cx1 = Math.Atan(cy / cx)
                cx1 = (cx1 * 180) / Math.PI
                cy1 = 90 - ((Math.Sqrt((cx * cx) + (cy * cy))) * 90)
                If cx < 0 Then cx1 = 90 + cx1
                If cx > 0 Then cx1 = cx1 + 270
                If cy1 < 0 Then cy1 = 0
                'Label8.Text = Format(cx1, "0")
                Label9.Text = Format(cy1, "0")
                Label10.Text = 90 - Format(cy1, "0")
                Select Case cx1
                    Case Is >= 180
                        Label11.Text = Format(-180 + cx1, "0")
                        Label8.Text = Format(cx1, "0")
                    Case 90.01 To 180
                        Label11.Text = Format(cx1 + 180, "0")
                        Label8.Text = Format(cx1, "0")
                    Case 90
                        Label11.Text = Format(cx1 + 90, "0")
                        Label8.Text = Format(cx1 - 90, "0")
                    Case 0 To 89.99
                        Label11.Text = Format(cx1 + 180, "0")
                        Label8.Text = Format(cx1, "0")
                    Case -90
                        Label11.Text = Format(cx1 + 90, "0")
                        Label8.Text = Format(cx1 + 270, "0")
                End Select
                If aper = True Then
                    If conta = 0 Then
                        poi.X = e.X
                        poi.Y = e.Y
                        res1 = Label11.Text
                        res2 = Label10.Text
                        res3 = e.X
                        res4 = e.Y
                    End If
                    If conta > 0 Then
                        formGraphics.DrawLine(Pens.Blue, e.X, e.Y, poi.X, poi.Y)
                    End If
                    poi.X = e.X
                    poi.Y = e.Y
                    conta = conta + 1
                    PrintLine(15, Label11.Text, Label10.Text, e.X, e.Y)
                End If
                'If prval2 = True Then
                ' azi = Label11.Text
                ' di = Label10.Text
                ' End If
                ' 'primer parell
                ' If prval2 = True Then
                ' azi = (azi * Math.PI) / 180
                ' di = (di * Math.PI) / 180
                ' i = Math.Sin(azi)
                ' j = Math.Cos(azi)
                ' k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
                ' If k > 100000 Then k = 99999.999999999
                ' If azi = 0 And di = 0 Then
                ' i = 0
                ' j = 0
                '  k = 0
                '  End If
                'prval2 = False
                'End If

            Case 2
                'editar els poligons
                '1.busqueda del punt
                Dim xx As Integer
                Dim dist As Double
                Dim dist2 As Double
                'Dim escollit As Double
                Dim distancia As Double = 1000
                For xx = 1 To contador1  'falla
                    dist = Math.Abs(coordenadax(xx) - e.X)
                    dist2 = Math.Abs(coordenaday(xx) - e.Y)
                    dist = Math.Sqrt((dist * dist) + (dist2 * dist2))
                    If dist < distancia Then
                        distancia = dist
                        escollit = xx
                    End If
                Next xx
                formGraphics = Me.CreateGraphics()
                formGraphics.FillEllipse(Brushes.Yellow, coordenadax(escollit) - 3, coordenaday(escollit) - 3, r + 1, r + 1)
                formGraphics.DrawEllipse(Pens.Black, coordenadax(escollit) - 3, coordenaday(escollit) - 3, r, r)
                state = 4
            Case 4
                Dim sa As String
                Dim xx As Integer
                Dim lec(0) As Integer
                Dim lec1(0) As Integer
                Dim lec2(0) As Integer
                Dim lec3(0) As Integer
                coord.Add(New Point(e.X, e.Y))
                formGraphics = Me.CreateGraphics()
                formGraphics.FillEllipse(Brushes.Cyan, e.X - 3, e.Y - 3, r, r)
                formGraphics.DrawEllipse(Pens.Black, e.X - 3, e.Y - 3, r, r)
                Dim cx As Double
                Dim cx1 As Double
                Dim cy As Double
                Dim cy1 As Double
                cx = ((-1 * e.X) + (zoomx + radi2)) / radi2
                cy = ((-1 * e.Y) + (zoomy + radi2)) / radi2
                cx1 = Math.Atan(cy / cx)
                cx1 = (cx1 * 180) / Math.PI
                cy1 = 90 - ((Math.Sqrt((cx * cx) + (cy * cy))) * 90)
                If cx < 0 Then cx1 = 90 + cx1
                If cx > 0 Then cx1 = cx1 + 270
                If cy1 < 0 Then cy1 = 0
                'Label8.Text = Format(cx1, " 0")
                Label9.Text = Format(cy1, " 0")
                Label10.Text = 90 - Format(cy1, " 0")
                Select Case cx1
                    Case Is >= 180
                        Label11.Text = Format(-180 + cx1, "0")
                        Label8.Text = Format(cx1, "0")
                    Case 90.01 To 180
                        Label11.Text = Format(cx1 + 180, "0")
                        Label8.Text = Format(cx1, "0")
                    Case 90
                        Label11.Text = Format(cx1 + 90, "0")
                        Label8.Text = Format(cx1 - 90, "0")
                    Case 0 To 89.99
                        Label11.Text = Format(cx1 + 180, "0")
                        Label8.Text = Format(cx1, "0")
                    Case -90
                        Label11.Text = Format(cx1 + 90, "0")
                        Label8.Text = Format(cx1 + 270, "0")
                End Select
                contador1 = 0
                sa = numfam
                FileOpen(1, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Input)
                Do Until EOF(1)
                    contador1 = contador1 + 1
                    ReDim Preserve lec(contador1)
                    ReDim Preserve lec1(contador1)
                    ReDim Preserve lec2(contador1)
                    ReDim Preserve lec3(contador1)
                    Input(1, lec(contador1))
                    Input(1, lec1(contador1))
                    Input(1, lec2(contador1))
                    Input(1, lec3(contador1))
                Loop
                FileClose(1)
                FileOpen(1, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Output)
                If escollit = 1 Then
                    'PrintLine(1, Label8.Text, Label11.Text, e.X, e.Y)
                    contador1 = contador1 - 1
                End If
                For xx = 1 To contador1
                    If xx = escollit Then
                        PrintLine(1, Label11.Text, Label10.Text, e.X, e.Y)
                    Else
                        PrintLine(1, lec(xx), lec1(xx), lec2(xx), lec3(xx))
                    End If
                Next xx
                If escollit = 1 Then PrintLine(1, Label11.Text, Label10.Text, e.X, e.Y)
                FileClose(1)
                state = 2
        End Select
    End Sub

    Private Sub Form17_sPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint
        radi2 = radi / 2
        e.Graphics.FillEllipse(Brushes.White, zoomx, zoomy, radi + 0, radi + 0)
        e.Graphics.DrawLine(Pens.Black, zoomx + radi2, zoomy, zoomx + radi2, zoomy - 20)
        e.Graphics.DrawLine(Pens.Black, zoomx + radi2 - 10, zoomy + radi2, zoomx + radi2 + 10, zoomy + radi2)
        e.Graphics.DrawLine(Pens.Black, zoomx + radi2, zoomy + radi2 - 10, zoomx + radi2, zoomy + radi2 + 10)
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        'Load file statistic
        numfam = 0
        formeGraphics = Me.CreateGraphics()
        radi2 = radi / 2
        'fitxer
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.InitialDirectory = Form10.TextBox1.Text
        openFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, openFileDialog1.FileName, OpenMode.Input)
        'fi fitxer
        maxvalue = 0
        minvalue = 0
        'carregar informacio a marc(ejx,ejy)
        Do Until EOF(1)
            Input(1, ejx)
            Input(1, ejy)
            Input(1, marc(ejx, ejy))
            If marc(ejx, ejy) >= maxvalue Then maxvalue = marc(ejx, ejy)
            If ejx = 360 Then marc(360, ejy) = marc(360, ejy) + marc(0, ejy)
        Loop
        FileClose(1)
        'carregada la informacio
        pas = True
        NumericUpDown21.Value = maxvalue
        NumericUpDown22.Value = minvalue
        If CheckBox1.Checked = True Then
            maxvalue = NumericUpDown21.Value
            minvalue = NumericUpDown22.Value
        End If
        difere = maxvalue - minvalue
        pasos = maxvalue / 10
        pasos = difere / 10
        NumericUpDown2.Value = Math.Abs(pasos)
        NumericUpDown3.Value = Math.Abs(pasos) + 1
        NumericUpDown4.Value = 2 * (Math.Abs(pasos))
        NumericUpDown5.Value = 2 * (Math.Abs(pasos)) + 1
        NumericUpDown6.Value = 3 * (Math.Abs(pasos))
        NumericUpDown7.Value = (3 * (Math.Abs(pasos))) + 1
        NumericUpDown8.Value = 4 * (Math.Abs(pasos))
        NumericUpDown9.Value = (4 * (Math.Abs(pasos))) + 1
        NumericUpDown10.Value = 5 * (Math.Abs(pasos))
        NumericUpDown11.Value = (5 * (Math.Abs(pasos))) + 1
        NumericUpDown12.Value = 6 * (Math.Abs(pasos))
        NumericUpDown13.Value = (6 * (Math.Abs(pasos))) + 1
        NumericUpDown14.Value = 7 * (Math.Abs(pasos))
        NumericUpDown15.Value = (7 * (Math.Abs(pasos))) + 1
        NumericUpDown16.Value = 8 * (Math.Abs(pasos))
        NumericUpDown17.Value = (8 * (Math.Abs(pasos))) + 1
        NumericUpDown18.Value = 9 * (Math.Abs(pasos))
        NumericUpDown19.Value = (9 * (Math.Abs(pasos))) + 1
        NumericUpDown20.Value = maxvalue

        For con = 1 To 360
            For con2 = 0 To 89
                ta = (con - 180) * (Math.PI / 180)
                td = (90 - con2) * (Math.PI / 180)
                z1 = -(Math.Sin(td))
                x1 = Math.Cos(td) * Math.Cos(ta)
                y1 = Math.Cos(td) * Math.Sin(ta)
                nx = 1 * (y1 * Math.Sqrt(1 / (1 - z1)))
                ny = -1 * (x1 * Math.Sqrt(1 / (1 - z1)))
                points.X = radi2 * nx + zoomx + radi2 - 2
                points.Y = radi2 * ny + zoomy + radi2 - 2
                pas = False
                Select Case marc(con, con2)
                    Case 0 To Math.Abs(pasos)
                        Me.CreateGraphics.FillEllipse(Brushes.Lime, points.X, points.Y, ps1, ps2)
                    Case Math.Abs(pasos) + 1 To 2 * (Math.Abs(pasos))
                        Me.CreateGraphics.FillEllipse(Brushes.GreenYellow, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown5.Value To NumericUpDown6.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Yellow, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown7.Value To NumericUpDown8.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Orange, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown9.Value To NumericUpDown10.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Red, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown11.Value To NumericUpDown12.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Fuchsia, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown13.Value To NumericUpDown14.Value
                        Me.CreateGraphics.FillEllipse(Brushes.DarkViolet, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown15.Value To NumericUpDown16.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Blue, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown17.Value To NumericUpDown18.Value
                        Me.CreateGraphics.FillEllipse(Brushes.LightSkyBlue, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown19.Value To NumericUpDown20.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Cyan, points.X, points.Y, ps1, ps2)
                    Case Else
                        con = con
                End Select
            Next con2
        Next con
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy, zoomx + radi2, zoomy - 20)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2 - 10, zoomy + radi2, zoomx + radi2 + 10, zoomy + radi2)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy + radi2 - 10, zoomx + radi2, zoomy + radi2 + 10)

errorhandler:
        Exit Sub
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'activa pintar familes
        Button2.Enabled = False
        state = 1
        If RadioButton1.Checked = True Then numfam = 1
        If RadioButton2.Checked = True Then numfam = 2
        If RadioButton3.Checked = True Then numfam = 3
        If RadioButton4.Checked = True Then numfam = 4
        If RadioButton5.Checked = True Then numfam = 5
        If RadioButton6.Checked = True Then numfam = 6
        If RadioButton7.Checked = True Then numfam = 7
        If RadioButton8.Checked = True Then numfam = 8
        If RadioButton9.Checked = True Then numfam = 9
        If RadioButton10.Checked = True Then numfam = 10
        If RadioButton11.Checked = True Then numfam = 11
        If RadioButton12.Checked = True Then numfam = 12
        If RadioButton13.Checked = True Then numfam = 13
        If RadioButton14.Checked = True Then numfam = 14
        If RadioButton15.Checked = True Then numfam = 15
        If RadioButton17.Checked = True Then numfam = 16
        If RadioButton18.Checked = True Then numfam = 17
        If RadioButton19.Checked = True Then numfam = 18
        If RadioButton20.Checked = True Then numfam = 19
        If RadioButton21.Checked = True Then numfam = 20
        If RadioButton22.Checked = True Then numfam = 21
        If RadioButton23.Checked = True Then numfam = 22
        If RadioButton24.Checked = True Then numfam = 23
        If RadioButton25.Checked = True Then numfam = 24
        Dim sa As String
        pintarfamilies = True 'no se perqué serveix
        sa = numfam
        If numfam <= 24 Then FileOpen(15, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Output)
        'numfam = numfam + 1
        If numfam = 1 Then RadioButton1.Checked = True
        If numfam = 2 Then RadioButton2.Checked = True
        If numfam = 3 Then RadioButton3.Checked = True
        If numfam = 4 Then RadioButton4.Checked = True
        If numfam = 5 Then RadioButton5.Checked = True
        If numfam = 6 Then RadioButton6.Checked = True
        If numfam = 7 Then RadioButton7.Checked = True
        If numfam = 8 Then RadioButton8.Checked = True
        If numfam = 9 Then RadioButton9.Checked = True
        If numfam = 10 Then RadioButton10.Checked = True
        If numfam = 11 Then RadioButton11.Checked = True
        If numfam = 12 Then RadioButton12.Checked = True
        If numfam = 13 Then RadioButton13.Checked = True
        If numfam = 14 Then RadioButton14.Checked = True
        If numfam = 15 Then RadioButton15.Checked = True
        If numfam = 16 Then RadioButton17.Checked = True
        If numfam = 17 Then RadioButton18.Checked = True
        If numfam = 18 Then RadioButton19.Checked = True
        If numfam = 19 Then RadioButton20.Checked = True
        If numfam = 20 Then RadioButton21.Checked = True
        If numfam = 21 Then RadioButton22.Checked = True
        If numfam = 22 Then RadioButton23.Checked = True
        If numfam = 23 Then RadioButton24.Checked = True
        If numfam = 24 Then RadioButton25.Checked = True
        sa = numfam 'ja esta fet
        aper = True
        'If numfam <= 15 Then FileOpen(15, Form10.TextBox1.Text + "Fam" + sa + ".txt", OpenMode.Output)
    End Sub
    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        'refresh
        formeGraphics = Me.CreateGraphics()
        Dim sa As String
        ' zoomy = 50
        ' radi = 600
        radi2 = radi / 2
        maxvalue2 = maxvalue
        formeGraphics.FillEllipse(Brushes.White, zoomx, zoomy, radi + 0, radi + 0)
        If CheckBox1.Checked = True Then
            maxvalue2 = maxvalue
            maxvalue = NumericUpDown21.Value
            minvalue = NumericUpDown22.Value
            'End If
            'minvalue = 0
            'maxvalue = maxvalue2
            'End If
            difere = maxvalue - minvalue
            pasos = maxvalue / 10
            pasos = difere / 10
            NumericUpDown1.Value = minvalue
            NumericUpDown2.Value = Math.Abs(pasos)
            NumericUpDown3.Value = Math.Abs(pasos) + 1
            NumericUpDown4.Value = 2 * (Math.Abs(pasos))
            NumericUpDown5.Value = 2 * (Math.Abs(pasos)) + 1
            NumericUpDown6.Value = 3 * (Math.Abs(pasos))
            NumericUpDown7.Value = (3 * (Math.Abs(pasos))) + 1
            NumericUpDown8.Value = 4 * (Math.Abs(pasos))
            NumericUpDown9.Value = (4 * (Math.Abs(pasos))) + 1
            NumericUpDown10.Value = 5 * (Math.Abs(pasos))
            NumericUpDown11.Value = (5 * (Math.Abs(pasos))) + 1
            NumericUpDown12.Value = 6 * (Math.Abs(pasos))
            NumericUpDown13.Value = (6 * (Math.Abs(pasos))) + 1
            NumericUpDown14.Value = 7 * (Math.Abs(pasos))
            NumericUpDown15.Value = (7 * (Math.Abs(pasos))) + 1
            NumericUpDown16.Value = 8 * (Math.Abs(pasos))
            NumericUpDown17.Value = (8 * (Math.Abs(pasos))) + 1
            NumericUpDown18.Value = 9 * (Math.Abs(pasos))
            NumericUpDown19.Value = (9 * (Math.Abs(pasos))) + 1
            NumericUpDown20.Value = maxvalue

        End If

        For con = 1 To 360
            For con2 = 0 To 89
                ta = (con - 180) * (Math.PI / 180)
                td = (90 - con2) * (Math.PI / 180)
                z1 = -(Math.Sin(td))
                x1 = Math.Cos(td) * Math.Cos(ta)
                y1 = Math.Cos(td) * Math.Sin(ta)
                nx = 1 * (y1 * Math.Sqrt(1 / (1 - z1)))
                ny = -1 * (x1 * Math.Sqrt(1 / (1 - z1)))
                points.X = radi2 * nx + zoomx + radi2 - 2
                points.Y = radi2 * ny + zoomy + radi2 - 2
                pas = False
                Select Case marc(con, con2)
                    Case NumericUpDown1.Value To NumericUpDown2.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Lime, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown3.Value To NumericUpDown4.Value
                        Me.CreateGraphics.FillEllipse(Brushes.GreenYellow, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown5.Value To NumericUpDown6.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Yellow, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown7.Value To NumericUpDown8.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Orange, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown9.Value To NumericUpDown10.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Red, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown11.Value To NumericUpDown12.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Fuchsia, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown13.Value To NumericUpDown14.Value
                        Me.CreateGraphics.FillEllipse(Brushes.DarkViolet, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown15.Value To NumericUpDown16.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Blue, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown17.Value To NumericUpDown18.Value
                        Me.CreateGraphics.FillEllipse(Brushes.LightSkyBlue, points.X, points.Y, ps1, ps2)
                    Case NumericUpDown19.Value To NumericUpDown20.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Cyan, points.X, points.Y, ps1, ps2)
                    Case Else
                End Select
            Next con2
        Next con
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy, zoomx + radi2, zoomy - 20)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2 - 10, zoomy + radi2, zoomx + radi2 + 10, zoomy + radi2)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy + radi2 - 10, zoomx + radi2, zoomy + radi2 + 10)
        'Pintar familes
        Dim po1 As Point
        Dim po2 As Point
        Dim contador As Integer
        Dim inutil As Double
        For contador = 1 To 15
            If RadioButton1.Checked = True Then numfam = 1
            If RadioButton2.Checked = True Then numfam = 2
            If RadioButton3.Checked = True Then numfam = 3
            If RadioButton4.Checked = True Then numfam = 4
            If RadioButton5.Checked = True Then numfam = 5
            If RadioButton6.Checked = True Then numfam = 6
            If RadioButton7.Checked = True Then numfam = 7
            If RadioButton8.Checked = True Then numfam = 8
            If RadioButton9.Checked = True Then numfam = 9
            If RadioButton10.Checked = True Then numfam = 10
            If RadioButton11.Checked = True Then numfam = 11
            If RadioButton12.Checked = True Then numfam = 12
            If RadioButton13.Checked = True Then numfam = 13
            If RadioButton14.Checked = True Then numfam = 14
            If RadioButton15.Checked = True Then numfam = 15
            If RadioButton17.Checked = True Then numfam = 16
            If RadioButton18.Checked = True Then numfam = 17
            If RadioButton19.Checked = True Then numfam = 18
            If RadioButton20.Checked = True Then numfam = 19
            If RadioButton21.Checked = True Then numfam = 20
            If RadioButton22.Checked = True Then numfam = 21
            If RadioButton23.Checked = True Then numfam = 22
            If RadioButton24.Checked = True Then numfam = 23
            If RadioButton25.Checked = True Then numfam = 24
        Next contador
        If numfam > 0 Then
            For contador = 1 To numfam
                sa = contador
                FileOpen(1, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Input)
                On Error GoTo errorhandler
                Input(1, inutil)
                Input(1, inutil)
                Input(1, po1.X)
                Input(1, po1.Y)
                formeGraphics.FillEllipse(Brushes.Cyan, po1.X - 3, po1.Y - 3, r, r)
                formeGraphics.DrawEllipse(Pens.Black, po1.X - 3, po1.Y - 3, r, r)
                Do Until EOF(1)
                    Input(1, inutil)
                    Input(1, inutil)
                    Input(1, po2.X)
                    Input(1, po2.Y)
                    formeGraphics.FillEllipse(Brushes.Cyan, po2.X - 3, po2.Y - 3, r, r)
                    formeGraphics.DrawEllipse(Pens.Black, po2.X - 3, po2.Y - 3, r, r)
                    If contador = 1 Then formeGraphics.DrawLine(Pens.Black, po1, po2)
                    If contador = 2 Then formeGraphics.DrawLine(Pens.DimGray, po1, po2)
                    If contador = 3 Then formeGraphics.DrawLine(Pens.White, po1, po2)
                    If contador = 4 Then formeGraphics.DrawLine(Pens.Maroon, po1, po2)
                    If contador = 5 Then formeGraphics.DrawLine(Pens.Firebrick, po1, po2)
                    If contador = 6 Then formeGraphics.DrawLine(Pens.LightCoral, po1, po2)
                    If contador = 7 Then formeGraphics.DrawLine(Pens.Tomato, po1, po2)
                    If contador = 8 Then formeGraphics.DrawLine(Pens.Sienna, po1, po2)
                    If contador = 9 Then formeGraphics.DrawLine(Pens.SandyBrown, po1, po2)
                    If contador = 10 Then formeGraphics.DrawLine(Pens.DarkGoldenrod, po1, po2)
                    If contador = 11 Then formeGraphics.DrawLine(Pens.YellowGreen, po1, po2)
                    If contador = 12 Then formeGraphics.DrawLine(Pens.Olive, po1, po2)
                    If contador = 13 Then formeGraphics.DrawLine(Pens.DarkKhaki, po1, po2)
                    If contador = 14 Then formeGraphics.DrawLine(Pens.OliveDrab, po1, po2)
                    If contador = 15 Then formeGraphics.DrawLine(Pens.DarkSeaGreen, po1, po2)
                    If contador = 16 Then formeGraphics.DrawLine(Pens.ForestGreen, po1, po2)
                    If contador = 17 Then formeGraphics.DrawLine(Pens.LimeGreen, po1, po2)
                    If contador = 18 Then formeGraphics.DrawLine(Pens.LightSeaGreen, po1, po2)
                    If contador = 19 Then formeGraphics.DrawLine(Pens.DarkSlateGray, po1, po2)
                    If contador = 20 Then formeGraphics.DrawLine(Pens.DeepSkyBlue, po1, po2)
                    If contador = 21 Then formeGraphics.DrawLine(Pens.MidnightBlue, po1, po2)
                    If contador = 22 Then formeGraphics.DrawLine(Pens.Violet, po1, po2)
                    If contador = 23 Then formeGraphics.DrawLine(Pens.DarkMagenta, po1, po2)
                    If contador = 24 Then formeGraphics.DrawLine(Pens.MediumVioletRed, po1, po2)
 


                    po1.X = po2.X
                    po1.Y = po2.Y
                Loop
                FileClose(1)
            Next contador
        End If
errorhandler:
        Exit Sub
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        aper = False
        'FileClose(15)
        Me.Close()
        Form9.Show()
    End Sub



    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub



    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        zoomx = zoomx + 100
    End Sub




    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        ' mesura l'amglr
        state = 5
        Dim i2 As Double
        Dim j2 As Double
        Dim k2 As Double
        Dim azi2 As Double
        Dim di2 As Double
        Dim ang As Double
        If prval2 = False Then
            azi2 = Label11.Text
            di2 = Label10.Text
            azi2 = (azi2 * Math.PI) / 180
            di2 = (di2 * Math.PI) / 180
            i2 = Math.Sin(azi2)
            j2 = Math.Cos(azi2)
            k2 = Math.Sqrt(((i2 * i2) + (j2 * j2)) / (Math.Tan(di2) * (Math.Tan(di2))))
            If k2 > 100000 Then k2 = 99999.999999999
            If azi2 = 0 And di2 = 0 Then
                i2 = 0
                j2 = 0
                k2 = 0
            End If
            prval2 = True
        End If
        ang = Math.Acos(Math.Abs(((i * i2) + (j * j2) + (k * k2)) / (Math.Sqrt((i * i) + (j * j) + (k * k)) * Math.Sqrt((i2 * i2) + (j2 * j2) + (k2 * k2)))))
        ang = (ang * 180) / Math.PI
        Label12.Text = Format(ang, "0.00")

    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        'Editar poligons
        state = 2
        formeGraphics = Me.CreateGraphics()
        Dim inutil As Integer
        Dim sa As String
        Dim po As Point
        If RadioButton1.Checked = True Then numfam = 1
        If RadioButton2.Checked = True Then numfam = 2
        If RadioButton3.Checked = True Then numfam = 3
        If RadioButton4.Checked = True Then numfam = 4
        If RadioButton5.Checked = True Then numfam = 5
        If RadioButton6.Checked = True Then numfam = 6
        If RadioButton7.Checked = True Then numfam = 7
        If RadioButton8.Checked = True Then numfam = 8
        If RadioButton9.Checked = True Then numfam = 9
        If RadioButton10.Checked = True Then numfam = 10
        If RadioButton11.Checked = True Then numfam = 11
        If RadioButton12.Checked = True Then numfam = 12
        If RadioButton13.Checked = True Then numfam = 13
        If RadioButton14.Checked = True Then numfam = 14
        If RadioButton15.Checked = True Then numfam = 15
        If RadioButton17.Checked = True Then numfam = 16
        If RadioButton18.Checked = True Then numfam = 17
        If RadioButton19.Checked = True Then numfam = 18
        If RadioButton20.Checked = True Then numfam = 19
        If RadioButton21.Checked = True Then numfam = 20
        If RadioButton22.Checked = True Then numfam = 21
        If RadioButton23.Checked = True Then numfam = 22
        If RadioButton24.Checked = True Then numfam = 23
        If RadioButton25.Checked = True Then numfam = 24
        sa = numfam
        FileClose(1)
        FileOpen(1, Form10.TextBox1.Text + "SetPoly" + sa + ".txt", OpenMode.Input)
        contador1 = 0
        Do Until EOF(1)
            contador1 = contador1 + 1
            Input(1, inutil)
            Input(1, inutil)
            Input(1, po.X)
            Input(1, po.Y)
            formeGraphics.FillEllipse(Brushes.Red, po.X - 3, po.Y - 3, r, r)
            ReDim Preserve coordenadax(contador1)
            ReDim Preserve coordenaday(contador1)
            coordenadax(contador1) = po.X
            coordenaday(contador1) = po.Y
        Loop
        FileClose(1)
    End Sub
    '  Private Sub Form17_mouseclick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseClick
    '      m_points.Add(New Point(e.X, e.Y))
    '      formeGraphics.FillEllipse(Brushes.Cyan, e.X - 3, e.Y - 3, 7, 7)
    '      formeGraphics.DrawEllipse(Pens.Black, e.X - 3, e.Y - 3, 7, 7)
    '  Dim hull As List(Of Point) = Nothing
    '      If m_points.Count >= 2 Then
    '          Using hull_pen As New Pen(Color.Blue, 3)
    '  Dim hull_points(0 To m_points.Count - 1) As Point
    '              m_points.CopyTo(hull_points)
    '              formeGraphics.DrawPolygon(hull_pen, hull_points)
    '              m_points.RemoveAt(0)
    '          End Using
    '      End If
    '  End Sub

    Private Sub Form17_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        TextBox1.Text = radi
        TextBox2.Text = zoomx
        TextBox3.Text = zoomy
        TextBox4.Text = r
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged

    End Sub

    Private Sub RadioButton16_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton16.CheckedChanged
        If RadioButton16.Checked = True Then numfam = 0

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged

    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click

    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click

    End Sub

    Private Sub Button15_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button15_Click_2(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton24_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton24.CheckedChanged

    End Sub

    Private Sub RadioButton7_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton7.CheckedChanged

    End Sub

    Private Sub RadioButton17_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton17.CheckedChanged

    End Sub

    Private Sub RadioButton25_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton25.CheckedChanged

    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub

    Private Sub RadioButton18_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton18.CheckedChanged

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button15_Click_3(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        radi = TextBox1.Text
        zoomx = TextBox2.Text
        zoomy = TextBox3.Text
        r = TextBox4.Text
    End Sub
End Class
