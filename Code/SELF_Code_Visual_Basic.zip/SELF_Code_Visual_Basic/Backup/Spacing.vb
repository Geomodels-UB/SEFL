﻿Module Spacing
    Public mean1 As Double
    Public mean2 As Double
    Public mean3 As Double
    Public mean4 As Double
    Public mean5 As Double
    Public mean6 As Double
    Public mean7 As Double
    Public mean8 As Integer
    Public mean9 As String

    Public pucont As Integer = 0
    Public bipolar As Boolean = False
    Public vectori3(), vectorj3(), vectork3() As Double
    Public D1() As Double
    Public D2 As Double
    Public selection() As Integer
    Public distr() As Double
    Public veci1(), vecj1(), veck1() As Double
    Public Vec1b, Vec2b, Vec3b As Double
    Public dipfunc, dirfunc As Double
    ' Public dipfunc2, dirfunc2 As Double
    Public vector_i, vector_j, vector_k As Double
    Public cx1, cy1, cz1 As New List(Of Double)
    Public vx1, vy1, vz1 As New List(Of Double)
    Public vi1, vj1, vk1 As New List(Of Double)
    Public dipdir1, dip1, M1, K1 As New List(Of Double)
    Public Population1, Number1 As New List(Of Integer)
    Public Rugosity1, Wide1, Long1, Area1 As New List(Of Double)
    Public Set1 As New List(Of String)
    '  Public Set2 As New List(Of String)
    '  Public Set3 As New List(Of String)
    Public orienpla2 As Double
    Public pendpla2 As Double
    Public orienpla1 As Double
    Public pendpla1 As Double
    Public vecipla2, vecjpla2, veckpla2 As Double
    Public vecipla1, vecjpla1, veckpla1 As Double
    Public puntcontactexr(), puntcontacteyr(), puntcontactezr() As Double
    Dim at As Double
    Dim bt As Double
    Dim ct As Double
    Dim distreal() As Double
    Dim chiv1 As Boolean = False 'false=vector spacing  true=points density
    Dim numberofplans As Integer
    Dim d(3) As Double
    Public setna As String
    Public indat As Boolean

    Sub readmorphology()
        FileClose(2)
        FileClose(3)
        '  FileClose(5)
        '  Dim selection() As Integer
        Dim contadorSet As Integer = 0
        Dim mummy1 As Double
        Dim mummy2 As Integer
        Dim mummy As String
        Dim setname(0) As String
        Dim num As Integer = 0
        Dim i As Integer = 0
        Dim ii As Integer = 0
        Dim n As Integer = -1
        Dim openFileDialog1 As New OpenFileDialog()
        Dim openFileDialog2 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog2.Title = "Open Morphology File to Spacing.ts"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        FileOpen(2, openFileDialog2.FileName, OpenMode.Input)
        FileOpen(3, Form10.TextBox1.Text + "Spac_Density" + "_" + Form27.TextBox1.Text + "_" + Form27.TextBox2.Text + "_" + Form27.TextBox3.Text + ".txt", OpenMode.Output)
        ' FileOpen(5, Form10.TextBox1.Text + "Spac_Density_Resume" + "_" + Form27.TextBox1.Text + "_" + Form27.TextBox2.Text + "_" + Form27.TextBox3.Text + ".txt", OpenMode.Output)

        On Error GoTo ErrorHandler
        mummy = LineInput(2)
        Do While Not EOF(2)
            Input(2, mummy1)
            cx1.Add(mummy1)
            Input(2, mummy1)
            cy1.Add(mummy1)
            Input(2, mummy1)
            cz1.Add(mummy1)
            Input(2, mummy1)
            vx1.Add(mummy1)
            Input(2, mummy1)
            vy1.Add(mummy1)
            Input(2, mummy1)
            vz1.Add(mummy1)
            Input(2, mummy1)
            dipdir1.Add(mummy1)
            Input(2, mummy1)
            dip1.Add(mummy1)
            Input(2, mummy1)
            M1.Add(mummy1)
            Input(2, mummy1)
            K1.Add(mummy1)
            Input(2, mummy2)
            Population1.Add(mummy2)
            Input(2, mummy2)
            Number1.Add(mummy2)
            Input(2, mummy1)
            Rugosity1.Add(mummy1)
            Input(2, mummy1)
            Wide1.Add(mummy1)
            Input(2, mummy1)
            Long1.Add(mummy1)
            Input(2, mummy1)
            Area1.Add(mummy1)
            Input(2, mummy)
            Set1.Add(mummy)
        Loop
        FileClose(2)
        'Averiguar quants Sets diferents hi han i el número d'items queda a contadorset, el nom a setname
        setname(contadorSet) = Set1.Item(0)
        Dim chivato = False
        For i = 1 To Set1.Count - 1
            For ii = 0 To contadorSet
                If Set1.Item(i) <> setname(ii) Then
                    chivato = True
                Else
                    ii = contadorSet
                    chivato = False
                End If
            Next
            If chivato = True Then
                contadorSet += 1
                ReDim Preserve setname(contadorSet)
                setname(contadorSet) = Set1.Item(i)
                ii = contadorSet
                chivato = False
            End If
        Next
        PrintLine(3, "File:", TAB(40), openFileDialog2.FileName)
        PrintLine(3, "Unit:", TAB(40), Form27.TextBox1.Text)
        PrintLine(3, "Sector:", TAB(40), Form27.TextBox2.Text)
        PrintLine(5, "Unit:", Form27.TextBox1.Text, "Sector:", Form27.TextBox2.Text)
        PrintLine(3, "")
        'Ara treballa en cada contadorSet, i els item a selection(). El número d'items a selection.lenght
        For ii = 0 To contadorSet
            For i = 0 To Set1.Count - 1
                If Set1.Item(i) = setname(ii) Then
                    n += 1
                    ReDim Preserve selection(n)
                    selection(n) = i
                End If
            Next
            PrintLine(3, setname(ii) + ":")
            setna = setname(ii)
            PrintLine(3, "")
            Select Case Form27.CheckBox4.Checked
                Case True
                    PrintLine(3, "----------Spacing---------")
                    chiv1 = False
                    If Form27.CheckBox1.Checked = True Then
                        PrintLine(3, "Number of planes:", TAB(40), selection.Length) '
                        mean3 = selection.Length
                        fisherBingham()
                        Select Case bipolar
                            Case True
                                Preferentdirections()
                                PrintLine(3, "Method to Calculate Set Orientation: ", TAB(40), "Principal Mean Direction") '
                                PrintLine(3, "Set Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) '
                                Mean1 = dirfunc
                                Mean2 = dipfunc
                                PrintLine(3, "Eigenvalues:            ", TAB(40), Format(d(1), "0.000"), Format(d(2), "0.000"), Format(d(3), "0.000"))
                                PrintLine(3, "Shape parameter: ", TAB(40), Format(prop3, "0.00"))
                                PrintLine(3, "Strenght parameter: ", TAB(40), Format(kapa, "0.00"))
                                PrintLine(3, "") '
                            Case False
                                meandirections()
                                PrintLine(3, "Method to Calculate Set Orientation: ", TAB(40), "Resultant Vector Mean Direction") '
                                PrintLine(3, "Set Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00"))
                                Mean1 = dirfunc
                                Mean2 = dipfunc
                        End Select
                        'calcul de la mitja preferent. Input vx1(selection), vy1(selection), vz1(selection) output vec1,vec2,vec3
                        puntmitja() ' input cx1,cy1,cz1,selection.lenght, output xmean, ymean, zmean
                        lineaprojpreferent() ' input cx1,cy1,cz1,vec1,vec2,vec3,selection.lenght, output xmean, ymean, zmean
                        distances()
                        clasification()
                        ' 
                    End If
                    If Form27.CheckBox3.Checked = True Then
                        PrintLine(3, "Number of Planes:", TAB(40), selection.Length) '
                        mean3 = selection.Length
                        PrintLine(3, "Feature Plane Orientation:", TAB(40), "Individual Plane Orientation")
                        PrintLine(3, "")
                        fisherBingham()
                        Select Case bipolar
                            Case True
                                Preferentdirections()
                                PrintLine(3, "Orientation ScanLine Method: ", TAB(40), "Principal Mean Direction") '
                                PrintLine(3, "Line Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) '
                                Mean1 = dirfunc
                                Mean2 = dipfunc
                                PrintLine(3, "Eigenvalues:            ", TAB(40), Format(d(1), "0.000"), Format(d(2), "0.000"), Format(d(3), "0.000"))
                                PrintLine(3, "Shape parameter: ", TAB(40), Format(prop3, "0.00"))
                                PrintLine(3, "Strenght parameter: ", TAB(40), Format(kapa, "0.00"))
                                PrintLine(3, "") '
                            Case False
                                meandirections()
                                PrintLine(3, "Orientation ScanLine Method:", TAB(40), "Resultant Vector Mean Direction") '
                                PrintLine(3, "Line Orientation:  ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00"))
                                PrintLine(3, "")
                                Mean1 = dirfunc
                                Mean2 = dipfunc
                        End Select
                        puntmitja()
                        lineaprojpreferent2()
                        distances()
                        clasification()
                    End If
                    ' Array.Resize(selection, Nothing)
                    ' n = -1
            End Select

            chiv1 = True
            PrintLine(3, "")
            If Form27.CheckBox5.Checked = True Then PrintLine(3, "----------Density---------")
            fisherBingham()
            Select Case Form27.CheckBox5.Checked
                Case True
                    If Form27.RadioButton6.Checked = True Then
                        Dim azi, dipdir As Double
                        Preferentdirections() 'calcul de la mitja preferent. Input cx1(selection), cy1(selection), cz1(selection) output vec1,vec2,vec3
                        vecipla1 = Vec1 : vecjpla1 = Vec2 : veckpla1 = Vec3 'orientacio del pla de l'aflorament
                        PrintLine(3, "Surface Outcrop Plane Method:", TAB(40), "Principal Mean Direction") '
                        PrintLine(3, "Surface Outcrop Plane Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) '
                        PrintLine(3, "Eigenvalues:            ", TAB(40), Format(d(1), "0.000"), Format(d(2), "0.000"), Format(d(3), "0.000"))
                        PrintLine(3, "Shape parameter: ", TAB(40), Format(prop3, "0.00"))
                        PrintLine(3, "Strenght parameter: ", TAB(40), Format(kapa, "0.00"))
                        PrintLine(3, "") '

                        orienpla1 = dirfunc
                        pendpla1 = dipfunc
                        vectorlineas()
                        plans()
                        areadens()
                    End If
                    If Form27.RadioButton5.Checked = True Then
                        Dim azi, dipdir As Double
                        chiv1 = False
                        ' Preferentdirections() 'calcul de la mitja preferent. Input cx1(selection), cy1(selection), cz1(selection) output vec1,vec2,vec3
                        Select Case bipolar
                            Case True
                                Preferentdirections()
                                PrintLine(3, "Surface Outcrop Plane Method:", TAB(40), "Principal Mean Direction") '
                                PrintLine(3, "Surface Outcrop Plane Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) '
                                PrintLine(3, "Eigenvalues:            ", TAB(40), Format(d(1), "0.000"), Format(d(2), "0.000"), Format(d(3), "0.000"))
                                PrintLine(3, "Shape parameter: ", TAB(40), Format(prop3, "0.00"))
                                PrintLine(3, "Strenght parameter: ", TAB(40), Format(kapa, "0.00"))
                                PrintLine(3, "") '
                            Case False
                                meandirections()
                                PrintLine(3, "Surface Outcrop Plane Method:", TAB(40), "Resultant Vector Mean Direction") '
                                PrintLine(3, "Surface Outcrop Plane Orientation: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00"))
                                PrintLine(3, "")
                        End Select
                        vecipla1 = -Vec2 : vecjpla1 = Vec1 : veckpla1 = Vec3 'orientacio del pla de l'aflorament
                        orienpla1 = dirfunc
                        pendpla1 = dipfunc
                        puntmitja()
                        vectorlineas()
                        plans()
                        areadens()
                    End If
            End Select
            exportgocad()
            Array.Resize(selection, Nothing)
            n = -1
            PrintLine(3, "")
            PrintLine(3, "*****************************************************************")
            PrintLine(3, "")
            PrintLine(5, setname(ii), mean3, Format(mean1, "0.00"), Format(mean2, "0.00"), Format(distreal.Average, "0.00"), mean4, Format(mean5, "0.00"), Format(mean6, "0.000"), mean9)
        Next
        FileClose(2)
        FileClose(3)
        ' FileClose(5)
        MsgBox("Spacing and Density Completed")
        cx1.Clear()
        cy1.Clear()
        cz1.Clear()
        vx1.Clear()
        vy1.Clear()
        vz1.Clear()
        dipdir1.Clear()
        dip1.Clear()
        M1.Clear()
        K1.Clear()
        Population1.Clear()
        Number1.Clear()
        Rugosity1.Clear()
        Wide1.Clear()
        Long1.Clear()
        Area1.Clear()
        Set1.Clear()
        bipolar = False
        Exit Sub
ErrorHandler:
    End Sub
    Public Sub Preferentdirections()
        Dim i As Integer
        Dim sum1, sum2, sum3, sum4, sum5, sum6 As Double
        Dim c As Double
        ' Dim d(3) As Double
        '******agafem els punts escollits*******
        If selection.Length > 3 Then
            If chiv1 = False Then '****** per calcular el vector a partir de vectors
                For i = 0 To selection.Length - 1
                    sum1 = sum1 + (vx1(selection(i)) * vx1(selection(i)))
                    sum2 = sum2 + (vx1(selection(i)) * vy1(selection(i)))
                    sum3 = sum3 + (vx1(selection(i)) * vz1(selection(i)))
                    sum4 = sum4 + (vy1(selection(i)) * vy1(selection(i)))
                    sum5 = sum5 + (vy1(selection(i)) * vz1(selection(i)))
                    sum6 = sum6 + (vz1(selection(i)) * vz1(selection(i)))
                Next i
            End If
            If chiv1 = True Then '****** per calcular el vector a partir de punts
                Dim sumax, sumay, sumaz As Double
                sumax = 0 : sumay = 0 : sumaz = 0
                For i = 0 To selection.Length - 1
                    sumax = sumax + cx1(selection(i))
                    sumay = sumay + cy1(selection(i))
                    sumaz = sumaz + cz1(selection(i))
                Next i
                xmean = sumax / selection.Length
                ymean = sumay / selection.Length
                zmean = sumaz / selection.Length

                sum5 = 0 : sum3 = 0 : sum2 = 0
                sum1 = 0 : sum4 = 0 : sum6 = 0
                For i = 0 To selection.Length - 1
                    sum5 = sum5 + (cy1(selection(i)) - ymean) * (cz1(selection(i)) - zmean)
                    sum3 = sum3 + (cx1(selection(i)) - xmean) * (cz1(selection(i)) - zmean)
                    sum2 = sum2 + (cx1(selection(i)) - xmean) * (cy1(selection(i)) - ymean)

                    sum1 = sum1 + Math.Pow(((cx1(selection(i))) - xmean), 2)
                    sum4 = sum4 + Math.Pow(((cy1(selection(i))) - ymean), 2)
                    sum6 = sum6 + Math.Pow(((cz1(selection(i))) - zmean), 2)

                    '***aquest es pels eigenvalues***
                    '***calculo l'arrel del modul xq vull el sumatori dls quadrats dls moduls***
                    '  modpt = Math.Pow((x(di) - xmean), 2) + Math.Pow((y(di) - ymean), 2) + Math.Pow((z(di) - zmean), 2)
                    ' summodpt = summodpt + modpt
                Next i
          
            End If

            '***Ara ve el càlcul***
            Dim n As Integer = 3
            Dim a(3, 3) As Double
            Dim V(3, 3) As Double
            Dim b(3) As Double
            Dim zz(3) As Double
            Dim sm As Double, g As Double, h As Double, s As Double, t As Double, p As Double
            Dim tau As Double, tresh As Double, theta As Double
            Dim Nrot As Integer
            Dim j As Integer, k As Integer
            Dim ip As Integer, iq As Integer
            Dim prop4 As String
            a(1, 1) = sum1
            a(1, 2) = sum2
            a(1, 3) = sum3
            a(2, 1) = sum2
            a(2, 2) = sum4
            a(2, 3) = sum5
            a(3, 1) = sum3
            a(3, 2) = sum5
            a(3, 3) = sum6
            'inici Jacobi transformació matrix
            For ip = 1 To n
                For iq = 1 To n
                    V(ip, iq) = 0
                Next iq
                V(ip, ip) = 1
            Next ip
            For ip = 1 To n
                b(ip) = a(ip, ip)
                d(ip) = b(ip)
                zz(ip) = 0
            Next ip
            Nrot = 0
            For i = 1 To 50
                sm = 0
                For ip = 1 To (n - 1)
                    For iq = (ip + 1) To n
                        sm = sm + Math.Abs(a(ip, iq))
                    Next iq
                Next ip
                If sm = 0 Then GoTo LINE123
                If i < 4 Then
                    tresh = 0.2 * sm / n ^ 2
                Else
                    tresh = 0
                End If
                For ip = 1 To (n - 1)
                    For iq = (ip + 1) To n
                        g = 100 * Math.Abs(a(ip, iq))
                        If i > 4 And (Math.Abs(d(ip)) + g) = Math.Abs(d(ip)) And (Math.Abs(d(iq)) + g) = Math.Abs(d(iq)) Then
                            a(ip, iq) = 0
                        ElseIf Math.Abs(a(ip, iq)) > tresh Then
                            h = d(iq) - d(ip)
                            If (Math.Abs(h) + g) = Math.Abs(h) Then
                                t = a(ip, iq) / h
                            Else
                                theta = 0.5 * h / a(ip, iq)
                                t = 1 / (Math.Abs(theta) + Math.Sqrt(1 + theta ^ 2))
                                If theta < 0 Then t = -t
                            End If
                            c = 1 / Math.Sqrt(1 + Math.Pow(t, 2))
                            s = t * c
                            tau = s / (1 + c)
                            h = t * a(ip, iq)
                            zz(ip) = zz(ip) - h
                            zz(iq) = zz(iq) + h
                            d(ip) = d(ip) - h
                            d(iq) = d(iq) + h
                            a(ip, iq) = 0
                            For j = 1 To (ip - 1)
                                g = a(j, ip)
                                h = a(j, iq)
                                a(j, ip) = g - s * (h + g * tau)
                                a(j, iq) = h + s * (g - h * tau)
                            Next j
                            For j = (ip + 1) To (iq - 1)
                                g = a(ip, j)
                                h = a(j, iq)
                                a(ip, j) = g - s * (h + g * tau)
                                a(j, iq) = h + s * (g - h * tau)
                            Next j
                            For j = (iq + 1) To n
                                g = a(ip, j)
                                h = a(iq, j)
                                a(ip, j) = g - s * (h + g * tau)
                                a(iq, j) = h + s * (g - h * tau)
                            Next j
                            For j = 1 To n
                                g = V(j, ip)
                                h = V(j, iq)
                                V(j, ip) = g - s * (h + g * tau)
                                V(j, iq) = h + s * (g - h * tau)
                            Next j
                            Nrot = Nrot + 1
                        End If
                    Next iq
                Next ip
                For ip = 1 To n
                    b(ip) = b(ip) + zz(ip)
                    d(ip) = b(ip)
                    zz(ip) = 0
                Next ip
            Next i
            'Final de Jacobi Transformation matrix
LINE123:

            '***ara ordenem***
            'inici eigsrt
            For i = 1 To n - 1
                k = i
                p = d(i)
                For j = i + 1 To n
                    If d(j) > p Then
                        k = j
                        p = d(j)
                    End If
                Next j
                If k <> i Then
                    d(k) = d(i)
                    d(i) = p
                    For j = 1 To n
                        p = V(j, i)
                        V(j, i) = V(j, k)
                        V(j, k) = p
                    Next j
                End If
            Next i
            'final Press et at 1986
            Dim normalized As Double
            For i = 1 To 3
                normalized = d(i) + normalized
            Next
            d(1) = d(1) / normalized
            d(2) = d(2) / normalized
            d(3) = d(3) / normalized
            Dim prop1 As Double, prop2 As Double
            Select Case chiv1
                Case True '

                    If V(3, 3) < 0 Then      '  If V(3, 3) < 0 Then
                        Vec1 = -V(1, 3)     ' vector_i = V(2, 3)
                        Vec2 = -V(2, 3)     ' vector_j = V(1, 3)
                        Vec3 = -V(3, 3)    '  vector_k = -V(3, 3)
                    Else
                        Vec1 = V(1, 3)     '     vector_i = V(1, 3)
                        Vec2 = V(2, 3)   '     vector_j = V(2, 3)
                        Vec3 = V(3, 3) '      vector_k = V(3, 3)
                    End If
                    'afegit
                Case False
                    If V(3, 3) < 0 Then  '  If V(3, 1) < 0 Then
                        Vec1 = -V(1, 1)
                        Vec2 = -V(2, 1)
                        Vec3 = -V(3, 1)
                    Else
                        Vec1 = V(1, 1)
                        Vec2 = V(2, 1)
                        Vec3 = V(3, 1)
                    End If
            End Select
            prop1 = Math.Log(d(1) / d(2))
            prop2 = Math.Log(d(2) / d(3))
            prop3 = Math.Log(d(1) / d(3)) 'Aixo es la M
            ' Form1.Label1.Text = Format(prop3, "#.###")
            If vector_i = 0 And vector_j = 1 And vector_k = 0 Then prop3 = 10
            If vector_i = 0 And vector_j = 0 And vector_k = 1 Then prop3 = 10
            If vector_i = 1 And vector_j = 0 And vector_k = 0 Then prop3 = 10
            prop4 = Str(prop3)
            If prop4 = "Infinito" Then prop3 = 1035
            kapa = prop1 / prop2  ' Això es la K
        Else
            vector_i = 0
            vector_j = 0
            vector_k = 0
            PrintLine(3, "Insufficient population")
            indat = True
        End If
        ' If Form27.CheckBox5.Checked = True And Form27.RadioButton5.Checked = True Then
        ' Vec1 = -Vec2 : Vec2 = Vec1
        ' End If
        ' PrintLine(3, "Number of planes:", TAB(40), selection.Length) '
        calculateDipdir(Vec1, Vec2, Vec3)
        ' PrintLine(3, "Principal Mean Direction: ", TAB(40), Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) '
        ' PrintLine(3, "Eigenvalues:            ", TAB(40), Format(d(1), "0.000"), Format(d(2), "0.000"), Format(d(3), "0.000"))
        ' PrintLine(3, "Shape parameter: ", TAB(40), Format(prop3, "0.00"))
        ' PrintLine(3, "Strenght parameter: ", TAB(40), Format(kapa, "0.00"))
        ' PrintLine(3, "") '
    End Sub
    Function calculateDipdir(ByVal vec1 As Double, ByVal vec2 As Double, ByVal vec3 As Double) As Double
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        Dim dt As Double
        at = vec1
        bt = vec2
        ct = vec3
        If ct < 0 Then dt = ct * (-1)
        Dim a1 As Double
        Dim b1 As Double
        If at = 0 And bt = 0 Then   '***la traça és horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        If vec3 < 0 Then
            b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / dt)
        Else
            b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        End If


        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
        ' a1 = 180 + a1
        ' b1 = 90 - b1
        If ct < 0 Then
            Select Case a1
                Case Is > 180
                    a1 = a1 - 180
                Case Is < 180
                    a1 = a1 + 180
            End Select
            ' a1 = a1 - 180
            ' ct = dt
        End If
500:
        dipfunc = b1
        dirfunc = a1
        Return dirfunc
        Return dipfunc
    End Function
    Sub lineproj()
        '******** inici de la projeccio *********************
        Array.Resize(puntcontactex, Nothing)
        Array.Resize(puntcontactey, Nothing)
        Array.Resize(puntcontactez, Nothing)

        minx = xmean : miny = ymean : minz = zmean
        maxx = xmean : maxy = ymean : maxz = zmean
        Dim cont As Integer
        For cont = 0 To selection.Length - 1
            ' d = (cx1(cont) * vx1(cont)) + (cy1(cont) * vy1(cont)) + (cz1(cont) * vz1(cont)) ' plano 
            ' t = (d - (vx1(cont) * xmean) - (vy1(cont) * ymean) - (vz1(cont) * zmean)) / ((vx1(cont) * Vec1) + (vy1(cont) * Vec2) + (vz1(cont) * Vec3))
            'D = (cx1(cont) * Vec1) + (cy1(cont) * Vec2) + (cz1(cont) * Vec3) ' plano 
            't = (D - (Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean)) / ((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3))
            ReDim Preserve puntcontactex(cont)
            ReDim Preserve puntcontactey(cont)
            ReDim Preserve puntcontactez(cont)
            puntcontactex(cont) = xmean + (t * Vec1)
            puntcontactey(cont) = ymean + (t * Vec2)
            puntcontactez(cont) = zmean + (t * Vec3)
            PrintLine(3, "Coordinates:  ", Format(puntcontactex(cont), "0.00"), Format(puntcontactey(cont), "0.00"), Format(puntcontactez(cont), "0.00"))
            '********Búsqueda d'un extrem*********
            If puntcontactex(cont) > maxx Then maxx = puntcontactex(cont)
            If puntcontactey(cont) > maxy Then maxy = puntcontactey(cont)
            If puntcontactez(cont) > maxz Then maxz = puntcontactez(cont)
            If puntcontactex(cont) < minx Then minx = puntcontactex(cont)
            If puntcontactey(cont) < miny Then miny = puntcontactey(cont)
            If puntcontactez(cont) < minz Then minz = puntcontactez(cont)
        Next cont
    End Sub
    Sub puntmitja()
        '********* calcul del punt mitjà *********************
        xmean = cx1.Average
        ymean = cy1.Average
        zmean = cz1.Average
        '******** Final calcul del punt mig *********************
    End Sub
    Sub lineaprojpreferent()
        Array.Resize(puntcontactex, Nothing)
        Array.Resize(puntcontactey, Nothing)
        Array.Resize(puntcontactez, Nothing)
        minx = xmean : miny = ymean : minz = zmean
        maxx = xmean : maxy = ymean : maxz = zmean
        Dim dist() As Double
        Array.Resize(dist, Nothing)
        Array.Resize(distr, Nothing)
        ReDim dist(selection.Length - 1)
        Dim ang As Double
        Dim d1, d2, d3 As Double
        Dim cont As Integer
        For cont = 0 To selection.Length - 1
            d1 = -(cx1(selection(cont)) * Vec1) - (cy1(selection(cont)) * Vec2) - (cz1(selection(cont)) * Vec3) 'cada centroide * vector pla
            d2 = -(Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean) - d1 ' vector pla * punt en l'scanline
            d3 = ((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)) ' cada pla per vector scanline
            t = d2 / d3
            ReDim Preserve puntcontactex(cont)
            ReDim Preserve puntcontactey(cont)
            ReDim Preserve puntcontactez(cont)
            puntcontactex(cont) = xmean + (t * Vec1)
            puntcontactey(cont) = ymean + (t * Vec2)
            puntcontactez(cont) = zmean + (t * Vec3)
            dist(cont) = Math.Sqrt(Math.Pow(puntcontactex(cont) - xmean, 2) + Math.Pow(puntcontactey(cont) - ymean, 2) + Math.Pow(puntcontactez(cont) - zmean, 2))
        Next
        Dim valora As Integer
        Dim valorb As Integer
        Dim dis As Double
        valora = dist.IndexOf(dist, dist.Min)
        valorb = dist.IndexOf(dist, dist.Max)
        PrintLine(3, "ScanLine Starting Coordinates   (m):", TAB(40), Format(puntcontactex(valora), "00.00"), Format(puntcontactey(valora), "00.00"), Format(puntcontactez(valora), "00.00"))
        PrintLine(3, "ScanLine Ending Coordinates  (m):", TAB(40), Format(puntcontactex(valorb), "00.00"), Format(puntcontactey(valorb), "00.00"), Format(puntcontactez(valorb), "00.00"))
        dis = Math.Sqrt(Math.Pow(puntcontactex(valora) - puntcontactex(valorb), 2) + Math.Pow(puntcontactey(valora) - puntcontactey(valorb), 2) + Math.Pow(puntcontactez(valora) - puntcontactez(valorb), 2))
        PrintLine(3, "Distance ScanLine (m):", TAB(40), Format(dis, "0.00"))
        PrintLine(3, "Scanline orientation (Azimuth-dip):", TAB(40), Format(dirfunc, "0.00") + "-" + Format(dipfunc, "0.00"))
        ReDim distr(selection.Length - 1)
        For cont = 0 To selection.Length - 1
            dist(cont) = Math.Sqrt(Math.Pow(puntcontactex(cont) - puntcontactex(valora), 2) + Math.Pow(puntcontactey(cont) - puntcontactey(valora), 2) + Math.Pow(puntcontactez(cont) - puntcontactez(valora), 2))
            ang = 0
            ' ang = Math.Acos(Math.Abs(((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)) / (Math.Sqrt((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)) * Math.Sqrt((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))))
            distr(cont) = dist(cont) * Math.Cos(ang)
        Next
        Array.Sort(distr)
    End Sub
    Sub distances()
        Array.Resize(distreal, Nothing)
        Dim i As Integer
        ReDim Preserve distreal(distr.Length - 1)
        'Això és l'espaiament entre els plans
        For i = 0 To distr.Length - 2
            distreal(i) = distr(i + 1) - distr(i)
        Next
        'I fins aqui la distancia entre punts
        PrintLine(3, "Mean Spacing (m):", TAB(40), Format(distreal.Average, "0.00"))
        Dim j As Integer = (distreal.Length) - 1
        Dim varianza2 As Double
        Dim desvstan2 As Double
        For i = 0 To j
            varianza2 = varianza2 + (Math.Pow((distreal(i) - distreal.Average), 2))
        Next
        varianza2 = varianza2 / (j + 1)
        desvstan2 = Math.Sqrt(varianza2)
        PrintLine(3, "Desv. Standart (m):", TAB(40), Format(desvstan2, "0.00"))
    End Sub
    Sub clasification()
        Dim clasesb(20) As Integer
        Dim per As Double
        Dim i As Integer
        Dim n As Integer
        Dim valora As Integer
        Dim areaclas0(0), areaclas1(0), areaclas2(0), areaclas3(0), areaclas4(0), areaclas5(0), areaclas6(0), areaclas7(0), areaclas8(0), areaclas9(0) As Double
        Dim areaclas10(0), areaclas11(0), areaclas12(0), areaclas13(0), areaclas14(0), areaclas15(0), areaclas16(0), areaclas17(0), areaclas18(0), areaclas19(0) As Double
        Dim clases(20) As Integer
        For i = 0 To distreal.Length - 1
            valora = distreal.IndexOf(distreal, distreal(i))
            Select Case distreal(i)
                Case 0 To 0.1
                    n = clases(0)
                    ReDim Preserve areaclas0(n)
                    areaclas0(n) = Area1(valora)
                    clases(0) += 1
                Case 0.1 To 0.2
                    n = clases(1)
                    ReDim Preserve areaclas1(n)
                    areaclas1(n) = Area1(valora)
                    clases(1) += 1
                Case 0.2 To 0.3
                    n = clases(2)
                    ReDim Preserve areaclas2(n)
                    areaclas2(n) = Area1(valora)
                    clases(2) += 1
                Case 0.3 To 0.4
                    n = clases(3)
                    ReDim Preserve areaclas3(n)
                    areaclas3(n) = Area1(valora)
                    clases(3) += 1
                Case 0.4 To 0.5
                    n = clases(4)
                    ReDim Preserve areaclas4(n)
                    areaclas4(n) = Area1(valora)
                    clases(4) += 1
                Case 0.5 To 0.6
                    n = clases(5)
                    ReDim Preserve areaclas5(n)
                    areaclas5(n) = Area1(valora)
                    clases(5) += 1
                Case 0.6 To 0.7
                    n = clases(6)
                    ReDim Preserve areaclas6(n)
                    areaclas6(n) = Area1(valora)
                    clases(6) += 1
                Case 0.7 To 0.8
                    n = clases(7)
                    ReDim Preserve areaclas7(n)
                    areaclas7(n) = Area1(valora)
                    clases(7) += 1
                Case 0.8 To 0.9
                    n = clases(8)
                    ReDim Preserve areaclas8(n)
                    areaclas8(n) = Area1(valora)
                    clases(8) += 1
                Case 0.9 To 1
                    n = clases(9)
                    ReDim Preserve areaclas9(n)
                    areaclas9(n) = Area1(valora)
                    clases(9) += 1
                Case 1 To 2
                    n = clases(10)
                    ReDim Preserve areaclas10(n)
                    areaclas10(n) = Area1(valora)
                    clases(10) += 1
                Case 2 To 3
                    n = clases(11)
                    ReDim Preserve areaclas11(n)
                    areaclas11(n) = Area1(valora)
                    clases(11) += 1
                Case 3 To 4
                    n = clases(12)
                    ReDim Preserve areaclas12(n)
                    areaclas12(n) = Area1(valora)
                    clases(12) += 1
                Case 4 To 5
                    n = clases(13)
                    ReDim Preserve areaclas13(n)
                    areaclas13(n) = Area1(valora)
                    clases(13) += 1
                Case 5 To 6
                    n = clases(14)
                    ReDim Preserve areaclas14(n)
                    areaclas14(n) = Area1(valora)
                    clases(14) += 1
                Case 6 To 7
                    n = clases(15)
                    ReDim Preserve areaclas15(n)
                    areaclas15(n) = Area1(valora)
                    clases(15) += 1
                Case 7 To 8
                    n = clases(16)
                    ReDim Preserve areaclas16(n)
                    areaclas16(n) = Area1(valora)
                    clases(16) += 1
                Case 8 To 9
                    n = clases(17)
                    ReDim Preserve areaclas17(n)
                    areaclas17(n) = Area1(valora)
                    clases(17) += 1
                Case 9 To 10
                    n = clases(18)
                    ReDim Preserve areaclas18(n)
                    areaclas18(n) = Area1(valora)
                    clases(18) += 1
                Case Else
                    n = clases(19)
                    ReDim Preserve areaclas19(n)
                    areaclas19(n) = Area1(valora)
                    clases(19) += 1
            End Select
        Next
        per = 100 / selection.Length
        PrintLine(3, " ")
        PrintLine(3, "clasification by distances / Values / Percentage / Mean Areas (m2) /Desv. Stand ")
        PrintLine(3, " ")
        PrintLine(3, " 0  0.1  0.2  0.3  0.4  0.5  0.6  0.7  0.8  0.9   1    2    3    4    5    6    7    8    9    10 >10")
        PrintLine(3, TAB(2), clases(0), TAB(7), clases(1), TAB(12), clases(2), TAB(17), clases(3), TAB(22), clases(4), TAB(27), clases(5), TAB(32), clases(6), TAB(37), clases(7), TAB(42), clases(8), TAB(47), clases(9), TAB(52), clases(10), TAB(57), clases(11), TAB(62), clases(12), TAB(67), clases(13), TAB(72), clases(14), TAB(77), clases(15), TAB(82), clases(16), TAB(87), clases(17), TAB(93), clases(18), TAB(98), clases(19))
        PrintLine(3, TAB(2), Format(clases(0) * per, "0.0"), TAB(7), Format(clases(1) * per, "0.0"), TAB(12), Format(clases(2) * per, "0.0"), TAB(17), Format(clases(3) * per, "0.0"), TAB(22), Format(clases(4) * per, "0.0"), TAB(27), Format(clases(5) * per, "0.0"), TAB(32), Format(clases(6) * per, "0.0"), TAB(37), Format(clases(7) * per, "0.0"), TAB(42), Format(clases(8) * per, "0.0"), TAB(47), Format(clases(9) * per, "0.0"), TAB(52), Format(clases(10) * per, "0.0"), TAB(58), Format(clases(11) * per, "0.0"), TAB(63), Format(clases(12) * per, "0.0"), TAB(68), Format(clases(13) * per, "0.0"), TAB(73), Format(clases(14) * per, "0.0"), TAB(78), Format(clases(15) * per, "0.0"), TAB(83), Format(clases(16) * per, "0.0"), TAB(88), Format(clases(17) * per, "0.0"), TAB(93), Format(clases(18) * per, "0.0"), TAB(98), Format(clases(19) * per, "0.0"))
        ' mean7 = Format(clases.Max * per, "0.0")

        ' mean8 = Array.IndexOf(clases, clases.Max)
        Array.Copy(clases, clasesb, clases.Length)
        Array.Sort(clasesb)
        mean9 = ""
        For iii = 20 To 16 Step -1
            mean8 = Array.IndexOf(clases, clasesb(iii))
            mean7 = Format(clases(mean8) * per, "0.0")
            Select Case mean8
                Case 0
                    mean9 = mean9 + "0-0.1 (" + Format(mean7, "0") + "%)--"
                Case 1
                    mean9 = mean9 + "0.1-0.2 (" + Format(mean7, "0") + "%)--"
                Case 2
                    mean9 = mean9 + "0.2-0.3 (" + Format(mean7, "0") + "%)--"
                Case 3
                    mean9 = mean9 + "0.3-0.4 (" + Format(mean7, "0") + "%)--"
                Case 4
                    mean9 = mean9 + "0.4-0.5 (" + Format(mean7, "0") + "%)--"
                Case 5
                    mean9 = mean9 + "0.5-0.6 (" + Format(mean7, "0") + "%)--"
                Case 6
                    mean9 = mean9 + "0.6-0.7 (" + Format(mean7, "0") + "%)--"
                Case 7
                    mean9 = mean9 + "0.7-0.8 (" + Format(mean7, "0") + "%)--"
                Case 8
                    mean9 = mean9 + "0.8-0.9 (" + Format(mean7, "0") + "%)--"
                Case 9
                    mean9 = mean9 + "0.9-1 (" + Format(mean7, "0") + "%)--"
                Case 10
                    mean9 = mean9 + "1-2 (" + Format(mean7, "0") + "%)--"
                Case 11
                    mean9 = mean9 + "2-3 (" + Format(mean7, "0") + "%)--"
                Case 12
                    mean9 = mean9 + "3-4 (" + Format(mean7, "0") + "%)--"
                Case 13
                    mean9 = mean9 + "4-5 (" + Format(mean7, "0") + "%)--"
                Case 14
                    mean9 = mean9 + "5-6 (" + Format(mean7, "0") + "%)--"
                Case 15
                    mean9 = mean9 + "6-7 (" + Format(mean7, "0") + "%)--"
                Case 16
                    mean9 = mean9 + "7-8 (" + Format(mean7, "0") + "%)--"
                Case 17
                    mean9 = mean9 + "8-9 (" + Format(mean7, "0") + "%)--"
                Case 18
                    mean9 = mean9 + "9-10 (" + Format(mean7, "0") + "%)--"
                Case 19
                    mean9 = mean9 + ">10 (" + Format(mean7, "0") + "%)--"
            End Select
        Next
        PrintLine(3, TAB(2), Format(areaclas0.Average, "0.0"), TAB(7), Format(areaclas1.Average, "0.0"), TAB(12), Format(areaclas2.Average, "0.0"), TAB(17), Format(areaclas3.Average, "0.00"), TAB(22), Format(areaclas4.Average, "0.0"), TAB(27), Format(areaclas5.Average, "0.0"), TAB(32), Format(areaclas6.Average, "0.0"), TAB(37), Format(areaclas7.Average, "0.0"), TAB(42), Format(areaclas8.Average, "0.00"), TAB(47), Format(areaclas9.Average, "0.0"), TAB(52), Format(areaclas10.Average, "0.0"), TAB(58), Format(areaclas11.Average, "0.0"), TAB(63), Format(areaclas12.Average, "0.0"), TAB(68), Format(areaclas13.Average, "0.0"), TAB(73), Format(areaclas14.Average, "0.0"), TAB(78), Format(areaclas15.Average, "0.0"), TAB(83), Format(areaclas16.Average, "0.0"), TAB(88), Format(areaclas17.Average, "0.0"), TAB(93), Format(areaclas18.Average, "0.0"), TAB(98), Format(areaclas19.Average, "0.0"))
        Dim varianza2 As Double
        Dim desvstan2(19) As Double

        For i = 0 To areaclas0.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas0(i) - areaclas0.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas0.Length)
        desvstan2(0) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas1.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas1(i) - areaclas1.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas1.Length)
        desvstan2(1) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas2.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas2(i) - areaclas2.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas2.Length)
        desvstan2(2) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas3.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas3(i) - areaclas3.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas3.Length)
        desvstan2(3) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas4.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas4(i) - areaclas4.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas4.Length)
        desvstan2(4) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas5.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas5(i) - areaclas5.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas5.Length)
        desvstan2(5) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas6.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas6(i) - areaclas6.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas6.Length)
        desvstan2(6) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas7.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas7(i) - areaclas7.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas7.Length)
        desvstan2(7) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas8.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas8(i) - areaclas8.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas8.Length)
        desvstan2(8) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas9.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas9(i) - areaclas9.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas9.Length)
        desvstan2(9) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas10.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas10(i) - areaclas10.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas10.Length)
        desvstan2(10) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas11.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas11(i) - areaclas11.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas11.Length)
        desvstan2(11) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas12.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas12(i) - areaclas12.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas12.Length)
        desvstan2(12) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas13.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas13(i) - areaclas13.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas13.Length)
        desvstan2(13) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas14.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas14(i) - areaclas14.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas14.Length)
        desvstan2(14) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas15.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas15(i) - areaclas15.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas15.Length)
        desvstan2(15) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas16.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas16(i) - areaclas16.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas16.Length)
        desvstan2(16) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas17.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas17(i) - areaclas17.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas17.Length)
        desvstan2(17) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas18.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas18(i) - areaclas18.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas18.Length)
        desvstan2(18) = Math.Sqrt(varianza2)
        varianza2 = 0
        For i = 0 To areaclas19.Length - 1
            varianza2 = varianza2 + (Math.Pow((areaclas19(i) - areaclas19.Average), 2))
        Next
        varianza2 = varianza2 / (areaclas19.Length)
        desvstan2(19) = Math.Sqrt(varianza2)
        varianza2 = 0
        PrintLine(3, TAB(2), Format(desvstan2(0), "0.0"), TAB(7), Format(desvstan2(1), "0.0"), TAB(12), Format(desvstan2(2), "0.0"), TAB(17), Format(desvstan2(3), "0.00"), TAB(22), Format(desvstan2(4), "0.0"), TAB(27), Format(desvstan2(5), "0.0"), TAB(32), Format(desvstan2(6), "0.0"), TAB(37), Format(desvstan2(7), "0.0"), TAB(42), Format(desvstan2(8), "0.00"), TAB(47), Format(desvstan2(9), "0.0"), TAB(52), Format(desvstan2(10), "0.0"), TAB(58), Format(desvstan2(11), "0.0"), TAB(63), Format(desvstan2(12), "0.0"), TAB(68), Format(desvstan2(13), "0.0"), TAB(73), Format(desvstan2(14), "0.0"), TAB(78), Format(desvstan2(15), "0.0"), TAB(83), Format(desvstan2(16), "0.0"), TAB(88), Format(desvstan2(17), "0.0"), TAB(93), Format(desvstan2(18), "0.0"), TAB(98), Format(desvstan2(19), "0.0"))
        PrintLine(3, " ")
        Array.Resize(clasesb, Nothing)
    End Sub
    Sub meandirections()
        Vec1b = 0
        Vec2b = 0
        Vec3b = 0
        Dim i1 As Integer
        Select Case selection.Length
            Case Is <= 1
                If dipdir1.Count = 0 Then
                    Vec1b = 0
                    Vec2b = 0
                    Vec3b = 0
                Else
                    Vec1b = vx1(selection(i1)) + Vec1b
                    Vec2b = vy1(selection(i1)) + Vec2b
                    Vec3b = vz1(selection(i1)) + Vec3b
                End If
            Case Is > 1
                For i1 = 0 To selection.Length - 1
                    Vec1b = vx1(selection(i1)) + Vec1b
                    Vec2b = vy1(selection(i1)) + Vec2b
                    Vec3b = vz1(selection(i1)) + Vec3b
                Next
        End Select
        Dim unitari As Double
        unitari = Math.Sqrt((Vec1b * Vec1b) + (Vec2b * Vec2b) + (Vec3b * Vec3b))
        Vec1b = Vec1b / unitari
        Vec2b = Vec2b / unitari
        Vec3b = Vec3b / unitari
        calculateDipdir(Vec1b, Vec2b, Vec3b)
        PrintLine(3, "1", "Mean_Res_direction:", Format(dirfunc, "0.00") + "/" + Format(dipfunc, "0.00")) 'potser borrar abril 2020
        ' PrintLine(3, "Number of planes:", TAB(40), selection.Length) 'potser borrar abril 2020
        ' PrintLine(3, "Mean directions", "")
        ' Posicions d'intersecció de l'scanline amb els plans sel·leccionats
        'final 150 copiado
        Vec1 = Vec1b
        Vec2 = Vec2b
        Vec3 = Vec3b
    End Sub
    Sub lineaprojpreferent2()
        Array.Resize(puntcontactex, Nothing)
        Array.Resize(puntcontactey, Nothing)
        Array.Resize(puntcontactez, Nothing)
        minx = xmean : miny = ymean : minz = zmean
        maxx = xmean : maxy = ymean : maxz = zmean
        Dim dist() As Double
        Array.Resize(dist, Nothing)
        Array.Resize(distr, Nothing)
        ReDim dist(selection.Length - 1)
        Dim ang As Double
        Dim d1, d2, d3 As Double
        Dim cont As Integer
        For cont = 0 To selection.Length - 1
            d1 = -(cx1(selection(cont)) * vx1(selection(cont))) - (cy1(selection(cont)) * vy1(selection(cont))) - (cz1(selection(cont)) * vz1(selection(cont))) 'cada centroide * vector pla
            d2 = -(vx1(selection(cont)) * xmean) - (vy1(selection(cont)) * ymean) - (vz1(selection(cont)) * zmean) - d1 ' vector pla * punt en l'scanline
            d3 = ((vx1(selection(cont)) * Vec1) + (vy1(selection(cont)) * Vec2) + (vz1(selection(cont)) * Vec3)) ' cada pla per vector scanline
            t = d2 / d3
            ReDim Preserve puntcontactex(cont)
            ReDim Preserve puntcontactey(cont)
            ReDim Preserve puntcontactez(cont)
            puntcontactex(cont) = xmean + (t * Vec1)
            puntcontactey(cont) = ymean + (t * Vec2)
            puntcontactez(cont) = zmean + (t * Vec3)
            dist(cont) = Math.Sqrt(Math.Pow(puntcontactex(cont) - xmean, 2) + Math.Pow(puntcontactey(cont) - ymean, 2) + Math.Pow(puntcontactez(cont) - zmean, 2))
        Next
        Dim valora As Integer
        Dim valorb As Integer
        Dim dis As Double
        valora = dist.IndexOf(dist, dist.Min)
        valorb = dist.IndexOf(dist, dist.Max)
        PrintLine(3, "Coordinates start ScanLine (m):", TAB(40), Format(puntcontactex(valora), "00.00"), Format(puntcontactey(valora), "00.00"), Format(puntcontactez(valora), "00.00"))
        PrintLine(3, "Coordinates end ScanLine (m):", TAB(40), Format(puntcontactex(valorb), "00.00"), Format(puntcontactey(valorb), "00.00"), Format(puntcontactez(valorb), "00.00"))
        dis = Math.Sqrt(Math.Pow(puntcontactex(valora) - puntcontactex(valorb), 2) + Math.Pow(puntcontactey(valora) - puntcontactey(valorb), 2) + Math.Pow(puntcontactez(valora) - puntcontactez(valorb), 2))
        PrintLine(3, "Distance ScanLine (m):", TAB(40), Format(dis, "0.00"))
        PrintLine(3, "Scanline density (#planes/m):", TAB(40), Format((selection.Length) / dis, "0.00"))
        mean4 = Format((selection.Length) / dis, "0.00")
        mean5 = dis
        PrintLine(3, "Scanline orientation (Azimuth-dip):", TAB(40), Format(dirfunc, "0.00") + "-" + Format(dipfunc, "0.00"))
        ReDim distr(selection.Length - 1)
        For cont = 0 To selection.Length - 1
            dist(cont) = Math.Sqrt(Math.Pow(puntcontactex(cont) - puntcontactex(valora), 2) + Math.Pow(puntcontactey(cont) - puntcontactey(valora), 2) + Math.Pow(puntcontactez(cont) - puntcontactez(valora), 2))
            ang = Math.Acos(Math.Abs(((vx1(selection(cont)) * Vec1) + (vy1(selection(cont)) * Vec2) + (vz1(selection(cont)) * Vec3)) / (Math.Sqrt((vx1(selection(cont)) * vx1(selection(cont))) + (vy1(selection(cont)) * vy1(selection(cont))) + (vz1(selection(cont)) * vz1(selection(cont)))) * Math.Sqrt((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))))
            distr(cont) = dist(cont) * Math.Cos(ang)
        Next
        Array.Sort(distr)
    End Sub
    Sub vectorlineas()
        '********* Vector de les líneas a projectar *********************
        'estan contenidas en els dos plans
        '  Dim vectori3() As Double
        ' Dim vectorj3() As Double
        ' Dim vectork3() As Double
        Dim noui3() As Double
        Dim nouj3() As Double
        Dim nouk3() As Double
        Dim orienpla3() As Double
        Dim pendpla3() As Double
        ' Dim D1() As Double
        ReDim Preserve vectori3(selection.Length - 1)
        ReDim Preserve vectorj3(selection.Length - 1)
        ReDim Preserve vectork3(selection.Length - 1)
        ReDim Preserve noui3(selection.Length - 1)
        ReDim Preserve nouj3(selection.Length - 1)
        ReDim Preserve nouk3(selection.Length - 1)
        ReDim Preserve orienpla3(selection.Length - 1)
        ReDim Preserve pendpla3(selection.Length - 1)
        ReDim Preserve D1(selection.Length - 1)
        For i = 0 To selection.Length - 1
            vectori3(i) = (vecjpla1 * vz1(selection(i)) - (veckpla1 * vy1(selection(i))))
            vectorj3(i) = (veckpla1 * vx1(selection(i)) - (vecipla1 * vz1(selection(i))))
            vectork3(i) = (vecipla1 * vy1(selection(i)) - (vecjpla1 * vx1(selection(i))))
            '  If vectork3(i) < 0 Then
            'vectori3(i) = -vectori3(i)
            '  vectorj3(i) = -vectorj3(i)
            '  vectork3(i) = -vectork3(i)
            '  End If
            '********* Vectors unitaris **********************************
            '  nouj3(i) = Math.Sqrt((Math.Pow(vectorj3(i), 2) / (Math.Pow(vectori3(i), 2) + Math.Pow(vectorj3(i), 2) + Math.Pow(vectork3(i), 2))))
            nouj3(i) = Math.Sqrt(Math.Pow(vectorj3(i), 2) / (Math.Pow(vectori3(i), 2) + Math.Pow(vectorj3(i), 2) + Math.Pow(vectork3(i), 2)))


            noui3(i) = (vectori3(i) * nouj3(i)) / vectorj3(i)
            nouk3(i) = (vectork3(i) * nouj3(i)) / vectorj3(i)
            vectori3(i) = noui3(i)
            vectorj3(i) = nouj3(i)
            vectork3(i) = nouk3(i)
            '************ Fi vectors unitaris ***************************
            Vec1 = vectori3(i) : Vec2 = vectorj3(i) : Vec3 = vectork3(i)
            orienpla3(i) = dirfunc
            pendpla3(i) = dipfunc
            'per vectors
            D1(i) = (vx1(selection(i)) * cx1(selection(i))) + (vy1(selection(i)) * cy1(selection(i))) + (vz1(selection(i)) * cz1(selection(i)))
        Next
        D2 = (vecipla1 * xmean) + (vecjpla1 * ymean) + (veckpla1 * zmean) ' Del pla de projeccio
    End Sub
    Sub plans()
        'Aqui es calcula si el pla de fractura esta interseccionat pel pla mitj
        Dim linx3(), liny3(), linz3() As Double
        Dim cofi(), cofj() As Double
        Dim t11() As Double
        Dim t33() As Double
        Dim distan As Double
        Dim distan2 As Double
        ' Dim numberofplans As Integer
        '******** Punt per la linea, centroide del pla *********************
        ReDim Preserve t11(selection.Length - 1)
        ReDim Preserve t33(selection.Length - 1)
        ReDim Preserve linx3(selection.Length - 1)
        ReDim Preserve liny3(selection.Length - 1)
        ReDim Preserve linz3(selection.Length - 1)
        ReDim Preserve cofi(selection.Length - 1)
        ReDim Preserve cofj(selection.Length - 1)
        ReDim Preserve puntcontactex(selection.Length - 1)
        ReDim Preserve puntcontactey(selection.Length - 1)
        ReDim Preserve puntcontactez(selection.Length - 1)
        numberofplans = 0
        '******** final Rotacions per trovar les extensions *********************
        For i = 0 To selection.Length - 1
            cofi(i) = -(vx1(selection(i)) / vecipla1)
            cofj(i) = -(vy1(selection(i)) / vecjpla1)
            'de l'equació de la línea 3 trobar un punt per situar les D
            linz3(i) = 1
            liny3(i) = (-linz3(i) * (vz1(selection(i)) + (cofi(i) * veckpla1)) + (cofi(i) * D2) + D1(i)) / (vy1(selection(i)) + (cofi(i) * vecjpla1))
            linx3(i) = (-linz3(i) * (vz1(selection(i)) + (cofj(i) * veckpla1)) + (cofj(i) * D2) + D1(i)) / (vx1(selection(i)) + (cofj(i) * vecipla1))
            ' es calcula la t de la lineació 3
            t33(i) = ((vectori3(i) * (cx1(selection(i)) - linx3(i))) + (vectorj3(i) * (cy1(selection(i)) - liny3(i))) + (vectork3(i) * (cz1(selection(i)) - linz3(i)))) / ((vectori3(i) * vectori3(i)) + (vectorj3(i) * vectorj3(i)) + (vectork3(i) * vectork3(i)))
            ' es tova el punt de contacte amb la variable t33 per cada punt
            puntcontactex(i) = linx3(i) + (t33(i) * vectori3(i))
            puntcontactey(i) = liny3(i) + (t33(i) * vectorj3(i))
            puntcontactez(i) = linz3(i) + (t33(i) * vectork3(i))
            '****Fins aquí funciona bé
            'PrintLine(3, Format(puntcontactex(i), "#.##"), Format(puntcontactey(i), "#.##"), Format(puntcontactez(i), "#.##"))
            ' PrintLine(3, Format(cx1(i), "#.##"), Format(cy1(i), "#.##"), Format(cz1(i), "#.##"))

            distan = Math.Sqrt(Math.Pow(puntcontactex(i) - cx1(selection(i)), 2) + Math.Pow(puntcontactey(i) - cy1(selection(i)), 2) + Math.Pow(puntcontactez(i) - cz1(selection(i)), 2))
            distan2 = Math.Sqrt(Math.Pow(Wide1(selection(i)), 2) + Math.Pow(Long1(selection(i)), 2))
            If distan2 >= distan Then numberofplans += 1
        Next i
        PrintLine(3, "Planes for density:", TAB(40), numberofplans)
        ' PrintLine(3, "")
        Array.Resize(t11, Nothing)
        Array.Resize(t33, Nothing)
        Array.Resize(linx3, Nothing)
        Array.Resize(liny3, Nothing)
        Array.Resize(linz3, Nothing)
        Array.Resize(cofi, Nothing)
        Array.Resize(cofj, Nothing)
    End Sub
    Sub areadens()
        Dim radio As Double
        Dim Px1, Px2, Px3, Psx1 As Double
        Dim Py1, Py2, Py3, Psy1 As Double
        Dim areatotal As Double
        Dim dist1b(2) As Double
        Dim puntescollit As Double
        Dim dist1(2) As Double
        areatotal = 0
        Dim valora As Integer
        Dim valorb As Integer
        Dim vecareai(), vecareaj(), vecareak() As Double
        Dim aziarea() As Double
        Dim aziarea2() As Double
        ReDim Preserve vecareai(selection.Length - 1)
        ReDim Preserve vecareaj(selection.Length - 1)
        ReDim Preserve vecareak(selection.Length - 1)
        ReDim Preserve aziarea(selection.Length - 1)
        ReDim Preserve aziarea2(selection.Length - 1)
        'calcular la orientacio de cada punten relació a la xmean
        rotation2()
        For i = 0 To selection.Length - 1
            Vec1 = puntcontactexr.Average - puntcontactexr(i) ' -
            Vec2 = puntcontacteyr.Average - puntcontacteyr(i) '- 
            Vec3 = puntcontactezr.Average - puntcontactezr(i) '- 
            Vec3 = 0
            calculateDipdir(Vec1, Vec2, Vec3)
            aziarea(i) = dirfunc
        Next
        Array.Copy(aziarea, aziarea2, aziarea.Length)
        Array.Sort(aziarea2)
        Dim areatotal1 As Double
        For i = 1 To selection.Length
            If i = selection.Length Then
                valora = Array.IndexOf(aziarea, aziarea2(0))
                valorb = Array.IndexOf(aziarea, aziarea2(i - 1))
            Else
                valora = Array.IndexOf(aziarea, aziarea2(i - 1))
                valorb = Array.IndexOf(aziarea, aziarea2(i))
            End If
            dist1(0) = Math.Sqrt(Math.Pow(puntcontactexr(valora) - puntcontactexr.Average, 2) + Math.Pow(puntcontacteyr(valora) - puntcontacteyr.Average, 2) + Math.Pow(puntcontactezr(valora) - puntcontactezr.Average, 2))
            dist1(1) = Math.Sqrt(Math.Pow(puntcontactexr(valorb) - puntcontactexr(valora), 2) + Math.Pow(puntcontacteyr(valorb) - puntcontacteyr(valora), 2) + Math.Pow(puntcontactezr(valorb) - puntcontactezr(valora), 2))
            dist1(2) = Math.Sqrt(Math.Pow(puntcontactexr(valorb) - puntcontactexr.Average, 2) + Math.Pow(puntcontacteyr(valorb) - puntcontacteyr.Average, 2) + Math.Pow(puntcontactezr(valorb) - puntcontactezr.Average, 2))
            Array.Copy(dist1, dist1b, dist1.Length)
            Array.Sort(dist1b)
            puntescollit = Array.IndexOf(dist1, dist1b(2))
            Select Case puntescollit
                Case 0
                    Px1 = puntcontactexr(valorb) : Py1 = puntcontacteyr(valorb) ': Pz1 = puntcontactezr(valorb) 'pùnto a proyectar
                    Px2 = puntcontactexr(valora) : Py2 = puntcontacteyr(valora) ': Pz2 = puntcontactezr(valora) 'extremo linea
                    Px3 = puntcontactexr.Average : Py3 = puntcontacteyr.Average ': Pz3 = puntcontactezr.Average 'extremo linea
                Case 1
                    Px1 = puntcontactexr.Average : Py1 = puntcontacteyr.Average ': Pz1 = puntcontactezr.Average 'pùnto a proyectar
                    Px2 = puntcontactexr(valora) : Py2 = puntcontacteyr(valora) ': Pz2 = puntcontactezr(valora) 'extremo linea
                    Px3 = puntcontactexr(valorb) : Py3 = puntcontacteyr(valorb) ': Pz3 = puntcontactezr(valorb) 'extremo linea
                Case 2
                    Px1 = puntcontactexr(valora) : Py1 = puntcontacteyr(valora) ': Pz1 = puntcontactezr(valorb) 'pùnto a proyectar
                    Px2 = puntcontactexr.Average : Py2 = puntcontacteyr.Average ': Pz2 = puntcontactezr.Average 'extremo linea
                    Px3 = puntcontactexr(valorb) : Py3 = puntcontacteyr(valorb) ': Pz3 = puntcontactezr(valora) 'extremo linea
            End Select
            Dim aaa, bbb, ddd1, ddd2, ddd3, ddd4, ddd5, ddd6 As Double

            aaa = (Py3 - Py2) / (Px3 - Px2)
            bbb = (-(((Py3 - Py2) / (Px3 - Px2)) * Px3) + Py3)
            radio = Math.Abs((aaa * Px1) - Py1 + bbb) / Math.Sqrt((Math.Pow(aaa, 2)) + 1)
            ' repeticion
            ddd1 = 1 + (aaa * aaa)
            ddd2 = ((-2 * Px1) + (2 * aaa * bbb) - (2 * Py1 * aaa))
            ddd3 = (Px1 * Px1) + (bbb * bbb) + (-2 * Py1 * bbb) + (Py1 * Py1) - (Math.Pow(radio, 2))
            ' ddd4 = (Math.Pow(353188.337, 2) * ddd1) + (353188.337 * ddd2) + ddd3

            ' solución
            ddd4 = 4 * ddd1 * ddd3
            ddd5 = Math.Pow(ddd2, 2)
            If ddd5 > ddd4 Then ' a vegades no es tan precis i no encerta al secant cercle linea.
                ddd6 = Math.Sqrt(ddd5 - ddd4)
            Else
                ddd6 = Math.Sqrt(ddd4 - ddd5)
            End If
            Psx1 = (((-ddd2 + ddd6) / (2 * ddd1)) + ((-ddd2 - ddd6) / (2 * ddd1))) / 2
            Psy1 = (aaa * Psx1) + bbb
            Select Case puntescollit
                Case 0
                    dist1(1) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(2) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(1)) / 2) + ((radio * dist1(2)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(1), dist1(2), areatotal, areatotal1)
                Case 1
                    dist1(0) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(2) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(0)) / 2) + ((radio * dist1(2)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(0), dist1(2), areatotal, areatotal1)
                Case 2
                    dist1(0) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(1) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(0)) / 2) + ((radio * dist1(1)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(0), dist1(1), areatotal, areatotal1)
            End Select
        Next
        PrintLine(3, "Surface area for density (m2):", TAB(40), Format(areatotal, "0.00"))
        PrintLine(3, "Fracture Density (#/m2):", TAB(40), Format(numberofplans / areatotal, "0.000"))
        mean6 = Format(numberofplans / areatotal, "0.000")
        PrintLine(3, "")
        Array.Resize(puntcontactex, Nothing)
        Array.Resize(puntcontactey, Nothing)
        Array.Resize(puntcontactez, Nothing)
        Array.Resize(puntcontactexr, Nothing)
        Array.Resize(puntcontacteyr, Nothing)
        Array.Resize(puntcontactezr, Nothing)
        Array.Resize(vecareai, Nothing)
        Array.Resize(vecareaj, Nothing)
        Array.Resize(vecareak, Nothing)
        Array.Resize(aziarea, Nothing)
        Array.Resize(aziarea2, Nothing)
    End Sub
    Sub fisherBingham()
        ' Dim dif As Double
        ' Dim dif1 As Double
        ' Select Case selection.Length
        '     Case Is = 1
        ' bipolar = False
        '     Case Is > 1
        ' For i = 0 To selection.Length - 1
        '     dif = Math.Abs(dipdir1(selection(i)) - 360)
        '     dif1 = dipdir1(selection(0)) - dif
        '      If dif1 > 100 Then bipolar = True
        '  Next
        '  End Select
        bipolar = False
        Dim dif1 As Double
        calculateDipdir(vx1.Average, vy1.Average, 0)
        dif1 = dirfunc
        If Math.Abs(dirfunc - dipdir1.Average) > 90 Then bipolar = True
        Select Case bipolar
            Case True
                vectorsperpendicular() ' Principal Mean direction
            Case False
                meandirectionsperpendicular() ' Mean Direction
        End Select
    End Sub
    Sub rotation2()
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        Dim xa, ya, za As Double
        o = 0
        p = 0
        k = -(((180 - orienpla1) * Math.PI) / 180)

        ReDim Preserve puntcontactexr(selection.Length - 1)
        ReDim Preserve puntcontacteyr(selection.Length - 1)
        ReDim Preserve puntcontactezr(selection.Length - 1)
        'Coeficients
        ang(1) = Math.Cos(p) * Math.Cos(k)
        ang(2) = -Math.Cos(p) * Math.Sin(k)
        ang(3) = Math.Sin(p)
        ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
        ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
        ang(6) = -Math.Sin(o) * Math.Cos(p)
        ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
        ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
        ang(9) = Math.Cos(o) * Math.Cos(p)

        'Matriu M
        For i = 0 To selection.Length - 1
            xa = puntcontactex(i) - puntcontactex.Average
            ya = puntcontactey(i) - puntcontactey.Average
            za = puntcontactez(i) - puntcontactez.Average
            puntcontactexr(i) = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3)))
            puntcontacteyr(i) = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6)))
            puntcontactezr(i) = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9)))
            ' puntcontactexr(selection(i)) = puntcontactexr(selection(i)) + puntcontactex(0)
            '  puntcontacteyr(selection(i)) = puntcontacteyr(selection(i)) + puntcontactey(0)
            '  puntcontactezr(selection(i)) = puntcontactezr(selection(i)) + puntcontactez(0)
            '  PrintLine(3, Format(puntcontactex(i), "0.00"), Format(puntcontactey(i), "0.00"), Format(puntcontactez(i), "0.00"))
            '  PrintLine(3, Format(puntcontactexr(selection(i)), "0.00"), Format(puntcontacteyr(selection(i)), "0.00"), Format(puntcontactezr(selection(i)), "0.00"))

        Next
        o = (((180 - pendpla1) * Math.PI) / 180)
        p = 0
        k = 0

        'Coeficients
        ang(1) = Math.Cos(p) * Math.Cos(k)
        ang(2) = -Math.Cos(p) * Math.Sin(k)
        ang(3) = Math.Sin(p)
        ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
        ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
        ang(6) = -Math.Sin(o) * Math.Cos(p)
        ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
        ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
        ang(9) = Math.Cos(o) * Math.Cos(p)

        'Matriu M
        For i = 0 To selection.Length - 1
            xa = puntcontactexr(i) ' - puntcontactex(0)
            ya = puntcontacteyr(i) ' - puntcontactey(0)
            za = puntcontactezr(i) ' - puntcontactez(0)
            puntcontactexr(i) = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3)))
            puntcontacteyr(i) = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6)))
            puntcontactezr(i) = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9)))
            puntcontactexr(i) = puntcontactexr(i) + puntcontactex.Average
            puntcontacteyr(i) = puntcontacteyr(i) + puntcontactey.Average
            puntcontactezr(i) = puntcontactezr(i) + puntcontactez.Average
            'PrintLine(3, Format(puntcontactex(i), "0.00"), Format(puntcontactey(i), "0.00"), Format(puntcontactez(i), "0.00"))
            ' PrintLine(3, Format(puntcontactexr(selection(i)), "0.00"), Format(puntcontacteyr(selection(i)), "0.00"), Format(puntcontactezr(selection(i)), "0.00"))
        Next
    End Sub
    Sub exportgocad()
        Dim n As Integer
        Dim puntx, punty, puntz As Double
        Dim na As Integer = 1
        Dim dipdir As Double
        Dim pendi As Double
        Dim lon As Double
        Dim wide As Double
        Dim ratio As Double
        Dim px(3), py(3), pz(3) As Double
        Dim pxf(3), pyf(3), pzf(3) As Double
        Dim o, p, ka As Double
        Dim ang(9) As Double
        Dim Position1a As Integer
        Dim Position2a As Integer
        Dim setnumer2 As String
        FileClose(4)
        Position1a = InStrRev(setna, "t")
        Position2a = Len(setna)
        setnumer2 = setna.Substring(Position1a)
        Dim openFileDialog1 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        FileOpen(4, Form10.TextBox1.Text + "GocadSurface_" + Form27.TextBox1.Text + "_" + Form27.TextBox2.Text + "_" + setna + ".ts", OpenMode.Output)
        PrintLine(4, "GOCAD TSurf 1")
        PrintLine(4, "HEADER {")
        PrintLine(4, "name:" + Form27.TextBox1.Text + "_" + Form27.TextBox2.Text + "_" + setna)
        PrintLine(4, "mesh:false")
        PrintLine(4, "cn:false")
        Select Case setna
            Case "Set 0" 'red
                PrintLine(4, "*solid*color:#ff0000")
            Case "Set0" 'red
                PrintLine(4, "*solid*color:#ff0000")
            Case "Set 1" 'cyan
                PrintLine(4, "*solid*color:#00ffff")
            Case "Set1" 'cyan
                PrintLine(4, "*solid*color:#00ffff")
            Case "Set 2" 'Yellow
                PrintLine(4, "*solid*color:#ffff00")
            Case "Set2" 'Yellow
                PrintLine(4, "*solid*color:#ffff00")
            Case "Set 3" 'dark green
                PrintLine(4, "*solid*color:#008000")
            Case "Set3" 'dark green
                PrintLine(4, "*solid*color:#008000")
            Case "Set 4" 'Blue
                PrintLine(4, "*solid*color:#0000ff")
            Case "Set4" 'Blue
                PrintLine(4, "*solid*color:#0000ff")
            Case "Set 5" 'snow
                PrintLine(4, "*solid*color:#fffafa")
            Case "Set5" 'snow
                PrintLine(4, "*solid*color:#fffafa")
            Case "Set 6" 'violet
                PrintLine(4, "*solid*color:#ee82ee")
            Case "Set6" 'violet
                PrintLine(4, "*solid*color:#ee82ee")
            Case "Set 7" 'Orange
                PrintLine(4, "*solid*color:#ffa500")
            Case "Set7" 'Orange
                PrintLine(4, "*solid*color:#ffa500")
            Case "Set 8" 'red brick
                PrintLine(4, "*solid*color:#fa8072")
            Case "Set8" 'red brick
                PrintLine(4, "*solid*color:#fa8072")
            Case "Set 9" 'Green 
                PrintLine(4, "*solid*color:#tcfc00")
            Case "Set9" 'Green 
                PrintLine(4, "*solid*color:#tcfc00")
            Case "Set 10" 'Dark violet
                PrintLine(4, "*solid*color:#c71585")
            Case "Set10" 'Dark violet
                PrintLine(4, "*solid*color:#c71585")
            Case "Set 11" 'SeaBlue
                PrintLine(4, "*solid*color:#6495ed")
            Case "Set11" 'SeaBlue
                PrintLine(4, "*solid*color:#6495ed")
            Case "Set 12"
                PrintLine(4, "*solid*color:#add8e6")
            Case "Set12"
                PrintLine(4, "*solid*color:#add8e6")
            Case "Set 13" 'Cyan
                PrintLine(4, "*solid*color:#99ffff")
            Case "Set13" 'Cyan
                PrintLine(4, "*solid*color:#99ffff")
            Case "Set 14"
                PrintLine(4, "*solid*color:0.854902 0.666667 0 1")
            Case "Set14"
                PrintLine(4, "*solid*color:0.854902 0.666667 0 1")
            Case Else
                PrintLine(4, "*solid*color:#add8e6")
        End Select
        PrintLine(4, "ivolmap:false")
        PrintLine(4, "imap:false")
        PrintLine(4, "}")
        PrintLine(4, "GOCAD_ORIGINAL_COORDINATE_SYSTEM")
        PrintLine(4, "NAME Default")
        PrintLine(4, "AXIS_NAME ""X"" ""Y"" ""Z""")
        PrintLine(4, "AXIS_UNIT ""m"" ""m"" ""m""")
        PrintLine(4, "ZPOSITIVE Elevation")
        PrintLine(4, "END_ORIGINAL_COORDINATE_SYSTEM")
        PrintLine(4, "PROPERTIES Set Height Length Area Azimuth Dip M K")
        PrintLine(4, "PROP_LEGAL_RANGES **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none**  **none**  **none**")
        PrintLine(4, "NO_DATA_VALUES -99999 -99999 -99999 -99999 -99999 -99999 -99999 -99999")
        PrintLine(4, "PROPERTY_CLASSES set height length area azimuth Dip m k")
        PrintLine(4, "PROPERTY_KINDS unknown Height Length Area Angle Angle unknown unknown")
        PrintLine(4, "PROPERTY_SUBCLASSES QUANTITY Float LINEARFUNCTION Float 1  0  LINEARFUNCTION Float 1  0  LINEARFUNCTION Float 1  0  QUANTITY Float QUANTITY Float QUANTITY Float QUANTITY Float")
        PrintLine(4, "ESIZES 1 1 1 1 1 1 1 1")
        PrintLine(4, "UNITS none m m m^2 deg deg none none")
        PrintLine(4, "PROPERTY_CLASS_HEADER Z {")
        PrintLine(4, "is_z:on")
        PrintLine(4, "}")
        PrintLine(4, "PROPERTY_CLASS_HEADER set {")
        PrintLine(4, "low_clip:0")
        PrintLine(4, "high_clip:0")
        PrintLine(4, "pclip:99")
        PrintLine(4, "}")
        'final de la capçelera

        For i = 0 To selection.Length - 1
            ratio = Long1(selection(i)) / Wide1(selection(i))
            wide = Math.Sqrt(Area1(selection(i)) / ratio)
            ' lon = Wide1(selection(i)) * ratio
            lon = wide * ratio

            '2 Calcul dels 4 punts, extrems del rectangle

            px(0) = -lon / 2
            py(0) = wide / 2
            pz(0) = 0
            px(1) = lon / 2
            py(1) = wide / 2
            pz(1) = 0
            px(2) = -lon / 2
            py(2) = -wide / 2
            pz(2) = 0
            px(3) = lon / 2
            py(3) = -wide / 2
            pz(3) = 0

            '3 Rotació al voltant de omega
            dipdir = dipdir1(selection(i))
            pendi = dip1(selection(i))

            If dipdir > 180 Then pendi = -pendi
            If dipdir > 180 Then dipdir = dipdir - 180

            o = -(pendi * Math.PI) / 180
            p = 0
            ka = 0

            '4 rotacions

            ang(1) = Math.Cos(p) * Math.Cos(ka)
            ang(2) = -Math.Cos(p) * Math.Sin(ka)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
            ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
            ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            '5 Traslacio
            For n = 0 To 3
                pxf(n) = ((px(n) * ang(1)) + (py(n) * ang(2)) + (pz(n) * ang(3)))
                pyf(n) = ((px(n) * ang(4)) + (py(n) * ang(5)) + (pz(n) * ang(6)))
                pzf(n) = ((px(n) * ang(7)) + (py(n) * ang(8)) + (pz(n) * ang(9)))
            Next n
            '6 Rotació al voltant de kappa

            o = 0
            p = 0
            ka = -(dipdir * Math.PI) / 180

            '7 Rotacio
            ang(1) = Math.Cos(p) * Math.Cos(ka)
            ang(2) = -Math.Cos(p) * Math.Sin(ka)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
            ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
            ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            '8 Traslacio
            For n = 0 To 3
                px(n) = ((pxf(n) * ang(1)) + (pyf(n) * ang(2)) + (pzf(n) * ang(3)))
                py(n) = ((pxf(n) * ang(4)) + (pyf(n) * ang(5)) + (pzf(n) * ang(6)))
                pz(n) = ((pxf(n) * ang(7)) + (pyf(n) * ang(8)) + (pzf(n) * ang(9)))
            Next n

            PrintLine(4, "TFACE")

            '   Send a data point to the current command

            puntx = cx1(selection(i)) + px(0)
            punty = cy1(selection(i)) + py(0)
            puntz = cz1(selection(i)) + pz(0)

            PrintLine(4, "PVRTX", SPC(0), na, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), SPC(0), setnumer2, SPC(0), Wide1(selection(i)), SPC(0), Long1(selection(i)), SPC(0), Area1(selection(i)), SPC(0), dipdir1(selection(i)), SPC(0), dip1(selection(i)), SPC(0), M1(selection(i)), SPC(0), K1(selection(i)), SPC(0), " CNXYZ")


            puntx = cx1(selection(i)) + px(2)
            punty = cy1(selection(i)) + py(2)
            puntz = cz1(selection(i)) + pz(2)
            PrintLine(4, "PVRTX", SPC(0), na + 1, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), Wide1(selection(i)), SPC(0), Long1(selection(i)), SPC(0), Area1(selection(i)), SPC(0), dipdir1(selection(i)), SPC(0), dip1(selection(i)), SPC(0), M1(selection(i)), SPC(0), K1(selection(i)), SPC(0), " CNXYZ")

            puntx = cx1(selection(i)) + px(3)
            punty = cy1(selection(i)) + py(3)
            puntz = cz1(selection(i)) + pz(3)
            PrintLine(4, "PVRTX", SPC(0), na + 2, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), Wide1(selection(i)), SPC(0), Long1(selection(i)), SPC(0), Area1(selection(i)), SPC(0), dipdir1(selection(i)), SPC(0), dip1(selection(i)), SPC(0), M1(selection(i)), SPC(0), K1(selection(i)), SPC(0), " CNXYZ")


            puntx = cx1(selection(i)) + px(1)
            punty = cy1(selection(i)) + py(1)
            puntz = cz1(selection(i)) + pz(1)

            PrintLine(4, "PVRTX", SPC(0), na + 3, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), Wide1(selection(i)), SPC(0), Long1(selection(i)), SPC(0), Area1(selection(i)), SPC(0), dipdir1(selection(i)), SPC(0), dip1(selection(i)), SPC(0), M1(selection(i)), SPC(0), K1(selection(i)), SPC(0), " CNXYZ")


            PrintLine(4, "TRGL", SPC(0), na + 3, SPC(0), na + 2, SPC(0), na + 1)
            PrintLine(4, "TRGL", SPC(0), na + 3, SPC(0), na + 1, SPC(0), na)
            na = na + 4
        Next
        'cua del fitxer
        PrintLine(4, "BSTONE 1")
        PrintLine(4, "BSTONE 5")
        PrintLine(4, "BORDER 9 1 2")
        PrintLine(4, "BORDER 10 5 8")
        PrintLine(4, "END")
        FileClose(4)
        Exit Sub
    End Sub
    Sub sortxyz()
        Dim erro As Integer = 0
        FileClose(1)
        FileClose(2)
        FileClose(3)
        Dim cont As Integer = 0
        Dim coxb As Double
        Dim coyb As Double
        Dim cozb As Double
        Dim mummy As String
        Dim num As Integer = 0
        Dim pep As Double
        Dim i As Integer = 0
        Dim cas As Integer = 0
        Dim rfiles As String = ""
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim openFileDialog2 As New OpenFileDialog()
        Dim position1a As Integer
        Dim position2a As Integer
        Dim cadena As String = ""
        Dim cox(num) As Double
        Dim coy(num) As Double
        Dim coz(num) As Double
        Dim used(num) As Boolean
        Dim dist2(num) As Double

        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog2.Multiselect = True
        openFileDialog2.Title = "Open Gocad PointSet XYZ for sorting"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        For Each rfiles In openFileDialog2.FileNames
            FileOpen(2, rfiles, OpenMode.Input)
            On Error GoTo ErrorHandler
            mummy = LineInput(2)
            Do While Not EOF(2)
                ReDim Preserve cox(num)
                ReDim Preserve coy(num)
                ReDim Preserve coz(num)
                ReDim Preserve dist2(num)
                ReDim Preserve used(num)
                e = LineInput(2)
                e = Trim(e) : position1 = InStrRev(e, " ")
                coz(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                e = Trim(e) : position1 = InStrRev(e, " ")
                coy(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                e = Trim(e) : position1 = InStrRev(e, " ")
                cox(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                num += 1
            Loop
            FileClose(2)
            position1a = InStrRev(rfiles, "\")
            position2a = InStrRev(rfiles, ".")
            cadena = rfiles.Substring(position1a, ((position2a - 1) - position1a))
            FileOpen(3, Form10.TextBox1.Text + cadena + "_Sort.txt", OpenMode.Output)
            Dim ii As Integer
            Dim i0 As Integer
            Dim minimum As Double
            For i0 = 0 To num - 1
                For ii = 0 To num - 1
                    Select Case used(ii)
                        Case False
                            dist2(ii) = Math.Sqrt(Math.Pow(cox(ii) - cox(i0), 2) + Math.Pow(coy(ii) - coy(i0), 2) + Math.Pow(coz(ii) - coz(i0), 2))
                            If dist2(ii) = 0 Then dist2(ii) = 1000
                        Case True
                            dist2(ii) = 1000
                    End Select
                Next ii
                'totes les distàncies  estan calculades, s'ha de buscar el més proper
                'minimum = dist2.Min()
                cont = Array.IndexOf(dist2, dist2.Min)
                If dist2(cont) > 4 Then MsgBox("Gap >4m")
                PrintLine(3, cox(cont), coy(cont), coz(cont))
                used(cont) = True
                Array.Resize(dist2, Nothing)
                ReDim Preserve dist2(num - 1)
            Next i0
            'ileClose(3)
            FileClose(2)
        Next rfiles
        FileClose(3)
        MsgBox("Sort completed")
        Exit Sub
ErrorHandler:
    End Sub
    Sub sortxyz2()
        Dim erro As Integer = 0
        FileClose(1)
        FileClose(2)
        FileClose(3)
        Dim nal As Integer = 0
        Dim alternativa(0) As Integer
        Dim indexnpm As Integer
        Dim indexnpmtmp As Integer
        Dim numerodepuntos As Integer = 0
        Dim npm As Double = 10000000
        Dim npmtmp As Double = 10000000
        Dim cont As Integer = 0
        Dim coxb As Double
        Dim coyb As Double
        Dim cozb As Double
        Dim attrib() As Double
        Dim dummy As String
        Dim num As Integer = 0
        Dim pep As Double
        Dim i As Integer = 0
        Dim cas As Integer = 0
        Dim rfiles As String = ""
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim openFileDialog2 As New OpenFileDialog()
        Dim position1a As Integer
        Dim position2a As Integer
        Dim cadena As String = ""
        Dim cox() As Double
        Dim coy() As Double
        Dim coz() As Double
        Dim used() As Boolean
        Dim dist0() As Double
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog2.Multiselect = True
        openFileDialog2.Title = "Sorting X, Y, Z, Att."
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        For Each rfiles In openFileDialog2.FileNames
            FileOpen(2, rfiles, OpenMode.Input)
            On Error GoTo ErrorHandler
            dummy = LineInput(2)
            Do While Not EOF(2)
                dummy = LineInput(2)
                numerodepuntos += 1
            Loop

            ReDim Preserve cox(numerodepuntos)
            ReDim Preserve coy(numerodepuntos)
            ReDim Preserve coz(numerodepuntos)
            ReDim Preserve dist0(numerodepuntos)
            ReDim Preserve attrib(numerodepuntos)
            ReDim Preserve used(numerodepuntos)

            num = 0
            FileClose(2)
            FileOpen(2, rfiles, OpenMode.Input)
            dummy = LineInput(2)
            Do While Not EOF(2)
                e = LineInput(2)
                ' e = Trim(e) : position1 = InStrRev(e, " ")
                ' attrib(num) = e.Substring(position1, e.Length - position1)
                ' e = Left(e, position1)
                e = Trim(e) : position1 = InStrRev(e, " ")
                coz(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                e = Trim(e) : position1 = InStrRev(e, " ")
                coy(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                e = Trim(e) : position1 = InStrRev(e, " ")
                cox(num) = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                dist0(num) = Math.Sqrt(Math.Pow(cox(num), 2) + Math.Pow(coy(num), 2) + Math.Pow(coz(num), 2))
                If dist0(num) < npm Then
                    indexnpm = num
                    npm = dist0(num)
                End If
                num += 1
            Loop

            FileClose(2)
            position1a = InStrRev(rfiles, "\")
            position2a = InStrRev(rfiles, ".")
            cadena = rfiles.Substring(position1a, ((position2a - 1) - position1a))
            FileOpen(3, Form10.TextBox1.Text + cadena + "_Sort.txt", OpenMode.Output)

            PrintLine(3, cox(indexnpm), coy(indexnpm), coz(indexnpm)) ', attrib(indexnpm))
            used(indexnpm) = True

            Dim ii As Integer
            Dim i0 As Integer
            For i0 = 0 To numerodepuntos - 1
                For ii = 0 To numerodepuntos - 1
                    Select Case used(ii)
                        Case False
                            'dist0(ii) = Math.Sqrt(Math.Pow(cox(ii) - cox(indexnpm), 2) + Math.Pow(coy(ii) - coy(indexnpm), 2) + Math.Pow(coz(ii) - coz(indexnpm), 2))
                            dist0(ii) = Math.Sqrt(Math.Pow(cox(ii) - cox(indexnpm), 2) + Math.Pow(coy(ii) - coy(indexnpm), 2))

                        Case True
                            dist0(ii) = 100000
                    End Select
                    'buscar el minimo
                    If dist0(ii) = 0 Then used(ii) = True
                    If dist0(ii) <= npmtmp And dist0(ii) > 0 And dist0(ii) < Form27.NumericUpDown2.Value Then
                        indexnpmtmp = ii
                        npmtmp = dist0(ii)
                    End If
                Next ii
                'càlcul de la ruta més bona


                used(indexnpmtmp) = True
                PrintLine(3, cox(indexnpmtmp), coy(indexnpmtmp), coz(indexnpmtmp)) ', dist0(indexnpmtmp), indexnpmtmp) 'b(indexnpmtmp))
                npm = npmtmp
                npmtmp = 100000
                indexnpm = indexnpmtmp
                indexnpmtmp = 0


                ' Array.Resize(dist0, Nothing)
                ' Array.Resize(alternativa, Nothing)
                nal = 0
                'fileClose(3)
            Next i0
            FileClose(2)
            FileClose(3)
            Array.Resize(dist0, Nothing)
            Array.Resize(cox, Nothing)
            Array.Resize(coy, Nothing)
            Array.Resize(coz, Nothing)
            Array.Resize(used, Nothing)
            indexnpm = 0
            indexnpmtmp = 0
            numerodepuntos = 0
            npm = 10000000
            npmtmp = 10000000
            cont = 0
            num = 0
        Next rfiles
        MsgBox("Sort completed")
        Exit Sub
ErrorHandler:
    End Sub

End Module





