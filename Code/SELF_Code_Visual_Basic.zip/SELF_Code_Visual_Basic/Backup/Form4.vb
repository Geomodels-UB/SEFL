Public Class Form4

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If CheckBox1.Checked = True Then continuitat()
        If CheckBox1.Checked = False Then continuitat2()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        Label11.Text = "          "
        If Me.CheckBox1.Checked = True Then
            Me.NumericUpDown10.Enabled = False
            Me.NumericUpDown2.Enabled = True
            Me.NumericUpDown3.Enabled = True
        End If
        If Me.CheckBox1.Checked = False Then
            Me.NumericUpDown10.Enabled = True
            Me.NumericUpDown2.Enabled = False
            Me.NumericUpDown3.Enabled = False
        End If
    End Sub

    Private Sub NumericUpDown7_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown7.ValueChanged

    End Sub

    Private Sub Form4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label8.Click

    End Sub
End Class