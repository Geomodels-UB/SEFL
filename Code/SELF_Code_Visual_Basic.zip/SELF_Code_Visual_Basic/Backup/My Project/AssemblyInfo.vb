﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' La información general sobre un ensamblado se controla mediante el siguiente 
' conjunto de atributos. Cambie estos atributos para modificar la información
' asociada con un ensamblado.

' Revisar los valores de los atributos del ensamblado

<Assembly: AssemblyTitle("Projecte120")> 
<Assembly: AssemblyDescription("Processament de dades Lidar")> 
<Assembly: AssemblyCompany("Universitat de Barcelona I. R. Geomodels")> 
<Assembly: AssemblyProduct("Projecte120")> 
<Assembly: AssemblyCopyright("©  2008")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'El siguiente GUID sirve como identificador de la biblioteca de tipos si este proyecto se expone a COM
<Assembly: Guid("ce0a3e66-b3ed-4909-a9be-e50da696e44a")> 

' La información de versión de un ensamblado consta de los cuatro valores siguientes:
'
'      Versión principal
'      Versión secundaria 
'      Número de versión de compilación
'      Revisión
'
' Puede especificar todos los valores o establecer como predeterminados los números de versión de compilación y de revisión 
' mediante el asterisco ('*'), como se muestra a continuación:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("6.3.0.0")> 
<Assembly: AssemblyFileVersion("6.2.0.0")> 

<Assembly: NeutralResourcesLanguageAttribute("en")> 