Imports System.IO
Imports System

Public Class Form2

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim px As Double
        Dim py As Double
        Dim pz As Double
        Dim iz As Double
        Dim jz As Double
        Dim kz As Double
        Dim oriz As Double
        Dim penz As Double
        Dim pint As Integer
        Dim pr As Integer
        Dim pg As Integer
        Dim pv As Integer
        Dim offx As Double
        Dim offy As Double
        Dim offz As Double
        Dim pm As Double
        Dim pk As Double
        Dim pn As Double
        Dim rugosity As Double
        Dim weight As Double
        Dim hei As Double
        Dim ar As Double
        Dim fam As String = "as"
        Dim aass As Double
        Dim co As Integer
        Dim inputRecord As String = Nothing
        Dim mypath As String
        Dim myPoints() As String
        offx = CSng(Me.TextBox1.Text) : offy = CSng(Me.TextBox2.Text) : offz = CSng(Me.TextBox3.Text)
        Dim openFileDialog1 As New OpenFileDialog()
        Me.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Me.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        FileOpen(1, Me.OpenFileDialog1.FileName, OpenMode.Input)
        mypath = Me.OpenFileDialog1.FileName
        FileOpen(2, Form10.TextBox1.Text + "coordenate.txt", OpenMode.Output)
        If RadioButton1.Checked = True And CheckBox3.Checked = True Then

            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"))
            Loop


            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            '            For co = 4 To 1731817
            ' '  numeropunts = numeropunts + 1
            ' Input(1, px)
            ' Input(1, py)
            ' Input(1, pz)
            ' Input(1, aass)
            ' px = px + offx : py = py + offy : pz = pz + offz
            ' PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"))
            ' Next
            ' FileClose(2)
            ' FileOpen(2, Form10.TextBox1.Text + "coordenate1.txt", OpenMode.Output)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' For co = 1731823 To 2132085
            ' Input(1, px)
            ' Input(1, py)
            ' Input(1, pz)
            '  Input(1, aass)
            '  px = px + offx : py = py + offy : pz = pz + offz
            ' PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"))
            ' Next
            ' FileClose(2)
            ' FileOpen(2, Form10.TextBox1.Text + "coordenate2.txt", OpenMode.Output)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            '  fam = LineInput(1)
            ' fam = LineInput(1)
            ' fam = LineInput(1)
            ' For co = 2132091 To 2801417
            ' Input(1, px)
            ' Input(1, py)
            ' Input(1, pz)
            ' Input(1, aass)
            ' px = px + offx : py = py + offy : pz = pz + offz
            ' PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"))
            ' Next
            ' FileClose(2)
            ' FileOpen(2, Form10.TextBox1.Text + "coordenate3.txt", OpenMode.Output)
            '  fam = LineInput(1)
            ' fam = LineInput(1)
            '  fam = LineInput(1)
            '  fam = LineInput(1)
            '  fam = LineInput(1)
            ' For co = 2801423 To 26314058
            '     Input(1, px)
            '     Input(1, py)
            '     Input(1, pz)
            '     Input(1, aass)
            '     px = px + offx : py = py + offy : pz = pz + offz
            '     PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"))
            ' Next
            ' FileClose(2)

        End If
        If RadioButton2.Checked = True And CheckBox3.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, pint)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, Format(px, "##.####"), Format(py, "##.####"), Format(pz, "##.####"), pint)
            Loop
        End If
        If RadioButton3.Checked = True And CheckBox3.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, pr)
                Input(1, pg)
                Input(1, pv)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, Format(px, "##.##"), Format(py, "##.##"), Format(pz, "##.##"), pr, pg, pv)
            Loop
        End If
        If RadioButton1.Checked = True And CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, iz)
                Input(1, jz)
                Input(1, kz)
                Input(1, oriz)
                Input(1, penz)
                Input(1, pm)
                Input(1, pk)
                Input(1, pn)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn)
            Loop
        End If
        If RadioButton2.Checked = True And CheckBox1.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, iz)
                Input(1, jz)
                Input(1, kz)
                Input(1, oriz)
                Input(1, penz)
                Input(1, pm)
                Input(1, pk)
                Input(1, pn)
                Input(1, pint)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pint)
            Loop
        End If
        If RadioButton1.Checked = True And CheckBox3.Checked = True Then
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, iz)
                Input(1, jz)
                Input(1, kz)
                Input(1, oriz)
                Input(1, penz)
                Input(1, pm)
                Input(1, pk)
                Input(1, pn)
                Input(1, pr)
                Input(1, pg)
                Input(1, pv)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pr, pg, pv)
            Loop
        End If
        If CheckBox2.Checked = True Then
            PrintLine(2, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Wide", "Long", "Area", "Family")
            Do Until EOF(1)
                numeropunts = numeropunts + 1
                Input(1, px)
                Input(1, py)
                Input(1, pz)
                Input(1, iz)
                Input(1, jz)
                Input(1, kz)
                Input(1, oriz)
                Input(1, penz)
                Input(1, pm)
                Input(1, pk)
                Input(1, pn)
                Input(1, pr)
                Input(1, rugosity)
                Input(1, weight)
                Input(1, hei)
                Input(1, ar)
                Input(1, fam)
                px = px + offx : py = py + offy : pz = pz + offz
                PrintLine(2, px, py, pz, iz, jz, kz, oriz, penz, pm, pk, pn, pr, rugosity, weight, hei, ar, fam)
            Loop
        End If
        FileClose(1)
        FileClose(2)
        MsgBox("Coordenates completed")
        Exit Sub
ErrorHandler:
    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk

    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            CheckBox2.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        If CheckBox2.Checked = True Then
            CheckBox1.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub CheckBox3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            CheckBox1.Checked = False
            CheckBox2.Checked = False
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        rotation()
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged

    End Sub
End Class