﻿Imports System
Imports System.IO

Module MU
    Public it As Integer
    Dim coordx As New List(Of Double)
    Dim coordy As New List(Of Double)
    Dim coordz As New List(Of Double)
    Public Sub FSB()
        Dim Arestes, Arestes1, Arestes2, Arestes3, Arestes4 As Integer
        Dim numfrac1 As Integer
        Dim vx As New List(Of Double)
        Dim vy As New List(Of Double)
        Dim vz As New List(Of Double)
        Dim azimu As New List(Of Double)
        Dim pende As New List(Of Double)
        Dim colineal As New List(Of Double)
        Dim coplanar As New List(Of Double)
        Dim population As New List(Of Integer)
        Dim number As New List(Of Integer)
        Dim rugosity As New List(Of Double)
        Dim lon As New List(Of Double)
        Dim wide As New List(Of Double)
        Dim areas As New List(Of Double)
        Dim fami As New List(Of String)
        Dim dfracture As New List(Of Double)
        Dim angulorder As New List(Of Double)
        Dim angulordenado As New List(Of Double)
        Dim dist5 As Double
        Dim o, p, ka As Double
        Dim ang(9) As Double
        Dim dipdir As Double
        Dim pendi As Double
        Dim P0x, P0y, P0z, P1x, P1y, P1z, P2x, P2y, P3x, P3y As Double
        Dim Puntx1, Puntx2, Puntx3, Puntx4, Punty1, Punty2, Punty3, Punty4, Puntz1, Puntz2, Puntz3, Puntz4 As New List(Of Double)
        ' Dim it As Integer = 0
        Dim puntinterx, puntintery, puntinterz As Double
        Dim puninterx(), punintery(), puninterz() As Double
        Dim px(3), py(3), pz(3) As Double
        Dim pxf(3), pyf(3), pzf(3) As Double
        FileClose(3)
        FileOpen(3, Form10.TextBox1.Text + "Fracture_Boundary.txt", OpenMode.Output)
        '******Vectores de bedding********************************
        azibedd = Form31.NumericUpDown1.Value
        dibedd = Form31.NumericUpDown2.Value
        pe = Form31.NumericUpDown2.Value
        azibedd = (azibedd * Math.PI) / 180
        dibedd = (dibedd * Math.PI) / 180
        vecibedd = Math.Sin(azibedd)
        vecjbedd = Math.Cos(azibedd)
        veckbedd = Math.Sqrt(((vecibedd * vecibedd) + (vecjbedd * vecjbedd)) / (Math.Tan(dibedd) * (Math.Tan(dibedd))))
        If veckbedd > 100000 Then veckbedd = 99999.999999999
        If azibedd = 0 And dibedd = 0 Then
            vecibedd = 0
            vecjbedd = 0
            veckbedd = 0
        End If
        ' vecibedd = 0
        'vecjbedd = 0
        ' veckbedd = 0
        '******Coneixer l'ordre de les arestes**************
        Dim PuntInterArestesX, PuntInterArestesY, PuntInterArestesZ As New List(Of Double)
        Dim PuntX, PuntY, PuntZ As Double
        Dim tlinea As New List(Of Double)
        Dim cenfrax, cenfray, cenfraz As Double
        Dim valorlinea, valorlinea2, valorlinea3 As Double
        Dim seleccio() As Integer
        Dim sel, sel2 As Integer
        '******obrir fitxer properties de fractures**************
        ' Dim mypath2 As String
        Dim openFileDialog1 As New OpenFileDialog()
        On Error GoTo errorhandler
        Form31.OpenFileDialog1.Title = "Read Fracture Properties"
        Form31.OpenFileDialog1.ShowDialog()
        myPath = Form31.OpenFileDialog1.FileName
        Dim dummy As Double
        Dim dummy1 As Integer
        Dim dummy2 As String = ""
        Dim inputRecord As String = Nothing
        Dim myPoints() As String
        Dim LastNonEmpty As Integer = -1
        Dim inReader As StreamReader = File.OpenText(myPath)
        Dim plix, pliy, pliz As Double  'afegit 9-01-16
        Dim Doutc As Double  'afegit 9-01-16
        Dim l1extensio As Double 'afegit 9-01-16
        Dim pun1x, pun1y, pun1z As Double   ' afegit 9-01-16
        Dim puntinterxls(2), puntinteryls(2), puntinterzls(2) As Double    'afegit 9-01-16
        Dim longscli1 As Double    'afegit 9-01-16
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            sel2 = 0
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                dummy = CDbl(myPoints(0).Trim)
                coordx.Add(dummy)
                dummy = CDbl(myPoints(1).Trim)
                coordy.Add(dummy)
                dummy = CDbl(myPoints(2).Trim)
                coordz.Add(dummy)
                dummy = CDbl(myPoints(3).Trim)
                vx.Add(dummy)
                dummy = CDbl(myPoints(4).Trim)
                vy.Add(dummy)
                dummy = CDbl(myPoints(5).Trim)
                vz.Add(dummy)
                dummy = CDbl(myPoints(6).Trim)
                azimu.Add(dummy)
                dummy = CDbl(myPoints(7).Trim)
                pende.Add(dummy)
                dummy = CDbl(myPoints(8).Trim)
                colineal.Add(dummy)
                dummy = CDbl(myPoints(9).Trim)
                coplanar.Add(dummy)
                dummy1 = CInt(myPoints(10).Trim)
                population.Add(dummy1)
                dummy1 = CInt(myPoints(11).Trim)
                number.Add(dummy1)
                dummy = CDbl(myPoints(12).Trim)
                rugosity.Add(dummy)
                dummy = CDbl(myPoints(13).Trim)
                lon.Add(dummy)
                dummy = CDbl(myPoints(14).Trim)
                wide.Add(dummy)
                dummy = CDbl(myPoints(15).Trim)
                areas.Add(dummy)
                dummy2 = myPoints(16).Trim
                fami.Add(dummy2)
                '**********calcul de les arestes******************
                'extrems del rectangle
                A = (vecjbedd * vz.Item(it)) - (veckbedd * vy.Item(it))
                B = (veckbedd * vx.Item(it)) - (vecibedd * vz.Item(it))
                C = (vecibedd * vy.Item(it)) - (vecjbedd * vx.Item(it))
                calculpendent()
                pz(0) = 0
                pz(1) = 0
                pz(2) = 0
                pz(3) = 0
                P0x = (lon.Item(it) / 2) * Math.Sin((b1) * (Math.PI / 180))
                P0y = (lon.Item(it) / 2) * Math.Cos((b1) * (Math.PI / 180))
                P1x = -(lon.Item(it) / 2) * Math.Sin((b1) * (Math.PI / 180))
                P1y = -(lon.Item(it) / 2) * Math.Cos((b1) * (Math.PI / 180))
                P2x = (wide.Item(it) / 2) * Math.Sin((b1) * (Math.PI / 180))
                P2y = (wide.Item(it) / 2) * Math.Cos((b1) * (Math.PI / 180))
                P3x = -(wide.Item(it) / 2) * Math.Sin((b1) * (Math.PI / 180))
                P3y = -(wide.Item(it) / 2) * Math.Cos((b1) * (Math.PI / 180))
                px(1) = P0x + P3y
                py(1) = P0y + P2x
                px(0) = P0x + P2y
                py(0) = P0y + P3x
                px(3) = P1x + P3y
                py(3) = P1y + P2x
                px(2) = P1x + P2y
                py(2) = P1y + P3x
                o = -((pendi) * Math.PI) / 180
                p = 0
                ka = 0
                '4 rotacions
                ang(1) = Math.Cos(p) * Math.Cos(ka)
                ang(2) = -Math.Cos(p) * Math.Sin(ka)
                ang(3) = Math.Sin(p)
                ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
                ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
                ang(6) = -Math.Sin(o) * Math.Cos(p)
                ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
                ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
                ang(9) = Math.Cos(o) * Math.Cos(p)
                '5 Traslacio
                For n = 0 To 3
                    pxf(n) = ((px(n) * ang(1)) + (py(n) * ang(2)) + (pz(n) * ang(3)))
                    pyf(n) = ((px(n) * ang(4)) + (py(n) * ang(5)) + (pz(n) * ang(6)))
                    pzf(n) = ((px(n) * ang(7)) + (py(n) * ang(8)) + (pz(n) * ang(9)))
                Next n
                '6 Rotació al voltant de kappa
                o = 0
                p = 0
                ka = -(((dipdir) * Math.PI) / 180) '-(((dipdir - 90) * Math.PI) / 180) 
                '7 Rotacio
                ang(1) = Math.Cos(p) * Math.Cos(ka)
                ang(2) = -Math.Cos(p) * Math.Sin(ka)
                ang(3) = Math.Sin(p)
                ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
                ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
                ang(6) = -Math.Sin(o) * Math.Cos(p)
                ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
                ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
                ang(9) = Math.Cos(o) * Math.Cos(p)
                '8 Traslacio
                For n = 0 To 3
                    px(n) = ((pxf(n) * ang(1)) + (pyf(n) * ang(2)) + (pzf(n) * ang(3)))
                    py(n) = ((pxf(n) * ang(4)) + (pyf(n) * ang(5)) + (pzf(n) * ang(6)))
                    pz(n) = ((pxf(n) * ang(7)) + (pyf(n) * ang(8)) + (pzf(n) * ang(9)))
                Next n
                'Rotar bedding
                '   Send a data point to the current command
                Puntx1.Add(coordx.Item(it) + px(0))
                Punty1.Add(coordy.Item(it) + py(0))
                Puntz1.Add(coordz.Item(it) + pz(0))
                Puntx2.Add(coordx.Item(it) + px(2))
                Punty2.Add(coordy.Item(it) + py(2))
                Puntz2.Add(coordz.Item(it) + pz(2))
                Puntx3.Add(coordx.Item(it) + px(3))
                Punty3.Add(coordy.Item(it) + py(3))
                Puntz3.Add(coordz.Item(it) + pz(3))
                Puntx4.Add(coordx.Item(it) + px(1))
                Punty4.Add(coordy.Item(it) + py(1))
                Puntz4.Add(coordz.Item(it) + pz(1))
                'màxim i minim de les fractures
                If it = 0 Then
                    cenfrax = coordx.Item(it)
                    cenfray = coordy.Item(it)
                    cenfraz = coordz.Item(it)
                    valorlinea3 = Math.Pow(vecibedd, 2) + Math.Pow(vecjbedd, 2) + Math.Pow(veckbedd, 2)
                End If
                PuntX = coordx.Item(it) - cenfrax
                PuntY = coordy.Item(it) - cenfray
                PuntZ = coordz.Item(it) - cenfraz
                valorlinea = (vecibedd * PuntX) + (vecjbedd * PuntY) + (veckbedd * PuntZ)
                PuntInterArestesX.Add(((valorlinea * vecibedd) / valorlinea3) + cenfrax)
                PuntInterArestesY.Add(((valorlinea * vecjbedd) / valorlinea3) + cenfray)
                PuntInterArestesZ.Add(((valorlinea * veckbedd) / valorlinea3) + cenfraz)
                tlinea.Add((PuntInterArestesX.Item(it) - cenfrax) / vecibedd)
                '**************pla de fractura*****************
                dfracture.Add(-(vx.Item(it) * coordx.Item(it)) - (vy.Item(it) * coordy.Item(it)) - (vz.Item(it) * coordz.Item(it))) 'vector fractura*posicio fractura pla, de fractura
            End If
            it += 1
            LastNonEmpty = -1
            inputRecord = inReader.ReadLine()
        End While
        '*************orientació del pla*****************
        If Form31.NumericUpDown6.Value = 0 And Form31.NumericUpDown7.Value = 0 And Form31.NumericUpDown8.Value = 0 And Form31.NumericUpDown9.Value = 0 And Form31.NumericUpDown10.Value = 0 And Form31.NumericUpDown11.Value = 0 Then
            calculoutcrop()
            Form31.Label8.Text = Format(Vec1, "0.000")
            Form31.Label9.Text = Format(Vec2, "0.000")
            Form31.Label10.Text = Format(Vec3, "0.000")
            Form31.Label11.Text = Format(xmean, "0.000")
            Form31.Label12.Text = Format(ymean, "0.000")
            Form31.Label13.Text = Format(zmean, "0.000")
        Else
            Vec1 = Form31.NumericUpDown6.Value
            Vec2 = Form31.NumericUpDown7.Value
            Vec3 = Form31.NumericUpDown8.Value
            xmean = Form31.NumericUpDown9.Value
            ymean = Form31.NumericUpDown10.Value
            zmean = Form31.NumericUpDown11.Value
        End If
        '***************vector de la linea bedding-Superficie outcrop --> SCLbo
        Dim lslx, lsly, lslz As Double
        lslx = (Vec2 * veckbedd) - (Vec3 * vecjbedd)
        lsly = (Vec3 * vecibedd) - (Vec1 * veckbedd)  ' vector linea SCLbo
        lslz = (Vec1 * vecjbedd) - (Vec2 * vecibedd)
        '**************Numero i posicions d'SCL en vertical
        Dim refmax, refmin As Double
        Dim valormax, valormin As Integer
        refmax = tlinea.Max
        valormax = tlinea.IndexOf(refmax)
        refmin = tlinea.Min
        valormin = tlinea.IndexOf(refmin)
        Dim PuntPartidaX, PuntPartidaY, PuntPartidaZ As Double
        Dim PuntFinalX, PuntFinalY, PuntFinalZ As Double
        Dim longitud, longitudt, dist1, dist2, dist3, dist4 As Double
        PuntPartidaX = cenfrax + (tlinea.Item(valormin) * vecibedd)
        PuntPartidaY = cenfray + (tlinea.Item(valormin) * vecjbedd)
        PuntPartidaZ = cenfraz + (tlinea.Item(valormin) * veckbedd)

        PuntFinalX = cenfrax + (tlinea.Item(valormax) * vecibedd)
        PuntFinalY = cenfray + (tlinea.Item(valormax) * vecjbedd)
        PuntFinalZ = cenfraz + (tlinea.Item(valormax) * veckbedd)

        longitud = Math.Sqrt((Math.Pow(PuntFinalX - PuntPartidaX, 2)) + (Math.Pow(PuntFinalY - PuntPartidaY, 2)) + (Math.Pow(PuntFinalZ - PuntPartidaZ, 2)))
        longitudt = tlinea.Max - tlinea.Min
        Dim interval As Double
        interval = Math.Truncate((longitud / (Form31.NumericUpDown3.Value / 100)) + 1)
        interval = longitudt / interval
        '************** Final numero i posicions d'SCL en vertical

        Dim Dsl, pox, poy, poz, vxlinea, vylinea, vzlinea, Pliny, Plinx, Plinz, t1linea As Double
        PrintLine(3, "Pos_X", "Pos_Y", "Pos_Z", "#Fractures", "#Arestes", "SL_length", "Frac_Int", "Tics_Int", "item")
        Doutc = -(Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean) 'afegit 09-01-16
        '************* inici dels SCL
        For i = tlinea.Min To tlinea.Max Step interval
            sel = 0
            'punt del scanline
            pox = cenfrax + (i * vecibedd)
            poy = cenfray + (i * vecjbedd)
            poz = cenfraz + (i * veckbedd)
            'completar el pla de l'scanline
            Dsl = -(vecibedd * pox) - (vecjbedd * poy) - (veckbedd * poz)
            For ii = 0 To it - 1
                ' Vector de la linea de interseccio
                vxlinea = (vecjbedd * vz.Item(ii)) - (veckbedd * vy.Item(ii))
                vylinea = (veckbedd * vx.Item(ii)) - (vecibedd * vz.Item(ii))
                vzlinea = (vecibedd * vy.Item(ii)) - (vecjbedd * vx.Item(ii))
                ' Un punt de la recta
                Pliny = ((-dfracture.Item(ii) * vecibedd) + (vx.Item(ii) * Dsl)) / ((-vx.Item(ii) * vecjbedd) + (vy.Item(ii) * vecibedd))
                Plinx = ((-vecjbedd * Pliny) - Dsl) / vecibedd
                Plinz = 0
                'Punt més proper al centroide del pla de fractura i la linea de intersecció
                t1linea = ((((vxlinea * (coordx.Item(ii) - Plinx) + ((vylinea * (coordy.Item(ii) - Pliny))) + ((vzlinea * (coordz.Item(ii) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                puntinterx = ((vxlinea * t1linea) + Plinx)
                puntintery = ((vylinea * t1linea) + Pliny)
                puntinterz = ((vzlinea * t1linea) + Plinz)
                '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding
                'distancia total: centre de bedding al centroid de la fractura
                dist2 = Math.Sqrt((Math.Pow((pox - coordx.Item(ii)), 2)) + (Math.Pow((poy - coordy.Item(ii)), 2)) + (Math.Pow((poz - coordz.Item(ii)), 2)))
                'distancia vertical: pla de bedding al centroide
                dist1 = Math.Abs((vecibedd * coordx.Item(ii)) + (vecjbedd * coordy.Item(ii)) + (veckbedd * coordz.Item(ii)) + Dsl) / Math.Sqrt((Math.Pow(vecibedd, 2)) + (Math.Pow(vecjbedd, 2)) + (Math.Pow(veckbedd, 2)))
                'distancia horitzontal: centre de bedding al punt de intersecció
                dist3 = Math.Sqrt((Math.Pow((pox - puntinterx), 2)) + (Math.Pow((poy - puntintery), 2)) + (Math.Pow((poz - puntinterz), 2)))
                'distancia vertical:  Centroide al punt de intersecció
                dist4 = Math.Sqrt((Math.Pow((coordx.Item(ii) - puntinterx), 2)) + (Math.Pow((coordy.Item(ii) - puntintery), 2)) + (Math.Pow((coordz.Item(ii) - puntinterz), 2)))
                ' PrintLine(3, Format(puntinterx, "0.000"), Format(puntintery, "0.000"), Format(puntinterz, "0.000"), Format(dist4, "0.000"))

                pliy = ((-Doutc * vecibedd) + (Vec1 * Dsl)) / ((-Vec1 * vecjbedd) + (Vec2 * vecibedd))
                plix = ((-vecjbedd * pliy) - Dsl) / vecibedd
                pliz = 0
                l1extensio = ((((lslx * (puntinterx - plix) + ((lsly * (puntintery - pliy))) + ((lslz * (puntinterz - pliz))))) / ((lslx * lslx) + (lsly * lsly) + (lslz * lslz))))
                pun1x = ((lslx * l1extensio) + plix)
                pun1y = ((lsly * l1extensio) + pliy)
                pun1z = ((lslz * l1extensio) + pliz)
                ' PrintLine(3, Format(pun1x, "0.000"), Format(pun1y, "0.000"), Format(pun1z, "0.000"))

                dist5 = Math.Sqrt((Math.Pow((pun1x - puntinterx), 2)) + (Math.Pow((pun1y - puntintery), 2)) + (Math.Pow((pun1z - puntinterz), 2)))
                If (wide.Item(ii) / 2) >= dist4 And dist5 < Form31.NumericUpDown5.Value Then
                    ReDim Preserve seleccio(sel)
                    ReDim Preserve puninterx(sel)
                    ReDim Preserve punintery(sel)
                    ReDim Preserve puninterz(sel)
                    seleccio(sel) = ii
                    puninterx(sel) = puntinterx
                    punintery(sel) = puntintery
                    puninterz(sel) = puntinterz
                    ' PrintLine(3, puntinterx, puntintery, puntinterz, sel)
                    ' PrintLine(3, pun1x, pun1y, pun1z)
                    sel += 1
                End If
            Next
            If sel = 0 Then
                ReDim Preserve seleccio(sel)
                ReDim Preserve puninterx(sel)
                ReDim Preserve punintery(sel)
                ReDim Preserve puninterz(sel)
                puninterx(sel) = 0
                punintery(sel) = 0
                puninterz(sel) = 0

            End If
            '***************Calcul de l'extensió de l'Scanline**************
            ' Dim plix, pliy, pliz As Double
            ' Dim Doutc As Double
            Dim lextensio(puninterx.Length - 1) As Double
            Dim punx(puninterx.Length - 1), puny(puninterx.Length - 1), punz(puninterx.Length - 1) As Double
            Dim puntinterxls1(2), puntinteryls1(2), puntinterzls1(2) As Double
            Dim longscli As Double
            '  Doutc = -(Vec1 * coordx.Average) - (Vec2 * coordy.Average) - (Vec3 * coordz.Average)
            For conta = 0 To puninterx.Length - 1
                'coordx.Average()
                ' Un punt de la recta
                pliy = ((-Doutc * vecibedd) + (Vec1 * Dsl)) / ((-Vec1 * vecjbedd) + (Vec2 * vecibedd))
                plix = ((-vecjbedd * pliy) - Dsl) / vecibedd
                pliz = 0
                'Punt més proper al centroide del pla de fractura i la linea de intersecció
                lextensio(conta) = ((((lslx * (puninterx(conta) - plix) + ((lsly * (punintery(conta) - pliy))) + ((lslz * (puninterz(conta) - pliz))))) / ((lslx * lslx) + (lsly * lsly) + (lslz * lslz))))
                punx(conta) = ((lslx * lextensio(conta)) + plix)
                puny(conta) = ((lsly * lextensio(conta)) + pliy)
                punz(conta) = ((lslz * lextensio(conta)) + pliz)
            Next
            '*****************Final de l'extensio de l'scanline
            Dim lextensio2(puninterx.Length - 1) As Double
            Dim ll As Integer
            Array.Copy(lextensio, lextensio2, lextensio.Length)
            Array.Sort(lextensio2)
            '  puntinterxls(0) = ((lslx * lextensio.Min) + plix)
            ' puntinteryls(0) = ((lsly * lextensio.Min) + pliy)
            ' puntinterzls(0) = ((lslz * lextensio.Min) + pliz)0
            Dim prim, seco As Integer
            For l = 0 To lextensio2.Length - 2
                prim = Array.IndexOf(lextensio, lextensio2(l))
                seco = Array.IndexOf(lextensio, lextensio2(l + 1))
                '  puntinterxls(1) = ((lslx * lextensio(ll)) + plix)
                ' puntinteryls(1) = ((lsly * lextensio(ll)) + pliy)
                ' puntinterzls(1) = ((lslz * lextensio(ll)) + pliz)
                '  longscli = longscli + Math.Sqrt((Math.Pow(puntinterxls(0) - puntinterxls(1), 2) + Math.Pow(puntinteryls(0) - puntinteryls(1), 2) + Math.Pow(puntinterzls(0) - puntinterzls(1), 2)))
                longscli = longscli + Math.Sqrt((Math.Pow(puninterx(prim) - puninterx(seco), 2) + Math.Pow(punintery(prim) - punintery(seco), 2) + Math.Pow(puninterz(prim) - puninterz(seco), 2)))
                ' puntinterxls(0) = puntinterxls(1)
                ' puntinteryls(0) = puntinteryls(1)
                ' puntinterzls(0) = puntinterzls(1)
            Next
            'longscli = Math.Sqrt((Math.Pow(puntinterxls(0) - puntinterxls(1), 2) + Math.Pow(puntinteryls(0) - puntinteryls(1), 2) + Math.Pow(puntinterzls(0) - puntinterzls(1), 2)))
            ' puntinterxls(1) = ((lslx * lextensio.Max) + plix)
            '  puntinteryls(1) = ((lsly * lextensio.Max) + pliy)
            ' puntinterzls(1) = ((lslz * lextensio.Max) + pliz)
            ' longscli = Math.Sqrt((Math.Pow(puntinterxls(0) - puntinterxls(1), 2) + Math.Pow(puntinteryls(0) - puntinteryls(1), 2) + Math.Pow(puntinterzls(0) - puntinterzls(1), 2)))
            sel2 += 1
            '**********Distancia ales arestes********************
            Dim distanceArestes, tren1, tren2 As Double
            For iii = 0 To it - 1
                tren1 = Math.Abs((vecibedd * Puntx1.Item(iii)) + (vecjbedd * Punty1.Item(iii)) + (veckbedd * Puntz1.Item(iii)) + Dsl)
                tren2 = Math.Sqrt(Math.Pow(vecibedd, 2) + Math.Pow(vecjbedd, 2) + Math.Pow(veckbedd, 2))
                distanceArestes = tren1 / tren2
                If distanceArestes < (Form31.NumericUpDown4.Value / 100) Then
                    Arestes1 += 1
                End If
                tren1 = Math.Abs((vecibedd * Puntx2.Item(iii)) + (vecjbedd * Punty2.Item(iii)) + (veckbedd * Puntz2.Item(iii)) + Dsl)
                tren2 = Math.Sqrt(Math.Pow(vecibedd, 2) + Math.Pow(vecjbedd, 2) + Math.Pow(veckbedd, 2))
                distanceArestes = tren1 / tren2
                If distanceArestes < (Form31.NumericUpDown4.Value / 100) Then
                    Arestes2 += 1
                End If
                tren1 = Math.Abs((vecibedd * Puntx3.Item(iii)) + (vecjbedd * Punty3.Item(iii)) + (veckbedd * Puntz3.Item(iii)) + Dsl)
                tren2 = Math.Sqrt(Math.Pow(vecibedd, 2) + Math.Pow(vecjbedd, 2) + Math.Pow(veckbedd, 2))
                distanceArestes = tren1 / tren2
                If distanceArestes < (Form31.NumericUpDown4.Value / 100) Then
                    Arestes3 += 1
                End If
                tren1 = Math.Abs((vecibedd * Puntx4.Item(iii)) + (vecjbedd * Punty4.Item(iii)) + (veckbedd * Puntz4.Item(iii)) + Dsl)
                tren2 = Math.Sqrt(Math.Pow(vecibedd, 2) + Math.Pow(vecjbedd, 2) + Math.Pow(veckbedd, 2))
                distanceArestes = tren1 / tren2
                If distanceArestes < (Form31.NumericUpDown4.Value / 100) Then
                    Arestes4 += 1
                End If
                If Arestes1 = 1 Or Arestes2 = 1 Or Arestes3 = 1 Or Arestes4 = 1 Then Arestes = Arestes + 1
                Arestes1 = 0
                Arestes2 = 0
                Arestes3 = 0
                Arestes4 = 0
            Next
            PrintLine(3, Format(pox, "0.000"), Format(poy, "0.000"), Format(poz, "0.000"), sel, Arestes, Format(longscli, "0.000"), Format(sel / longscli, "0.000"), Format(Arestes / longscli, "0.000"), sel2)
            Arestes = 0
            longscli = 0
        Next
        MsgBox("Process Completed")
        sel2 = 0
        FileClose(3)
errorhandler:
    End Sub
    Public Sub calculoutcrop() 'preferent direction
        Dim i As Integer
        Dim sum1, sum2, sum3, sum4, sum5, sum6 As Double
        Dim c As Double
        Dim d(3) As Double
        '******agafem els punts escollits*******
        If it > 3 Then
            Dim sumax, sumay, sumaz As Double
            sumax = 0 : sumay = 0 : sumaz = 0
            For i = 0 To it - 1
                sumax = sumax + coordx.item(i)
                sumay = sumay + coordy.Item(i)
                sumaz = sumaz + coordz.Item(i)
            Next i
            xmean = sumax / it
            ymean = sumay / it
            zmean = sumaz / it

            sum5 = 0 : sum3 = 0 : sum2 = 0
            sum1 = 0 : sum4 = 0 : sum6 = 0
            For i = 0 To it - 1
                sum5 = sum5 + (coordy.Item(i) - ymean) * (coordz.Item(i) - zmean)
                sum3 = sum3 + (coordx.Item(i) - xmean) * (coordz.Item(i) - zmean)
                sum2 = sum2 + (coordx.Item(i) - xmean) * (coordy.Item(i) - ymean)

                sum1 = sum1 + Math.Pow(((coordx.Item(i)) - xmean), 2)
                sum4 = sum4 + Math.Pow(((coordy.Item(i)) - ymean), 2)
                sum6 = sum6 + Math.Pow(((coordz.Item(i)) - zmean), 2)
            Next i
            '***Ara ve el càlcul***
            Dim n As Integer = 3
            Dim a(3, 3) As Double
            Dim V(3, 3) As Double
            Dim b(3) As Double
            Dim zz(3) As Double
            Dim sm As Double, g As Double, h As Double, s As Double, t As Double, p As Double
            Dim tau As Double, tresh As Double, theta As Double
            Dim Nrot As Integer
            Dim j As Integer, k As Integer
            Dim ip As Integer, iq As Integer
            Dim prop4 As String
            a(1, 1) = sum1
            a(1, 2) = sum2
            a(1, 3) = sum3
            a(2, 1) = sum2
            a(2, 2) = sum4
            a(2, 3) = sum5
            a(3, 1) = sum3
            a(3, 2) = sum5
            a(3, 3) = sum6
            'inici Jacobi transformació matrix
            For ip = 1 To n
                For iq = 1 To n
                    V(ip, iq) = 0
                Next iq
                V(ip, ip) = 1
            Next ip
            For ip = 1 To n
                b(ip) = a(ip, ip)
                d(ip) = b(ip)
                zz(ip) = 0
            Next ip
            Nrot = 0
            For i = 1 To 50
                sm = 0
                For ip = 1 To (n - 1)
                    For iq = (ip + 1) To n
                        sm = sm + Math.Abs(a(ip, iq))
                    Next iq
                Next ip
                If sm = 0 Then GoTo LINE123
                If i < 4 Then
                    tresh = 0.2 * sm / n ^ 2
                Else
                    tresh = 0
                End If
                For ip = 1 To (n - 1)
                    For iq = (ip + 1) To n
                        g = 100 * Math.Abs(a(ip, iq))
                        If i > 4 And (Math.Abs(d(ip)) + g) = Math.Abs(d(ip)) And (Math.Abs(d(iq)) + g) = Math.Abs(d(iq)) Then
                            a(ip, iq) = 0
                        ElseIf Math.Abs(a(ip, iq)) > tresh Then
                            h = d(iq) - d(ip)
                            If (Math.Abs(h) + g) = Math.Abs(h) Then
                                t = a(ip, iq) / h
                            Else
                                theta = 0.5 * h / a(ip, iq)
                                t = 1 / (Math.Abs(theta) + Math.Sqrt(1 + theta ^ 2))
                                If theta < 0 Then t = -t
                            End If
                            c = 1 / Math.Sqrt(1 + Math.Pow(t, 2))
                            s = t * c
                            tau = s / (1 + c)
                            h = t * a(ip, iq)
                            zz(ip) = zz(ip) - h
                            zz(iq) = zz(iq) + h
                            d(ip) = d(ip) - h
                            d(iq) = d(iq) + h
                            a(ip, iq) = 0
                            For j = 1 To (ip - 1)
                                g = a(j, ip)
                                h = a(j, iq)
                                a(j, ip) = g - s * (h + g * tau)
                                a(j, iq) = h + s * (g - h * tau)
                            Next j
                            For j = (ip + 1) To (iq - 1)
                                g = a(ip, j)
                                h = a(j, iq)
                                a(ip, j) = g - s * (h + g * tau)
                                a(j, iq) = h + s * (g - h * tau)
                            Next j
                            For j = (iq + 1) To n
                                g = a(ip, j)
                                h = a(iq, j)
                                a(ip, j) = g - s * (h + g * tau)
                                a(iq, j) = h + s * (g - h * tau)
                            Next j
                            For j = 1 To n
                                g = V(j, ip)
                                h = V(j, iq)
                                V(j, ip) = g - s * (h + g * tau)
                                V(j, iq) = h + s * (g - h * tau)
                            Next j
                            Nrot = Nrot + 1
                        End If
                    Next iq
                Next ip
                For ip = 1 To n
                    b(ip) = b(ip) + zz(ip)
                    d(ip) = b(ip)
                    zz(ip) = 0
                Next ip
            Next i
            'Final de Jacobi Transformation matrix
LINE123:

            '***ara ordenem***
            'inici eigsrt
            For i = 1 To n - 1
                k = i
                p = d(i)
                For j = i + 1 To n
                    If d(j) > p Then
                        k = j
                        p = d(j)
                    End If
                Next j
                If k <> i Then
                    d(k) = d(i)
                    d(i) = p
                    For j = 1 To n
                        p = V(j, i)
                        V(j, i) = V(j, k)
                        V(j, k) = p
                    Next j
                End If
            Next i
            'final Press et at 1986
            Dim normalized As Double
            For i = 1 To 3
                normalized = d(i) + normalized
            Next
            d(1) = d(1) / normalized
            d(2) = d(2) / normalized
            d(3) = d(3) / normalized
            Dim prop1 As Double, prop2 As Double

            If V(3, 3) < 0 Then      '  If V(3, 3) < 0 Then
                Vec1 = -V(1, 3)     ' vector_i = V(2, 3)
                Vec2 = -V(2, 3)     ' vector_j = V(1, 3)
                Vec3 = -V(3, 3)    '  vector_k = -V(3, 3)
            Else
                Vec1 = V(1, 3)     '     vector_i = V(1, 3)
                Vec2 = V(2, 3)   '     vector_j = V(2, 3)
                Vec3 = V(3, 3) '      vector_k = V(3, 3)
            End If
            'afegit
            prop1 = Math.Log(d(1) / d(2))
            prop2 = Math.Log(d(2) / d(3))
            prop3 = Math.Log(d(1) / d(3)) 'Aixo es la M
            If vector_i = 0 And vector_j = 1 And vector_k = 0 Then prop3 = 10
            If vector_i = 0 And vector_j = 0 And vector_k = 1 Then prop3 = 10
            If vector_i = 1 And vector_j = 0 And vector_k = 0 Then prop3 = 10
            prop4 = Str(prop3)
            If prop4 = "Infinito" Then prop3 = 1035
            kapa = prop1 / prop2  ' Això es la K
        Else
            vector_i = 0
            vector_j = 0
            vector_k = 0
            indat = True
        End If
    End Sub
End Module
