﻿Public Class Form23

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i1, i2 As Double
        Dim j1, j2 As Double
        Dim k1, k2 As Double
        Dim azi1, azi2 As Double
        Dim di1, di2 As Double
        Dim ang As Double
        Dim ang2 As Double
        azi1 = NumericUpDown1.Text
        di1 = NumericUpDown2.Text
        azi2 = NumericUpDown3.Text
        di2 = NumericUpDown4.Text
        '******primer angle*******
        azi1 = (azi1 * Math.PI) / 180
        di1 = (di1 * Math.PI) / 180
        i1 = Math.Sin(azi1)
        j1 = Math.Cos(azi1)
        k1 = Math.Sqrt(((i1 * i1) + (j1 * j1)) / (Math.Tan(di1) * (Math.Tan(di1))))
        If k1 > 100000 Then k1 = 9999.999
        If di1 = 0 Then k1 = 0
        If azi1 = 0 And di1 = 0 Then
            i1 = 0
            j1 = 0
            k1 = 0
        End If
        TextBox1.Text = i1
        TextBox2.Text = j1
        TextBox3.Text = k1
        '******segon angle*******
        azi2 = (azi2 * Math.PI) / 180
        di2 = (di2 * Math.PI) / 180
        i2 = Math.Sin(azi2)
        j2 = Math.Cos(azi2)
        k2 = Math.Sqrt(((i2 * i2) + (j2 * j2)) / (Math.Tan(di2) * (Math.Tan(di2))))
        If k2 > 100000 Then k2 = 9999.999
        If di2 = 0 Then k2 = 0
        If azi2 = 0 And di2 = 0 Then
            i2 = 0
            j2 = 0
            k2 = 0
        End If
        TextBox4.Text = Format(i2, "0.00000")
        TextBox5.Text = Format(j2, "0.00000")
        TextBox6.Text = Format(k2, "0.00000")
        '********fi segon angle**********
        ang = Math.Acos(Math.Abs(((i1 * i2) + (j1 * j2) + (k1 * k2)) / (Math.Sqrt((i1 * i1) + (j1 * j1) + (k1 * k1)) * Math.Sqrt((i2 * i2) + (j2 * j2) + (k2 * k2)))))
        ang2 = (ang * 180) / Math.PI
        Label6.Text = Format(ang2, "0.000")
        '********Sigma 2*****************
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        Dim dt As Double
        at = (j1 * k2) - (j2 * k1)
        bt = (i2 * k1) - (i1 * k2)
        ct = (i1 * j2) - (i2 * j1)
        If ct < 0 Then dt = ct * (-1)
        Dim a1 As Double
        Dim b1 As Double
        If at = 0 And bt = 0 Then   '***la traça és horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        If ct < 0 Then
            b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / dt)
        Else
            b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        End If


        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
        a1 = 180 + a1
        b1 = 90 - b1
        If ct < 0 Then
            a1 = a1 - 180
            ct = dt
        End If
500:
        Label11.Text = Format(a1, "0.00")
        Label14.Text = Format(b1, "0.00")
        '******sigma 3************
        ' at+bt+ct = 0
        'unitario
        Dim unitari As Double
        unitari = Math.Sqrt((at * at) + (bt * bt) + (ct * ct))
        at = at / unitari
        bt = bt / unitari
        ct = ct / unitari
        at = 0.083
        bt = -0.164
        ct = 0.983


        ' ang3=ang/2
        Dim ang3 As Double
        ang3 = ang / 2
        'at+bt+ct=0
        'i1+j1+k1=ang3
        'i2+j2+k2=ang3
        'solucion ni, nj, nk 
        Dim ni As Double '= -0.4353
        Dim nj As Double ' = 0.15698
        Dim nk As Double '= 0.0629
        Dim carro1 As Double
        carro1 = (i2 * bt * i1 * ct) / ((at * at * j1) - (i1 * bt * at))
        Dim carro2 As Double
        carro2 = (i2 * bt * at * k1) / ((at * at * j1) - (i1 * bt * at))
        Dim carro3 As Double
        carro3 = (i2 * bt * ang3 * at) / ((at * at * j1) - (i1 * bt * at))
        Dim carro4 As Double
        carro4 = ((i2 * ct)) / (at)
        Dim carro5 As Double
        carro5 = (j2 * i1 * ct) / ((at * j1) - (i1 * bt))
        Dim carro6 As Double
        carro6 = (j2 * at * k1) / ((at * j1) - (i1 * bt))
        Dim carro7 As Double
        carro7 = (j2 * ang3 * at) / ((at * j1) - (i1 * bt))

        nk = (ang3 + carro3 - carro7) / (-carro1 + carro2 - carro4 + carro5 - carro6 + k2)
        nj = ((i1 * ct * nk) - (at * k1 * nk) + (ang3 * at)) / ((at * j1) - (i1 * bt))
        ni = (-(bt * nj) - (ct * nk)) / at
        unitari = Math.Sqrt((ni * ni) + (nj * nj) + (nk * nk))
        'i(unitario)
        ni = ni / unitari
        nj = nj / unitari
        nk = nk / unitari
        'i(unitario)


        'segmentation calcula azimuth i pendiente
        Dim a2 As Double
        Dim b2 As Double
        If ni = 0 And nj = 0 Then   '***la traça és horitzontal***
            a2 = 0
            b2 = 0
            GoTo 501
        End If
        '***calculem dip i dip direction***
        b2 = Math.Atan(Math.Sqrt((ni * ni) + (nj * nj)) / nk)
        b2 = (b2 * 180) / Math.PI

        If nj <> 0 Then
            a2 = Math.Atan(ni / nj)
            a2 = (a2 * 180) / Math.PI
        Else
            If ni < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a2 = -90
            Else
                a2 = 90
            End If
        End If

        If nj < 0 Then
            a2 = 180 + a2
        Else
            If nj < 0 Then
                a2 = 360 + a2
            Else
            End If
        End If
        a2 = 180 + a2
        b2 = 90 - b2

501:
        Label12.Text = Format(a2, "0.00")
        Label15.Text = Format(b2, "0.00")
        '***sigma 1*********
        ' producto vectorial entre at,bt,ct i ni, nj, nk 

        Dim si As Double
        Dim sj As Double
        Dim sk As Double
        si = (bt * nk) - (nj * ct)
        sj = (ni * ct) - (at * nk)
        sk = (at * nj) - (ni * bt)
        unitari = Math.Sqrt((si * si) + (sj * sj) + (sk * sk))
        'i(unitario)
        si = si / unitari
        sj = sj / unitari
        sk = sk / unitari

        '  If sk < 0 Then
        ' sk = sk * (-1)
        ' si = unitari
        ' si = sj
        ' sj = unitari
        ' End If

        Dim a3 As Double
        Dim b3 As Double
        If si = 0 And sj = 0 Then   '***la traça és horitzontal***
            a3 = 0
            b3 = 0
            GoTo 502
        End If
        '***calculem dip i dip direction***
        b3 = Math.Atan(Math.Sqrt((si * si) + (sj * sj)) / sk)
        b3 = (b3 * 180) / Math.PI

        If sj <> 0 Then
            a3 = Math.Atan(si / sj)
            a3 = (a3 * 180) / Math.PI
        Else
            If si < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a3 = -90
            Else
                a3 = 90
            End If
        End If

        If sj < 0 Then
            a3 = 180 + a3
        Else
            If si < 0 Then
                a3 = 360 + a3
            Else
            End If
        End If
        '   a3 = 180 + a3
        b3 = 90 + b3

502:
        Label10.Text = Format(a3, "0.00")
        Label13.Text = Format(b3, "0.00")






    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class