﻿Module Module4
    Dim at As Double
    Dim bt As Double
    Dim ct As Double
    Sub projectionPlane()
        '*****dimensionament******
        '****along X ---> long
        '****along Y ---> wide
        'omega es x, phi es y i K es Z
        Dim aaa As Integer
        Dim tx(), ty() As Double
        Dim noui3, nouj3, nouk3 As Double
        Dim dipdir As Double
        Dim dimenx, dimeny As Double
        Dim valor As Integer
        Dim contad As Integer = 0
        Dim linx3(), liny3(), linz3() As Double
        Dim espaiament As Integer
        Dim cofi As Double
        Dim cofj As Double
        Dim vectori3, vectorj3, vectork3 As Double
        Dim vecipla2, vecjpla2, veckpla2 As Double
        Dim vecipla1, vecjpla1, veckpla1 As Double
        Dim vectori(), vectorj(), vectork() As Double
        Dim ang(9) As Double
        Dim n As Double
        Dim px() As Double
        Dim pxf() As Double
        Dim py() As Double
        Dim pyf() As Double
        Dim pz() As Double
        Dim pzf() As Double
        Dim o, p, ka As Double
        Dim t11() As Double
        Dim t33() As Double
        Dim D1() As Double
        Dim D2 As Double
        Dim azi As Double
        Dim xyboolean(,) As Boolean
        Dim orienpla1 As Double
        Dim orienpla2 As Double
        Dim orienpla3 As Double
        Dim pendpla1 As Double
        Dim pendpla2 As Double
        Dim pendpla3 As Double
        Dim coordx(), coordy(), coordz() As Double
        Dim azimu(), pende() As Double
        Dim intenso As String = "A"
        Dim colineal, coplanar, population, number, rugosity(), lon(), wide(), areas() As Double
        Dim fami, familie, contadorletra As String
        fami = "a" : familie = "a" : contadorletra = "a"
        Dim sumax, sumay, sumaz As Double
        Dim i As Double
        Dim di, cont As Integer
        Dim puntcontactex, puntcontactey, puntcontactez As Double
        Dim puntcontactex2, puntcontactey2, puntcontactez2 As Double
        Dim maxx, maxy, maxz As Double
        Dim seccio As Integer
        Dim tram() As Double
        Dim rr As Double
        Dim areatram() As Double
        Dim conta As Integer = 1
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        FileOpen(2, Form10.TextBox1.Text + "projectionplane" + contadorletra + ".txt", OpenMode.Output)

        '******Fi dimensionament*********
        seleccio = 1
        '******obrir fitxer morfometria**************
        Form20.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form20.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form20.OpenFileDialog1.FileName, OpenMode.Input)
        Input(1, intenso) ' ****** primera linea de lletres
        Do Until EOF(1)
            ReDim Preserve x(seleccio)
            ReDim Preserve y(seleccio)
            ReDim Preserve z(seleccio)
            ReDim Preserve coordx(seleccio)
            ReDim Preserve coordy(seleccio)
            ReDim Preserve coordz(seleccio)
            ReDim Preserve areas(seleccio)
            ReDim Preserve escollits(seleccio)
            ReDim Preserve azimu(seleccio)
            ReDim Preserve pende(seleccio)
            ReDim Preserve lon(seleccio)
            ReDim Preserve wide(seleccio)
            ReDim Preserve rugosity(seleccio)
            Input(1, coordx(seleccio)) 'x
            Input(1, coordy(seleccio)) 'y
            Input(1, coordz(seleccio)) 'z
            Input(1, x(seleccio)) 'i
            Input(1, y(seleccio)) 'j
            Input(1, z(seleccio)) 'k
            Input(1, azimu(seleccio)) 'azi
            Input(1, pende(seleccio)) 'dip
            Input(1, colineal) 'M
            Input(1, coplanar) 'K
            Input(1, population) 'Population
            Input(1, number) 'Number
            Input(1, rugosity(seleccio)) 'Rugosity
            Input(1, lon(seleccio)) 'Long
            Input(1, wide(seleccio)) 'Wide
            Input(1, areas(seleccio)) 'Area
            Input(1, fami) 'Family
            If seleccio = 1 Then familie = fami
            If fami <> familie Then
                seleccio = seleccio - 1
                '********* calcul dels vectors mitjos,fracturació o estratificació Pla 1 *********************
                ' l'entrada es x(i)y(i)z(i) que s'ha canviat per vectors
                calculvectors()
                'Vec1 = AA : Vec2 = BB : Vec3 = CC
                If Vec3 < 0 Then
                    Vec1 = -Vec1
                    Vec2 = -Vec2
                    Vec3 = -Vec3
                End If
                AA = Vec1 : BB = Vec2 : CC = Vec3
                calculdips()
                orienpla1 = orien
                pendpla1 = pend
                vecipla1 = Vec1 : vecjpla1 = Vec2 : veckpla1 = Vec3
                '********* Pla a on s'ha de projectar projeccio, Pla 2 *********************
                ReDim vectori(seleccio)
                ReDim vectorj(seleccio)
                ReDim vectork(seleccio)
                'canviem els vectors pels punts
                For i = 0 To seleccio
                    vectori(i) = x(i)
                    vectorj(i) = y(i)
                    vectork(i) = z(i)
                    x(i) = coordx(i)
                    y(i) = coordy(i)
                    z(i) = coordz(i)
                Next i
                'Depen on es vulgui projectar
                'a la mitja de la paret de l'aflorament
                If Form20.RadioButton1.Checked = True Then
                    calculvectors()
                    calculdips()
                    orienpla2 = orien
                    pendpla2 = pend
                    vecipla2 = AA : vecjpla2 = BB : veckpla2 = CC
                End If
                ' a la perpendicular de la fracturació
                If Form20.RadioButton3.Checked = True Then
                    pendpla2 = 90 - pendpla1
                    orienpla2 = orienpla1 + 90
                    If orienpla1 > 360 Then
                        orienpla2 = orienpla2 - 360
                    End If
                    azi = (orienpla2 * Math.PI) / 180
                    dipdir = (pendpla2 * Math.PI) / 180
                    vecipla2 = Math.Sin(azi)
                    vecjpla2 = Math.Cos(azi)
                    veckpla2 = Math.Sqrt(((vecipla2 * vecipla2) + (vecjpla2 * vecjpla2)) / (Math.Tan(dipdir) * (Math.Tan(dipdir))))
                    If veckpla2 > 100000 Then veckpla2 = 99999.999999999
                    If azi = 0 And dipdir = 0 Then
                        vecipla2 = 0
                        vecjpla2 = 0
                        veckpla2 = 0
                    End If
                End If
                'a la perpendicular de l'opció1
                If Form20.RadioButton2.Checked = True Then
                    pendpla2 = 90 - pendpla2
                    If orienpla2 > 180 Then
                        orienpla2 = orienpla2 - 180
                    Else
                        orienpla2 = orienpla2 + 180
                    End If
                    azi = (orienpla2 * Math.PI) / 180
                    dipdir = (pendpla2 * Math.PI) / 180
                    vecipla2 = Math.Sin(azi)
                    vecjpla2 = Math.Cos(azi)
                    veckpla2 = Math.Sqrt(((vecipla2 * vecipla2) + (vecjpla2 * vecjpla2)) / (Math.Tan(dipdir) * (Math.Tan(dipdir))))
                    If veckpla2 > 100000 Then veckpla2 = 99999.999999999
                    If azi = 0 And dipdir = 0 Then
                        vecipla2 = 0
                        vecjpla2 = 0
                        veckpla2 = 0
                    End If
                End If
                ' a l'altre perpendicular de la fracturacio long
                If Form20.RadioButton4.Checked = True Then
                    pendpla2 = pendpla1
                    orienpla2 = orienpla1 + 90
                    If orienpla1 > 360 Then
                        orienpla2 = orienpla2 - 360
                    End If
                    azi = (orienpla2 * Math.PI) / 180
                    dipdir = (pendpla2 * Math.PI) / 180
                    vecipla2 = Math.Sin(azi)
                    vecjpla2 = Math.Cos(azi)
                    veckpla2 = Math.Sqrt(((vecipla2 * vecipla2) + (vecjpla2 * vecjpla2)) / (Math.Tan(dipdir) * (Math.Tan(dipdir))))
                    If veckpla2 > 100000 Then veckpla2 = 99999.999999999
                    If azi = 0 And dipdir = 0 Then
                        vecipla2 = 0
                        vecjpla2 = 0
                        veckpla2 = 0
                    End If
                End If






                '********* Vector de les líneas a projectar *********************
                'estan contenidas en els dos plans
                vectori3 = (vecjpla2 * veckpla1) - (veckpla2 * vecjpla1)
                vectorj3 = (veckpla2 * vecipla1) - (vecipla2 * veckpla1)
                vectork3 = (vecipla2 * vecjpla1) - (vecjpla2 * vecipla1)
                If vectork3 < 0 Then
                    vectori3 = (vecjpla1 * veckpla2) - (veckpla1 * vecjpla2)
                    vectorj3 = (veckpla1 * vecipla2) - (vecipla1 * veckpla2)
                    vectork3 = (vecipla1 * vecjpla2) - (vecjpla1 * vecipla2)
                End If
                '********* Vectors unitaris **********************************
                nouj3 = Math.Sqrt((Math.Pow(vectorj3, 2) / (Math.Pow(vectori3, 2) + Math.Pow(vectorj3, 2) + Math.Pow(vectork3, 2))))
                noui3 = (vectori3 * nouj3) / vectorj3
                nouk3 = (vectork3 * nouj3) / vectorj3
                vectori3 = noui3
                vectorj3 = nouj3
                vectork3 = nouk3
                '************ Fi vectors unitaris ***************************
                AA = vectori3 : BB = vectorj3 : CC = vectork3
                calculdips()
                orienpla3 = orien
                pendpla3 = pend
                '********* calcul de D de l'equació del pla punt mig, Pla 2 ********************
                'per cada punt a projectar
                sumax = 0 : sumay = 0 : sumaz = 0
                ReDim D1(seleccio)
                For i = 1 To seleccio
                    di = escollits(i)
                    sumax = sumax + x(di)
                    sumay = sumay + y(di)
                    sumaz = sumaz + z(di)
                    D1(i) = (vecipla1 * x(i)) + (vecjpla1 * y(i)) + (veckpla1 * z(i))
                Next i
                'de la paret mitja
                xmean = sumax / seleccio
                ymean = sumay / seleccio
                zmean = sumaz / seleccio
                D2 = (vecipla2 * xmean) + (vecjpla2 * ymean) + (veckpla2 * zmean) ' Del pla de projeccio
                '******** Punt per la linea, centroide del pla *********************
                ReDim t11(seleccio)
                ReDim t33(seleccio)
                ReDim linx3(seleccio)
                ReDim liny3(seleccio)
                ReDim linz3(seleccio)
                '******** final Rotacions per trovar les extensions *********************
                '******** Calcul de la linea3 continguda en pla2 de projeccio per cada pla1 *********************'
                cofi = -(vecipla1 / vecipla2)
                cofj = -(vecjpla1 / vecjpla2)
                For i = 1 To seleccio
                    'de l'equació de la línea 3 trobar un punt per situar les D
                    linz3(i) = 1
                    liny3(i) = (-linz3(i) * (veckpla1 + (cofi * veckpla2)) + (cofi * D2) + D1(i)) / (vecjpla1 + (cofi * vecjpla2))
                    linx3(i) = (-linz3(i) * (veckpla1 + (cofj * veckpla2)) + (cofj * D2) + D1(i)) / (vecipla1 + (cofj * vecipla2))
                    ' es calcula la t de la lineació 3
                    t33(i) = ((vectori3 * (x(i) - linx3(i))) + (vectorj3 * (y(i) - liny3(i))) + (vectork3 * (z(i) - linz3(i)))) / ((vectori3 * vectori3) + (vectorj3 * vectorj3) + (vectork3 * vectork3))
                    ' es tova el punt de contacte amb la variable t33 per cada punt
                    puntcontactex = linx3(i) + (t33(i) * vectori3)
                    puntcontactey = liny3(i) + (t33(i) * vectorj3)
                    puntcontactez = linz3(i) + (t33(i) * vectork3)
                    '****Fins aquí funciona bé
                    'PrintLine(2, Format(puntcontactex, "#.####"), Format(puntcontactey, "#.####"), Format(puntcontactez, "#.####"), i)
                    'nou
                    espaiament = Math.Truncate((wide(i) / 2) / Form20.NumericUpDown1.Value)
                    If Form20.RadioButton4.Checked = True Then
                        espaiament = Math.Truncate((lon(i) / 2) / Form20.NumericUpDown1.Value)
                    End If
                    For n = -espaiament To espaiament
                        '    Dim nouespace As Integer
                        '   nouespace = Math.Truncate(espaiament / Form20.NumericUpDown1.Value) + 1
                        'For n = 0 To nouespace
                        'If i = 11 Then Stop
                        puntcontactex2 = linx3(i) + ((t33(i) + (n * Form20.NumericUpDown1.Value)) * vectori3)
                        puntcontactey2 = liny3(i) + ((t33(i) + (n * Form20.NumericUpDown1.Value)) * vectorj3)
                        puntcontactez2 = linz3(i) + ((t33(i) + (n * Form20.NumericUpDown1.Value)) * vectork3)
                        puntcontactex = puntcontactex2 + (t11(i) * vecipla1)
                        puntcontactey = puntcontactey2 + (t11(i) * vecjpla1)
                        puntcontactez = puntcontactez2 + (t11(i) * veckpla1)
                        contad = contad + 1
                        ReDim Preserve px(contad)
                        ReDim Preserve py(contad)
                        ReDim Preserve pz(contad)
                        px(contad) = puntcontactex
                        py(contad) = puntcontactey
                        pz(contad) = puntcontactez
                        'PrintLine(2, Format(puntcontactex, "#.####"), Format(puntcontactey, "#.####"), Format(puntcontactez, "#.####"), n)
                    Next n
                Next i
                'lonprojectat = (Math.sin((pendpla3 * Math.PI) / 180)) * (lon(i) / 2)
                'difz = (Math.Cos((pendpla3 * Math.PI) / 180)) * (lon(i) / 2)
                'dify = (Math.Sin((orienpla3 * Math.PI) / 180)) * (lonprojectat)
                'difx = (Math.Cos((orienpla3 * Math.PI) / 180)) * (lonprojectat)
                '3 Rotació al voltant de Kappa
                o = 0
                p = 0
                ka = (orienpla2 * Math.PI) / 180
                '4 rotacions
                ang(1) = Math.Cos(p) * Math.Cos(ka)
                ang(2) = -Math.Cos(p) * Math.Sin(ka)
                ang(3) = Math.Sin(p)
                ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
                ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
                ang(6) = -Math.Sin(o) * Math.Cos(p)
                ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
                ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
                ang(9) = Math.Cos(o) * Math.Cos(p)
                '5 Traslacio
                aaa = contad / Form20.NumericUpDown1.Value
                ReDim pxf(contad)
                ReDim pyf(contad)
                ReDim pzf(contad)
                For n = 1 To contad
                    pxf(n) = ((px(n) * ang(1)) + (py(n) * ang(2)) + (pz(n) * ang(3)))
                    pyf(n) = ((px(n) * ang(4)) + (py(n) * ang(5)) + (pz(n) * ang(6)))
                    pzf(n) = ((px(n) * ang(7)) + (py(n) * ang(8)) + (pz(n) * ang(9)))
                Next n
                '6 Rotació al voltant d'omega
                o = (pendpla2 * Math.PI) / 180
                p = 0
                ka = 0
                '7 Rotacio
                ang(1) = Math.Cos(p) * Math.Cos(ka)
                ang(2) = -Math.Cos(p) * Math.Sin(ka)
                ang(3) = Math.Sin(p)
                ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
                ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
                ang(6) = -Math.Sin(o) * Math.Cos(p)
                ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
                ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
                ang(9) = Math.Cos(o) * Math.Cos(p)
                '8 Traslacio
                For n = 1 To contad
                    'px(n) = Math.Abs(Math.Truncate(((pxf(n) * ang(1)) + (pyf(n) * ang(2)) + (pzf(n) * ang(3)))))
                    'py(n) = Math.Abs(Math.Truncate(((pxf(n) * ang(4)) + (pyf(n) * ang(5)) + (pzf(n) * ang(6)))))

                    px(n) = ((pxf(n) * ang(1)) + (pyf(n) * ang(2)) + (pzf(n) * ang(3)))
                    py(n) = ((pxf(n) * ang(4)) + (pyf(n) * ang(5)) + (pzf(n) * ang(6)))

                    pz(n) = ((pxf(n) * ang(7)) + (pyf(n) * ang(8)) + (pzf(n) * ang(9)))
                    If n = 1 Then
                        maxx = px(1)
                        minx = px(1)
                        maxy = py(1)
                        miny = py(1)
                    End If
                    If px(n) > maxx Then maxx = px(n)
                    If px(n) < minx Then minx = px(n)
                    If py(n) > maxy Then maxy = py(n)
                    If py(n) < miny Then miny = py(n)
                    'PrintLine(2, Format(px(n), "#.####"), Format(py(n), "#.####"), Format(pz(n), "#.####"))
                Next n
                Dim valora As Integer
                Dim valorb As Integer
                Dim cordexx As Integer
                Dim cordeyy As Integer
                dimenx = maxx - minx
                dimeny = maxy - miny
                valora = Math.Truncate(dimenx / Form20.NumericUpDown1.Value)
                valorb = Math.Truncate(dimeny / Form20.NumericUpDown1.Value)

                ReDim xyboolean(valora + 1, valorb + 1)
                ReDim tx(contad)
                ReDim ty(contad)
                'contad tots els valors donats com positius
                For n = 1 To contad
                    tx(n) = px(n) - minx
                    ty(n) = py(n) - miny
                    cordexx = Math.Truncate(tx(n) / Form20.NumericUpDown1.Value)
                    cordeyy = Math.Truncate(ty(n) / Form20.NumericUpDown1.Value)
                    xyboolean(cordexx, cordeyy) = True
                    'PrintLine(2, Format(px(n), "#.####"), Format(py(n), "#.####"))
                    'PrintLine(2, px(n), py(n), xyboolean(px(n), py(n)), n)
                Next n
                'En una matriu de les dimensions max i min segmentats en la mida de cel·la
                Dim na As Double
                Dim ina As Double
                'PrintLine(2, valora + 1, valorb + 1, Form20.NumericUpDown1.Value) ' alternativa matlab d'impressio
                For n = 0 To valora + 1
                    For i = 0 To valorb + 1
                        If xyboolean(n, i) = True Then valor = 1
                        If xyboolean(n, i) = False Then valor = 0

                        '***********Inici Impresions *********************


                        PrintLine(2, na, ina, valor) 'alternativa projecte120 d'impressio
                        '''''''PrintLine(2, valor) 'alternativa matlab d'impressio

                        '********** Final d'impresions ******************

                        ina = ina + Form20.NumericUpDown1.Value
                    Next i
                    na = na + Form20.NumericUpDown1.Value
                    ina = 0
                Next n
                'PrintLine(2, Format(px(n), "#.####"), Format(py(n), "#.####"), Format(pz(n), "#.####"))


                FileClose(2)
                FileClose(1)
                conta = conta + 1
                '******** inici de canvi de familia *********************


                familie = fami
                seleccio = 0
                seccio = 0
                ReDim tram(seccio)
                ReDim areatram(seccio)
                '               ReDim puntcontactex(seleccio)
                '               ReDim puntcontactey(seleccio)
                '               ReDim puntcontactey(seleccio)

                ReDim x(seleccio)
                ReDim y(seleccio)
                ReDim z(seleccio)
                ReDim coordx(seleccio)
                ReDim coordy(seleccio)
                ReDim coordz(seleccio)
                ReDim escollits(seleccio)
                ReDim azimu(seleccio)
                ReDim pende(seleccio)
                '******** Final de canvi de familia *********************
            End If
            escollits(seleccio) = seleccio
            If areas(seleccio) > Form20.NumericUpDown7.Value Then
                If colineal > Form20.NumericUpDown9.Value Then
                    If coplanar < Form20.NumericUpDown8.Value Then
                        If population > Form20.NumericUpDown3.Value Then
                            If rugosity(seleccio) > Form20.NumericUpDown4.Value Then
                                If lon(seleccio) > Form20.NumericUpDown5.Value Then
                                    If wide(seleccio) > Form20.NumericUpDown6.Value Then
                                        seleccio = seleccio + 1

                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Loop

        seleccio = seleccio - 1
        calculvectors() 'mitja dels vectors
        A = Vec1 : B = Vec2 : C = Vec3
        '********* calcul del punt mig *********************
        sumax = 0 : sumay = 0 : sumaz = 0
        For i = 1 To seleccio
            di = escollits(i)
            sumax = sumax + coordx(di)
            sumay = sumay + coordy(di)
            sumaz = sumaz + coordz(di)
        Next i
        xmean = sumax / seleccio
        ymean = sumay / seleccio
        zmean = sumaz / seleccio
        '******** Final calcul del punt mig *********************
        '******** inici informació *********************
        'Form19.NumericUpDown13.Value = Vec3
        ' Form19.NumericUpDown12.Value = Vec2
        ' Form19.NumericUpDown11.Value = Vec1
        ' Form19.NumericUpDown10.Value = zmean
        ' Form19.NumericUpDown9.Value = ymean
        ' Form19.NumericUpDown8.Value = xmean
        at = Vec1
        bt = Vec2
        ct = Vec3

        '*** inici calcul de vector a dip ****
        dipproj()
        '***calculem dip i dip direction***

        'Form19.NumericUpDown14.Value = a1
        'Form19.NumericUpDown15.Value = b1

        '*** inici calcul de vector a dip ****

        '******** Final informació *********************
        'If Form19.CheckBox1.Checked = False Or Form19.CheckBox2.Checked = False Then
        'response = MsgBox("Modify Point or/and Vector?", MsgBoxStyle.YesNoCancel, "Alert")
        'If response = MsgBoxResult.Yes Then Form19.Focus()
        'If response = MsgBoxResult.No Then Form19.Focus()
        'If response = MsgBoxResult.Cancel Then Form19.Focus()
        'End If
        If Form19.CheckBox2.Checked = True Then
            Vec1 = Form19.NumericUpDown11.Value
            Vec2 = Form19.NumericUpDown12.Value
            Vec3 = Form19.NumericUpDown13.Value
        End If
        If Form19.CheckBox1.Checked = True Then
            xmean = Form19.NumericUpDown8.Value
            ymean = Form19.NumericUpDown9.Value
            zmean = Form19.NumericUpDown10.Value
        End If
        '******** inici de la projeccio *********************
        minx = xmean : miny = ymean : minz = zmean
        maxx = xmean : maxy = ymean : maxz = zmean
        contadorletra = CStr(conta)
        FileOpen(2, Form10.TextBox1.Text + "projection" + contadorletra + ".txt", OpenMode.Output)
        ' For cont = 1 To seleccio
        ' D = (coordx(cont) * x(cont)) + (coordy(cont) * y(cont)) + (coordz(cont) * z(cont)) ' plano 
        ' t = (D - (x(cont) * xmean) - (y(cont) * ymean) - (z(cont) * zmean)) / ((x(cont) * Vec1) + (y(cont) * Vec2) + (z(cont) * Vec3))

        'ReDim Preserve puntcontactex(cont)
        'ReDim Preserve puntcontactey(cont)
        'ReDim Preserve puntcontactez(cont)
        'puntcontactex(cont) = xmean + (t * Vec1)
        'puntcontactey(cont) = ymean + (t * Vec2)
        'puntcontactez(cont) = zmean + (t * Vec3)

        '********Búsqueda d'un extrem*********
        '           If puntcontactex(cont) > maxx Then maxx = puntcontactex(cont)
        '            If puntcontactey(cont) > maxy Then maxy = puntcontactey(cont)
        '          If puntcontactez(cont) > maxz Then maxz = puntcontactez(cont)
        '         If puntcontactex(cont) < minx Then minx = puntcontactex(cont)
        '        If puntcontactey(cont) < miny Then miny = puntcontactey(cont)
        '       If puntcontactez(cont) < minz Then minz = puntcontactez(cont)
        '      '********Búsqueda d'un extrem*********
        '     If Form19.RadioButton1.Checked = True Then
        'PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), azimu(cont))
        'E() 'nd If
        'If Form19.RadioButton2.Checked = True Then
        'PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), pende(cont))
        'End If
        'If Form19.RadioButton3.Checked = True Then
        ' PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), rugosity(cont))
        ' End If
        ' If Form19.RadioButton4.Checked = True Then
        ' PrintLine(2, Format(puntcontactex(cont), "#.###"), Format(puntcontactey(cont), "#.###"), Format(puntcontactez(cont), "#.###"), Format(a1, "#.###"), Format(b1, "#.###"), Format(azimu(cont), "#.###"), Format(pende(cont), "#.###"), areas(cont))
        ' End If
        '
        '       Next cont
        'FileClose(2)
        FileClose(1)
        MsgBox("Projection Completed")
errorhandler:
        Exit Sub
    End Sub
    Sub segmentation()
        'Solament funciona amb intensitat
        Dim nm As String
        Dim vect1 As Double
        Dim vect2 As Double
        Dim vect3 As Double
        Dim numfile As Integer
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Integer
        Dim gf As Integer
        Dim vf As Integer
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d As Integer
        b = 0
        a = 0
        c = 0
        Dim openFileDialog1 As New OpenFileDialog()
        Form8.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form8.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form8.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "reduce.txt", OpenMode.Output)
        d = CSng(Form8.NumericUpDown2.Value)
        If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                PrintLine(2, xf, yf, zf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    FileClose(2)
                    numfile = numfile + 1
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + numfile + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, intenf)
                PrintLine(2, xf, yf, zf, intenf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    a = 0
                    FileClose(2)
                    numfile = numfile + 1
                    nm = CStr(numfile)
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + nm + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
                PrintLine(2, xf, yf, zf, rf, gf, vf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    a = 0
                    FileClose(2)
                    numfile = numfile + 1
                    nm = CStr(numfile)
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + nm + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    a = 0
                    FileClose(2)
                    numfile = numfile + 1
                    nm = CStr(numfile)
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + nm + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
                PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, intenf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    a = 0
                    FileClose(2)
                    numfile = numfile + 1
                    nm = CStr(numfile)
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + nm + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
                PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, rf, gf, vf)
                If a = CSng(Form8.NumericUpDown2.Value) Then
                    a = 0
                    FileClose(2)
                    numfile = numfile + 1
                    nm = CStr(numfile)
                    FileOpen(2, Form10.TextBox1.Text + "reduce" + nm + ".txt", OpenMode.Output)
                End If
            Loop
        End If
        'Loop
        Form8.Label4.Text = b
        Form8.Label5.Text = c
        FileClose(2)
        FileClose(1)
errorhandler:
        Exit Sub
    End Sub
    Sub filtermorpho()
        Dim pep As Double
        Dim cox As Double
        Dim coy As Double
        Dim coz As Double
        Dim vectora As Double
        Dim vectorb As Double
        Dim vectorc As Double
        Dim dipdir As Double
        Dim pendi As Double
        Dim m As Double
        Dim k As Double
        Dim population As Integer
        Dim number As Integer
        Dim rugosity As Double
        Dim lon As Double
        Dim wide As Double
        Dim area As Double
        Dim familia As String = "a"
        Dim cas As Integer = 0
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog1.InitialDirectory = Form10.TextBox1.Text
        openFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        If Form21.NumericUpDown1.Value > Form21.NumericUpDown2.Value Then cas = 1
        FileOpen(1, Form10.TextBox1.Text + "FilterMorphology_Accept.txt", OpenMode.Output)
        FileOpen(3, Form10.TextBox1.Text + "FilterMorphology_Rejected.txt", OpenMode.Output)
        FileOpen(2, openFileDialog1.FileName, OpenMode.Input)
        PrintLine(1, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Wide", "Long", "Area", "Set")
        PrintLine(3, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Wide", "Long", "Area", "Set")
        Input(2, familia)
        Do While Not EOF(2)
            Input(2, cox)
            Input(2, coy)
            Input(2, coz)
            Input(2, vectora)
            Input(2, vectorb)
            Input(2, vectorc)
            Input(2, dipdir)
            Input(2, pendi)
            Input(2, m)
            Input(2, k)
            Input(2, population)
            Input(2, number)
            Input(2, rugosity)
            Input(2, lon)
            Input(2, wide)
            Input(2, area)
            Input(2, familia)
            If pendi > Form21.NumericUpDown3.Value And pendi < Form21.NumericUpDown4.Value Then
                If m > Form21.NumericUpDown5.Value And m < Form21.NumericUpDown6.Value Then
                    If k > Form21.NumericUpDown7.Value And k < Form21.NumericUpDown8.Value Then
                        If population > Form21.NumericUpDown9.Value Then
                            If area > Form21.NumericUpDown10.Value Then
                                If lon > Form21.NumericUpDown11.Value Then
                                    If wide > Form21.NumericUpDown12.Value Then
                                        If rugosity > Form21.NumericUpDown13.Value Then
                                            Select Form21.RadioButton1.Checked
                                                Case False
                                                    If dipdir > Form21.NumericUpDown1.Value And dipdir < Form21.NumericUpDown2.Value Then
                                                        PrintLine(1, cox, coy, coz, vectora, vectorb, vectorc, dipdir, pendi, m, k, population, number, rugosity, lon, wide, area, familia)
                                                    Else
                                                        PrintLine(3, cox, coy, coz, vectora, vectorb, vectorc, dipdir, pendi, m, k, population, number, rugosity, lon, wide, area, familia)
                                                    End If
                                                Case True
                                                    pep = Math.Acos(Math.Abs(((Form21.NumericUpDown14.Value * vectora) + (Form21.NumericUpDown15.Value * vectorb) + (Form21.NumericUpDown16.Value * vectorc)) / (Math.Sqrt((Form21.NumericUpDown14.Value * Form21.NumericUpDown14.Value) + (Form21.NumericUpDown15.Value * Form21.NumericUpDown15.Value) + (Form21.NumericUpDown16.Value * Form21.NumericUpDown16.Value))) * (Math.Sqrt((vectora * vectora) + (vectorb * vectorb) + (vectorc * vectorc)))))
                                                    pep = (pep * 180) / Math.PI
                                                    If pep <= Form21.NumericUpDown17.Value Then
                                                        PrintLine(1, cox, coy, coz, vectora, vectorb, vectorc, dipdir, pendi, m, k, population, number, rugosity, lon, wide, area, familia)
                                                    Else
                                                        PrintLine(3, cox, coy, coz, vectora, vectorb, vectorc, dipdir, pendi, m, k, population, number, rugosity, lon, wide, area, familia)
                                                    End If
                                            End Select
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        Loop
        FileClose(2)
        FileClose(3)
        FileClose(1)
        cas = 0
        MsgBox("Filter Morphology Completed")
        Exit Sub
ErrorHandler:
    End Sub
    Sub export2()
        Dim nm As String
        Dim vect1 As Double
        Dim vect2 As Double
        Dim vect3 As Double
        Dim numfile As Integer
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Integer
        Dim gf As Integer
        Dim vf As Integer
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d
        Dim openFileDialog1 As New OpenFileDialog()
        Form22.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form22.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form22.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "clusterindiv1.txt", OpenMode.Output)
        If Form22.RadioButton1.Checked = True Then
            Input(1, xf)
            Input(1, yf)
            Input(1, zf)
            Input(1, dirf)
            Input(1, pendf)
            Input(1, mf)
            Input(1, kf)
            Input(1, nf)
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                If xf = 0 And yf = 0 And zf = 0 Then
                    FileClose(2)
                    d = CStr(dirf)
                    FileOpen(2, Form10.TextBox1.Text + "clusterindiv" + d + ".txt", OpenMode.Output)
                    'numfile = dirf
                Else
                    PrintLine(2, xf, yf, zf, dirf, pendf, mf, kf, nf)
                End If
            Loop
        End If
        If Form22.RadioButton2.Checked = True Then
            Input(1, xf)
            Input(1, yf)
            Input(1, zf)
            Input(1, dirf)
            Input(1, pendf)
            Input(1, mf)
            Input(1, kf)
            Input(1, nf)
            Input(1, intenf)
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
                If xf = 0 And yf = 0 And zf = 0 Then
                    FileClose(2)
                    d = CStr(dirf)
                    FileOpen(2, Form10.TextBox1.Text + "clusterindiv" + d + ".txt", OpenMode.Output)
                Else
                    PrintLine(2, xf, yf, zf, dirf, pendf, mf, kf, nf, intenf)
                End If
            Loop
        End If
        If Form22.RadioButton3.Checked = True Then
            Input(1, xf)
            Input(1, yf)
            Input(1, zf)
            Input(1, dirf)
            Input(1, pendf)
            Input(1, mf)
            Input(1, kf)
            Input(1, nf)
            Input(1, rf)
            Input(1, gf)
            Input(1, vf)
            Do Until EOF(1)
                a = a + 1
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
                If xf = 0 And yf = 0 And zf = 0 Then
                    FileClose(2)
                    d = CStr(dirf)
                    FileOpen(2, Form10.TextBox1.Text + "clusterindiv" + numfile + ".txt", OpenMode.Output)
                    'numfile = dirf
                Else
                    PrintLine(2, xf, yf, zf, dirf, pendf, mf, kf, nf, rf, gf, vf)
                End If
            Loop
        End If
        FileClose(2)
        FileClose(1)
        MsgBox("Clusters Individualization Completed")
errorhandler:
        Exit Sub
        
    End Sub
    Sub subset()
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim vect1 As Double
        Dim vect2 As Double
        Dim vect3 As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Integer
        Dim gf As Integer
        Dim vf As Integer
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d As Integer

        Dim openFileDialog1 As New OpenFileDialog()
        Form8.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form8.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form8.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "Subset.txt", OpenMode.Output)
        'd = CSng(Form8.NumericUpDown1.Value)
        If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf)
                    End If
                End If
            Loop
        End If
        If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, intenf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf, intenf)
                    End If
                End If
            Loop
        End If
        If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = False Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf, rf, gf, vf)
                    End If
                End If
            Loop
        End If
        If Form8.RadioButton1.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf)
                    End If
                End If
            Loop
        End If
        If Form8.RadioButton2.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, intenf)
                    End If
                End If
            Loop
        End If
        If Form8.RadioButton3.Checked = True And Form8.CheckBox1.Checked = True Then
            Do Until EOF(1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
                If xf > Form8.NumericUpDown6.Value And yf > Form8.NumericUpDown4.Value And zf > Form8.NumericUpDown8.Value Then
                    If xf < Form8.NumericUpDown3.Value And yf < Form8.NumericUpDown7.Value And zf < Form8.NumericUpDown5.Value Then
                        PrintLine(2, xf, yf, zf, vect1, vect2, vect3, dirf, pendf, mf, kf, nf, rf, gf, vf)
                    End If
                End If
            Loop
        End If
        FileClose(2)
        FileClose(1)
        MsgBox("Subset Completed")
errorhandler:
        Exit Sub
    End Sub
    Sub Escala()
        Dim xe As Double
        Dim ye As Double
        Dim ze As Double
        Dim ie As Double
        Dim je As Double
        Dim ke As Double
        Dim re As Integer
        Dim ge As Integer
        Dim ve As Integer
        Dim intes As Integer
        B = 0
        a = 0
        c = 0
        D = CSng(Form26.NumericUpDown1.Value)
        Dim openFileDialog1 As New OpenFileDialog()
        Form26.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form26.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, Form26.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "escalate.txt", OpenMode.Output)
        D = CSng(Form26.NumericUpDown1.Value)
        Do Until EOF(1)
            e = LineInput(1)
            'Entrada RGB
            If Form26.RadioButton3.Checked = True Then
                'entrada R
                e = Trim(e) : position1 = InStrRev(e, " ")
                ve = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'entrada G
                e = Trim(e) : position1 = InStrRev(e, " ")
                ge = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'entrada B
                e = Trim(e) : position1 = InStrRev(e, " ")
                re = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            'Entrada intensitat
            If Form26.RadioButton2.Checked = True Then
                'entrada int
                e = Trim(e) : position1 = InStrRev(e, " ")
                intes = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            If Form26.CheckBox1.Checked = True Then
                'entrada i
                e = Trim(e) : position1 = InStrRev(e, " ")
                ke = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'entrada i
                e = Trim(e) : position1 = InStrRev(e, " ")
                je = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'entrada i
                e = Trim(e) : position1 = InStrRev(e, " ")
                ie = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            e = LineInput(1)
            'entrada de Z
            e = Trim(e) : position1 = InStrRev(e, " ")
            ze = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            ' entrada de Y
            e = Trim(e) : position1 = InStrRev(e, " ")
            ye = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            ' entrada de X
            e = Trim(e) : position1 = InStrRev(e, " ")
            xe = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            If Form26.CheckBox1.Checked = False And Form26.RadioButton1.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D)
            If Form26.CheckBox1.Checked = False And Form26.RadioButton2.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D, intes)
            If Form26.CheckBox1.Checked = False And Form26.RadioButton3.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D, re, ge, ve)
            If Form26.CheckBox1.Checked = True And Form26.RadioButton1.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D, ie, je, ke)
            If Form26.CheckBox1.Checked = True And Form26.RadioButton2.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D, ie, je, ke, intes)
            If Form26.CheckBox1.Checked = True And Form26.RadioButton3.Checked = True Then PrintLine(2, xe * D, ye * D, ze * D, ie, je, ke, re, ge, ve)
        Loop
        FileClose(2)
        FileClose(1)
errorhandler:
        Exit Sub
    End Sub
End Module