﻿
Imports System
Imports System.IO
Module FilesOpen
    Public myPath As String 'afegit 23 sept2013
    Public Sub readCSVPoints(ByVal CSV_FileName As String)
        '  Dim myPath As String = CSV_FileName 'eliminat 23 sept2013
        myPath = CSV_FileName 'afegit 23 sept2013
        Dim inputRecord As String = Nothing
        Dim myPoints() As String
        Dim LastNonEmpty As Integer = -1
        Dim imReader As StreamReader = File.OpenText(myPath)
        numeropunts = 0
        inputRecord = imReader.ReadLine()
        While (inputRecord IsNot Nothing)
            numeropunts += 1
            Form1.ProgressBar1.Value = (((numeropunts) / (logbytes / 27.5))) * 50
            inputRecord = imReader.ReadLine()
        End While
        imReader.Close()
        numeropunts -= 1
        numero = numeropunts
        ReDim Preserve x(numeropunts)
        ReDim Preserve y(numeropunts)
        ReDim Preserve z(numeropunts)
        ReDim Preserve inten(numeropunts)
        ReDim Preserve R(numeropunts)
        ReDim Preserve G(numeropunts)
        ReDim Preserve V(numeropunts)
        ReDim Preserve vect1(numeropunts)
        ReDim Preserve vect2(numeropunts)
        ReDim Preserve vect3(numeropunts)
        ReDim Preserve orientacio(numeropunts)
        ReDim Preserve pendent(numeropunts)
        ReDim Preserve bprop3(numeropunts)
        ReDim Preserve bkapa(numeropunts)
        ReDim Preserve bseleccio(numeropunts)
        ReDim Preserve apte(numeropunts)
        numeropunts = 0
        Dim inReader As StreamReader = File.OpenText(myPath)
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = False Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = False Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    inten(numeropunts) = CDbl(myPoints(3).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = False Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    R(numeropunts) = CDbl(myPoints(3).Trim)
                    G(numeropunts) = CDbl(myPoints(4).Trim)
                    V(numeropunts) = CDbl(myPoints(5).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = True Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    vect1(numeropunts) = CDbl(myPoints(3).Trim)
                    vect2(numeropunts) = CDbl(myPoints(4).Trim)
                    vect3(numeropunts) = CDbl(myPoints(5).Trim)
                    orientacio(numeropunts) = CDbl(myPoints(6).Trim)
                    pendent(numeropunts) = CDbl(myPoints(7).Trim)
                    bprop3(numeropunts) = CDbl(myPoints(8).Trim)
                    bkapa(numeropunts) = CDbl(myPoints(9).Trim)
                    bseleccio(numeropunts) = CDbl(myPoints(10).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = True Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    vect1(numeropunts) = CDbl(myPoints(3).Trim)
                    vect2(numeropunts) = CDbl(myPoints(4).Trim)
                    vect3(numeropunts) = CDbl(myPoints(5).Trim)
                    orientacio(numeropunts) = CDbl(myPoints(6).Trim)
                    pendent(numeropunts) = CDbl(myPoints(7).Trim)
                    bprop3(numeropunts) = CDbl(myPoints(8).Trim)
                    bkapa(numeropunts) = CDbl(myPoints(9).Trim)
                    bseleccio(numeropunts) = CDbl(myPoints(10).Trim)
                    inten(numeropunts) = CDbl(myPoints(11).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = True Then
                    x(numeropunts) = CDbl(myPoints(0).Trim)
                    y(numeropunts) = CDbl(myPoints(1).Trim)
                    z(numeropunts) = CDbl(myPoints(2).Trim)
                    vect1(numeropunts) = CDbl(myPoints(3).Trim)
                    vect2(numeropunts) = CDbl(myPoints(4).Trim)
                    vect3(numeropunts) = CDbl(myPoints(5).Trim)
                    orientacio(numeropunts) = CDbl(myPoints(6).Trim)
                    pendent(numeropunts) = CDbl(myPoints(7).Trim)
                    bprop3(numeropunts) = CDbl(myPoints(8).Trim)
                    bkapa(numeropunts) = CDbl(myPoints(9).Trim)
                    bseleccio(numeropunts) = CDbl(myPoints(10).Trim)
                    R(numeropunts) = CDbl(myPoints(11).Trim)
                    G(numeropunts) = CDbl(myPoints(12).Trim)
                    V(numeropunts) = CDbl(myPoints(13).Trim)
                    Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                End If
                numeropunts += 1
                LastNonEmpty = -1
            End If
            inputRecord = inReader.ReadLine()
        End While
        dimensionarmodel()
    End Sub
    Public Sub ReaderLAS()
        Form29.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form29.OpenFileDialog1.ShowDialog()
        ' On Error GoTo ErrorHandler
        ' infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog1.FileName)
        ' FileOpen(1, Form29.OpenFileDialog1.FileName, OpenMode.Input)
        ' MsgBox(Form1.SaveFileDialog1.FileName)
        FileOpen(2, Form10.TextBox1.Text + "las.txt", OpenMode.Output)
        'FileOpen(2, "C:\Dades\projecte120\filt.txt", OpenMode.Output)


        Dim xlas, ylas, zlas As Double
        Dim intens As Integer
        Dim mypath2 As String
        ' Dim CSV_FileName As String
        mypath2 = Form29.OpenFileDialog1.FileName 'afegit 23 sept2013
        Dim dummy As Integer
        Dim inputRecord As String = Nothing
        Dim myPoints() As String
        Dim LastNonEmpty As Integer = -1
        Dim inReader As StreamReader = File.OpenText(mypath2)
        numeropunts = 0
        inputRecord = inReader.ReadLine()
        numeropunts = inReader.ReadLine()
        ' While (inputRecord IsNot Nothing)
        ' numeropunts += 1
        ' Form1.ProgressBar1.Value = (((numeropunts) / (logbytes / 27.5))) * 50
        ' inputRecord = imReader.ReadLine()
        ' End While
        ' imReader.Close()
        ' numeropunts -= 1
        ' numero = numeropunts
        ' ReDim Preserve x(numeropunts)
        ' ReDim Preserve y(numeropunts)
        ' ReDim Preserve z(numeropunts)
        ' ReDim Preserve inten(numeropunts)
        ' ReDim Preserve R(numeropunts)
        ' ReDim Preserve G(numeropunts)
        ' ReDim Preserve V(numeropunts)
        ' ReDim Preserve vect1(numeropunts)
        ' ReDim Preserve vect2(numeropunts)
        ' ReDim Preserve vect3(numeropunts)
        ' ReDim Preserve orientacio(numeropunts)
        ' ReDim Preserve pendent(numeropunts)
        ' ReDim Preserve bprop3(numeropunts)
        ' ReDim Preserve bkapa(numeropunts)
        ' ReDim Preserve bseleccio(numeropunts)
        '  ReDim Preserve apte(numeropunts)
        ' numeropunts = 0
        ' Dim inReader As StreamReader = File.OpenText(myPath)
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                '  If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = False Then
                ' x(numeropunts) = CDbl(myPoints(0).Trim)
                ' y(numeropunts) = CDbl(myPoints(1).Trim)
                ' z(numeropunts) = CDbl(myPoints(2).Trim)
                ' Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                ' End If
                ' If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = False Then
                '  x(numeropunts) = CDbl(myPoints(0).Trim)
                '  y(numeropunts) = CDbl(myPoints(1).Trim)
                '  z(numeropunts) = CDbl(myPoints(2).Trim)
                '  inten(numeropunts) = CDbl(myPoints(3).Trim)
                '  Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                ' End If
                ' If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = False Then
                '  x(numeropunts) = CDbl(myPoints(0).Trim)
                '  y(numeropunts) = CDbl(myPoints(1).Trim)
                '  z(numeropunts) = CDbl(myPoints(2).Trim)
                '  R(numeropunts) = CDbl(myPoints(3).Trim)
                '  G(numeropunts) = CDbl(myPoints(4).Trim)
                '  V(numeropunts) = CDbl(myPoints(5).Trim)
                '  Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                ' End If
                ' If Form1.RadioButton1.Checked = True And Form1.CheckBox1.Checked = True Then
                ' x(numeropunts) = CDbl(myPoints(0).Trim)
                ' y(numeropunts) = CDbl(myPoints(1).Trim)
                ' z(numeropunts) = CDbl(myPoints(2).Trim)
                ' vect1(numeropunts) = CDbl(myPoints(3).Trim)
                ' vect2(numeropunts) = CDbl(myPoints(4).Trim)
                ' vect3(numeropunts) = CDbl(myPoints(5).Trim)
                ' orientacio(numeropunts) = CDbl(myPoints(6).Trim)
                ' pendent(numeropunts) = CDbl(myPoints(7).Trim)
                ' bprop3(numeropunts) = CDbl(myPoints(8).Trim)
                ' bkapa(numeropunts) = CDbl(myPoints(9).Trim)
                ' bseleccio(numeropunts) = CDbl(myPoints(10).Trim)
                '  Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                '  End If
                ' If Form1.RadioButton2.Checked = True And Form1.CheckBox1.Checked = True Then
                '  x(numeropunts) = CDbl(myPoints(0).Trim)
                '  y(numeropunts) = CDbl(myPoints(1).Trim)
                '  z(numeropunts) = CDbl(myPoints(2).Trim)
                '  vect1(numeropunts) = CDbl(myPoints(3).Trim)
                '  vect2(numeropunts) = CDbl(myPoints(4).Trim)
                '  vect3(numeropunts) = CDbl(myPoints(5).Trim)
                '  orientacio(numeropunts) = CDbl(myPoints(6).Trim)
                '  pendent(numeropunts) = CDbl(myPoints(7).Trim)
                '  bprop3(numeropunts) = CDbl(myPoints(8).Trim)
                '  bkapa(numeropunts) = CDbl(myPoints(9).Trim)
                '  bseleccio(numeropunts) = CDbl(myPoints(10).Trim)
                '  inten(numeropunts) = CDbl(myPoints(11).Trim)
                '  Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                '  End If
                ' If Form1.RadioButton3.Checked = True And Form1.CheckBox1.Checked = True Then
                xlas = CDbl(myPoints(0).Trim)
                ylas = CDbl(myPoints(1).Trim)
                zlas = CDbl(myPoints(2).Trim)
                dummy = CDbl(myPoints(3).Trim)
                dummy = CDbl(myPoints(4).Trim)
                dummy = CDbl(myPoints(5).Trim)
                dummy = CDbl(myPoints(6).Trim)
                dummy = CDbl(myPoints(7).Trim)
                dummy = CDbl(myPoints(8).Trim)
                dummy = CDbl(myPoints(9).Trim)
                dummy = CDbl(myPoints(10).Trim)
                intens = CDbl(myPoints(11).Trim)
                dummy = CDbl(myPoints(12).Trim)
                ' V(numeropunts) = CDbl(myPoints(13).Trim)
                'Form1.ProgressBar1.Value = 50 + ((numeropunts * 50) / numero)
                ' End If
                ' numeropunts += 1
                LastNonEmpty = -1
                PrintLine(2, xlas, ylas, zlas, intens)
            End If
            inputRecord = inReader.ReadLine()
        End While
    End Sub
End Module
