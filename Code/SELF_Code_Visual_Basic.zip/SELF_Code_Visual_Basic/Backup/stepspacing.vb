﻿Module stepspacing
    Dim pas As Integer = 0
    Dim set1 As Integer
    Dim set2 As Integer
    Dim set3 As Integer
    Dim set4 As Integer
    Dim set5 As Integer
    Dim set6 As Integer
    Dim set7 As Integer
    Dim set8 As Integer
    Dim set9 As Integer
    Dim set10 As Integer
    Dim set11 As Integer
    Dim set12 As Integer
    Dim set13 As Integer
    Dim set14 As Integer
    Dim attrib() As Double
    Dim cox() As Double
    Dim coy() As Double
    Dim coz() As Double
    Dim cox1 As Double
    Dim coy1 As Double
    Dim coz1 As Double
    Dim cox2 As Double
    Dim coy2 As Double
    Dim coz2 As Double
    Dim dist2() As Double
    Dim dist1 As Double
    Dim numval As Integer = 0
    Dim longitude As Double
    Dim contadorfra As Integer = 0
    Dim contadorvueltas As Integer = 1
    Dim block As Integer = 0
    Dim block1 As Double
    Public Sub readspacing()
        Dim position1a As Integer
        Dim position2a As Integer
        Dim cadena As String = ""
        Dim rfiles As String = ""
        Dim openFileDialog2 As New OpenFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog2.Multiselect = True
        openFileDialog2.Title = "Open Line to surface from Gocad.txt"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        For Each rfiles In openFileDialog2.FileNames
            FileOpen(2, rfiles, OpenMode.Input)
            ' FileOpen(2, openFileDialog2.FileName, OpenMode.Input)
            'FileOpen(3, Form10.TextBox1.Text + "Spac_Density" + "_" + Form27.TextBox1.Text + "_" + Form27.TextBox2.Text + "_" + Form27.TextBox3.Text + ".txt", OpenMode.Output)
            position1a = InStrRev(rfiles, "\")
            position2a = InStrRev(rfiles, ".")
            cadena = rfiles.Substring(position1a, ((position2a - 1) - position1a))
            FileOpen(3, Form10.TextBox1.Text + "stepspace" + cadena + ".txt", OpenMode.Output)
            PrintLine(3, cadena)
            PrintLine(3, " #_Tramo #_Fracturas set1 set2 set3 set4 set5 set6 set7 set8 set9 set10 set11 set12 set13 set14")
            On Error GoTo ErrorHandler
            Do While Not EOF(2)
                ReDim Preserve attrib(numval)
                ReDim Preserve cox(numval)
                ReDim Preserve coy(numval)
                ReDim Preserve coz(numval)
                ReDim Preserve dist2(numval)
                e = LineInput(2)
                Do While e <> ""
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    attrib(numval) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    coz(numval) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    coy(numval) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                    e = Trim(e) : position1 = InStrRev(e, " ")
                    cox(numval) = e.Substring(position1, e.Length - position1)
                    e = Left(e, position1)
                    If numval > 0 Then
                        calculdistance()
                    Else
                        contadorfra = 1
                    End If

                    Select Case attrib(numval)
                        Case 1
                            set1 = set1 + 1
                        Case 2
                            set2 = set2 + 1
                        Case 3
                            set3 = set3 + 1
                        Case 4
                            set4 = set4 + 1
                        Case 5
                            set5 = set5 + 1
                        Case 6
                            set6 = set6 + 1
                        Case 7
                            set7 = set7 + 1
                        Case 8
                            set8 = set8 + 1
                        Case 9
                            set9 = set9 + 1
                        Case 10
                            set10 = set10 + 1
                        Case 11
                            set11 = set11 + 1
                        Case 12
                            set12 = set12 + 1
                        Case 13
                            set13 = set13 + 1
                        Case 14
                            set14 = set14 + 1
                    End Select
                    numval += 1
                Loop
            Loop
            PrintLine(3, contadorvueltas, contadorfra, set1, set2, set3, set4, set5, set6, set7, set8, set9, set10, set11, set12, set13, set14)
            set1 = 0 : set2 = 0 : set3 = 0 : set4 = 0 : set5 = 0 : set6 = 0 : set7 = 0 : set8 = 0 : set9 = 0 : set10 = 0 : set11 = 0 : set12 = 0 : set13 = 0 : set14 = 0
            numval = numval - 1
            numval = 0
            FileClose(2)
            FileClose(3)
            Array.Resize(cox, Nothing)
            Array.Resize(coy, Nothing)
            Array.Resize(coz, Nothing)
            Array.Resize(attrib, Nothing)
            Array.Resize(dist2, Nothing)
            dist1 = 0
            contadorvueltas = 1
            contadorfra = 0
            pas = 0
        Next rfiles
        MsgBox("Step Spacing Completed")
ErrorHandler:
    End Sub
    Sub calculdistance()
        dist2(numval) = Math.Sqrt(Math.Pow((cox(numval) - cox(numval - 1)), 2) + Math.Pow((coy(numval) - coy(numval - 1)), 2) + Math.Pow((coz(numval) - coz(numval - 1)), 2))
        dist1 = dist1 + dist2(numval)
        If dist1 > (contadorvueltas) * Form27.NumericUpDown1.Value Then
            PrintLine(3, contadorvueltas, contadorfra, set1, set2, set3, set4, set5, set6, set7, set8, set9, set10, set11, set12, set13, set14)
            contadorfra = 1
            pas += 1
            set1 = 0 : set2 = 0 : set3 = 0 : set4 = 0 : set5 = 0 : set6 = 0 : set7 = 0 : set8 = 0 : set9 = 0 : set10 = 0 : set11 = 0 : set12 = 0 : set13 = 0 : set14 = 0
            Do While Not ((contadorvueltas + 1) * Form27.NumericUpDown1.Value > dist1)
                contadorvueltas += 1
                If pas > 0 Then PrintLine(3, contadorvueltas, 0, set1, set2, set3, set4, set5, set6, set7, set8, set9, set10, set11, set12, set13, set14)
                set1 = 0 : set2 = 0 : set3 = 0 : set4 = 0 : set5 = 0 : set6 = 0 : set7 = 0 : set8 = 0 : set9 = 0 : set10 = 0 : set11 = 0 : set12 = 0 : set13 = 0 : set14 = 0
                pas += 1
            Loop
            pas = 0
            ' contadorfra += 1
            contadorvueltas += 1
        Else
            contadorfra += 1
        End If
    End Sub
End Module
