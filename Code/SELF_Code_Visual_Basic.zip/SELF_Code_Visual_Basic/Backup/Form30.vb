﻿Imports System.IO
Public Class Form30
    '  Public itemordermu(0) As Integer
    '  Public dipdirmu(0) As Double
    '  Public dipmu(0) As Double
    '  Public xmu(0) As Double
    '  Public ymu(0) As Double
    '  Public zmu(0) As Double
    '  Public Hzmu(0) As Double
    '  Public Lzmu(0) As Double
    '  Public numeroMU As Integer = -1
    Dim i As Integer = 0
    Dim l As Integer

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        numeroMU += 1
        ReDim Preserve itemordermu(numeroMu)
        ReDim Preserve dipdirmu(numeroMu)
        ReDim Preserve dipmu(numeroMu)
        ReDim Preserve xmu(numeroMu)
        ReDim Preserve ymu(numeroMu)
        ReDim Preserve zmu(numeroMu)
        ReDim Preserve Hzmu(numeroMu)
        ReDim Preserve Lzmu(numeroMU)
        ReDim Preserve TotalHorExt(numeroMU + 1)
        itemordermu(numeroMu) = NumericUpDown1.Value
        dipdirmu(numeroMu) = NumericUpDown2.Value
        dipmu(numeroMu) = NumericUpDown3.Value
        xmu(numeroMu) = NumericUpDown4.Value
        ymu(numeroMu) = NumericUpDown5.Value
        zmu(numeroMu) = NumericUpDown6.Value
        Hzmu(numeroMu) = NumericUpDown7.Value
        Lzmu(numeroMu) = NumericUpDown8.Value
        Label6.Text = itemordermu(numeroMu)
        Label7.Text = dipdirmu(numeroMu)
        Label8.Text = dipmu(numeroMu)
        Label9.Text = xmu(numeroMu)
        Label10.Text = ymu(numeroMu)
        Label11.Text = zmu(numeroMu)
        Label12.Text = Hzmu(numeroMu)
        Label13.Text = Lzmu(numeroMU)
        TotalHorExt(numeroMU) = Lzmu(numeroMU)
        TotalHorExt(numeroMU + 1) = Hzmu(numeroMU)
        NumericUpDown1.Value = numeroMU + 1
        l = numeroMU
    End Sub

    Private Sub Form30_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If l > 0 Then
            l = l - 1
            Label6.Text = itemordermu(l)
            Label7.Text = dipdirmu(l)
            Label8.Text = dipmu(l)
            Label9.Text = xmu(l)
            Label10.Text = ymu(l)
            Label11.Text = zmu(l)
            Label12.Text = Hzmu(l)
            Label13.Text = Lzmu(l)
        Else
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        l += 1
        If l <= numeroMU Then
            Label6.Text = itemordermu(l)
            Label7.Text = dipdirmu(l)
            Label8.Text = dipmu(l)
            Label9.Text = xmu(l)
            Label10.Text = ymu(l)
            Label11.Text = zmu(l)
            Label12.Text = Hzmu(l)
            Label13.Text = Lzmu(l)
        Else

        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim cont As Integer
        Dim inputRecord As String = Nothing
        Dim myPoints() As String
        Dim LastNonEmpty As Integer = -1
        Dim mypath2 As String
        numeroMU = 0
        OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        OpenFileDialog1.ShowDialog()
        mypath2 = OpenFileDialog1.FileName
        Dim inReader As StreamReader = File.OpenText(mypath2)
        inputRecord = inReader.ReadLine()
        numeroMU = CInt(inputRecord)
        inputRecord = inReader.ReadLine()
        ReDim itemordermu(numeroMU)
        ReDim dipdirmu(numeroMU)
        ReDim dipmu(numeroMU)
        ReDim xmu(numeroMU)
        ReDim ymu(numeroMU)
        ReDim zmu(numeroMU)
        ReDim Hzmu(numeroMU)
        ReDim Lzmu(numeroMU)
        ReDim TotalHorExt(numeroMU + 1)
        While (inputRecord IsNot Nothing)
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                itemordermu(cont) = CInt(myPoints(0).Trim)
                dipdirmu(cont) = CDbl(myPoints(1).Trim)
                dipmu(cont) = CDbl(myPoints(2).Trim)
                xmu(cont) = CDbl(myPoints(3).Trim)
                ymu(cont) = CDbl(myPoints(4).Trim)
                zmu(cont) = CDbl(myPoints(5).Trim)
                Hzmu(cont) = CDbl(myPoints(6).Trim)
                Lzmu(cont) = CDbl(myPoints(7).Trim)
                TotalHorExt(cont) = Lzmu(cont)
                TotalHorExt(cont + 1) = Hzmu(cont)
                cont += 1
                LastNonEmpty = -1
            End If
            inputRecord = inReader.ReadLine()
        End While
        Label6.Text = itemordermu(numeroMU)
        Label7.Text = dipdirmu(numeroMU)
        Label8.Text = dipmu(numeroMU)
        Label9.Text = xmu(numeroMU)
        Label10.Text = ymu(numeroMU)
        Label11.Text = zmu(numeroMU)
        Label12.Text = Hzmu(numeroMU)
        Label13.Text = Lzmu(numeroMU)
        NumericUpDown1.Value = itemordermu(numeroMU) + 1
        NumericUpDown2.Value = dipdirmu(numeroMU)
        NumericUpDown3.Value = dipmu(numeroMU)
        NumericUpDown4.Value = xmu(numeroMU)
        NumericUpDown5.Value = ymu(numeroMU)
        NumericUpDown6.Value = zmu(numeroMU)
        NumericUpDown7.Value = Hzmu(numeroMU)
        NumericUpDown8.Value = Lzmu(numeroMU)
        FileClose(1)
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim i As Integer
        FileOpen(2, Form10.TextBox1.Text + "M_U_Setting.txt", OpenMode.Output)
        PrintLine(2, numeroMU)
        For i = 0 To numeroMU
            PrintLine(2, itemordermu(i), dipdirmu(i), dipmu(i), xmu(i), ymu(i), zmu(i), Hzmu(i), Lzmu(i))
        Next
        FileClose(2)
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        JointMU()

    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Me.Close()

    End Sub
End Class