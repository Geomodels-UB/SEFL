﻿Public Class Form14

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        inpscanline()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Label19.Text = Format(Math.Abs((NumericUpDown1.Value) - (NumericUpDown4.Value)), "#.###")
        Label20.Text = Format(Math.Abs((NumericUpDown2.Value) - (NumericUpDown5.Value)), "#.###")
        Label21.Text = Format(Math.Abs((NumericUpDown3.Value) - (NumericUpDown6.Value)), "#.###")
        Label22.Text = Format(Math.Sqrt(Math.Pow(NumericUpDown1.Value - NumericUpDown4.Value, 2) + Math.Pow(NumericUpDown2.Value - NumericUpDown5.Value, 2) + Math.Pow(NumericUpDown3.Value - NumericUpDown6.Value, 2)), "#.###")
        Dim a1 As Double
        Dim b1 As Double
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        at = (NumericUpDown1.Value) - (NumericUpDown4.Value)
        bt = (NumericUpDown2.Value) - (NumericUpDown5.Value)
        ct = (NumericUpDown3.Value) - (NumericUpDown6.Value)
        If at = 0 And bt = 0 Then   '***la traça és horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
500:
        Label23.Text = Format(a1, "#.###")
        b1 = b1 - 90
        Label24.Text = Format(b1, "#.###")


    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        scanline()
    End Sub

    Private Sub NumericUpDown7_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown7.ValueChanged

    End Sub

    Private Sub NumericUpDown8_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown8.ValueChanged
 
    End Sub

    Private Sub NumericUpDown9_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown9.ValueChanged

    End Sub

    Private Sub NumericUpDown10_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown10.ValueChanged

    End Sub

    Private Sub NumericUpDown11_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumericUpDown11.ValueChanged

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double
        azi = Me.NumericUpDown7.Value
        di = Me.NumericUpDown8.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        i = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            i = 0
            j = 0
            k = 0
        End If
        Me.NumericUpDown9.Value = i
        Me.NumericUpDown10.Value = j
        Me.NumericUpDown11.Value = k
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim a1 As Double
        Dim b1 As Double
        Dim at As Double
        Dim bt As Double
        Dim ct As Double
        at = Me.NumericUpDown9.Value
        bt = Me.NumericUpDown10.Value
        ct = Me.NumericUpDown11.Value
        If at = 0 And bt = 0 Then   '***la traça és horitzontal***
            a1 = 0
            b1 = 0
            GoTo 500
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((at * at) + (bt * bt)) / ct)
        b1 = (b1 * 180) / Math.PI

        If bt <> 0 Then
            a1 = Math.Atan(at / bt)
            a1 = (a1 * 180) / Math.PI
        Else
            If at < 0 Then        '***si m=0, llavors l<>0 perquè ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If bt < 0 Then
            a1 = 180 + a1
        Else
            If at < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If
500:
        Me.NumericUpDown7.Value = a1
        Me.NumericUpDown8.Value = b1
    End Sub
End Class