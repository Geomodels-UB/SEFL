﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form9
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form9))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.CreateBoxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VectorizedPointCloudToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LoadModelToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator13 = New System.Windows.Forms.ToolStripSeparator
        Me.OptionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FiltersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ByContinuityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaveClustersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AutotrackingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FileToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReduceFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FractureAbundanceMeasuresToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FracturesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MechanicalUnitsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MeasurementsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FilterByAToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClusterAttributesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CreateMorphologyFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DistributionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FilterMorphologyFilesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FromClusterToIndivualizedFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExportTotsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator15 = New System.Windows.Forms.ToolStripSeparator
        Me.PlanesPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AttributeProjectedOnAPlaneToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator12 = New System.Windows.Forms.ToolStripSeparator
        Me.MatchingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SpacingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReducePlanesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ScanLineToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StatisticsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StereoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ChangeCoordinatesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ScaleToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.FilterPointsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FilterDifferencesFileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.LASCCToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RGBTOPointCloudToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.HelpPDFToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripSeparator14 = New System.Windows.Forms.ToolStripSeparator
        Me.AboutProjecte120ToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NuevoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AbrirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.GuardarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.GuardarcomoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.ImprimirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.VistapreviadeimpresiónToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.SalirToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DeshacerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RehacerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator
        Me.CortarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CopiarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PegarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator
        Me.SeleccionartodoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.PersonalizarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OpcionesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ContenidoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ÍndiceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.BuscarToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator
        Me.AcercadeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.NuevoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.AbrirToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator6 = New System.Windows.Forms.ToolStripSeparator
        Me.GuardarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.GuardarcomoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator7 = New System.Windows.Forms.ToolStripSeparator
        Me.ImprimirToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.VistapreviadeimpresiónToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator8 = New System.Windows.Forms.ToolStripSeparator
        Me.SalirToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.DeshacerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.RehacerToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator9 = New System.Windows.Forms.ToolStripSeparator
        Me.CortarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CopiarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PegarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator10 = New System.Windows.Forms.ToolStripSeparator
        Me.SeleccionartodoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.PersonalizarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.OpcionesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ContenidoToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ÍndiceToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.BuscarToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.toolStripSeparator11 = New System.Windows.Forms.ToolStripSeparator
        Me.AcercadeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateBoxToolStripMenuItem, Me.FiltersToolStripMenuItem, Me.FileToolsToolStripMenuItem, Me.ToolStripMenuItem1, Me.HelpToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional
        Me.MenuStrip1.Size = New System.Drawing.Size(507, 24)
        Me.MenuStrip1.TabIndex = 52
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'CreateBoxToolStripMenuItem
        '
        Me.CreateBoxToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.VectorizedPointCloudToolStripMenuItem, Me.LoadModelToolStripMenuItem1, Me.ToolStripSeparator13, Me.OptionsToolStripMenuItem})
        Me.CreateBoxToolStripMenuItem.Name = "CreateBoxToolStripMenuItem"
        Me.CreateBoxToolStripMenuItem.Size = New System.Drawing.Size(43, 20)
        Me.CreateBoxToolStripMenuItem.Text = "Load"
        '
        'VectorizedPointCloudToolStripMenuItem
        '
        Me.VectorizedPointCloudToolStripMenuItem.Name = "VectorizedPointCloudToolStripMenuItem"
        Me.VectorizedPointCloudToolStripMenuItem.ShortcutKeyDisplayString = ""
        Me.VectorizedPointCloudToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.VectorizedPointCloudToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.VectorizedPointCloudToolStripMenuItem.Text = "Load Point Cloud"
        '
        'LoadModelToolStripMenuItem1
        '
        Me.LoadModelToolStripMenuItem1.Name = "LoadModelToolStripMenuItem1"
        Me.LoadModelToolStripMenuItem1.ShortcutKeys = System.Windows.Forms.Keys.F2
        Me.LoadModelToolStripMenuItem1.Size = New System.Drawing.Size(206, 22)
        Me.LoadModelToolStripMenuItem1.Text = "Load Planar Regression"
        '
        'ToolStripSeparator13
        '
        Me.ToolStripSeparator13.Name = "ToolStripSeparator13"
        Me.ToolStripSeparator13.Size = New System.Drawing.Size(203, 6)
        '
        'OptionsToolStripMenuItem
        '
        Me.OptionsToolStripMenuItem.Name = "OptionsToolStripMenuItem"
        Me.OptionsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.D), System.Windows.Forms.Keys)
        Me.OptionsToolStripMenuItem.Size = New System.Drawing.Size(206, 22)
        Me.OptionsToolStripMenuItem.Text = "Directory Options"
        '
        'FiltersToolStripMenuItem
        '
        Me.FiltersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ByContinuityToolStripMenuItem, Me.SaveClustersToolStripMenuItem, Me.AutotrackingToolStripMenuItem})
        Me.FiltersToolStripMenuItem.Enabled = False
        Me.FiltersToolStripMenuItem.Name = "FiltersToolStripMenuItem"
        Me.FiltersToolStripMenuItem.Size = New System.Drawing.Size(90, 20)
        Me.FiltersToolStripMenuItem.Text = "Continuity tools"
        '
        'ByContinuityToolStripMenuItem
        '
        Me.ByContinuityToolStripMenuItem.Name = "ByContinuityToolStripMenuItem"
        Me.ByContinuityToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4
        Me.ByContinuityToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.ByContinuityToolStripMenuItem.Text = "Filter By Attributes"
        '
        'SaveClustersToolStripMenuItem
        '
        Me.SaveClustersToolStripMenuItem.Name = "SaveClustersToolStripMenuItem"
        Me.SaveClustersToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F5
        Me.SaveClustersToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.SaveClustersToolStripMenuItem.Text = "Create Clusters"
        '
        'AutotrackingToolStripMenuItem
        '
        Me.AutotrackingToolStripMenuItem.Name = "AutotrackingToolStripMenuItem"
        Me.AutotrackingToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.A), System.Windows.Forms.Keys)
        Me.AutotrackingToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
        Me.AutotrackingToolStripMenuItem.Text = "Autotracking"
        '
        'FileToolsToolStripMenuItem
        '
        Me.FileToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReduceFileToolStripMenuItem, Me.FractureAbundanceMeasuresToolStripMenuItem, Me.MeasurementsToolStripMenuItem, Me.FilterByAToolStripMenuItem, Me.ClusterAttributesToolStripMenuItem, Me.ReducePlanesToolStripMenuItem, Me.ScanLineToolStripMenuItem, Me.StatisticsToolStripMenuItem, Me.StereoToolStripMenuItem, Me.ChangeCoordinatesToolStripMenuItem, Me.ScaleToolStripMenuItem})
        Me.FileToolsToolStripMenuItem.Name = "FileToolsToolStripMenuItem"
        Me.FileToolsToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.FileToolsToolStripMenuItem.Text = "AttributeTools"
        '
        'ReduceFileToolStripMenuItem
        '
        Me.ReduceFileToolStripMenuItem.Name = "ReduceFileToolStripMenuItem"
        Me.ReduceFileToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F3
        Me.ReduceFileToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ReduceFileToolStripMenuItem.Text = "Attributes Classification"
        '
        'FractureAbundanceMeasuresToolStripMenuItem
        '
        Me.FractureAbundanceMeasuresToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FracturesToolStripMenuItem, Me.MechanicalUnitsToolStripMenuItem})
        Me.FractureAbundanceMeasuresToolStripMenuItem.Name = "FractureAbundanceMeasuresToolStripMenuItem"
        Me.FractureAbundanceMeasuresToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.FractureAbundanceMeasuresToolStripMenuItem.Text = "Fracture Measures"
        '
        'FracturesToolStripMenuItem
        '
        Me.FracturesToolStripMenuItem.Name = "FracturesToolStripMenuItem"
        Me.FracturesToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.FracturesToolStripMenuItem.Text = "Characterization"
        '
        'MechanicalUnitsToolStripMenuItem
        '
        Me.MechanicalUnitsToolStripMenuItem.Name = "MechanicalUnitsToolStripMenuItem"
        Me.MechanicalUnitsToolStripMenuItem.Size = New System.Drawing.Size(211, 22)
        Me.MechanicalUnitsToolStripMenuItem.Text = "Fracture Stratigraphy Bounds"
        '
        'MeasurementsToolStripMenuItem
        '
        Me.MeasurementsToolStripMenuItem.Name = "MeasurementsToolStripMenuItem"
        Me.MeasurementsToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.MeasurementsToolStripMenuItem.Text = "Measurements"
        '
        'FilterByAToolStripMenuItem
        '
        Me.FilterByAToolStripMenuItem.Name = "FilterByAToolStripMenuItem"
        Me.FilterByAToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.M), System.Windows.Forms.Keys)
        Me.FilterByAToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.FilterByAToolStripMenuItem.Text = "Merge Files"
        '
        'ClusterAttributesToolStripMenuItem
        '
        Me.ClusterAttributesToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateMorphologyFileToolStripMenuItem, Me.DistributionsToolStripMenuItem, Me.FilterMorphologyFilesToolStripMenuItem, Me.FromClusterToIndivualizedFileToolStripMenuItem, Me.ExportTotsToolStripMenuItem, Me.ToolStripSeparator15, Me.PlanesPToolStripMenuItem, Me.AttributeProjectedOnAPlaneToolStripMenuItem, Me.ToolStripSeparator12, Me.MatchingToolStripMenuItem, Me.SpacingToolStripMenuItem})
        Me.ClusterAttributesToolStripMenuItem.Name = "ClusterAttributesToolStripMenuItem"
        Me.ClusterAttributesToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ClusterAttributesToolStripMenuItem.Text = "Morphology"
        '
        'CreateMorphologyFileToolStripMenuItem
        '
        Me.CreateMorphologyFileToolStripMenuItem.Name = "CreateMorphologyFileToolStripMenuItem"
        Me.CreateMorphologyFileToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F6
        Me.CreateMorphologyFileToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.CreateMorphologyFileToolStripMenuItem.Text = "Create Morphology File"
        '
        'DistributionsToolStripMenuItem
        '
        Me.DistributionsToolStripMenuItem.Name = "DistributionsToolStripMenuItem"
        Me.DistributionsToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.DistributionsToolStripMenuItem.Text = "Distributions"
        '
        'FilterMorphologyFilesToolStripMenuItem
        '
        Me.FilterMorphologyFilesToolStripMenuItem.Name = "FilterMorphologyFilesToolStripMenuItem"
        Me.FilterMorphologyFilesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.F), System.Windows.Forms.Keys)
        Me.FilterMorphologyFilesToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.FilterMorphologyFilesToolStripMenuItem.Text = "Filter Morphology Files"
        '
        'FromClusterToIndivualizedFileToolStripMenuItem
        '
        Me.FromClusterToIndivualizedFileToolStripMenuItem.Name = "FromClusterToIndivualizedFileToolStripMenuItem"
        Me.FromClusterToIndivualizedFileToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.FromClusterToIndivualizedFileToolStripMenuItem.Text = "From Cluster to Indivualized File"
        '
        'ExportTotsToolStripMenuItem
        '
        Me.ExportTotsToolStripMenuItem.Name = "ExportTotsToolStripMenuItem"
        Me.ExportTotsToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.E), System.Windows.Forms.Keys)
        Me.ExportTotsToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.ExportTotsToolStripMenuItem.Text = "From Morphology File to Gocad.ts"
        '
        'ToolStripSeparator15
        '
        Me.ToolStripSeparator15.Name = "ToolStripSeparator15"
        Me.ToolStripSeparator15.Size = New System.Drawing.Size(264, 6)
        '
        'PlanesPToolStripMenuItem
        '
        Me.PlanesPToolStripMenuItem.Name = "PlanesPToolStripMenuItem"
        Me.PlanesPToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.PlanesPToolStripMenuItem.Text = "Attribute Projected on a Line"
        '
        'AttributeProjectedOnAPlaneToolStripMenuItem
        '
        Me.AttributeProjectedOnAPlaneToolStripMenuItem.Name = "AttributeProjectedOnAPlaneToolStripMenuItem"
        Me.AttributeProjectedOnAPlaneToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.AttributeProjectedOnAPlaneToolStripMenuItem.Text = "Attribute Projected on a Plane"
        '
        'ToolStripSeparator12
        '
        Me.ToolStripSeparator12.Name = "ToolStripSeparator12"
        Me.ToolStripSeparator12.Size = New System.Drawing.Size(264, 6)
        '
        'MatchingToolStripMenuItem
        '
        Me.MatchingToolStripMenuItem.Name = "MatchingToolStripMenuItem"
        Me.MatchingToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.MatchingToolStripMenuItem.Text = "Matching Coordinates-Morphology"
        '
        'SpacingToolStripMenuItem
        '
        Me.SpacingToolStripMenuItem.Name = "SpacingToolStripMenuItem"
        Me.SpacingToolStripMenuItem.Size = New System.Drawing.Size(267, 22)
        Me.SpacingToolStripMenuItem.Text = "Spacing and Density"
        '
        'ReducePlanesToolStripMenuItem
        '
        Me.ReducePlanesToolStripMenuItem.Name = "ReducePlanesToolStripMenuItem"
        Me.ReducePlanesToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ReducePlanesToolStripMenuItem.Text = "Reduce Files"
        '
        'ScanLineToolStripMenuItem
        '
        Me.ScanLineToolStripMenuItem.Name = "ScanLineToolStripMenuItem"
        Me.ScanLineToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ScanLineToolStripMenuItem.Text = "ScanLine"
        '
        'StatisticsToolStripMenuItem
        '
        Me.StatisticsToolStripMenuItem.Name = "StatisticsToolStripMenuItem"
        Me.StatisticsToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.StatisticsToolStripMenuItem.Text = "Statistics from Planar Regression Files"
        '
        'StereoToolStripMenuItem
        '
        Me.StereoToolStripMenuItem.Name = "StereoToolStripMenuItem"
        Me.StereoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.StereoToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.StereoToolStripMenuItem.Text = "Stereoplot"
        '
        'ChangeCoordinatesToolStripMenuItem
        '
        Me.ChangeCoordinatesToolStripMenuItem.Name = "ChangeCoordinatesToolStripMenuItem"
        Me.ChangeCoordinatesToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.ChangeCoordinatesToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ChangeCoordinatesToolStripMenuItem.Text = "Translate and Rotate Data"
        '
        'ScaleToolStripMenuItem
        '
        Me.ScaleToolStripMenuItem.Name = "ScaleToolStripMenuItem"
        Me.ScaleToolStripMenuItem.Size = New System.Drawing.Size(252, 22)
        Me.ScaleToolStripMenuItem.Text = "Scale"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FilterPointsToolStripMenuItem, Me.FilterDifferencesFileToolStripMenuItem, Me.LASCCToolStripMenuItem, Me.RGBTOPointCloudToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(76, 20)
        Me.ToolStripMenuItem1.Text = "Topography"
        '
        'FilterPointsToolStripMenuItem
        '
        Me.FilterPointsToolStripMenuItem.Name = "FilterPointsToolStripMenuItem"
        Me.FilterPointsToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FilterPointsToolStripMenuItem.Text = "Topography Module"
        '
        'FilterDifferencesFileToolStripMenuItem
        '
        Me.FilterDifferencesFileToolStripMenuItem.Name = "FilterDifferencesFileToolStripMenuItem"
        Me.FilterDifferencesFileToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.FilterDifferencesFileToolStripMenuItem.Text = "Filter Differences File"
        '
        'LASCCToolStripMenuItem
        '
        Me.LASCCToolStripMenuItem.Name = "LASCCToolStripMenuItem"
        Me.LASCCToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.LASCCToolStripMenuItem.Text = "LAS_CC"
        '
        'RGBTOPointCloudToolStripMenuItem
        '
        Me.RGBTOPointCloudToolStripMenuItem.Name = "RGBTOPointCloudToolStripMenuItem"
        Me.RGBTOPointCloudToolStripMenuItem.Size = New System.Drawing.Size(172, 22)
        Me.RGBTOPointCloudToolStripMenuItem.Text = "RGB TO PointCloud"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpPDFToolStripMenuItem, Me.ToolStripSeparator14, Me.AboutProjecte120ToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(41, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'HelpPDFToolStripMenuItem
        '
        Me.HelpPDFToolStripMenuItem.Name = "HelpPDFToolStripMenuItem"
        Me.HelpPDFToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.H), System.Windows.Forms.Keys)
        Me.HelpPDFToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.HelpPDFToolStripMenuItem.Text = "Help PDF"
        '
        'ToolStripSeparator14
        '
        Me.ToolStripSeparator14.Name = "ToolStripSeparator14"
        Me.ToolStripSeparator14.Size = New System.Drawing.Size(159, 6)
        '
        'AboutProjecte120ToolStripMenuItem
        '
        Me.AboutProjecte120ToolStripMenuItem.Name = "AboutProjecte120ToolStripMenuItem"
        Me.AboutProjecte120ToolStripMenuItem.Size = New System.Drawing.Size(162, 22)
        Me.AboutProjecte120ToolStripMenuItem.Text = "About Projecte120"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(36, 20)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'NuevoToolStripMenuItem
        '
        Me.NuevoToolStripMenuItem.Image = CType(resources.GetObject("NuevoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NuevoToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NuevoToolStripMenuItem.Name = "NuevoToolStripMenuItem"
        Me.NuevoToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.N), System.Windows.Forms.Keys)
        Me.NuevoToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.NuevoToolStripMenuItem.Text = "&Nuevo"
        '
        'AbrirToolStripMenuItem
        '
        Me.AbrirToolStripMenuItem.Image = CType(resources.GetObject("AbrirToolStripMenuItem.Image"), System.Drawing.Image)
        Me.AbrirToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AbrirToolStripMenuItem.Name = "AbrirToolStripMenuItem"
        Me.AbrirToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.AbrirToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.AbrirToolStripMenuItem.Text = "&Abrir"
        '
        'toolStripSeparator
        '
        Me.toolStripSeparator.Name = "toolStripSeparator"
        Me.toolStripSeparator.Size = New System.Drawing.Size(188, 6)
        '
        'GuardarToolStripMenuItem
        '
        Me.GuardarToolStripMenuItem.Image = CType(resources.GetObject("GuardarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.GuardarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GuardarToolStripMenuItem.Name = "GuardarToolStripMenuItem"
        Me.GuardarToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.GuardarToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.GuardarToolStripMenuItem.Text = "&Guardar"
        '
        'GuardarcomoToolStripMenuItem
        '
        Me.GuardarcomoToolStripMenuItem.Name = "GuardarcomoToolStripMenuItem"
        Me.GuardarcomoToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.GuardarcomoToolStripMenuItem.Text = "G&uardar como"
        '
        'toolStripSeparator1
        '
        Me.toolStripSeparator1.Name = "toolStripSeparator1"
        Me.toolStripSeparator1.Size = New System.Drawing.Size(188, 6)
        '
        'ImprimirToolStripMenuItem
        '
        Me.ImprimirToolStripMenuItem.Image = CType(resources.GetObject("ImprimirToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ImprimirToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ImprimirToolStripMenuItem.Name = "ImprimirToolStripMenuItem"
        Me.ImprimirToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.P), System.Windows.Forms.Keys)
        Me.ImprimirToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.ImprimirToolStripMenuItem.Text = "&Imprimir"
        '
        'VistapreviadeimpresiónToolStripMenuItem
        '
        Me.VistapreviadeimpresiónToolStripMenuItem.Image = CType(resources.GetObject("VistapreviadeimpresiónToolStripMenuItem.Image"), System.Drawing.Image)
        Me.VistapreviadeimpresiónToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.VistapreviadeimpresiónToolStripMenuItem.Name = "VistapreviadeimpresiónToolStripMenuItem"
        Me.VistapreviadeimpresiónToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.VistapreviadeimpresiónToolStripMenuItem.Text = "&Vista previa de impresión"
        '
        'toolStripSeparator2
        '
        Me.toolStripSeparator2.Name = "toolStripSeparator2"
        Me.toolStripSeparator2.Size = New System.Drawing.Size(188, 6)
        '
        'SalirToolStripMenuItem
        '
        Me.SalirToolStripMenuItem.Name = "SalirToolStripMenuItem"
        Me.SalirToolStripMenuItem.Size = New System.Drawing.Size(191, 22)
        Me.SalirToolStripMenuItem.Text = "&Salir"
        '
        'DeshacerToolStripMenuItem
        '
        Me.DeshacerToolStripMenuItem.Name = "DeshacerToolStripMenuItem"
        Me.DeshacerToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Z), System.Windows.Forms.Keys)
        Me.DeshacerToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.DeshacerToolStripMenuItem.Text = "&Deshacer"
        '
        'RehacerToolStripMenuItem
        '
        Me.RehacerToolStripMenuItem.Name = "RehacerToolStripMenuItem"
        Me.RehacerToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Y), System.Windows.Forms.Keys)
        Me.RehacerToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.RehacerToolStripMenuItem.Text = "&Rehacer"
        '
        'toolStripSeparator3
        '
        Me.toolStripSeparator3.Name = "toolStripSeparator3"
        Me.toolStripSeparator3.Size = New System.Drawing.Size(6, 6)
        '
        'CortarToolStripMenuItem
        '
        Me.CortarToolStripMenuItem.Image = CType(resources.GetObject("CortarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CortarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CortarToolStripMenuItem.Name = "CortarToolStripMenuItem"
        Me.CortarToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.X), System.Windows.Forms.Keys)
        Me.CortarToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.CortarToolStripMenuItem.Text = "Cor&tar"
        '
        'CopiarToolStripMenuItem
        '
        Me.CopiarToolStripMenuItem.Image = CType(resources.GetObject("CopiarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CopiarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopiarToolStripMenuItem.Name = "CopiarToolStripMenuItem"
        Me.CopiarToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.C), System.Windows.Forms.Keys)
        Me.CopiarToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.CopiarToolStripMenuItem.Text = "&Copiar"
        '
        'PegarToolStripMenuItem
        '
        Me.PegarToolStripMenuItem.Image = CType(resources.GetObject("PegarToolStripMenuItem.Image"), System.Drawing.Image)
        Me.PegarToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PegarToolStripMenuItem.Name = "PegarToolStripMenuItem"
        Me.PegarToolStripMenuItem.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.V), System.Windows.Forms.Keys)
        Me.PegarToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.PegarToolStripMenuItem.Text = "&Pegar"
        '
        'toolStripSeparator4
        '
        Me.toolStripSeparator4.Name = "toolStripSeparator4"
        Me.toolStripSeparator4.Size = New System.Drawing.Size(6, 6)
        '
        'SeleccionartodoToolStripMenuItem
        '
        Me.SeleccionartodoToolStripMenuItem.Name = "SeleccionartodoToolStripMenuItem"
        Me.SeleccionartodoToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.SeleccionartodoToolStripMenuItem.Text = "&Seleccionar todo"
        '
        'PersonalizarToolStripMenuItem
        '
        Me.PersonalizarToolStripMenuItem.Name = "PersonalizarToolStripMenuItem"
        Me.PersonalizarToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.PersonalizarToolStripMenuItem.Text = "&Personalizar"
        '
        'OpcionesToolStripMenuItem
        '
        Me.OpcionesToolStripMenuItem.Name = "OpcionesToolStripMenuItem"
        Me.OpcionesToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.OpcionesToolStripMenuItem.Text = "&Opciones"
        '
        'ContenidoToolStripMenuItem
        '
        Me.ContenidoToolStripMenuItem.Name = "ContenidoToolStripMenuItem"
        Me.ContenidoToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.ContenidoToolStripMenuItem.Text = "&Contenido"
        '
        'ÍndiceToolStripMenuItem
        '
        Me.ÍndiceToolStripMenuItem.Name = "ÍndiceToolStripMenuItem"
        Me.ÍndiceToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.ÍndiceToolStripMenuItem.Text = "Índic&e"
        '
        'BuscarToolStripMenuItem
        '
        Me.BuscarToolStripMenuItem.Name = "BuscarToolStripMenuItem"
        Me.BuscarToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.BuscarToolStripMenuItem.Text = "&Buscar"
        '
        'toolStripSeparator5
        '
        Me.toolStripSeparator5.Name = "toolStripSeparator5"
        Me.toolStripSeparator5.Size = New System.Drawing.Size(6, 6)
        '
        'AcercadeToolStripMenuItem
        '
        Me.AcercadeToolStripMenuItem.Name = "AcercadeToolStripMenuItem"
        Me.AcercadeToolStripMenuItem.Size = New System.Drawing.Size(32, 19)
        Me.AcercadeToolStripMenuItem.Text = "&Acerca de..."
        '
        'NuevoToolStripMenuItem1
        '
        Me.NuevoToolStripMenuItem1.Image = CType(resources.GetObject("NuevoToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.NuevoToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.NuevoToolStripMenuItem1.Name = "NuevoToolStripMenuItem1"
        Me.NuevoToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.NuevoToolStripMenuItem1.Text = "&Nuevo"
        '
        'AbrirToolStripMenuItem1
        '
        Me.AbrirToolStripMenuItem1.Image = CType(resources.GetObject("AbrirToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.AbrirToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.AbrirToolStripMenuItem1.Name = "AbrirToolStripMenuItem1"
        Me.AbrirToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.AbrirToolStripMenuItem1.Text = "&Abrir"
        '
        'toolStripSeparator6
        '
        Me.toolStripSeparator6.Name = "toolStripSeparator6"
        Me.toolStripSeparator6.Size = New System.Drawing.Size(6, 6)
        '
        'GuardarToolStripMenuItem1
        '
        Me.GuardarToolStripMenuItem1.Image = CType(resources.GetObject("GuardarToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.GuardarToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.GuardarToolStripMenuItem1.Name = "GuardarToolStripMenuItem1"
        Me.GuardarToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.GuardarToolStripMenuItem1.Text = "&Guardar"
        '
        'GuardarcomoToolStripMenuItem1
        '
        Me.GuardarcomoToolStripMenuItem1.Name = "GuardarcomoToolStripMenuItem1"
        Me.GuardarcomoToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.GuardarcomoToolStripMenuItem1.Text = "G&uardar como"
        '
        'toolStripSeparator7
        '
        Me.toolStripSeparator7.Name = "toolStripSeparator7"
        Me.toolStripSeparator7.Size = New System.Drawing.Size(6, 6)
        '
        'ImprimirToolStripMenuItem1
        '
        Me.ImprimirToolStripMenuItem1.Image = CType(resources.GetObject("ImprimirToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.ImprimirToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ImprimirToolStripMenuItem1.Name = "ImprimirToolStripMenuItem1"
        Me.ImprimirToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.ImprimirToolStripMenuItem1.Text = "&Imprimir"
        '
        'VistapreviadeimpresiónToolStripMenuItem1
        '
        Me.VistapreviadeimpresiónToolStripMenuItem1.Image = CType(resources.GetObject("VistapreviadeimpresiónToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.VistapreviadeimpresiónToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.VistapreviadeimpresiónToolStripMenuItem1.Name = "VistapreviadeimpresiónToolStripMenuItem1"
        Me.VistapreviadeimpresiónToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.VistapreviadeimpresiónToolStripMenuItem1.Text = "&Vista previa de impresión"
        '
        'toolStripSeparator8
        '
        Me.toolStripSeparator8.Name = "toolStripSeparator8"
        Me.toolStripSeparator8.Size = New System.Drawing.Size(6, 6)
        '
        'SalirToolStripMenuItem1
        '
        Me.SalirToolStripMenuItem1.Name = "SalirToolStripMenuItem1"
        Me.SalirToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.SalirToolStripMenuItem1.Text = "&Salir"
        '
        'DeshacerToolStripMenuItem1
        '
        Me.DeshacerToolStripMenuItem1.Name = "DeshacerToolStripMenuItem1"
        Me.DeshacerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.DeshacerToolStripMenuItem1.Text = "&Deshacer"
        '
        'RehacerToolStripMenuItem1
        '
        Me.RehacerToolStripMenuItem1.Name = "RehacerToolStripMenuItem1"
        Me.RehacerToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.RehacerToolStripMenuItem1.Text = "&Rehacer"
        '
        'toolStripSeparator9
        '
        Me.toolStripSeparator9.Name = "toolStripSeparator9"
        Me.toolStripSeparator9.Size = New System.Drawing.Size(6, 6)
        '
        'CortarToolStripMenuItem1
        '
        Me.CortarToolStripMenuItem1.Image = CType(resources.GetObject("CortarToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CortarToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CortarToolStripMenuItem1.Name = "CortarToolStripMenuItem1"
        Me.CortarToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.CortarToolStripMenuItem1.Text = "Cor&tar"
        '
        'CopiarToolStripMenuItem1
        '
        Me.CopiarToolStripMenuItem1.Image = CType(resources.GetObject("CopiarToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.CopiarToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.CopiarToolStripMenuItem1.Name = "CopiarToolStripMenuItem1"
        Me.CopiarToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.CopiarToolStripMenuItem1.Text = "&Copiar"
        '
        'PegarToolStripMenuItem1
        '
        Me.PegarToolStripMenuItem1.Image = CType(resources.GetObject("PegarToolStripMenuItem1.Image"), System.Drawing.Image)
        Me.PegarToolStripMenuItem1.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.PegarToolStripMenuItem1.Name = "PegarToolStripMenuItem1"
        Me.PegarToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.PegarToolStripMenuItem1.Text = "&Pegar"
        '
        'toolStripSeparator10
        '
        Me.toolStripSeparator10.Name = "toolStripSeparator10"
        Me.toolStripSeparator10.Size = New System.Drawing.Size(6, 6)
        '
        'SeleccionartodoToolStripMenuItem1
        '
        Me.SeleccionartodoToolStripMenuItem1.Name = "SeleccionartodoToolStripMenuItem1"
        Me.SeleccionartodoToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.SeleccionartodoToolStripMenuItem1.Text = "&Seleccionar todo"
        '
        'PersonalizarToolStripMenuItem1
        '
        Me.PersonalizarToolStripMenuItem1.Name = "PersonalizarToolStripMenuItem1"
        Me.PersonalizarToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.PersonalizarToolStripMenuItem1.Text = "&Personalizar"
        '
        'OpcionesToolStripMenuItem1
        '
        Me.OpcionesToolStripMenuItem1.Name = "OpcionesToolStripMenuItem1"
        Me.OpcionesToolStripMenuItem1.Size = New System.Drawing.Size(152, 22)
        Me.OpcionesToolStripMenuItem1.Text = "&Opciones"
        '
        'ContenidoToolStripMenuItem1
        '
        Me.ContenidoToolStripMenuItem1.Name = "ContenidoToolStripMenuItem1"
        Me.ContenidoToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.ContenidoToolStripMenuItem1.Text = "&Contenido"
        '
        'ÍndiceToolStripMenuItem1
        '
        Me.ÍndiceToolStripMenuItem1.Name = "ÍndiceToolStripMenuItem1"
        Me.ÍndiceToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.ÍndiceToolStripMenuItem1.Text = "Índic&e"
        '
        'BuscarToolStripMenuItem1
        '
        Me.BuscarToolStripMenuItem1.Name = "BuscarToolStripMenuItem1"
        Me.BuscarToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.BuscarToolStripMenuItem1.Text = "&Buscar"
        '
        'toolStripSeparator11
        '
        Me.toolStripSeparator11.Name = "toolStripSeparator11"
        Me.toolStripSeparator11.Size = New System.Drawing.Size(6, 6)
        '
        'AcercadeToolStripMenuItem1
        '
        Me.AcercadeToolStripMenuItem1.Name = "AcercadeToolStripMenuItem1"
        Me.AcercadeToolStripMenuItem1.Size = New System.Drawing.Size(32, 19)
        Me.AcercadeToolStripMenuItem1.Text = "&Acerca de..."
        '
        'Form9
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(507, 48)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MaximumSize = New System.Drawing.Size(650, 100)
        Me.MinimizeBox = False
        Me.MinimumSize = New System.Drawing.Size(8, 50)
        Me.Name = "Form9"
        Me.ShowIcon = False
        Me.Text = "Projecte 120  Version 6.3c"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents CreateBoxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FiltersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FileToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReduceFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReducePlanesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatisticsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeCoordinatesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ByContinuityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaveClustersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutotrackingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilterByAToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VectorizedPointCloudToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LoadModelToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OptionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StereoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScanLineToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClusterAttributesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NuevoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AbrirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GuardarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuardarcomoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImprimirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VistapreviadeimpresiónToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SalirToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeshacerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RehacerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CortarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PegarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SeleccionartodoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PersonalizarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpcionesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContenidoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ÍndiceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuscarToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AcercadeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NuevoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AbrirToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator6 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents GuardarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GuardarcomoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator7 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImprimirToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents VistapreviadeimpresiónToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator8 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SalirToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeshacerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RehacerToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator9 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CortarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CopiarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PegarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator10 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SeleccionartodoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PersonalizarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OpcionesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContenidoToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ÍndiceToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BuscarToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents toolStripSeparator11 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents AcercadeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HelpPDFToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutProjecte120ToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateMorphologyFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PlanesPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportTotsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AttributeProjectedOnAPlaneToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilterMorphologyFilesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator12 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator13 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator14 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents FromClusterToIndivualizedFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MeasurementsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilterPointsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FilterDifferencesFileToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScaleToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MatchingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripSeparator15 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents SpacingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FractureAbundanceMeasuresToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DistributionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents LASCCToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RGBTOPointCloudToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FracturesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MechanicalUnitsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
