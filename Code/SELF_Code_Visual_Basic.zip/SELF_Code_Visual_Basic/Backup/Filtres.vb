Module Filtres
    Public e As String
    Public position1 As Integer
    Public position2 As Integer
    Public position3 As Integer
    Public position4 As Integer
    Public position5 As Integer
    Public position6 As Integer
    Public position7 As Integer
    Public position8 As Integer
    Public position9 As Integer
    Public position10 As Integer
    Public position11 As Integer
    Public position12 As Integer
    Public position13 As Integer
    Public coco As Double
    Public family As Integer
    Public Vec1 As Double
    Public Vec2 As Double
    Public Vec3 As Double
    Public a1 As Double
    Public b1 As Double
    Public A As Double
    Public B As Double
    Public C As Double
    Public AA As Double
    Public BB As Double
    Public CC As Double
    Public ad As Integer
    Public ac As Integer
    Public seleccio As Integer
    Public escollits() As Integer
    Public prop3 As Double
    Public kapa As Double
    Public orien As Double
    Public pend As Double
    Public orienestad As Integer
    Public pendestad As Integer
    Public marc(360, 90) As Integer
    Public xmean As Double, ymean As Double, zmean As Double



    Sub pendents()
        ReDim marc(360, 90)
        Dim ejx As Integer
        Dim ejy As Integer
        Dim cont As Integer
        Dim pap As Double
        Dim esp As Double
        Dim difx As Double
        Dim dify As Double
        Dim difz As Double
        Dim eixx As Double : Dim eixy As Double : Dim eixz As Double
        Dim eixx2 As Double : Dim eixy2 As Double : Dim eixz2 As Double
        Dim ac As Double
        Dim ab As Double
        Dim l As Integer
        Dim l2 As Integer
        Dim n As Integer
        Dim m As Integer
        Dim total As Integer
        coco = 0
        esp = Int(Form1.NumericUpDown6.Value / Form1.NumericUpDown1.Value) + 1
        'MsgBox(esp)
        'noms = Form1.TextBox1.Text
        'FileOpen(1, "C:\Dades\Projecte90\plans.txt", OpenMode.Output)
        FileOpen(1, Form1.TextBox1.Text + ".txt", OpenMode.Output)
        'copiada
        ac = 0
        seleccio = 0
        total = ((amplex + 1) * (ampley + 1) * (amplez + 1))
        Form1.ProgressBar1.Value = 1
        For eixx = 0 To amplex
            For eixy = 0 To ampley
                For eixz = 0 To amplez
                    ' N�mero de punts per cada voxel Refer(x,y,z)
                    If contadomax(eixx)(eixy)(eixz) <> Nothing Then  'Si hi han punts al voxel busca continu�tat
                        ab = contadomax(eixx)(eixy)(eixz) 'numero de centroides al voxel
                        For l = 1 To ab
                            n = refer(eixx)(eixy)(eixz)(l - 1) 'aqui tenim la referencia del primer punt
                            ' ara s�han de buscar tots els del voltant
                            seleccio = 0
                            ReDim escollits(0)
                            cont = 0
                            For difx = -esp To esp
                                eixx2 = eixx + difx
                                If eixx2 < 0 Or eixx2 > amplex Then GoTo line40
                                For dify = -esp To esp
                                    eixy2 = eixy + dify
                                    If eixy2 < 0 Or eixy2 > ampley Then GoTo line30
                                    For difz = -esp To esp
                                        eixz2 = eixz + difz
                                        If eixz2 < 0 Or eixz2 > amplez Then GoTo line20
                                        If contadomax(eixx2)(eixy2)(eixz2) <> Nothing Then
                                            ad = contadomax(eixx2)(eixy2)(eixz2)
                                            For l2 = 1 To ad
                                                m = refer(eixx2)(eixy2)(eixz2)(l2 - 1)
                                                'Cumpleix la dist�ncia?
                                                pap = Math.Sqrt(Math.Pow(x(n) - x(m), 2) + Math.Pow(y(n) - y(m), 2) + Math.Pow(z(n) - z(m), 2))
                                                If pap < Form1.NumericUpDown6.Value And pap > Form1.NumericUpDown4.Value Then
                                                    ' Enmagatzemar indexs
                                                    seleccio = seleccio + 1
                                                    ReDim Preserve escollits(seleccio)
                                                    escollits(seleccio) = m
                                                End If ' de pap
                                            Next l2
                                        End If
line20:                             Next difz
line30:                         Next dify
line40:                     Next difx
                            If seleccio > 4 Then
                                calculvectors()
                                If prop3 >= Form1.NumericUpDown9.Value And kapa <= Form1.NumericUpDown8.Value Then
                                    'aqui afegir lligam per calcular el dip
                                    calculdips()
                                    If Form1.CheckBox2.Checked = True Then estadistica()
                                    If Form1.RadioButton1.Checked = True Then 'nou
                                        PrintLine(1, x(n), y(n), z(n), Format(AA, "0.0000"), Format(BB, "0.0000"), Format(CC, "0.0000"), Format(orien, "0.00"), Format(pend, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), seleccio) 'nou
                                    End If 'nou
                                    If Form1.RadioButton2.Checked = True Then 'nou
                                        PrintLine(1, x(n), y(n), z(n), Format(AA, "0.0000"), Format(BB, "0.0000"), Format(CC, "0.0000"), Format(orien, "0.00"), Format(pend, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), seleccio, inten(n)) 'nou
                                    End If 'nou
                                    If Form1.RadioButton3.Checked = True Then 'nou
                                        PrintLine(1, x(n), y(n), z(n), Format(AA, "0.0000"), Format(BB, "0.0000"), Format(CC, "0.0000"), Format(orien, "0.00"), Format(pend, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), seleccio, R(n), G(n), V(n)) 'nou
                                    End If 'nou
                                    coco = coco + 1
                                    seleccio = 0
                                    ReDim escollits(0)
                                End If 'prop3
                            End If 'seleccio
                        Next l
                        seleccio = 0
                        ReDim escollits(0)
                    End If

                Next eixz
            Next eixy
            Form1.ProgressBar1.Value = (eixx * eixy * eixz * 100) / total
        Next eixx
        Form1.ProgressBar1.Value = 100
        FileClose(1)
        If Form1.CheckBox2.Checked = True Then
            FileOpen(1, Form1.TextBox1.Text + "estadistica.txt", OpenMode.Output)
            For ejx = 0 To 360
                For ejy = 0 To 90
                    PrintLine(1, ejx, ejy, marc(ejx, ejy))
                Next ejy
            Next ejx
            FileClose(1)
        End If
        'MsgBox("Acabat")
    End Sub

    Function calculpendent() As Double
        ' MsgBox("9")
        '***eliminem les traces horiztontals***
        'Dim a1 As Double
        'Dim b1 As Double
        If A = 0 And B = 0 Then   '***la tra�a �s horitzontal***
            a1 = 0
            b1 = 0
            GoTo line100
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((A * A) + (B * B)) / C)
        b1 = (b1 * 180) / Math.PI

        If B <> 0 Then
            a1 = Math.Atan(A / B)
            a1 = (a1 * 180) / Math.PI
        Else
            If A < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If B < 0 Then
            a1 = 180 + a1
        Else
            If A < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If

line100:
        'az1 = CInt(a1)
        Return Math.Abs(CInt(b1))
        'gh
    End Function
    Sub calculvectors()
        '***variables necess�ries per al c�lcul dels moments d'in�rcia***
        Dim i As Integer
        Dim sumx As Double, sumy As Double, sumz As Double
        'Dim xmean As Double, ymean As Double, zmean As Double
        Dim sumyz As Double, sumxz As Double, sumxy As Double
        Dim sumxsq As Double, sumysq As Double, sumzsq As Double
        Dim summodpt As Double
        Dim modpt As Double
        Dim c As Double
        Dim di As Integer
        'Dim xmp As Double, ymp As Double, zmp As Double
        'Dim l As Double, m As Double
        'Dim modul As Double
        'Dim a1 As Double, B1 As Double
        sumx = 0 : sumy = 0 : sumz = 0
        '***calculem sumatoris***
        For i = 1 To seleccio
            di = escollits(i)
            sumx = sumx + x(di)
            sumy = sumy + y(di)
            sumz = sumz + z(di)
        Next i
        '***calculem promitjos***
        xmean = sumx / seleccio
        ymean = sumy / seleccio
        zmean = sumz / seleccio

        sumyz = 0 : sumxz = 0 : sumxy = 0
        sumxsq = 0 : sumysq = 0 : sumzsq = 0
        summodpt = 0

        '***calculem sumatoris***
        For i = 1 To seleccio
            di = escollits(i)
            sumyz = sumyz + ((y(di)) - ymean) * ((z(di)) - zmean)
            sumxz = sumxz + ((x(di)) - xmean) * ((z(di)) - zmean)
            sumxy = sumxy + ((x(di)) - xmean) * ((y(di)) - ymean)

            sumxsq = sumxsq + Math.Pow(((x(di)) - xmean), 2)
            sumysq = sumysq + Math.Pow(((y(di)) - ymean), 2)
            sumzsq = sumzsq + Math.Pow(((z(di)) - zmean), 2)

            '***aquest es pels eigenvalues***
            '***calculo l'arrel del modul xq vull el sumatori dls quadrats dls moduls***
            modpt = Math.Pow((x(di) - xmean), 2) + Math.Pow((y(di) - ymean), 2) + Math.Pow((z(di) - zmean), 2)
            summodpt = summodpt + modpt
        Next i
        '***Ara ve el c�lcul***

        Dim n As Integer = 3
        Dim a(3, 3) As Double
        Dim d(3) As Double
        Dim V(3, 3) As Double
        Dim b(3) As Double
        Dim zz(3) As Double
        Dim sm As Double, g As Double, h As Double, s As Double, t As Double, p As Double
        'redim c As Double
        Dim tau As Double, tresh As Double, theta As Double
        Dim Nrot As Integer
        'redim i As Integer
        Dim j As Integer, k As Integer
        Dim ip As Integer, iq As Integer
        Dim prop4 As String

        a(1, 1) = sumxsq
        a(2, 2) = sumysq
        a(3, 3) = sumzsq
        a(1, 2) = sumxy
        a(2, 1) = sumxy
        a(1, 3) = sumxz
        a(3, 1) = sumxz
        a(2, 3) = sumyz
        a(3, 2) = sumyz


        For ip = 1 To n
            For iq = 1 To n
                V(ip, iq) = 0
            Next iq
            V(ip, ip) = 1
        Next ip
        For ip = 1 To n
            b(ip) = a(ip, ip)
            d(ip) = b(ip)
            zz(ip) = 0
        Next ip
        Nrot = 0
        For i = 1 To 50
            sm = 0
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    sm = sm + Math.Abs(a(ip, iq))
                Next iq
            Next ip
            If sm = 0 Then GoTo LINE123
            If i < 4 Then
                tresh = 0.2 * sm / n ^ 2
            Else
                tresh = 0
            End If
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    g = 100 * Math.Abs(a(ip, iq))
                    If i > 4 And (Math.Abs(d(ip)) + g) = Math.Abs(d(ip)) And (Math.Abs(d(iq)) + g) = Math.Abs(d(iq)) Then
                        a(ip, iq) = 0
                    ElseIf Math.Abs(a(ip, iq)) > tresh Then
                        h = d(iq) - d(ip)
                        If (Math.Abs(h) + g) = Math.Abs(h) Then
                            t = a(ip, iq) / h
                        Else
                            theta = 0.5 * h / a(ip, iq)
                            t = 1 / (Math.Abs(theta) + Math.Sqrt(1 + theta ^ 2))
                            If theta < 0 Then t = -t
                        End If
                        c = 1 / Math.Sqrt(1 + Math.Pow(t, 2))
                        s = t * c
                        tau = s / (1 + c)
                        h = t * a(ip, iq)
                        zz(ip) = zz(ip) - h
                        zz(iq) = zz(iq) + h
                        d(ip) = d(ip) - h
                        d(iq) = d(iq) + h
                        a(ip, iq) = 0
                        For j = 1 To (ip - 1)
                            g = a(j, ip)
                            h = a(j, iq)
                            a(j, ip) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (ip + 1) To (iq - 1)
                            g = a(ip, j)
                            h = a(j, iq)
                            a(ip, j) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (iq + 1) To n
                            g = a(ip, j)
                            h = a(iq, j)
                            a(ip, j) = g - s * (h + g * tau)
                            a(iq, j) = h + s * (g - h * tau)
                        Next j
                        For j = 1 To n
                            g = V(j, ip)
                            h = V(j, iq)
                            V(j, ip) = g - s * (h + g * tau)
                            V(j, iq) = h + s * (g - h * tau)
                        Next j
                        Nrot = Nrot + 1
                    End If
                Next iq
            Next ip
            For ip = 1 To n
                b(ip) = b(ip) + zz(ip)
                d(ip) = b(ip)
                zz(ip) = 0
            Next ip
        Next i

        'ret = MbeMessageBox("50 iterations overpassed", 2048)

LINE123:

        '***ara ordenem***

        For i = 1 To n - 1
            k = i
            p = d(i)
            For j = i + 1 To n
                If d(j) > p Then
                    k = j
                    p = d(j)
                End If
            Next j
            If k <> i Then
                d(k) = d(i)
                d(i) = p
                For j = 1 To n
                    p = V(j, i)
                    V(j, i) = V(j, k)
                    V(j, k) = p
                Next j
            End If
        Next i

        '***parem si la matriu d'eigenvectors �s la identitat (per exemple si mesurem cabussament d'isol�nies)***
        'If V(1, 1) = 0 And V(2, 2) = 0 And V(3, 3) = 0 Then
        'ret = MbeMessageBox("Solution not possible with current eigenvector algorithm", 2048)
        '    Exit Sub
        'End If

        'Dim ll As Double, mm As Double, nn As Double
        'Dim B1 As Double, a1 As Double

        '***volem el vector 3 (criteri Woodcock (1977))***
        '***redrecem el vector per a qu� pugi***
        Dim prop1 As Double, prop2 As Double
        If V(3, 3) < 0 Then
            AA = -V(1, 3)
            BB = -V(2, 3)
            CC = -V(3, 3)
        Else
            AA = V(1, 3)
            BB = V(2, 3)
            CC = V(3, 3)
        End If
        'afegit
        If V(3, 3) < 0 Then
            Vec1 = -V(1, 1)
            Vec2 = -V(2, 1)
            Vec3 = -V(3, 1)
        Else
            Vec1 = V(1, 1)
            Vec2 = V(2, 1)
            Vec3 = V(3, 1)
        End If
        'afegit



        prop1 = Math.Log(d(1) / d(2))
        prop2 = Math.Log(d(2) / d(3))
        prop3 = Math.Log(d(1) / d(3)) 'Aixo es la M
        If AA = 0 And BB = 1 And CC = 0 Then prop3 = 10
        If AA = 0 And BB = 0 And CC = 1 Then prop3 = 10
        If AA = 1 And BB = 0 And CC = 0 Then prop3 = 10
        prop4 = Str(prop3)
        If prop4 = "Infinito" Then prop3 = 1035
        kapa = prop1 / prop2  ' Aix� es la K
    End Sub
    Sub filtrardip()
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim iif As Double
        Dim jjf As Double
        Dim kkf As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim difer As Double
        Dim intenf As Integer
        Dim rf As Double
        Dim gf As Double
        Dim bf As Double
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim acep As Double
        Dim porc As Double
        Dim acep2 As Double
        acep = 0
        Form3.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form3.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog1.FileName)
        FileOpen(1, Form3.OpenFileDialog1.FileName, OpenMode.Input)
        ' MsgBox(Form1.SaveFileDialog1.FileName)
        FileOpen(2, Form10.TextBox1.Text + "filter.txt", OpenMode.Output)
        'FileOpen(2, "C:\Dades\projecte120\filt.txt", OpenMode.Output)

        Do Until EOF(1)
            If Form3.RadioButton1.Checked = True Then
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                position6 = InStrRev(e, " ", position5 - 1)
                position7 = InStrRev(e, " ", position6 - 1)
                position8 = InStrRev(e, " ", position7 - 1)
                position9 = InStrRev(e, " ", position8 - 1)
                position10 = InStrRev(e, " ", position9 - 1)
                xf = e.Substring(0, e.Length - position10)
                yf = e.Substring(position10, position9 - position10)
                zf = e.Substring(position9, position8 - position9)
                iif = e.Substring(position8, position7 - position8)
                jjf = e.Substring(position7, position6 - position7)
                kkf = e.Substring(position6, position5 - position6)
                dirf = e.Substring(position5, position4 - position5)
                pendf = e.Substring(position4, position3 - position4)
                mf = e.Substring(position3, position2 - position3)
                kf = e.Substring(position2, position1 - position2)
                nf = e.Substring(position1, e.Length - position1)

                'Input(1, xf)
                'Input(1, yf)
                'Input(1, zf)
                'Input(1, iif)
                'Input(1, jjf)
                'Input(1, kkf)
                'Input(1, dirf)
                'Input(1, pendf)
                'Input(1, mf)
                'Input(1, kf)
                'Input(1, nf)
            End If
            If Form3.RadioButton2.Checked = True Then
                e = LineInput(1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                intenf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                nf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                kf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                mf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                pendf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                dirf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                kkf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                jjf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                iif = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                zf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                yf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'int
                e = Trim(e) : position1 = InStrRev(e, " ")
                xf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)

 
            End If
            If Form3.RadioButton3.Checked = True Then

                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                position6 = InStrRev(e, " ", position5 - 1)
                position7 = InStrRev(e, " ", position6 - 1)
                position8 = InStrRev(e, " ", position7 - 1)
                position9 = InStrRev(e, " ", position8 - 1)
                position10 = InStrRev(e, " ", position9 - 1)
                position11 = InStrRev(e, " ", position10 - 1)
                position12 = InStrRev(e, " ", position11 - 1)
                position13 = InStrRev(e, " ", position12 - 1)
                xf = e.Substring(0, position13)
                yf = e.Substring(position13, position12 - position13)
                zf = e.Substring(position12, position11 - position12)
                iif = e.Substring(position11, position10 - position11)
                jjf = e.Substring(position10, position9 - position10)
                kkf = e.Substring(position9, position8 - position9)
                dirf = e.Substring(position8, position7 - position8)
                pendf = e.Substring(position7, position6 - position7)
                mf = e.Substring(position6, position5 - position6)
                kf = e.Substring(position5, position4 - position5)
                nf = e.Substring(position4, position3 - position4)
                rf = e.Substring(position3, position2 - position3)
                gf = e.Substring(position2, position1 - position2)
                bf = e.Substring(position1, e.Length - position1)

                'Input(1, xf)
                'Input(1, yf)
                'Input(1, zf)
                'Input(1, iif)
                'Input(1, jjf)
                'Input(1, kkf)
                'Input(1, dirf)
                'Input(1, pendf)
                'Input(1, mf)
                'Input(1, kf)
                'Input(1, nf)
                'Input(1, rf)
                'Input(1, gf)
                'Input(1, bf)
            End If
            acep = acep + 1
            difer = Math.Sqrt(Math.Pow((dirf - Form3.NumericUpDown1.Value), 2))
            If difer > 180 Then
                difer = 360 - difer
            End If
            If difer <= Form3.NumericUpDown2.Value And Math.Sqrt(Math.Pow((pendf - Form3.NumericUpDown3.Value), 2)) <= Form3.NumericUpDown4.Value Then
                If mf >= Form3.NumericUpDown5.Value And mf <= Form3.NumericUpDown6.Value Then
                    If kf >= Form3.NumericUpDown7.Value And kf <= Form3.NumericUpDown8.Value Then
                        If nf >= Form3.NumericUpDown9.Value And nf <= Form3.NumericUpDown10.Value Then
                            acep2 = acep2 + 1
                            If Form3.RadioButton1.Checked = True Then PrintLine(2, xf, yf, zf, iif, jjf, kkf, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                            If Form3.RadioButton2.Checked = True Then PrintLine(2, xf, yf, zf, iif, jjf, kkf, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                            If Form3.RadioButton3.Checked = True Then PrintLine(2, xf, yf, zf, iif, jjf, kkf, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                        End If
                    End If
                End If
            End If
            Form3.ProgressBar1.Value = ((acep) / (infoReader.Length / 27.5)) * 100
            porc = ((acep2 * 100) / acep)
            Form3.Label2.Text = Format(porc, "##.###")
        Loop
        FileClose(1)
        FileClose(2)
        Form3.ProgressBar1.Value = 100
        MsgBox("Filter Completed")
        Exit Sub
ErrorHandler:

    End Sub
    Sub filtrardip2()
        Dim ori As Double
        Dim pendi As Double
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim difer As Double
        Dim intenf As Integer
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim acep As Double
        Dim porc As Double
        Dim acep2 As Double
        Dim re As Double
        Dim gr As Double
        Dim bl As Double
        'Dim stri, stri2, stri3, stri4, stri5, stri6, stri7, stri8, stri9 As String
        acep = 0
        Form3.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form3.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog1.FileName)
        FileOpen(1, Form3.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "Filter.txt", OpenMode.Output)
        Do Until EOF(1)
            'Falta l'excepcio si per error esta escollida form1.radiobutton1
            If Form3.RadioButton1.Checked = True Then
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                position6 = InStrRev(e, " ", position5 - 1)
                position7 = InStrRev(e, " ", position6 - 1)
                position8 = InStrRev(e, " ", position7 - 1)
                position9 = InStrRev(e, " ", position8 - 1)
                position10 = InStrRev(e, " ", position9 - 1)
                xf = e.Substring(0, position10)
                yf = e.Substring(position10, position9 - position10)
                zf = e.Substring(position9, position8 - position9)
                i = e.Substring(position8, position7 - position8)
                j = e.Substring(position7, position6 - position7)
                k = e.Substring(position6, position5 - position6)
                ori = e.Substring(position5, position4 - position5)
                pendi = e.Substring(position4, position3 - position4)
                mf = e.Substring(position3, position2 - position3)
                kf = e.Substring(position2, position1 - position2)
                nf = e.Substring(position1, e.Length - position1)

                'Input(1, xf)
                'Input(1, yf)
                'Input(1, zf)
                'Input(1, i)
                'Input(1, j)
                'Input(1, k)
                'Input(1, ori)
                'Input(1, pendi)
                'Input(1, mf)
                'Input(1, kf)
                'Input(1, nf)
            End If
            If Form3.RadioButton2.Checked = True Then
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                position6 = InStrRev(e, " ", position5 - 1)
                position7 = InStrRev(e, " ", position6 - 1)
                position8 = InStrRev(e, " ", position7 - 1)
                position9 = InStrRev(e, " ", position8 - 1)
                position10 = InStrRev(e, " ", position9 - 1)
                position11 = InStrRev(e, " ", position10 - 1)
                xf = e.Substring(0, position11)
                yf = e.Substring(position11, position10 - position11)
                zf = e.Substring(position10, position9 - position10)
                i = e.Substring(position9, position8 - position9)
                j = e.Substring(position8, position7 - position8)
                k = e.Substring(position7, position6 - position7)
                ori = e.Substring(position6, position5 - position6)
                pendi = e.Substring(position5, position4 - position5)
                mf = e.Substring(position4, position3 - position4)
                kf = e.Substring(position3, position2 - position3)
                nf = e.Substring(position2, position1 - position2)
                intenf = e.Substring(position1, e.Length - position1)
                'Input(1, xf)
                'Input(1, yf)
                'Input(1, zf)
                'Input(1, i)
                'Input(1, j)
                'Input(1, k)
                'Input(1, ori)
                'Input(1, pendi)
                'Input(1, mf)
                'Input(1, kf)
                'Input(1, nf)
                'Input(1, intenf)
            End If
            If Form3.RadioButton3.Checked = True Then
                e = LineInput(1)
                position1 = InStrRev(e, " ")
                position2 = InStrRev(e, " ", position1 - 1)
                position3 = InStrRev(e, " ", position2 - 1)
                position4 = InStrRev(e, " ", position3 - 1)
                position5 = InStrRev(e, " ", position4 - 1)
                position6 = InStrRev(e, " ", position5 - 1)
                position7 = InStrRev(e, " ", position6 - 1)
                position8 = InStrRev(e, " ", position7 - 1)
                position9 = InStrRev(e, " ", position8 - 1)
                position10 = InStrRev(e, " ", position9 - 1)
                position11 = InStrRev(e, " ", position10 - 1)
                position12 = InStrRev(e, " ", position11 - 1)
                position13 = InStrRev(e, " ", position12 - 1)
                xf = e.Substring(0, position13)
                yf = e.Substring(position13, position12 - position13)
                zf = e.Substring(position12, position11 - position12)
                i = e.Substring(position11, position10 - position11)
                j = e.Substring(position10, position9 - position10)
                k = e.Substring(position9, position8 - position9)
                ori = e.Substring(position8, position7 - position8)
                pendi = e.Substring(position7, position6 - position7)
                mf = e.Substring(position6, position5 - position6)
                kf = e.Substring(position5, position4 - position5)
                nf = e.Substring(position4, position3 - position4)
                re = e.Substring(position3, position2 - position3)
                gr = e.Substring(position2, position1 - position2)
                bl = e.Substring(position1, e.Length - position1)
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, i)
                Input(1, j)
                Input(1, k)
                Input(1, ori)
                Input(1, pendi)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, re)
                Input(1, gr)
                Input(1, bl)
            End If

            acep = acep + 1
            difer = Math.Acos(Math.Abs(((i * Form3.TextBox1.Text) + (j * Form3.TextBox2.Text) + (k * Form3.TextBox3.Text)) / (Math.Sqrt((i * i) + (j * j) + (k * k))) * (Math.Sqrt((Form3.TextBox1.Text * Form3.TextBox1.Text) + (Form3.TextBox2.Text * Form3.TextBox2.Text) + (Form3.TextBox3.Text * Form3.TextBox3.Text)))))
            difer = (difer * 180) / Math.PI
            If mf >= Form3.NumericUpDown5.Value And mf <= Form3.NumericUpDown6.Value Then
                If kf >= Form3.NumericUpDown7.Value And kf <= Form3.NumericUpDown8.Value Then
                    If nf >= Form3.NumericUpDown9.Value And nf <= Form3.NumericUpDown10.Value Then
                        If difer <= Form3.NumericUpDown11.Value Then
                            acep2 = acep2 + 1
                            If Form3.RadioButton1.Checked = True Then PrintLine(2, xf, yf, zf, Format(i, "0.0000"), Format(j, "0.0000"), Format(k, "0.0000"), ori, pendi, Format(mf, "0.0000"), Format(kf, "0.0000"), nf)
                            If Form3.RadioButton2.Checked = True Then PrintLine(2, xf, yf, zf, Format(i, "0.0000"), Format(j, "0.0000"), Format(k, "0.0000"), ori, pendi, Format(mf, "0.0000"), Format(kf, "0.0000"), nf, intenf)
                            If Form3.RadioButton3.Checked = True Then PrintLine(2, xf, yf, zf, Format(i, "0.0000"), Format(j, "0.0000"), Format(k, "0.0000"), ori, pendi, Format(mf, "0.0000"), Format(kf, "0.0000"), nf, re, gr, bl)
                        End If
                    End If
                End If
            End If
            Form3.ProgressBar1.Value = ((acep * 3200) / infoReader.Length)
            porc = ((acep2 * 100) / acep)
            Form3.Label2.Text = Format(porc, "##.###")
        Loop
        FileClose(1)
        FileClose(2)
        Form3.ProgressBar1.Value = 100
        MsgBox("Filter Completed")
        Exit Sub
ErrorHandler:

    End Sub
    Function calculdips() As Double
        If AA = 0 And BB = 0 Then   '***la tra�a �s horitzontal***
            orien = 0
            pend = 0
            GoTo line200
        End If
        '***calculem dip i dip direction***
        pend = Math.Atan(Math.Sqrt((AA * AA) + (BB * BB)) / CC)
        pend = (pend * 180) / Math.PI

        If BB <> 0 Then
            orien = Math.Atan(AA / BB)
            orien = (orien * 180) / Math.PI
        Else
            If AA < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                orien = -90
            Else
                orien = 90
            End If
        End If

        If BB < 0 Then
            orien = 180 + orien
        Else
            If AA < 0 Then
                orien = 360 + orien
            Else
            End If
        End If

line200:
        'az1 = CInt(a1)
        Return Math.Abs(CInt(pend))
    End Function
    Function estadistica() As Double
        orienestad = Math.Abs(orien)
        pendestad = Math.Abs(pend)
        marc(orienestad, pendestad) = marc(orienestad, pendestad) + 1
    End Function
    Sub filtrardip3()
        Dim tex As String = "0"
        Dim contador As Integer
        Dim sol(24) As Integer
        Dim family2 As Integer
        Dim fam As Integer
        Dim iff As Double
        Dim jff As Double
        Dim kff As Double
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim dirfe As Double
        Dim pendfe As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim rf As Double
        Dim gf As Double
        Dim bf As Double
        '  Dim difer As Double
        Dim intenf As Integer
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim acep As Double
        Dim porc As Double
        Dim acep2 As Double

        'afegit
        If Form3.TextBox4.Visible = True Then
            tex = Form3.TextBox4.Text
            sol(1) = tex
        End If
        If Form3.TextBox5.Visible = True Then
            tex = Form3.TextBox5.Text
            sol(2) = tex
        End If
        If Form3.TextBox6.Visible = True Then
            tex = Form3.TextBox6.Text
            sol(3) = tex
        End If
        If Form3.TextBox7.Visible = True Then
            tex = Form3.TextBox7.Text
            sol(4) = tex
        End If
        If Form3.TextBox8.Visible = True Then
            tex = Form3.TextBox8.Text
            sol(5) = tex
        End If
        If Form3.TextBox9.Visible = True Then
            tex = Form3.TextBox9.Text
            sol(6) = tex
        End If
        If Form3.TextBox10.Visible = True Then
            tex = Form3.TextBox10.Text
            sol(7) = tex
        End If
        If Form3.TextBox11.Visible = True Then
            tex = Form3.TextBox11.Text
            sol(8) = tex
        End If
        If Form3.TextBox12.Visible = True Then
            tex = Form3.TextBox12.Text
            sol(9) = tex
        End If
        If Form3.TextBox13.Visible = True Then
            tex = Form3.TextBox13.Text
            sol(10) = tex
        End If
        If Form3.TextBox14.Visible = True Then
            tex = Form3.TextBox14.Text
            sol(11) = tex
        End If
        If Form3.TextBox15.Visible = True Then
            tex = Form3.TextBox15.Text
            sol(12) = tex
        End If
        If Form3.TextBox16.Visible = True Then
            tex = Form3.TextBox16.Text
            sol(13) = tex
        End If
        If Form3.TextBox17.Visible = True Then
            tex = Form3.TextBox17.Text
            sol(14) = tex
        End If
        If Form3.TextBox18.Visible = True Then
            tex = Form3.TextBox18.Text
            sol(15) = tex
        End If
        If Form3.TextBox19.Visible = True Then
            tex = Form3.TextBox19.Text
            sol(16) = tex
        End If
        If Form3.TextBox20.Visible = True Then
            tex = Form3.TextBox20.Text
            sol(17) = tex
        End If
        If Form3.TextBox21.Visible = True Then
            tex = Form3.TextBox21.Text
            sol(18) = tex
        End If
        If Form3.TextBox22.Visible = True Then
            tex = Form3.TextBox22.Text
            sol(19) = tex
        End If
        If Form3.TextBox23.Visible = True Then
            tex = Form3.TextBox23.Text
            sol(20) = tex
        End If
        If Form3.TextBox24.Visible = True Then
            tex = Form3.TextBox24.Text
            sol(21) = tex
        End If
        If Form3.TextBox25.Visible = True Then
            tex = Form3.TextBox25.Text
            sol(22) = tex
        End If
        If Form3.TextBox26.Visible = True Then
            tex = Form3.TextBox26.Text
            sol(23) = tex
        End If
        If Form3.TextBox27.Visible = True Then
            tex = Form3.TextBox27.Text
            sol(24) = tex
        End If
        family2 = 0
        For contador = 1 To 24
            If sol(contador) > family2 Then family2 = sol(contador)
        Next contador
        'fi afegit

        acep = 0
        Form3.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form3.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog1.FileName)
        FileOpen(1, Form3.OpenFileDialog1.FileName, OpenMode.Input)
        If family2 >= 1 Then FileOpen(2, Form10.TextBox1.Text + "Set1.txt", OpenMode.Output)
        If family2 >= 2 Then FileOpen(3, Form10.TextBox1.Text + "Set2.txt", OpenMode.Output)
        If family2 >= 3 Then FileOpen(4, Form10.TextBox1.Text + "Set3.txt", OpenMode.Output)
        If family2 >= 4 Then FileOpen(5, Form10.TextBox1.Text + "Set4.txt", OpenMode.Output)
        If family2 >= 5 Then FileOpen(6, Form10.TextBox1.Text + "Set5.txt", OpenMode.Output)
        If family2 >= 6 Then FileOpen(7, Form10.TextBox1.Text + "Set6.txt", OpenMode.Output)
        If family2 >= 7 Then FileOpen(8, Form10.TextBox1.Text + "Set7.txt", OpenMode.Output)
        If family2 >= 8 Then FileOpen(9, Form10.TextBox1.Text + "Set8.txt", OpenMode.Output)
        If family2 >= 9 Then FileOpen(10, Form10.TextBox1.Text + "Set9.txt", OpenMode.Output)
        If family2 >= 10 Then FileOpen(11, Form10.TextBox1.Text + "Set10.txt", OpenMode.Output)
        If family2 >= 11 Then FileOpen(12, Form10.TextBox1.Text + "Set11.txt", OpenMode.Output)
        If family2 >= 12 Then FileOpen(13, Form10.TextBox1.Text + "Set12.txt", OpenMode.Output)
        If family2 >= 13 Then FileOpen(14, Form10.TextBox1.Text + "Set13.txt", OpenMode.Output)
        If family2 >= 14 Then FileOpen(15, Form10.TextBox1.Text + "Set14.txt", OpenMode.Output)
        If family2 >= 15 Then FileOpen(16, Form10.TextBox1.Text + "Set15.txt", OpenMode.Output)
        If family2 >= 16 Then FileOpen(17, Form10.TextBox1.Text + "Set16.txt", OpenMode.Output)
        If family2 >= 17 Then FileOpen(18, Form10.TextBox1.Text + "Set17.txt", OpenMode.Output)
        If family2 >= 18 Then FileOpen(19, Form10.TextBox1.Text + "Set18.txt", OpenMode.Output)
        If family2 >= 19 Then FileOpen(20, Form10.TextBox1.Text + "Set19.txt", OpenMode.Output)
        If family2 >= 20 Then FileOpen(21, Form10.TextBox1.Text + "Set20.txt", OpenMode.Output)
        If family2 >= 21 Then FileOpen(22, Form10.TextBox1.Text + "Set21.txt", OpenMode.Output)
        If family2 >= 22 Then FileOpen(23, Form10.TextBox1.Text + "Set22.txt", OpenMode.Output)
        If family2 >= 23 Then FileOpen(24, Form10.TextBox1.Text + "Set23.txt", OpenMode.Output)
        If family2 = 24 Then FileOpen(25, Form10.TextBox1.Text + "Set24.txt", OpenMode.Output)
        'Lectura del fitxer
        Dim ff As Integer = 0
        Dim fe As String
        Do Until EOF(1)
            ' ff = ff + 1
            e = LineInput(1)
            ' If ff = 68803 Then Stop
            fe = Replace(e, "Infinito", "1000")
            e = fe
            If Form3.RadioButton3.Checked = True Then
                e = Trim(e) : position1 = InStrRev(e, " ")
                bf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                gf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
                'final
                e = Trim(e) : position1 = InStrRev(e, " ")
                rf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            If Form3.RadioButton2.Checked = True Then
                e = Trim(e) : position1 = InStrRev(e, " ")
                intenf = e.Substring(position1, e.Length - position1)
                e = Left(e, position1)
            End If
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            nf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            kf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            mf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            pendf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            dirf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            kff = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            jff = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            iff = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            zf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            yf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final
            e = Trim(e) : position1 = InStrRev(e, " ")
            xf = e.Substring(position1, e.Length - position1)
            e = Left(e, position1)
            'final lectura del fitxer
            acep = acep + 1

            dirfe = Math.Floor(dirf)
            pendfe = Math.Floor(pendf)

            For fam = 1 To family 'a
                If inscrit(dirfe, pendfe, fam) = True Then
                    'If difer <= Form3.NumericUpDown2.Value And Math.Sqrt(Math.Pow((pendf - Form3.NumericUpDown3.Value), 2)) <= Form3.NumericUpDown4.Value Then
                    If mf >= Form3.NumericUpDown5.Value And mf <= Form3.NumericUpDown6.Value Then
                        If kf >= Form3.NumericUpDown7.Value And kf <= Form3.NumericUpDown8.Value Then
                            If nf >= Form3.NumericUpDown9.Value And nf <= Form3.NumericUpDown10.Value Then
                                acep2 = acep2 + 1
                                Select Case fam
                                    Case 1
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(1) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(1) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(1) + 1, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 2
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(2) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(2) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(2) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 3
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(3) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(3) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(3) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 4
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(4) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(4) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(4) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 5
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(5) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(5) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(5) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 6
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(6) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(6) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(6) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 7
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(7) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(7) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(7) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 8
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(8) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(8) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(8) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 9
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(9) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(9) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(9) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 10
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(10) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(10) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(10) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 11
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(11) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(11) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(11) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 12
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(12) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(12) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(12) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 13
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(13) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(13) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(13) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 14
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(14) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(14) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(14) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 15
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(15) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(15) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(15) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)

                                    Case 16
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(16) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(16) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(16) + 1, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 17
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(17) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(17) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(17) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 18
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(18) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(18) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(18) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 19
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(19) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(19) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(19) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 20
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(20) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(20) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(20) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 21
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(21) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(21) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(21) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 22
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(22) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(22) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(22) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 23
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(23) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(23) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(23) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)
                                    Case 24
                                        If Form3.RadioButton1.Checked = True Then PrintLine(sol(24) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf)
                                        If Form3.RadioButton2.Checked = True Then PrintLine(sol(24) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, intenf)
                                        If Form3.RadioButton3.Checked = True Then PrintLine(sol(24) + 1, xf, yf, zf, iff, jff, kff, Format(dirf, "0.000"), Format(pendf, "0.000"), Format(mf, "0.000"), Format(kf, "0.000"), nf, rf, gf, bf)

                                End Select

                            End If
                        End If
                    End If
                End If
                If Form3.RadioButton1.Checked = True Then
                    Form3.ProgressBar1.Value = ((acep) / (infoReader.Length / 144)) * 100
                End If

                If Form3.RadioButton2.Checked = True Then
                    Form3.ProgressBar1.Value = ((acep) / (infoReader.Length / 160)) * 100
                End If
                If Form3.RadioButton3.Checked = True Then
                    Form3.ProgressBar1.Value = ((acep) / (infoReader.Length / 193)) * 100
                End If
                porc = ((acep2 * 100) / acep)
                'Form3.Label2.Text = CStr(porc)
            Next 'a
80:     Loop
        FileClose(1)
        If family >= 1 Then FileClose(2)
        If family >= 2 Then FileClose(3)
        If family >= 3 Then FileClose(4)
        If family >= 4 Then FileClose(5)
        If family >= 5 Then FileClose(6)
        If family >= 6 Then FileClose(7)
        If family >= 7 Then FileClose(8)
        If family >= 8 Then FileClose(9)
        If family >= 9 Then FileClose(10)
        If family >= 10 Then FileClose(11)
        If family >= 11 Then FileClose(12)
        If family >= 12 Then FileClose(13)
        If family >= 13 Then FileClose(14)
        If family >= 14 Then FileClose(15)
        If family >= 15 Then FileClose(16)
        If family >= 16 Then FileClose(17)
        If family >= 17 Then FileClose(18)
        If family >= 18 Then FileClose(19)
        If family >= 19 Then FileClose(20)
        If family >= 20 Then FileClose(21)
        If family >= 21 Then FileClose(22)
        If family >= 22 Then FileClose(23)
        If family >= 23 Then FileClose(24)
        If family = 24 Then FileClose(25)
        Form3.ProgressBar1.Value = 100
        MsgBox("Filter Completed")
        Exit Sub
ErrorHandler:
    End Sub
    Sub estadistica2()
        Dim iff As Double
        Dim jff As Double
        Dim kff As Double
        Dim ejx As Integer
        Dim ejy As Integer
        ReDim marc(360, 90)
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Double
        Dim gf As Double
        Dim bf As Double
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form3.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form3.OpenFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form3.OpenFileDialog1.FileName)
        FileOpen(1, Form3.OpenFileDialog1.FileName, OpenMode.Input)
        Do Until EOF(1)
            If Form11.RadioButton1.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, iff)
                Input(1, jff)
                Input(1, kff)
                Input(1, orien)
                Input(1, pend)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
            End If
            If Form11.RadioButton2.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, iff)
                Input(1, jff)
                Input(1, kff)
                Input(1, orien)
                Input(1, pend)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
            End If
            If Form11.RadioButton3.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, iff)
                Input(1, jff)
                Input(1, kff)
                Input(1, orien)
                Input(1, pend)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, rf)
                Input(1, gf)
                Input(1, bf)
            End If
            If mf >= Form11.NumericUpDown5.Value And mf <= Form11.NumericUpDown6.Value Then
                If kf >= Form11.NumericUpDown7.Value And kf <= Form11.NumericUpDown8.Value Then
                    estadistica()
                End If
            End If

        Loop
        FileOpen(2, Form10.TextBox1.Text + "estadistica2.txt", OpenMode.Output)
        For ejx = 0 To 360
            For ejy = 0 To 90
                PrintLine(2, ejx, ejy, marc(ejx, ejy))
            Next ejy
        Next ejx
        FileClose(1)
        FileClose(2)
        MsgBox("Statistical completed")
errorhandler:
        Exit Sub
    End Sub
    Function angle() As Double
        If A = 0 And B = 0 Then   '***la tra�a �s horitzontal***
            a1 = 0
            b1 = 0
            GoTo line100
        End If
        '***calculem dip i dip direction***
        b1 = Math.Atan(Math.Sqrt((A * A) + (B * B)) / C)
        b1 = (b1 * 180) / Math.PI

        If B <> 0 Then
            a1 = Math.Atan(A / B)
            a1 = (a1 * 180) / Math.PI
        Else
            If A < 0 Then        '***si m=0, llavors l<>0 perqu� ja hem eliminat les traces horitzontals***
                a1 = -90
            Else
                a1 = 90
            End If
        End If

        If B < 0 Then
            a1 = 180 + a1
        Else
            If A < 0 Then
                a1 = 360 + a1
            Else
            End If
        End If

line100:
        Return Math.Abs(CInt(a1))
        Return Math.Abs(CInt(b1))
        'gh
    End Function
End Module
