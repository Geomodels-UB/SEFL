﻿Imports System
Imports System.IO
Module Module3
    Public rugositatmitja As Double = 0
    Public D As Double
    Public intens2 As Integer
    Public intens3 As Integer
    Public xtremsup As Double
    Public xtreminf As Double
    Public ytremsup As Double
    Public ytreminf As Double
    Public ztremsup As Double
    Public ztreminf As Double
    Public vecibedd As Double
    Public vecjbedd As Double
    Public veckbedd As Double
    Public azibedd As Double
    Public dibedd As Double
    Public pend1 As Double 'linea beddin frac
    Dim vxlinea, vylinea, vzlinea As Double
    Public pe As Double
    Public numeroMU As Integer = -1
    Public itemordermu(0) As Integer
    Public dipdirmu(0) As Double
    Public dipmu(0) As Double
    Public xmu(0) As Double
    Public ymu(0) As Double
    Public zmu(0) As Double
    Public Hzmu(0) As Double
    Public Lzmu(0) As Double
    Public TotalHorExt(0) As Double
    Public pcex(0), pcey(0), pcez(0) As Double

    Sub atributecluster()
        'Dim intens As Double
        'Dim pas As Integer
        'Dim intens1() As Double
        seleccio = -1
        Dim cont As Integer = 1
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form15.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form15.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form15.OpenFileDialog1.FileName)
        'calcul de bedding
        If Form15.CheckBox3.Checked = True Then
            azibedd = Form15.NumericUpDown8.Value
            dibedd = Form15.NumericUpDown9.Value
            pe = Form15.NumericUpDown9.Value
            azibedd = (azibedd * Math.PI) / 180
            dibedd = (dibedd * Math.PI) / 180
            vecibedd = Math.Sin(azibedd)
            vecjbedd = Math.Cos(azibedd)
            veckbedd = Math.Sqrt(((vecibedd * vecibedd) + (vecjbedd * vecjbedd)) / (Math.Tan(dibedd) * (Math.Tan(dibedd))))
            If veckbedd > 100000 Then veckbedd = 99999.999999999
            If azibedd = 0 And dibedd = 0 Then
                vecibedd = 0
                vecjbedd = 0
                veckbedd = 0
            End If
        Else
            vecibedd = 0
            vecjbedd = 0
            veckbedd = 0
        End If
        'final calcul de bedding
        For Each rfile In Form15.OpenFileDialog1.FileNames
            FileOpen(1, rfile, OpenMode.Input)
            Dim intens As Double
            Dim pas As Integer
            Dim intens1() As Double

            If Form15.CheckBox1.Checked = True Then Form15.TextBox1.Text = "Set" + CStr(cont)
            'FileOpen(1, Form15.OpenFileDialog1.FileName, OpenMode.Input)
            FileOpen(2, Form10.TextBox1.Text + "morphometry" + CStr(cont) + ".txt", OpenMode.Output) 'sortida
            PrintLine(2, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Length", "Height", "Area", "Set")
            'cas de xyz+int
            If Form15.RadioButton2.Checked = True Then
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens2)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Do Until EOF(1)
                    seleccio = seleccio + 1
                    ReDim Preserve x(seleccio)
                    ReDim Preserve y(seleccio)
                    ReDim Preserve z(seleccio)
                    ReDim Preserve escollits(seleccio)
                    Input(1, x(seleccio))
                    Input(1, y(seleccio))
                    Input(1, z(seleccio))
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens3)
                    escollits(seleccio) = seleccio
                    If seleccio = 1 Then
                        xtremsup = x(seleccio)
                        xtreminf = x(seleccio)
                        ytremsup = y(seleccio)
                        ytreminf = y(seleccio)
                        ztremsup = z(seleccio)
                        ztreminf = z(seleccio)
                    End If
                    ' es podria aturar
                    ' If z(seleccio) <> 0 And y(seleccio) <> 0 And x(seleccio) <> 0 Then
                    ' If x(seleccio) > xtremsup Then xtremsup = x(seleccio)
                    ' If x(seleccio) < xtreminf Then xtreminf = x(seleccio)
                    ' If y(seleccio) > ytremsup Then ytremsup = y(seleccio)
                    ' If y(seleccio) < ytreminf Then ytreminf = y(seleccio)
                    ' If z(seleccio) > ztremsup Then ztremsup = z(seleccio)
                    ' If z(seleccio) < ztreminf Then ztreminf = z(seleccio)
                    ' End If
                    If x(seleccio) = y(seleccio) And z(seleccio) = 0 Then '2
                        x(seleccio) = x(seleccio - 1)
                        y(seleccio) = y(seleccio - 1)
                        z(seleccio) = z(seleccio - 1)
                        seleccio = seleccio - 1

                        intens2 = intens2 + 1
                        pas = 0

                        If seleccio > Form15.NumericUpDown1.Value Then '1
                            calculvectors()
                            A = AA : B = BB : C = CC
                            calculpendent()
                            rugositat()
                            'area()
                            area2()
                            seleccio = -1
                        End If '1
                        seleccio = -1
                    End If '2
                Loop
                'final cas xyz+int
                'inici de cas sense textura
            End If
            If Form15.RadioButton1.Checked = True Then
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens2)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Do Until EOF(1)
                    seleccio = seleccio + 1
                    ReDim Preserve x(seleccio)
                    ReDim Preserve y(seleccio)
                    ReDim Preserve z(seleccio)
                    ReDim Preserve escollits(seleccio)
                    Input(1, x(seleccio))
                    Input(1, y(seleccio))
                    Input(1, z(seleccio))
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    escollits(seleccio) = seleccio
                    If seleccio = 1 Then        '*****Afegit
                        xtremsup = x(seleccio)  '*****Afegit
                        xtreminf = x(seleccio)  '*****Afegit
                        ytremsup = y(seleccio)  '*****Afegit
                        ytreminf = y(seleccio)  '*****Afegit
                        ztremsup = z(seleccio)  '*****Afegit
                        ztreminf = z(seleccio)  '*****Afegit
                    End If                      '*****Afegit 
                    If x(seleccio) = y(seleccio) And z(seleccio) = 0 Then
                        seleccio = seleccio - 1
                        intens2 = intens2 + 1             '*****Afegit 
                        pas = 0

                        If seleccio > Form15.NumericUpDown1.Value Then
                            calculvectors()
                            A = AA : B = BB : C = CC
                            calculpendent()
                            If a1 < 0 Then a1 = 180 + a1
                            rugositat()
                            'area()
                            area2()
                            intens2 = intens2 + 1
                            seleccio = -1
                        End If
                        seleccio = -1
                    End If
                Loop
            End If
            'final de cas sense textura
            If Form15.RadioButton3.Checked = True Then
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens2)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Input(1, intens)
                Do Until EOF(1)
                    seleccio = seleccio + 1
                    ReDim Preserve x(seleccio)
                    ReDim Preserve y(seleccio)
                    ReDim Preserve z(seleccio)
                    ReDim Preserve escollits(seleccio)
                    Input(1, x(seleccio))
                    Input(1, y(seleccio))
                    Input(1, z(seleccio))
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens)
                    Input(1, intens3)
                    escollits(seleccio) = seleccio
                    If x(seleccio) = y(seleccio) And z(seleccio) = 0 Then
                        seleccio = seleccio - 1
                        pas = 0

                        If seleccio > Form15.NumericUpDown1.Value Then
                            calculvectors()
                            A = AA : B = BB : C = CC
                            calculpendent()
                            If a1 < 0 Then a1 = 180 + a1
                            rugositat()
                            'area() substituït per area2
                            area2()
                            intens2 = intens2 + 1
                            seleccio = -1
                        End If
                        seleccio = -1
                    End If
                Loop
            End If
            If seleccio > Form15.NumericUpDown1.Value Then
                escollits(seleccio) = seleccio
                calculvectors()
                A = AA : B = BB : C = CC
                calculpendent()
                If a1 < 0 Then a1 = 180 + a1
                rugositat()
                'area() 'substituït per area2
                area2()
            End If
            FileClose(2)
            FileClose(1)
            cont = cont + 1
        Next rfile
        MsgBox("Proces Completed")
        Exit Sub
ErrorHandler:

    End Sub
    Sub rugositat()
        Dim i As Integer
        Dim rugindividual(seleccio) As Double
        rugositatmitja = 0
        D = -(A * xmean) - (B * ymean) - (C * zmean)
        For i = 1 To seleccio
            rugindividual(i) = ((A * x(i)) + (B * y(i)) + (C * z(i)) + D) / Math.Sqrt((A * A) + (B * B) + (C * C))
            rugositatmitja = rugositatmitja + Math.Sqrt(rugindividual(i) * rugindividual(i))
        Next i
        rugositatmitja = rugositatmitja / seleccio
    End Sub
    Sub area()
        Dim i As Integer
        Dim j As Integer
        Dim xnou(seleccio) As Double
        Dim ynou(seleccio) As Double
        Dim znou(seleccio) As Double
        Dim radio(seleccio) As Double
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        Dim o2 As Double
        Dim A3 As Double
        Dim B3 As Double
        Dim C3 As Double
        Dim max As Double
        Dim mix As Double
        Dim maz As Double
        Dim miz As Double
        Dim are As Double
        Dim distx As Double
        Dim distz As Double
        Dim aa1 As Double
        Dim bb1 As Double
        'b2 = 90 - b1
        'k = (20.72796133 * Math.PI) / 180
        'calcul de l'angle entre 100 i vector
        'a2 = 360 - a1
        'a2 = (a2 * Math.PI) / 180
        For i = 1 To seleccio
            'projecció dels punts a un pla
            xnou(i) = x(i) + A * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            ynou(i) = y(i) + B * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            znou(i) = z(i) + C * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            'rotacio sobre omega amb el valor de ABC 010
            o = -Math.Acos(((A * 0) + (B * 1) + (C * 0)) / (Math.Sqrt((A * A) + (B * B) + (C * C)) * Math.Sqrt((0 * 0) + (1 * 1) + (0 * 0))))
            o2 = (o * 180) / Math.PI
            p = 0
            k = 0
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            A3 = ((A * ang(1)) + (B * ang(2)) + (C * ang(3)))
            B3 = ((A * ang(4)) + (B * ang(5)) + (C * ang(6)))
            C3 = ((A * ang(7)) + (B * ang(8)) + (C * ang(9)))

            'rotacions2
            k = -Math.Acos(((A3 * 1) + (B3 * 0) + (C3 * 0)) / (Math.Sqrt((A3 * A3) + (B3 * B3) + (C3 * C3)) * Math.Sqrt((1 * 1) + (0 * 0) + (0 * 0))))
            'p2 = (k * 180) / Math.PI
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            x(i) = ((xnou(i) * ang(1)) + (ynou(i) * ang(2)) + (znou(i) * ang(3))) '+ trasladacioX
            y(i) = ((xnou(i) * ang(4)) + (ynou(i) * ang(5)) + (znou(i) * ang(6))) '+ trasladacioY
            z(i) = ((xnou(i) * ang(7)) + (ynou(i) * ang(8)) + (znou(i) * ang(9))) ' + trasladacioZ
        Next i
        'buscar els extrems
        For j = 1 To seleccio
            'PrintLine(2, Format(Form15.NumericUpDown5.Value + x(j), "0.0000"), Format(Form15.NumericUpDown5.Value + z(j), "0.0000"))
            If j = 1 Then
                max = x(j)
                maz = z(j)
                mix = x(j)
                miz = z(j)
            Else
                If x(j) >= max Then max = x(j)
                If x(j) <= mix Then mix = x(j)
                If z(j) >= maz Then maz = z(j)
                If z(j) <= miz Then miz = z(j)
            End If
        Next j
        distx = Math.Abs(max - mix)
        distz = Math.Abs(maz - miz)
        are = distx * distz
        'Distribuir en cel·les
        '1 dimensionar model
        Dim espaicella As Double
        Dim cellasx As Double
        Dim cellasy As Double
        Dim ad As Integer
        Dim ae As Integer
        Dim ad2 As Integer
        Dim ae2 As Integer
        Dim contador As Integer
        Dim referarea()() As Integer
        espaicella = (are / seleccio) * 2.5
        'If espaicella < 0.02 Then espaicella = (are / seleccio) * 12.5
        If espaicella < 0.05 Then espaicella = 0.12
        cellasx = Math.Ceiling(distx / espaicella)
        cellasy = Math.Ceiling(distz / espaicella)
        ReDim referarea(cellasx + 2)
        For ad = 0 To cellasx + 2
            referarea(ad) = New Integer(cellasy + 2) {}
        Next ad
        '2 posar els punts a les cel·les

        For ad = 1 To seleccio
            'Form1.ProgressBar1.Value = (d * 100) / (x.Length - 1)
            aa1 = (x(ad) - mix) / espaicella
            aa1 = Int(aa1) + 1
            bb1 = (z(ad) - miz) / espaicella
            bb1 = Int(bb1) + 1
            referarea(aa1)(bb1) = 1
        Next ad

        '3comprovar veins

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 3 Then referarea(ad)(ae) = 2
                contador = 0
            Next ae
        Next ad
        '4 comprovar veins per segona vegada

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Or referarea(ad + ad2)(ae + ae2) = 2 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 4 Then referarea(ad)(ae) = 3
                contador = 0
            Next ae
        Next ad
        ' 5 contar cel·les
        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) >= 1 Then
                    contador = contador + 1
                End If
            Next ae
        Next ad
        are = espaicella * espaicella * contador
        'Fí de la distribució en cel·les
        If seleccio > Form15.NumericUpDown1.Value Then
            If are > Form15.NumericUpDown2.Value Then
                If prop3 > Form15.NumericUpDown3.Value Then
                    If kapa < Form15.NumericUpDown4.Value Then
                        PrintLine(2, Format(Form15.NumericUpDown5.Value + xmean, "0.0000"), Format(Form15.NumericUpDown6.Value + ymean, "0.0000"), Format(Form15.NumericUpDown7.Value + zmean, "0.0000"), Format(AA, "0.0000"), Format(BB, "0.0000"), Format(CC, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), seleccio, intens2 - 1, Format(rugositatmitja, "0.0000"), Format(distz, "0.0000"), Format(distx, "0.0000"), Format(are, "0.0000"), Form15.TextBox1.Text)
                        'PrintLine(2, Format(max, "0.000"), Format(mix, "0.000"), Format(maz, "0.000"), Format(miz, "0.000"), Format(are, "0.000"))
                    End If
                End If
            End If
        End If
    End Sub
    Sub area2()
        Dim i As Integer
        Dim j As Integer
        Dim xnou(seleccio), xnou1(seleccio) As Double
        Dim ynou(seleccio), ynou1(seleccio) As Double
        Dim znou(seleccio), znou1(seleccio) As Double
        Dim radio(seleccio) As Double
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        'Dim o2 As Double
        Dim A3, A4 As Double
        Dim B3, B4 As Double
        Dim C3, C4 As Double
        Dim max As Double
        Dim mix As Double
        Dim maz As Double
        Dim miz As Double
        Dim are As Double
        Dim distx, distx1 As Double
        Dim distz, distz1 As Double
        Dim aa1 As Double
        Dim bb1 As Double
        Dim dip1 As Double 'linea bedding fract
        ' Dim pend1 As Double 'linea beddin frac
        ' Dim dist1, dist2, dist3, dist4, dist5, dist6 As Double
        ' Dim n(5) As Integer
        calculdips()
        aa1 = orien
        bb1 = pend
        'b2 = 90 - b1
        'k = (20.72796133 * Math.PI) / 180
        'calcul de l'angle entre 100 i vector
        'a2 = 360 - a1
        'a2 = (a2 * Math.PI) / 180
        'busqueda dels extrems 5-4-15
        '  n(0) = Array.IndexOf(x, x.Max)
        '  n(1) = Array.IndexOf(x, x.Min)
        '  n(2) = Array.IndexOf(y, y.Max)
        '  n(3) = Array.IndexOf(y, y.Min)
        '  n(4) = Array.IndexOf(z, z.Max)
        '  n(5) = Array.IndexOf(z, z.Min)
        'distàncies
        '  dist1 = Math.Sqrt((Math.Pow(x(n(0)) - x(n(3)), 2)))

        '  dist1 = Math.Sqrt((Math.Pow(x(n(0)) - x(n(3)), 2)) + (Math.Pow(y(n(0)) - y(n(3)), 2)) + (Math.Pow(z(n(0)) - z(n(3)), 2)))
        '  dist2 = Math.Sqrt((Math.Pow(x(n(0)) - x(n(5)), 2)) + (Math.Pow(y(n(0)) - y(n(5)), 2)) + (Math.Pow(z(n(0)) - z(n(5)), 2)))
        '  dist3 = Math.Sqrt((Math.Pow(x(n(2)) - x(n(1)), 2)) + (Math.Pow(y(n(2)) - y(n(1)), 2)) + (Math.Pow(z(n(2)) - z(n(1)), 2)))
        '  dist4 = Math.Sqrt((Math.Pow(x(n(2)) - x(n(5)), 2)) + (Math.Pow(y(n(2)) - y(n(5)), 2)) + (Math.Pow(z(n(2)) - z(n(5)), 2)))
        '  dist5 = Math.Sqrt((Math.Pow(x(n(4)) - x(n(1)), 2)) + (Math.Pow(y(n(4)) - y(n(1)), 2)) + (Math.Pow(z(n(4)) - z(n(1)), 2)))
        '  dist6 = Math.Sqrt((Math.Pow(x(n(4)) - x(n(3)), 2)) + (Math.Pow(y(n(4)) - y(n(3)), 2)) + (Math.Pow(z(n(4)) - z(n(3)), 2)))

        'busqueda dels extrems 11-4-15
        'Linea d'interseccio bedding, pla de falla
        'Dim vxlinea, vylinea, vzlinea As Double
        Dim vxfrac, vyfrac, vzfrac As Double
        If CC < 0 Then
            AA = -AA
            BB = -BB
            CC = -CC
        End If

        vxfrac = AA : vyfrac = BB : vzfrac = CC
        vxlinea = (vecjbedd * vzfrac) - (veckbedd * vyfrac)
        vylinea = (veckbedd * vxfrac) - (vecibedd * vzfrac)
        vzlinea = (vecibedd * vyfrac) - (vecjbedd * vxfrac)
        AA = vxlinea : BB = vylinea : CC = vzlinea
        If CC < 0 Then
            AA = -AA
            BB = -BB
            CC = -CC
        End If
        calculdips()
        dip1 = orien
        pend1 = pend
        AA = vxfrac : BB = vyfrac : CC = vzfrac
        'final busqueda dels extrems
        For i = 0 To seleccio
            'projecció dels punts a un pla
            xnou(i) = x(i) + A * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            ynou(i) = y(i) + B * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            znou(i) = z(i) + C * ((-D - (A * x(i)) - (B * y(i)) - (C * z(i))) / ((A * A) + (B * B) + (C * C)))
            'rotacio sobre omega amb el valor de ABC 010
            o = 0
            p = 0
            k = (aa1 * Math.PI) / 180
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            A3 = ((xnou(i) * ang(1)) + (ynou(i) * ang(2)) + (znou(i) * ang(3)))
            B3 = ((xnou(i) * ang(4)) + (ynou(i) * ang(5)) + (znou(i) * ang(6)))
            C3 = ((xnou(i) * ang(7)) + (ynou(i) * ang(8)) + (znou(i) * ang(9)))
            'Rotacio sobre l'eix z per desrotar el bedding
            o = 0
            p = 0
            k = (dip1 * Math.PI) / 180
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            A4 = ((x(i) * ang(1)) + (y(i) * ang(2)) + (z(i) * ang(3)))
            B4 = ((x(i) * ang(4)) + (y(i) * ang(5)) + (z(i) * ang(6)))
            C4 = ((x(i) * ang(7)) + (y(i) * ang(8)) + (z(i) * ang(9)))
            'Segona desrotacio bedding
            o = (pend1 * Math.PI) / 180
            p = 0
            k = 0
            'p2 = (k * 180) / Math.PI
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            xnou1(i) = ((A4 * ang(1)) + (B4 * ang(2)) + (C4 * ang(3))) '+ trasladacioX
            ynou1(i) = ((A4 * ang(4)) + (B4 * ang(5)) + (C4 * ang(6))) '+ trasladacioY
            znou1(i) = ((A4 * ang(7)) + (B4 * ang(8)) + (C4 * ang(9))) '+ trasladacioZ

            'rotacions2 per l'area
            o = (bb1 * Math.PI) / 180
            p = 0
            k = 0
            'p2 = (k * 180) / Math.PI
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            x(i) = ((A3 * ang(1)) + (B3 * ang(2)) + (C3 * ang(3))) '+ trasladacioX
            y(i) = ((A3 * ang(4)) + (B3 * ang(5)) + (C3 * ang(6))) '+ trasladacioY
            z(i) = ((A3 * ang(7)) + (B3 * ang(8)) + (C3 * ang(9))) '+ trasladacioZ
            ' PrintLine(2, Format(xnou1(i), "0.0000"), Format(ynou1(i), "0.0000"), Format(znou1(i), "0.0000"))
        Next i
        'buscar els extrems

        For j = 0 To seleccio
            'PrintLine(2, Format(Form15.NumericUpDown5.Value + x(j), "0.0000"), Format(Form15.NumericUpDown5.Value + z(j), "0.0000"))
            If j = 0 Then
                max = x(j)
                maz = y(j)
                mix = x(j)
                miz = y(j)
            Else
                If x(j) >= max Then max = x(j)
                If x(j) <= mix Then mix = x(j)
                If y(j) >= maz Then maz = y(j)
                If y(j) <= miz Then miz = y(j)
            End If
        Next j
        distx = Math.Abs(max - mix)
        distz = Math.Abs(maz - miz)
        distx1 = Math.Abs(ynou1.Max - ynou1.Min)
        distz1 = Math.Abs(znou1.Max - znou1.Min)
        are = distx * distz
        'Distribuir en cel·les
        '1 dimensionar model
        Dim espaicella As Double
        Dim cellasx As Double
        Dim cellasy As Double
        Dim ad As Integer
        Dim ae As Integer
        Dim ad2 As Integer
        Dim ae2 As Integer
        Dim contador As Integer
        Dim referarea()() As Integer
        espaicella = (are / seleccio) * 2.5
        'If espaicella < 0.02 Then espaicella = (are / seleccio) * 12.5
        If espaicella < 0.06 Then espaicella = 0.12
        cellasx = Math.Ceiling(distx / espaicella)
        cellasy = Math.Ceiling(distz / espaicella)
        ReDim referarea(cellasx + 2)
        For ad = 0 To cellasx + 2
            referarea(ad) = New Integer(cellasy + 2) {}
        Next ad
        '2 posar els punts a les cel·les

        For ad = 0 To seleccio
            'Form1.ProgressBar1.Value = (d * 100) / (x.Length - 1)
            aa1 = (x(ad) - mix) / espaicella
            aa1 = Int(aa1) + 1
            bb1 = (y(ad) - miz) / espaicella
            bb1 = Int(bb1) + 1
            referarea(aa1)(bb1) = 1
        Next ad

        '3comprovar veins

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 3 Then referarea(ad)(ae) = 2
                contador = 0
            Next ae
        Next ad
        '4 comprovar veins per segona vegada

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Or referarea(ad + ad2)(ae + ae2) = 2 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 4 Then referarea(ad)(ae) = 3
                contador = 0
            Next ae
        Next ad
        ' 5 contar cel·les
        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) >= 1 Then
                    contador = contador + 1
                End If
            Next ae
        Next ad
        are = espaicella * espaicella * contador
        'Fí de la distribució en cel·les
        If seleccio > Form15.NumericUpDown1.Value Then
            If are > Form15.NumericUpDown2.Value Then
                If prop3 > Form15.NumericUpDown3.Value Then
                    If kapa < Form15.NumericUpDown4.Value Then
                        PrintLine(2, Format(Form15.NumericUpDown5.Value + xmean, "0.0000"), Format(Form15.NumericUpDown6.Value + ymean, "0.0000"), Format(Form15.NumericUpDown7.Value + zmean, "0.0000"), Format(AA, "0.0000"), Format(BB, "0.0000"), Format(CC, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), seleccio, intens2 - 1, Format(rugositatmitja, "0.0000"), Format(distz1, "0.0000"), Format(distx1, "0.0000"), Format(are, "0.0000"), Form15.TextBox1.Text)
                        'PrintLine(2, Format(max, "0.000"), Format(mix, "0.000"), Format(maz, "0.000"), Format(miz, "0.000"), Format(are, "0.000"))
                    End If
                End If
            End If
        End If
    End Sub
    Sub exportts()
        Dim dipdir1 As Double
        Dim pendi1 As Double
        Dim n As Integer
        Dim puntx, punty, puntz As Double
        Dim status As Long
        Dim button As Long
        Dim na As Integer = 1
        Dim cox As Double
        Dim coy As Double
        Dim coz As Double
        Dim vectora As Double
        Dim vectorb As Double
        Dim vectorc As Double
        Dim dipdir As Double
        Dim pendi As Double
        Dim m As Double
        Dim k As Double
        Dim population As Integer
        Dim number As Integer
        Dim rugosity As Double
        Dim lon As Double
        Dim lon1 As Double
        Dim wide As Double
        Dim wide1 As Double
        Dim area As Double
        Dim familia As String = Nothing
        Dim incrementx As Double
        Dim incrementy As Double
        Dim incrementz As Double
        Dim incrementz2 As Double
        Dim ratio As Double
        Dim px(3), py(3), pz(3) As Double
        Dim pxf(3), pyf(3), pzf(3) As Double
        Dim o, p, ka As Double
        Dim ang(9) As Double
        Dim P0x, P0y, P0z, P1x, P1y, P1z, P2x, P2y, P3x, P3y As Double
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim savefileDialog2 As New SaveFileDialog()
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        'openFileDialog1.InitialDirectory = Form2.TextBox1.Text
        openFileDialog1.Title = "FROM MORPHOLOGY MODEL TO GOCAD SURFACE"
        openFileDialog1.InitialDirectory = Form10.TextBox1.Text
        openFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        ' savefileDialog2.Title = "GOCAD SURFACE FILE EXPORT .TS"
        ' savefileDialog2.ShowDialog()
        FileOpen(6, openFileDialog1.FileName, OpenMode.Input)
        Input(6, familia)
        Do While Not EOF(6)
            Input(6, cox)
            Input(6, coy)
            Input(6, coz)
            Input(6, vectora)
            Input(6, vectorb)
            Input(6, vectorc)
            Input(6, dipdir)
            Input(6, pendi)
            Input(6, m)
            Input(6, k)
            Input(6, population)
            Input(6, number)
            Input(6, rugosity)
            Input(6, wide1)
            Input(6, lon1)
            Input(6, area)
            Input(6, familia)
        Loop
        FileClose(6)
        Dim Position1a As Integer
        Dim Position2a As Integer
        Dim setnumer2 As String
        Dim nom As String
        Position1a = InStrRev(openFileDialog1.FileName, "\")
        Position2a = InStrRev(openFileDialog1.FileName, ".")
        nom = openFileDialog1.FileName.Substring(Position1a, ((Position2a - 1) - Position1a))
        FileOpen(1, Form10.TextBox1.Text + nom + ".ts", OpenMode.Output)
        PrintLine(1, "GOCAD TSurf 1")
        PrintLine(1, "HEADER {")
        PrintLine(1, "name:" + nom + "_" + familia)
        PrintLine(1, "mesh:false")
        PrintLine(1, "cn:false")
        Select Case familia
            Case "Set 3" 'red
                PrintLine(1, "*solid*color:#ff0000")
            Case "Set3" 'red
                PrintLine(1, "*solid*color:#ff0000")
            Case "Set 4" 'cyan
                PrintLine(1, "*solid*color:#00ffff")
            Case "Set4" 'cyan
                PrintLine(1, "*solid*color:#00ffff")
            Case "Set 0" 'Yellow
                PrintLine(1, "*solid*color:#ffff00")
            Case "Set0" 'Yellow
                PrintLine(1, "*solid*color:#ffff00")
            Case "Set 5" 'dark green
                PrintLine(1, "*solid*color:#008000")
            Case "Set5" 'dark green
                PrintLine(1, "*solid*color:#008000")
            Case "Set 1" 'Blue
                PrintLine(1, "*solid*color:#0000ff")
            Case "Set1" 'Blue
                PrintLine(1, "*solid*color:#0000ff")
            Case "Set 15" 'snow
                PrintLine(1, "*solid*color:#fffafa")
            Case "Set15" 'snow
                PrintLine(1, "*solid*color:#fffafa")
            Case "Set 0" 'violet
                PrintLine(1, "*solid*color:#ee82ee")
            Case "Set0" 'violet
                PrintLine(1, "*solid*color:#ee82ee")
            Case "Set 7" 'Orange
                PrintLine(1, "*solid*color:#ffa500")
            Case "Set7" 'Orange
                PrintLine(1, "*solid*color:#ffa500")
            Case "Set 8" 'red brick
                PrintLine(1, "*solid*color:#fa8072")
            Case "Set8" 'red brick
                PrintLine(1, "*solid*color:#fa8072")
            Case "Set 9" 'Green 
                PrintLine(1, "*solid*color:#tcfc00")
            Case "Set9" 'Green 
                PrintLine(1, "*solid*color:#tcfc00")
            Case "Set 10" 'Dark violet
                PrintLine(1, "*solid*color:#c71585")
            Case "Set10" 'Dark violet
                PrintLine(1, "*solid*color:#c71585")
            Case "Set 11" 'SeaBlue
                PrintLine(1, "*solid*color:#6495ed")
            Case "Set11" 'SeaBlue
                PrintLine(1, "*solid*color:#6495ed")
            Case "Set 12"
                PrintLine(1, "*solid*color:#add8e6")
            Case "Set12"
                PrintLine(1, "*solid*color:#add8e6")
            Case "Set 13"
                PrintLine(1, "*solid*color:#99ffff")
            Case "Set13"
                PrintLine(1, "*solid*color:#99ffff")
            Case "Set 14"
                PrintLine(1, "*solid*color:0.854902 0.666667 0 1")
            Case "Set14"
                PrintLine(1, "*solid*color:0.854902 0.666667 0 1")
            Case "Set 2"
                PrintLine(1, "*solid*color:#ffffff")
            Case "Set2"
                PrintLine(1, "*solid*color:#ffffff")
            Case Else
                PrintLine(1, "*solid*color:#add8e6")
        End Select
        PrintLine(1, "ivolmap:false")
        PrintLine(1, "imap:false")
        PrintLine(1, "}")
        PrintLine(1, "GOCAD_ORIGINAL_COORDINATE_SYSTEM")
        PrintLine(1, "NAME default")
        PrintLine(1, "AXIS_NAME ""X"" ""Y"" ""Z""")
        PrintLine(1, "AXIS_UNIT ""m"" ""m"" ""m""")
        PrintLine(1, "ZPOSITIVE Elevation")
        PrintLine(1, "END_ORIGINAL_COORDINATE_SYSTEM")
        PrintLine(1, "PROPERTIES Set Height Length Area Azimuth Dip M K")
        PrintLine(1, "PROP_LEGAL_RANGES **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none** **none**  **none**  **none**  **none**")
        PrintLine(1, "NO_DATA_VALUES -99999 -99999 -99999 -99999 -99999 -99999 -99999 -99999")
        PrintLine(1, "PROPERTY_CLASSES set height length area azimuth Dip m k")
        PrintLine(1, "PROPERTY_KINDS unknown Height Length Area Angle Angle unknown unknown")
        PrintLine(1, "PROPERTY_SUBCLASSES QUANTITY Float LINEARFUNCTION Float 1  0  LINEARFUNCTION Float 1  0  LINEARFUNCTION Float 1  0  QUANTITY Float QUANTITY Float QUANTITY Float QUANTITY Float")
        PrintLine(1, "ESIZES 1 1 1 1 1 1 1 1")
        PrintLine(1, "UNITS none m m m^2 deg deg none none")
        PrintLine(1, "PROPERTY_CLASS_HEADER Z {")
        PrintLine(1, "is_z:on")
        PrintLine(1, "}")
        PrintLine(1, "PROPERTY_CLASS_HEADER set {")
        PrintLine(1, "low_clip:0")
        PrintLine(1, "high_clip:0")
        PrintLine(1, "pclip:99")
        PrintLine(1, "}")
        'final de la capçelera
        FileOpen(6, openFileDialog1.FileName, OpenMode.Input)
        Input(6, familia)
        Do While Not EOF(6)
            Input(6, cox)
            Input(6, coy)
            Input(6, coz)
            Input(6, vectora)
            Input(6, vectorb)
            Input(6, vectorc)
            Input(6, dipdir)
            dipdir1 = dipdir
            Input(6, pendi)
            pendi1 = pendi
            Input(6, m)
            Input(6, k)
            Input(6, population)
            Input(6, number)
            Input(6, rugosity)
            Input(6, wide1)
            Input(6, lon1)
            Input(6, area)
            Input(6, familia)
            Position1a = InStrRev(familia, "t")
            Position2a = Len(familia)
            setnumer2 = familia.Substring(Position1a)
            ratio = lon1 / wide1
            wide = Math.Sqrt(area / ratio)
            lon = wide1 * ratio

            '
            If Form15.CheckBox3.Checked = True Then
                azibedd = Form15.NumericUpDown8.Value
                dibedd = Form15.NumericUpDown9.Value
                pe = Form15.NumericUpDown9.Value
                azibedd = (azibedd * Math.PI) / 180
                dibedd = (dibedd * Math.PI) / 180
                vecibedd = Math.Sin(azibedd)
                vecjbedd = Math.Cos(azibedd)
                veckbedd = Math.Sqrt(((vecibedd * vecibedd) + (vecjbedd * vecjbedd)) / (Math.Tan(dibedd) * (Math.Tan(dibedd))))
                If veckbedd > 100000 Then veckbedd = 99999.999999999
                If azibedd = 0 And dibedd = 0 Then
                    vecibedd = 0
                    vecjbedd = 0
                    veckbedd = 0
                End If
            Else
                vecibedd = 0
                vecjbedd = 0
                veckbedd = 0
            End If

            '2 Calcul dels 4 punts, extrems del rectangle

            A = (vecjbedd * vectorc) - (veckbedd * vectorb)
            B = (veckbedd * vectora) - (vecibedd * vectorc)
            C = (vecibedd * vectorb) - (vecjbedd * vectora)
            calculpendent()
            ' vxlinea = A
            ' vylinea = B
            ' vzlinea = C


            ' px(0) = -lon1 / 2
            ' py(0) = wide1 / 2
            pz(0) = 0
            ' px(1) = lon1 / 2
            ' py(1) = wide1 / 2
            pz(1) = 0
            ' px(2) = -lon1 / 2
            ' py(2) = -wide1 / 2
            pz(2) = 0
            ' px(3) = lon1 / 2
            ' py(3) = -wide1 / 2
            pz(3) = 0
            P0x = (wide1 / 2) * Math.Sin((b1) * (Math.PI / 180))
            P0y = (wide1 / 2) * Math.Cos((b1) * (Math.PI / 180))
            P1x = -(wide1 / 2) * Math.Sin((b1) * (Math.PI / 180))
            P1y = -(wide1 / 2) * Math.Cos((b1) * (Math.PI / 180))
            P2x = (lon1 / 2) * Math.Sin((b1) * (Math.PI / 180))
            P2y = (lon1 / 2) * Math.Cos((b1) * (Math.PI / 180))
            P3x = -(lon1 / 2) * Math.Sin((b1) * (Math.PI / 180))
            P3y = -(lon1 / 2) * Math.Cos((b1) * (Math.PI / 180))

            px(1) = P0x + P3y
            py(1) = P0y + P2x
            px(0) = P0x + P2y
            py(0) = P0y + P3x
            px(3) = P1x + P3y
            py(3) = P1y + P2x
            px(2) = P1x + P2y
            py(2) = P1y + P3x



            o = -((pendi) * Math.PI) / 180
            p = 0
            ka = 0
            '4 rotacions

            ang(1) = Math.Cos(p) * Math.Cos(ka)
            ang(2) = -Math.Cos(p) * Math.Sin(ka)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
            ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
            ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
            ang(9) = Math.Cos(o) * Math.Cos(p)
            '5 Traslacio
            For n = 0 To 3
                pxf(n) = ((px(n) * ang(1)) + (py(n) * ang(2)) + (pz(n) * ang(3)))
                pyf(n) = ((px(n) * ang(4)) + (py(n) * ang(5)) + (pz(n) * ang(6)))
                pzf(n) = ((px(n) * ang(7)) + (py(n) * ang(8)) + (pz(n) * ang(9)))
            Next n

            '6 Rotació al voltant de kappa

            o = 0
            p = 0
            ka = -(((dipdir) * Math.PI) / 180) '-(((dipdir - 90) * Math.PI) / 180) 

            '7 Rotacio
            ang(1) = Math.Cos(p) * Math.Cos(ka)
            ang(2) = -Math.Cos(p) * Math.Sin(ka)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(ka)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(ka))
            ang(5) = (Math.Cos(o) * Math.Cos(ka)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(ka))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(ka)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(ka))
            ang(8) = (Math.Sin(o) * Math.Cos(ka)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(ka))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            '8 Traslacio
            For n = 0 To 3
                px(n) = ((pxf(n) * ang(1)) + (pyf(n) * ang(2)) + (pzf(n) * ang(3)))
                py(n) = ((pxf(n) * ang(4)) + (pyf(n) * ang(5)) + (pzf(n) * ang(6)))
                pz(n) = ((pxf(n) * ang(7)) + (pyf(n) * ang(8)) + (pzf(n) * ang(9)))
            Next n

            'Rotar bedding

            PrintLine(1, "TFACE")

            '   Send a data point to the current command

            puntx = cox + px(0)
            punty = coy + py(0)
            puntz = coz + pz(0)
            PrintLine(1, "PVRTX", SPC(0), na, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), lon1, SPC(0), wide1, SPC(0), area, SPC(0), dipdir1, SPC(0), pendi1, SPC(0), m, SPC(0), k, SPC(0), " CNXYZ")


            puntx = cox + px(2)
            punty = coy + py(2)
            puntz = coz + pz(2)
            PrintLine(1, "PVRTX", SPC(0), na + 1, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), lon1, SPC(0), wide1, SPC(0), area, SPC(0), dipdir1, SPC(0), pendi1, SPC(0), m, SPC(0), k, SPC(0), " CNXYZ")

            puntx = cox + px(3)
            punty = coy + py(3)
            puntz = coz + pz(3)
            PrintLine(1, "PVRTX", SPC(0), na + 2, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), lon1, SPC(0), wide1, SPC(0), area, SPC(0), dipdir1, SPC(0), pendi1, SPC(0), m, SPC(0), k, SPC(0), " CNXYZ")


            puntx = cox + px(1)
            punty = coy + py(1)
            puntz = coz + pz(1)

            PrintLine(1, "PVRTX", SPC(0), na + 3, SPC(0), puntx, SPC(0), punty, SPC(0), puntz, SPC(0), setnumer2, SPC(0), lon1, SPC(0), wide1, SPC(0), area, SPC(0), dipdir1, SPC(0), pendi1, SPC(0), m, SPC(0), k, SPC(0), " CNXYZ")


            PrintLine(1, "TRGL", SPC(0), na + 3, SPC(0), na + 2, SPC(0), na + 1)
            PrintLine(1, "TRGL", SPC(0), na + 3, SPC(0), na + 1, SPC(0), na)
            na = na + 4
        Loop
        'cua del fitxer
        PrintLine(1, "BSTONE 1")
        PrintLine(1, "BSTONE 5")
        PrintLine(1, "BORDER 9 1 2")
        PrintLine(1, "BORDER 10 5 8")
        PrintLine(1, "END")
        FileClose(1)
        FileClose(6)
        MsgBox("End Export")
        Exit Sub
ErrorHandler:
    End Sub

    Sub match()
        Dim erro As Integer = 0
        FileClose(1)
        FileClose(2)
        FileClose(3)
        Dim coxb As Double
        Dim coyb As Double
        Dim cozb As Double
        Dim mummy As String
        Dim num As Integer = 0
        Dim pep As Double
        Dim i As Integer = 0
        Dim cas As Integer = 0
        Dim rfiles As String = ""
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim openFileDialog2 As New OpenFileDialog()
        Dim position1a As Integer
        Dim position2a As Integer
        Dim cadena As String = ""
        Dim cox(num) As Double
        Dim coy(num) As Double
        Dim coz(num) As Double
        Dim vectora(num) As Double
        Dim vectorb(num) As Double
        Dim vectorc(num) As Double
        Dim dipdir(num) As Double
        Dim pendi(num) As Double
        Dim m(num) As Double
        Dim k(num) As Double
        Dim population(num) As Integer
        Dim number(num) As Integer
        Dim rugosity(num) As Double
        Dim lon(num) As Double
        Dim wide(num) As Double
        Dim area(num) As Double
        Dim familia(num) As String
        Dim used(num) As Boolean

        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************

        openFileDialog2.Title = "Open Morphology File to Match.ts"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        FileOpen(2, openFileDialog2.FileName, OpenMode.Input)

        Do While Not EOF(2)
            mummy = LineInput(2)
            num += 1
        Loop
        ReDim Preserve cox(num - 1)
        ReDim Preserve coy(num - 1)
        ReDim Preserve coz(num - 1)
        ReDim Preserve vectora(num - 1)
        ReDim Preserve vectorb(num - 1)
        ReDim Preserve vectorc(num - 1)
        ReDim Preserve dipdir(num - 1)
        ReDim Preserve pendi(num - 1)
        ReDim Preserve m(num - 1)
        ReDim Preserve k(num - 1)
        ReDim Preserve population(num - 1)
        ReDim Preserve number(num - 1)
        ReDim Preserve rugosity(num - 1)
        ReDim Preserve lon(num - 1)
        ReDim Preserve wide(num - 1)
        ReDim Preserve area(num - 1)
        ReDim Preserve familia(num - 1)
        ReDim Preserve used(num - 1)
        FileClose(2)
        FileOpen(2, openFileDialog2.FileName, OpenMode.Input)
        For i = 0 To num - 1
            Input(2, cox(i))
            Input(2, coy(i))
            Input(2, coz(i))
            Input(2, vectora(i))
            Input(2, vectorb(i))
            Input(2, vectorc(i))
            Input(2, dipdir(i))
            Input(2, pendi(i))
            Input(2, m(i))
            Input(2, k(i))
            Input(2, population(i))
            Input(2, number(i))
            Input(2, rugosity(i))
            Input(2, lon(i))
            Input(2, wide(i))
            Input(2, area(i))
            Input(2, familia(i))
        Next i
        FileClose(2)
        openFileDialog1.Multiselect = True

        openFileDialog1.Title = "Open Coordenate File to Match.ts"
        openFileDialog1.InitialDirectory = Form10.TextBox1.Text
        openFileDialog1.ShowDialog()
        For Each rfiles In openFileDialog1.FileNames
            FileOpen(1, rfiles, OpenMode.Input)
            On Error GoTo ErrorHandler

            position1a = InStrRev(rfiles, "\")
            position2a = InStrRev(rfiles, ".")
            cadena = rfiles.Substring(position1a, ((position2a - 1) - position1a))
            FileOpen(3, Form10.TextBox1.Text + cadena + "_Match.txt", OpenMode.Output)
            PrintLine(3, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Wide", "Long", "Area", "Set")

            ' On Error GoTo ErrorHandler

            Dim ii As Integer
            Do While Not EOF(1)
                Input(1, coxb)
                Input(1, coyb)
                Input(1, cozb)
                For ii = 0 To num
                    Select Case used(ii)
                        Case False
                            If coxb = cox(ii) And coyb = coy(ii) And cozb = coz(ii) Then
                                PrintLine(3, Format(cox(ii), "0.0000"), Format(coy(ii), "0.0000"), Format(coz(ii), "0.0000"), Format(vectora(ii), "0.0000"), Format(vectorb(ii), "0.0000"), Format(vectorc(ii), "0.0000"), Format(dipdir(ii), "0.00"), Format(pendi(ii), "0.00"), Format(m(ii), "0.0000"), Format(k(ii), "0.0000"), population(ii), number(ii), Format(rugosity(ii), "0.0000"), Format(lon(ii), "0.0000"), Format(wide(ii), "0.0000"), Format(area(ii), "0.0000"), familia(ii))
                                used(ii) = True
                                ii = num
                            End If
                        Case True
                            If coxb = cox(ii) And coyb = coy(ii) And cozb = coz(ii) Then
                                erro += 1
                                ii = num
                            End If
                    End Select
                Next ii
            Loop
            FileClose(3)
            FileClose(1)
            If erro > 0 Then MsgBox("Repeated Coordenate, Continue?")
            erro = 0
        Next rfiles
        MsgBox("Match Morphology Completed")
        Exit Sub
ErrorHandler:
    End Sub
    Sub rotation()
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        Dim xa, ya, za As Double
        Dim xab, yab, zab As Double
        Dim vec1a, vec2a, vec3a As Double
        Dim ra, ga, va As Integer
        Dim intena As Integer
        Dim numer As Integer
        Dim par1, par2 As Integer
        Dim par3, par4, par5, par6 As Double
        Dim par7, par8 As String
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Form2.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form2.OpenFileDialog1.ShowDialog()
        On Error GoTo ErrorHandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form1.OpenFileDialog1.FileName)
        FileOpen(1, Form2.OpenFileDialog1.FileName, OpenMode.Input)
        FileOpen(2, Form10.TextBox1.Text + "Rotation.txt", OpenMode.Output) 'sortida

        o = -(Form2.NumericUpDown1.Value * Math.PI) / 180
        p = -(Form2.NumericUpDown2.Value * Math.PI) / 180
        k = -(Form2.NumericUpDown3.Value * Math.PI) / 180
        'Coeficients
        ang(1) = Math.Cos(p) * Math.Cos(k)
        ang(2) = -Math.Cos(p) * Math.Sin(k)
        ang(3) = Math.Sin(p)
        ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
        ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
        ang(6) = -Math.Sin(o) * Math.Cos(p)
        ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
        ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
        ang(9) = Math.Cos(o) * Math.Cos(p)

        'Matriu M
        If Form2.RadioButton1.Checked = True And Form2.CheckBox3.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                'Rotació de vector
                A = ((Vec1 * ang(1)) + (Vec2 * ang(2)) + (Vec3 * ang(3)))
                B = ((Vec1 * ang(4)) + (Vec2 * ang(5)) + (Vec3 * ang(6)))
                C = ((Vec1 * ang(7)) + (Vec2 * ang(8)) + (Vec3 * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xab, "0.0000"), Format(yab, "0.0000"), Format(za, "0.0000"))
            Loop
        End If
        If Form2.RadioButton2.Checked = True And Form2.CheckBox3.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, intena)
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                'Rotació de vector
                A = ((Vec1 * ang(1)) + (Vec2 * ang(2)) + (Vec3 * ang(3)))
                B = ((Vec1 * ang(4)) + (Vec2 * ang(5)) + (Vec3 * ang(6)))
                C = ((Vec1 * ang(7)) + (Vec2 * ang(8)) + (Vec3 * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xab, "0.0000"), Format(yab, "0.0000"), Format(za, "0.0000"), intena)
            Loop
        End If

        If Form2.RadioButton1.Checked = True And Form2.CheckBox3.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, ra)
                Input(1, ga)
                Input(1, va)
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                'Rotació de vector
                A = ((Vec1 * ang(1)) + (Vec2 * ang(2)) + (Vec3 * ang(3)))
                B = ((Vec1 * ang(4)) + (Vec2 * ang(5)) + (Vec3 * ang(6)))
                C = ((Vec1 * ang(7)) + (Vec2 * ang(8)) + (Vec3 * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xab, "0.0000"), Format(yab, "0.0000"), Format(za, "0.0000"), ra, ga, va)
            Loop
        End If
        If Form2.RadioButton1.Checked = True And Form2.CheckBox1.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, vec1a)
                Input(1, vec2a)
                Input(1, vec3a)
                Input(1, a1)
                Input(1, b1)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, numer)
                '***************Inici de Rotació dels centroides****************
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                'Rotació de vector
                A = ((Vec1 * ang(1)) + (Vec2 * ang(2)) + (Vec3 * ang(3)))
                B = ((Vec1 * ang(4)) + (Vec2 * ang(5)) + (Vec3 * ang(6)))
                C = ((Vec1 * ang(7)) + (Vec2 * ang(8)) + (Vec3 * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                '***************Final de Rotació dels centroides****************
                PrintLine(2, Format(xab, "0.0000"), Format(yab, "0.0000"), Format(za, "0.0000"), Format(A, "0.0000"), Format(B, "0.0000"), Format(C, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), numer)
            Loop
        End If
        If Form2.RadioButton2.Checked = True And Form2.CheckBox1.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, vec1a)
                Input(1, vec2a)
                Input(1, vec3a)
                Input(1, a1)
                Input(1, b1)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, numer)
                Input(1, intena)
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                'Rotació de vector
                A = ((vec1a * ang(1)) + (vec2a * ang(2)) + (vec3a * ang(3)))
                B = ((vec1a * ang(4)) + (vec2a * ang(5)) + (vec3a * ang(6)))
                C = ((vec1a * ang(7)) + (vec2a * ang(8)) + (vec3a * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xab, "0.0000"), Format(yab, "0.0000"), Format(zab, "0.0000"), Format(A, "0.0000"), Format(B, "0.0000"), Format(C, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), numer, intena)
            Loop
        End If
        If Form2.RadioButton3.Checked = True And Form2.CheckBox1.Checked = True Then
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, vec1a)
                Input(1, vec2a)
                Input(1, vec3a)
                Input(1, a1)
                Input(1, b1)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, bseleccio)
                Input(1, inten)
                Input(1, ra)
                Input(1, ga)
                Input(1, va)
                'Rotació de vector
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                A = ((vec1a * ang(1)) + (vec2a * ang(2)) + (vec3a * ang(3)))
                B = ((vec1a * ang(4)) + (vec2a * ang(5)) + (vec3a * ang(6)))
                C = ((vec1a * ang(7)) + (vec2a * ang(8)) + (vec3a * ang(9)))
                calculpendent()
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xa, "0.0000"), Format(ya, "0.0000"), Format(za, "0.0000"), Format(A, "0.0000"), Format(B, "0.0000"), Format(C, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), numer, ra, ga, va)
            Loop
        End If
        If Form2.RadioButton2.Checked = True Then
            par8 = LineInput(1)
            PrintLine(2, par8)
            Do While Not EOF(1)
                Input(1, xa)
                Input(1, ya)
                Input(1, za)
                Input(1, vec1a)
                Input(1, vec2a)
                Input(1, vec3a)
                Input(1, a1)
                Input(1, b1)
                Input(1, prop3)
                Input(1, kapa)
                Input(1, par1)
                Input(1, par2)
                Input(1, par3)
                Input(1, par4)
                Input(1, par5)
                Input(1, par6)
                Input(1, par7)
                'Rotació de vector
                xa = xa - Form2.NumericUpDown4.Value
                ya = ya - Form2.NumericUpDown5.Value
                za = za - Form2.NumericUpDown6.Value
                A = ((vec1a * ang(1)) + (vec2a * ang(2)) + (vec3a * ang(3)))
                B = ((vec1a * ang(4)) + (vec2a * ang(5)) + (vec3a * ang(6)))
                C = ((vec1a * ang(7)) + (vec2a * ang(8)) + (vec3a * ang(9)))
                calculpendent()
                If C < 0 Then
                    b1 = b1 * (-1)
                    If a1 >= 180 Then
                        a1 = a1 - 180
                        A = A * (-1)
                        B = B * (-1)
                        C = C * (-1)
                    Else
                        a1 = a1 + 180
                        A = A * (-1)
                        B = B * (-1)
                        C = C * (-1)
                    End If
                End If
                ' final rotacio vector
                xab = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3))) + CSng(Form2.TextBox1.Text)
                yab = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6))) + CSng(Form2.TextBox2.Text)
                zab = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9))) + CSng(Form2.TextBox3.Text)
                xab = xab + Form2.NumericUpDown4.Value
                yab = yab + Form2.NumericUpDown5.Value
                zab = zab + Form2.NumericUpDown6.Value
                PrintLine(2, Format(xa, "0.0000"), Format(ya, "0.0000"), Format(za, "0.0000"), Format(A, "0.0000"), Format(B, "0.0000"), Format(C, "0.0000"), Format(a1, "0.00"), Format(b1, "0.00"), Format(prop3, "0.0000"), Format(kapa, "0.0000"), par1, par2, Format(par3, "0.0000"), Format(par4, "0.0000"), Format(par5, "0.0000"), Format(par6, "0.0000"), par7)
            Loop
        End If
        FileClose(1)
        FileClose(2)
        MsgBox("Rotation completed")
        Exit Sub
ErrorHandler:
    End Sub

    Sub spacing()
        ' Dim i As Integer = 0
        ' Dim opcio As Integer
        ' If CheckBox4.Checked = False And CheckBox5.Checked = False Then opcio = 0
        ' If CheckBox4.Checked = True And CheckBox5.Checked = False Then opcio = 1
        ' If CheckBox4.Checked = False And CheckBox5.Checked = True Then opcio = 2
        ' If seleccionats3.Count > 1 Then
        ' Dim puntintersecx(seleccionats3.Length - 1) As Double
        ' Dim puntintersecy(seleccionats3.Length - 1) As Double
        ' Dim puntintersecz(seleccionats3.Length - 1) As Double
        ' Dim d1, d2, d3 As Double
        ' Dim t As Double
        ' Dim ang, ang2, ang3, ang4 As Double
        ' Dim dist((seleccionats3.Length) - 1) As Double
        ' Dim distr((seleccionats3.Length) - 1) As Double
        ' Dim distr2((seleccionats3.Length) - 1) As Double
        ' Dim ordre((seleccionats3.Length) - 1) As Integer
        ' Select Case opcio
        '     Case 0 'el de cada pla
        ' For i = 0 To seleccionats3.Length - 1
        ' d1 = -(centroidex(seleccionats3(i)) * veci1(seleccionats3(i))) - (centroidey(seleccionats3(i)) * vecj1(seleccionats3(i))) - (centroidez(seleccionats3(i)) * veck1(seleccionats3(i)))
        ' d2 = -(veci1(seleccionats3(i)) * solx((numerofinal(contadorobjectestemporal)) - 1)) - (vecj1(seleccionats3(i)) * soly((numerofinal(contadorobjectestemporal)) - 1)) - (veck1(seleccionats3(i)) * solz((numerofinal(contadorobjectestemporal)) - 1)) - d1
        ' d3 = ((veci1(seleccionats3(i)) * v1) + (vecj1(seleccionats3(i)) * v2) + (veck1(seleccionats3(i)) * v3))
        ' t = d2 / d3
        ' puntintersecx(i) = solx((numerofinal(contadorobjectestemporal)) - 1) + (t * v1)
        ' puntintersecy(i) = soly((numerofinal(contadorobjectestemporal)) - 1) + (t * v2)
        ' puntintersecz(i) = solz((numerofinal(contadorobjectestemporal)) - 1) + (t * v3)
        ' 'i la distància 
        ' dist(i) = Math.Sqrt(Math.Pow(puntintersecx(i) - solx((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecy(i) - soly((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecz(i) - solz((numerofinal(contadorobjectestemporal)) - 1), 2))
        ' ang = Math.Acos(Math.Abs(((v1 * veci1(seleccionats3(i))) + (v2 * vecj1(seleccionats3(i))) + (v3 * veck1(seleccionats3(i)))) / (Math.Sqrt((v1 * v1) + (v2 * v2) + (v3 * v3)) * Math.Sqrt((veci1(seleccionats3(i)) * veci1(seleccionats3(i))) + (vecj1(seleccionats3(i)) * vecj1(seleccionats3(i))) + (veck1(seleccionats3(i)) * veck1(seleccionats3(i)))))))
        ' distr(i) = dist(i) * Math.Cos(ang)
        ' Next
        '     Case 1 'Mean
        ' For i = 0 To seleccionats3.Length - 1
        ' d1 = -(centroidex(seleccionats3(i)) * vec1b) - (centroidey(seleccionats3(i)) * vec2b) - (centroidez(seleccionats3(i)) * vec3b)
        ' d2 = -(vec1b * solx((numerofinal(contadorobjectestemporal)) - 1)) - (vec2b * soly((numerofinal(contadorobjectestemporal)) - 1)) - (vec3b * solz((numerofinal(contadorobjectestemporal)) - 1)) - d1
        ' d3 = ((vec1b * v1) + (vec2b * v2) + (vec3b * v3))
        ' t = d2 / d3
        ' puntintersecx(i) = solx((numerofinal(contadorobjectestemporal)) - 1) + (t * v1)
        ' puntintersecy(i) = soly((numerofinal(contadorobjectestemporal)) - 1) + (t * v2)
        ' puntintersecz(i) = solz((numerofinal(contadorobjectestemporal)) - 1) + (t * v3)
        ' 'i la distància 
        ' dist(i) = Math.Sqrt(Math.Pow(puntintersecx(i) - solx((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecy(i) - soly((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecz(i) - solz((numerofinal(contadorobjectestemporal)) - 1), 2))
        ' ang = Math.Acos(Math.Abs(((v1 * vec1b) + (v2 * vec2b) + (v3 * vec3b)) / (Math.Sqrt((v1 * v1) + (v2 * v2) + (v3 * v3)) * Math.Sqrt((vec1b * vec1b) + (vec2b * vec2b) + (vec3b * vec3b)))))
        ' distr(i) = dist(i) * Math.Cos(ang)
        ' Next
        '     Case 2 'Preferent
        ' For i = 0 To seleccionats3.Length - 1
        ' d1 = -(centroidex(seleccionats3(i)) * Vec1) - (centroidey(seleccionats3(i)) * Vec2) - (centroidez(seleccionats3(i)) * Vec3)
        ' d2 = -(Vec1 * solx((numerofinal(contadorobjectestemporal)) - 1)) - (Vec2 * soly((numerofinal(contadorobjectestemporal)) - 1)) - (Vec3 * solz((numerofinal(contadorobjectestemporal)) - 1)) - d1
        ' d3 = ((Vec1 * v1) + (Vec2 * v2) + (Vec3 * v3))
        ' t = d2 / d3
        ' puntintersecx(i) = solx((numerofinal(contadorobjectestemporal)) - 1) + (t * v1)
        ' puntintersecy(i) = soly((numerofinal(contadorobjectestemporal)) - 1) + (t * v2)
        ' puntintersecz(i) = solz((numerofinal(contadorobjectestemporal)) - 1) + (t * v3)
        ' 'i la distància 
        ' dist(i) = Math.Sqrt(Math.Pow(puntintersecx(i) - solx((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecy(i) - soly((numerofinal(contadorobjectestemporal)) - 1), 2) + Math.Pow(puntintersecz(i) - solz((numerofinal(contadorobjectestemporal)) - 1), 2))
        ' ang = Math.Acos(Math.Abs(((v1 * Vec1) + (v2 * Vec2) + (v3 * Vec3)) / (Math.Sqrt((v1 * v1) + (v2 * v2) + (v3 * v3)) * Math.Sqrt((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))))
        ' distr(i) = dist(i) * Math.Cos(ang)
        ' Next
        ' End Select
        ' ang = Math.Acos(Math.Abs(((v1 * Vec1) + (v2 * Vec2) + (v3 * Vec3)) / (Math.Sqrt((v1 * v1) + (v2 * v2) + (v3 * v3)) * Math.Sqrt((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))))
        ' ang3 = Math.Acos(Math.Abs(((v1 * vec1b) + (v2 * vec2b) + (v3 * vec3b)) / (Math.Sqrt((v1 * v1) + (v2 * v2) + (v3 * v3)) * Math.Sqrt((vec1b * vec1b) + (vec2b * vec2b) + (vec3b * vec3b)))))
        ' ListBox2.Show()
        ' Array.Copy(distr, distr2, distr.Count)
        ' Array.Sort(distr)
        ' 'Per coneixer l'ordre
        ' i = 0
        ' For ii = 0 To (distr.Length - 1)
        ' Do Until distr2(i) = distr(ii)
        ' i += 1
        ' Loop
        ' ordre(ii) = i
        ' i = 0
        ' Next
        ' 'final
        ' Dim distreal(distr.Length - 1) As Double
        ' 'Això és l'espaiament entre els plans
        ' For i = 0 To distr.Length - 2
        ' distreal(i) = distr(i + 1) - distr(i)
        ' Next
        ' 'I fins aqui la distancia entre punts
        ' Label7.Text = Format(distreal.Average, "#.##")
        ' Dim j As Integer = (distreal.Length) - 1
        ' Dim varianza2 As Double
        ' Dim desvstan2 As Double
        ' For i = 0 To j
        ' varianza2 = varianza2 + (Math.Pow((distreal(i) - distreal.Average), 2))
        ' Next
        ' varianza2 = varianza2 / (j + 1)
        ' desvstan2 = Math.Sqrt(varianza2)
        ' Label8.Text = Format(desvstan2, "#.##")
        ' ang2 = (ang * 180) / Math.PI
        ' ang4 = (ang3 * 180) / Math.PI
        ' Label10.Text = Format(ang2, "0.000")
        ' Label5.Text = Format(ang4, "0.000")
        ' ' Crear Fitxer
        ' Dim a As Integer
        ' Dim ara As Integer
        ' If CheckBox6.Checked = True Then
        ' FileOpen(7, My.Computer.FileSystem.CurrentDirectory + "\Workspace\" + "Intensity.txt", OpenMode.Output)
        ' PrintLine(7, "Scanline data")
        ' PrintLine(7, "Coordinates")
        ' PrintLine(7, "Start, X:", solx((numerofinal(contadorobjectestemporal)) - 1), " Y:", soly((numerofinal(contadorobjectestemporal)) - 1), " Z:", solz((numerofinal(contadorobjectestemporal)) - 1))
        ' PrintLine(7, "End, X:", solx(numerofinal(contadorobjectestemporal - 1) + 1), " Y:", soly(numerofinal(contadorobjectestemporal - 1) + 1), "Z:", solz(numerofinal(contadorobjectestemporal - 1) + 1))
        ' PrintLine(7, "s")
        ' PrintLine(7, "Id. Name", "Centroid X", "Centroid y", "Centroid z", "Dip Direction", "Dip", "Coplanariety", "Collinearity", "Number of points", "Trace length", "Set name", "Intersection Point X", "Intersection Point Y", "Intersection Point Z", "Spacing", "Dist. Ap. SL", "Dist. SL")
        ' For i = 0 To seleccionats3.Length - 1
        ' A = Array.IndexOf(ordre, i)
        ' ara = Array.IndexOf(seleccionats3, A)
        ' PrintLine(7, nameobj(seleccionats3(i)), Format(centroidex(seleccionats3(i)), "#.##"), Format(centroidey(seleccionats3(i)), "#.##"), Format(centroidez(seleccionats3(i)), "#.##"), Format(DipDir(seleccionats3(i)), "#.##"), Format(Dip(seleccionats3(i)), "#.##"), Format(M(seleccionats3(i)), "#.##"), Format(K(seleccionats3(i)), "#.##"), popul(seleccionats3(i)), Format(trazelength(seleccionats3(i)), "#.##"), namefamily(seleccionats3(i)), Format(puntintersecx(i), "#.##"), Format(puntintersecy(i), "#.##"), Format(puntintersecz(i), "#.##"), Format(distreal(A), "#.###"), Format(dist(i), "#.###"), Format(distr(i), "#.###"))
        ' Next
        ' FileClose(7)
        ' MsgBox("Spacing Export Process Completed")
        ' End If
        ' Else
        ' Label9.Text = seleccionats3.Length - 1
        ' End If
    End Sub
    Sub JointMU()
        Dim mypath2 As String
        Dim cx, cy, cz As Double
        Dim vx, vy, vz As Double
        Dim dd, dp As Double
        Dim pop, nm As Integer
        Dim dummy As String = ""
        Dim inputRecord As String = 0
        Dim inputRecord2 As String = Nothing
        Dim infoReader As System.IO.FileInfo
        Dim openFileDialog1 As New OpenFileDialog()
        Dim myPoints() As String = Nothing
        Dim LastNonEmpty As Integer = -1
        'Cálculo del plano de las UM
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double
        Dim DMU(numeroMU), iMU(numeroMU), jMU(numeroMU), kMU(numeroMU) As Double
        Dim vdiri(numeroMU), vdirj(numeroMU), vdirk(numeroMU) As Double
        Dim pcex(numeroMU + 1), pcey(numeroMU + 1), pcez(numeroMU + 1) As Double
        pcex(0) = xmu(0)
        pcey(0) = ymu(0)
        pcez(0) = zmu(0)
        For i = 1 To numeroMU + 1
            pcex(i) = xmu(i - 1)
            pcey(i) = ymu(i - 1)
            pcez(i) = zmu(i - 1)
        Next i

        For ii = 0 To numeroMU
            azi = (dipdirmu(ii) * Math.PI) / 180
            di = (dipmu(ii) * Math.PI) / 180
            iMU(ii) = Math.Sin(azi)
            jMU(ii) = Math.Cos(azi)
            kMU(ii) = Math.Sqrt(((iMU(ii) * iMU(ii)) + (jMU(ii) * jMU(ii))) / (Math.Tan(di) * (Math.Tan(di))))
            If kMU(ii) > 100000 Then kMU(ii) = 99999.999999999
            If azi = 0 And di = 0 Then
                iMU(ii) = 0
                jMU(ii) = 0
                kMU(ii) = 0
            End If
            DMU(ii) = -(xmu(ii) * iMU(ii)) - (ymu(ii) * jMU(ii)) - (zmu(ii) * kMU(ii))
            FileOpen((ii + 1), Form10.TextBox1.Text + "M_U_" + CStr(ii) + ".txt", OpenMode.Output)
            'PrintLine(ii + 1, itemordermu(i), dipdirmu(i), dipmu(i), xmu(i), ymu(i), zmu(i), Hzmu(i), Lzmu(i))
        Next
        FileOpen((numeroMU + 2), Form10.TextBox1.Text + "M_U_" + CStr(numeroMU + 1) + ".txt", OpenMode.Output)
        'Fin cálculo del plano
        'apertura de numeroMu de ficheros para crear MU
        'Lectura de ficheros y búsqueda del punto
        Form30.OpenFileDialog1.InitialDirectory = Form10.TextBox1.Text
        Form30.OpenFileDialog1.ShowDialog()
        Dim rfile As String = Nothing
        On Error GoTo Errorhandler
        infoReader = My.Computer.FileSystem.GetFileInfo(Form30.OpenFileDialog1.FileName)
        For Each rfile In Form30.OpenFileDialog1.FileNames
            Dim imReader As StreamReader = File.OpenText(rfile)
            ' inputRecord = imReader.ReadLine() ' Capçalera del total
            While (inputRecord IsNot Nothing)
                inputRecord = imReader.ReadLine()
                inputRecord2 = inputRecord
                If inputRecord.Contains(" ") Then
                    myPoints = inputRecord.Split
                    For ii As Integer = 0 To myPoints.Length - 1
                        If myPoints(ii) <> "" Then
                            LastNonEmpty += 1
                            myPoints(LastNonEmpty) = myPoints(ii)
                        End If
                    Next ii
                End If
                cx = CDbl(myPoints(0).Trim)
                cy = CDbl(myPoints(1).Trim)
                cz = CDbl(myPoints(2).Trim)
                'punto perpendicular entre centroide y plano de MU
                Dim pcx(numeroMU), pcy(numeroMU), pcz(numeroMU) As Double
                Dim bina(numeroMU) As String
                Dim binb(numeroMU) As Integer
                For i = 0 To numeroMU
                    'dista.Add((Math.Abs((Vec1SL * cx1(i)) + (Vec2SL * cy1(i)) + (Vec3SL * cz1(i)) + D1)) / (Math.Sqrt((Math.Pow(Vec1SL, 2)) + (Math.Pow(Vec2SL, 2)) + (Math.Pow(Vec3SL, 2)))))
                    pcx(numeroMU) = cx - iMU(i) * (((iMU(i) * cx) + (jMU(i) * cy) + (kMU(i) * cz) + DMU(i)) / ((Math.Pow(iMU(i), 2) + Math.Pow(jMU(i), 2) + Math.Pow(kMU(i), 2))))
                    pcy(numeroMU) = cy - jMU(i) * (((iMU(i) * cx) + (jMU(i) * cy) + (kMU(i) * cz) + DMU(i)) / ((Math.Pow(iMU(i), 2) + Math.Pow(jMU(i), 2) + Math.Pow(kMU(i), 2))))
                    pcz(numeroMU) = cz - kMU(i) * (((iMU(i) * cx) + (jMU(i) * cy) + (kMU(i) * cz) + DMU(i)) / ((Math.Pow(iMU(i), 2) + Math.Pow(jMU(i), 2) + Math.Pow(kMU(i), 2))))
                    'Cálculo vector entre centroide y punto del plano más cercano

                    vdiri(i) = cx - pcx(numeroMU)
                    Select Case vdiri(i)
                        Case Is >= 0
                            vdiri(i) = 1
                        Case Else
                            vdiri(i) = 0
                    End Select
                    vdirj(i) = cy - pcy(numeroMU)
                    Select Case vdirj(i)
                        Case Is >= 0
                            vdirj(i) = 1
                        Case Else
                            vdirj(i) = 0
                    End Select
                    vdirk(i) = cz - pcz(numeroMU)
                    Select Case vdirk(i)
                        Case Is >= 0
                            vdirk(i) = 1
                        Case Else
                            vdirk(i) = 0
                    End Select
                    'Limite arriba 1, limite abajo 0
                    bina(i) = "0" + CStr(vdiri(i)) + CStr(vdirj(i)) + CStr(vdirk(i))
                    Dim va, vt As Integer
                    va = Val(Right(bina(i), 1))
                    vt = va * 1
                    bina(i) = Left(bina(i), 3)
                    va = Val(Right(bina(i), 1))
                    vt = vt + (va * 2)
                    bina(i) = Left(bina(i), 2)
                    va = Val(Right(bina(i), 1))
                    vt = vt + (va * 4)
                    Select Case vt
                        Case Is < 4
                            vt = 0
                        Case Is > 3
                            vt = 1
                    End Select
                    binb(i) = vt
                    vt = 0
                Next i
                'Comprovacio de distància i impressió
                Dim dis As Double
                dis = Math.Sqrt(Math.Pow((pcex(binb.Sum) - cx), 2) + Math.Pow((pcey(binb.Sum) - cy), 2) + Math.Pow((pcez(binb.Sum) - cz), 2))
                   Select dis
                    Case Is <= TotalHorExt(binb.Sum)
                        PrintLine(binb.Sum + 1, inputRecord2)
                    Case Else
                End Select
                LastNonEmpty = -1
            End While
        Next rfile
Errorhandler:
        Exit Sub
        For ii = 0 To numeroMU
            FileClose(ii + 1)
        Next
        FileClose(numeroMU + 2)
    End Sub
End Module
