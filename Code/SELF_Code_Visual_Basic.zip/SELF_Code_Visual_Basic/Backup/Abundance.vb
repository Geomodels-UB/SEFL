﻿Imports Microsoft.Office.Interop.Excel
Imports Microsoft.Office.Interop

Module Abundance
    Public Set1a As New List(Of String)
    Public indice As Integer
    Public vectorSLx(), VectorSLy(), VectorSLz() As Double
    Public dipfunc2, dirfunc2 As Double
    Public Vec1SL, Vec2SL, Vec3SL As Double
    Public Hei() As Double, ext() As Double, are() As Double
    Public xmean1() As Double, ymean1() As Double, zmean1() As Double   ' Centre de SL
    Public xcmean1() As Double, ycmean1() As Double, zcmean1() As Double ' Centroide de la M.U
    Public SLvec1() As Double, SLvec2() As Double, SLvec3() As Double
    Public vecSL1() As Double, vecSL2() As Double, vecSL3() As Double
    Public puntintersecx() As Double, puntintersecy() As Double, puntintersecz() As Double
    Public Puntx() As Double, Punty() As Double, Puntz() As Double
    Public puntintersecxupp() As Double, puntintersecyupp() As Double, puntinterseczupp() As Double
    Public puntintersecxlow() As Double, puntintersecylow() As Double, puntinterseczlow() As Double
    Public Dsl(), Dslupp(), Dsllow() As Double
    Public M(), K(), Roughness(), Height(), Wid(), Ar() As Double
    Public Populat(), Nume(), MechanicalUnity() As Integer
    Public includedSL() As Boolean
    Public FracturSet() As String
    Dim seleccio(,) As Integer
    Public seleccioupp(,) As Integer
    Public selecciolow(,) As Integer
    Public mucount As Integer
    Public numfrac0 As Integer
    Public selfinal(,,) As Integer ' selfinal(mu,fractureSet,index)
    Public name() As String
    Public numse As Integer
    Public Pintx, Pinty, Pintz As New List(Of Double)
    Public Prectax, Prectay, Prectaz As New List(Of Double)
    Public t1 As New List(Of Double)
    Public Settotal() As String
    Public ttotal() As Double
    Public PosRecbySL() As Integer
    Public nf As Integer
    Dim nufrac() As Integer
    Dim posrec() As Double
    Dim FracBySL As Integer
    Dim altUM As Double
    Dim extUM As Double
    Dim areUM As Double
    Public jk As Integer = 0
    Public jp As String
    Dim oExcel As Excel.Application
    Dim oBook As Excel.Workbook
    Dim oSheet As Excel.Worksheet
    Dim colIndex As Integer = 0
    Dim rowindex As Integer = 0
    Dim contset As Integer = 0
    Dim impfrac() As Boolean
    Dim numsets1() As String
    Dim nufrac1() As Integer
    Dim nufrac2() As Integer
    Dim sumats() As Double
    Dim contval As Integer = -1
    Dim orienSL() As Double
    Dim pendSL() As Double
    Dim P22Area(,) As Double
    Dim P22Set(,) As String
    Dim nfp22 As Integer
    Dim areatotalUM() As Double
    Dim finalpath1 As String
    Dim finalpath2 As String
    Dim mu As Integer = -1
    ' Dim numsheet As String
    Public Set2a As New List(Of String)
    Public useful As New List(Of String)
    Public utils As Integer = 0
    Dim espai() As Integer
    Dim chivato As Boolean
    Dim rfile2 As String
    Public openFileDialog4 As New OpenFileDialog()
    Public numsets As IEnumerable(Of String)
    Public direccioMorpho As String
    Public direccioPropert As String
    Dim valori, valorj, valork As Double
    Dim C13 As Double
    Dim C23 As Double
    Dim vxwell(), vywell(), vzwell() As Double
    Dim pwellx, pwelly, pwellz As Double
    Dim twell As New List(Of Double)
    Dim twell1 As New List(Of Double)
    Dim pwx, pwy, pwz, well As New List(Of Double)
    Dim setw As New List(Of String)
    Dim sumatoritotal() As Double
    Dim RQD() As Double
    Dim FracIndex() As Integer
    Dim log(,) As Double
    Dim Setlog(,) As String
    Dim fractura As Integer
    Sub ScanlinefromMorphology()
        Dim contadorSet As Integer = 0
        Dim mummy1 As Double
        Dim mummy2 As Integer
        Dim mummy As String
        Dim setname(0) As String
        Dim num As Integer = 0
        Dim i As Integer = 0
        Dim ii As Integer = 0
        Dim n As Integer = -1
        Dim openFileDialog1 As New OpenFileDialog()
        '  openFileDialog2.Multiselect = True
        '******Fi dimensionament*********
        FileOpen(3, Form10.TextBox1.Text + "ScanLines_MU.txt", OpenMode.Output)
        '******obrir fitxer projeccio**************
        ' openFileDialog2.Title = "Calculate SpaceLine From Morphology File"
        ' openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        ' openFileDialog2.ShowDialog()
        For Each rfile2 In openFileDialog4.FileNames
            'obre el fitxer de morphology i ho afegeix a list of T
            FileOpen(2, rfile2, OpenMode.Input)
            cx1.Clear()
            cy1.Clear()
            cz1.Clear()
            vx1.Clear()
            vy1.Clear()
            vz1.Clear()
            dipdir1.Clear()
            dip1.Clear()
            M1.Clear()
            K1.Clear()
            Population1.Clear()
            Number1.Clear()
            Rugosity1.Clear()
            Wide1.Clear()
            Long1.Clear()
            Area1.Clear()
            Set1a.Clear()
            Set2a.Clear()
            useful.Clear()
            xmean = 0
            ymean = 0
            zmean = 0
            On Error GoTo ErrorHandler
            mummy = LineInput(2)
            Do While Not EOF(2)
                Input(2, mummy1)
                cx1.Add(mummy1)
                Input(2, mummy1)
                cy1.Add(mummy1)
                Input(2, mummy1)
                cz1.Add(mummy1)
                Input(2, mummy1)
                vx1.Add(mummy1)
                Input(2, mummy1)
                vy1.Add(mummy1)
                Input(2, mummy1)
                vz1.Add(mummy1)
                Input(2, mummy1)
                dipdir1.Add(mummy1)
                Input(2, mummy1)
                dip1.Add(mummy1)
                Input(2, mummy1)
                M1.Add(mummy1)
                Input(2, mummy1)
                K1.Add(mummy1)
                Input(2, mummy2)
                Population1.Add(mummy2)
                Input(2, mummy2)
                Number1.Add(mummy2)
                Input(2, mummy1)
                Rugosity1.Add(mummy1)
                Input(2, mummy1)
                Wide1.Add(mummy1)
                Input(2, mummy1)
                Long1.Add(mummy1)
                Input(2, mummy1)
                Area1.Add(mummy1)
                Input(2, mummy)
                Set1a.Add(mummy)
                Set2a.Add(mummy)
                If Area1.Item(Area1.Count - 1) > Form28.NumericUpDown3.Value Then
                    useful.Add(True)
                    utils += 1
                Else
                    useful.Add(False)
                End If
            Loop
            FileClose(2)
            ' Càlcul número de fractures per MU i per Set
            Set2a.Sort()
            ' Dim numsets As IEnumerable(Of String) = Set2a.Distinct()
            ' numse = numsets.Count
            ReDim nufrac(numse - 1)
            ReDim nufrac2(numse - 1)
            For im = 0 To numsets.Count - 1
                For count = 0 To Set2a.Count - 1 'afegit 30-10-14
                    If Set2a.Item(count) = numsets(im) Then 'afegit 30-10-14
                        nufrac(im) += 1
                    End If
                Next
            Next
            ' Càlcul suma de longituts per MU i per Set
            Dim sumat(numsets.Count - 1) As Double
            For im = 0 To numsets.Count - 1
                For count = 0 To Set1a.Count - 1
                    If Set1a.Item(count) = numsets(im) Then
                        sumat(im) = Long1.Item(count) + sumat(im)
                        If useful.Item(count) = True Then nufrac2(im) += 1
                    End If
                Next
            Next
            'nom del fitxer
            Dim Position1a As Integer
            Dim Position2a As Integer
            Dim nom As String
            Position1a = InStrRev(rfile2, "\")
            Position2a = InStrRev(rfile2, ".")
            nom = rfile2.Substring(Position1a, ((Position2a - 1) - Position1a))
            ' fisherBingham test per l'orientació de l'aflorament
            Dim dif As Double
            Dim dif1 As Double
            For i = 0 To dipdir1.Count - 1
                dif = Math.Abs(dipdir1(i) - 360)
                dif1 = dipdir1(0) - dif
                If dif1 > 100 Then bipolar = True
            Next
            'End Fisher Bingham Test
            'Calcul de la orientació
            Select Case bipolar
                Case True
                    vectorsperpendicular() ' Principal Mean direction
                Case False
                    meandirectionsperpendicular() ' Mean Direction
            End Select
            ' input cx1,cy1,cz1,Càlcul de la posició mitja dels centroids (xmean, ymean,zmean)
            puntmitja()
            'lectura del bedding
            Vec1SL = Form28.TextBox1.Text
            Vec2SL = Form28.TextBox2.Text
            Vec3SL = Form28.TextBox3.Text
            Dim minim(2) As Double
            calculateDipdir(Vec1, Vec2, Vec3)
            orienpla1 = dirfunc
            pendpla1 = dipfunc
            'Calcul de l'amplada per coordenades en funció de la orientació del bedding
            Dim difmu As Double
            minim(0) = cx1.Max - cx1.Min
            minim(1) = cy1.Max - cy1.Min
            minim(2) = cz1.Max - cz1.Min
            ReDim puntcontactex(vx1.Count - 1)
            ReDim puntcontactey(vx1.Count - 1)
            ReDim puntcontactez(vx1.Count - 1)
            Dim D1 As Double
            Dim D2 As Double
            ' Dim vosx As Double = 0
            ' Dim vosy As Double = 0
            Dim vosz As Double = 0
            Dim dista As New List(Of Double)
            '  Dim distaOut As New List(Of Double)
            Dim upper As Double = 0
            Dim lower As Double = 0
            Dim indiupper As Integer = 0
            Dim indilower As Integer = 0
            Dim escollit As Double
            ' Es calcula la distancia al pla per saber el gruix
            dista.Clear()
            D1 = -(Vec1SL * xmean) - (Vec2SL * ymean) - (Vec3SL * zmean) 'bedding
            D2 = -(Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean) 'outcrop
            For i = 0 To cx1.Count - 1
                dista.Add((Math.Abs((Vec1SL * cx1(i)) + (Vec2SL * cy1(i)) + (Vec3SL * cz1(i)) + D1)) / (Math.Sqrt((Math.Pow(Vec1SL, 2)) + (Math.Pow(Vec2SL, 2)) + (Math.Pow(Vec3SL, 2)))))
                puntcontactex(i) = cx1(i) - Vec1SL * (((Vec1SL * cx1(i)) + (Vec2SL * cy1(i)) + (Vec3SL * cz1(i)) + D1) / ((Math.Pow(Vec1SL, 2) + Math.Pow(Vec2SL, 2) + Math.Pow(Vec3SL, 2))))
                puntcontactey(i) = cy1(i) - Vec2SL * (((Vec1SL * cx1(i)) + (Vec2SL * cy1(i)) + (Vec3SL * cz1(i)) + D1) / ((Math.Pow(Vec1SL, 2) + Math.Pow(Vec2SL, 2) + Math.Pow(Vec3SL, 2))))
                puntcontactez(i) = cz1(i) - Vec3SL * (((Vec1SL * cx1(i)) + (Vec2SL * cy1(i)) + (Vec3SL * cz1(i)) + D1) / ((Math.Pow(Vec1SL, 2) + Math.Pow(Vec2SL, 2) + Math.Pow(Vec3SL, 2))))
                '  vosx = puntcontactex(i) - cx1(i)
                '  vosy = puntcontactey(i) - cy1(i)
                vosz = puntcontactez(i) - cz1(i)
                ' Falta l'exepcio d3 dip=90
                Select Case vosz
                    Case Is > 0
                        If vosz > upper Then
                            upper = vosz
                            indiupper = i
                        End If
                    Case Is < 0
                        If vosz < lower Then
                            lower = vosz
                            indilower = i
                        End If
                End Select
            Next
            Dim widex As Double
            Dim widey As Double
            Dim widez As Double
            Array.Sort(minim)
            Dim xupper As Double
            Dim xlower As Double
            Dim yupper As Double
            Dim ylower As Double
            Dim zupper As Double
            Dim zlower As Double
            Dim diupper As Double
            Dim dilower As Double
            'Calcul de la distancia entre sostre i base
            xlower = cx1(indilower) : ylower = cy1(indilower) : zlower = cz1(indilower)
            'Distancia entre en punt mig xmean al sostre i a la base
            D2 = -(Vec1SL * cx1(indiupper)) - (Vec2SL * cy1(indiupper)) - (Vec3SL * cz1(indiupper))
            diupper = ((Math.Abs((Vec1SL * puntcontactex(indiupper)) + (Vec2SL * puntcontactey(indiupper)) + (Vec3SL * puntcontactez(indiupper)) + D2)) / (Math.Sqrt((Math.Pow(Vec1SL, 2)) + (Math.Pow(Vec2SL, 2)) + (Math.Pow(Vec3SL, 2)))))
            D2 = -(Vec1SL * xlower) - (Vec2SL * ylower) - (Vec3SL * zlower)
            dilower = ((Math.Abs((Vec1SL * puntcontactex(indilower)) + (Vec2SL * puntcontactey(indilower)) + (Vec3SL * puntcontactez(indilower)) + D2)) / (Math.Sqrt((Math.Pow(Vec1SL, 2)) + (Math.Pow(Vec2SL, 2)) + (Math.Pow(Vec3SL, 2)))))
            widex = diupper + dilower
            'i per l'extensió.
            Dim dilow As Double = 0
            ' dilow = Math.Sqrt((Math.Pow(minim(2), 2)) + (Math.Pow(minim(1), 1)))
            dilow = Math.Sqrt(Math.Pow((cx1.Max - cx1.Min), 2) + Math.Pow((cy1.Max - cy1.Min), 2) + Math.Pow((cz1.Max - cz1.Min), 2))
            widey = dilow * widex
            'impressio
            bipolar = False
            PrintLine(3, nom)
            PrintLine(3, "Outcrop orientation")
            PrintLine(3, Format(Vec1, "0.000"), Format(Vec2, "0.000"), Format(Vec3, "0.000"), Format(xmean, "0.000"), Format(ymean, "0.000"), Format(zmean, "0.000"))
            PrintLine(3, "ScanLine")
            PrintLine(3, Format(Vec1SL, "0.000"), Format(Vec2SL, "0.000"), Format(Vec3SL, "0.000"), Format(xmean, "0.000"), Format(ymean, "0.000"), Format(zmean, "0.000"))
            PrintLine(3, "SL(Upper)")
            PrintLine(3, Format(Vec1SL, "0.000"), Format(Vec2SL, "0.000"), Format(Vec3SL, "0.000"), Format(cx1(indiupper), "0.000"), Format(cy1(indiupper), "0.000"), Format(cz1(indiupper), "0.000"))
            PrintLine(3, "SL(Lower)")
            PrintLine(3, Format(Vec1SL, "0.000"), Format(Vec2SL, "0.000"), Format(Vec3SL, "0.000"), Format(xlower, "0.000"), Format(ylower, "0.000"), Format(zlower, "0.000"))
            PrintLine(3, "Height")
            PrintLine(3, Format(widex, "0.000"))
            PrintLine(3, "Extension")
            PrintLine(3, Format(dilow, "0.000"))
            PrintLine(3, "Area")
            PrintLine(3, Format(widey, "0.000"))
            PrintLine(3, nufrac.Count)
            For im = 0 To nufrac.Count - 1
                PrintLine(3, numsets(im))
                PrintLine(3, nufrac(im), nufrac2(im), sumat(im))
            Next
            Set2a.Clear()
            PrintLine(3, "           ")
            Array.Resize(puntcontactex, Nothing)
            Array.Resize(puntcontactey, Nothing)
            Array.Resize(puntcontactez, Nothing)
        Next (rfile2)
        FileClose(3)
        openFileDialog4.Multiselect = False
        Form28.TextBox6.Text = Form10.TextBox1.Text + "ScanLines_MU.txt"
        Form28.Button3.Enabled = True
        MsgBox("Properties Calculated")
        Exit Sub
ErrorHandler:
    End Sub
    Sub vectorsperpendicular()
        '***variables necessàries per al càlcul dels moments d'inèrcia***
        Dim i As Integer
        Dim sumx As Double, sumy As Double, sumz As Double
        'Dim xmean As Double, ymean As Double, zmean As Double
        Dim sumyz As Double, sumxz As Double, sumxy As Double
        Dim sumxsq As Double, sumysq As Double, sumzsq As Double
        Dim summodpt As Double
        Dim modpt As Double
        Dim c As Double

        'Dim xmp As Double, ymp As Double, zmp As Double
        'Dim l As Double, m As Double
        'Dim modul As Double
        'Dim a1 As Double, B1 As Double
        sumx = 0 : sumy = 0 : sumz = 0
        '***calculem sumatoris***


        '***calculem promitjos***
        'xmean = vx1.Average
        'ymean = vy1.Average
        'zmean = vz1.Average

        sumyz = 0 : sumxz = 0 : sumxy = 0
        sumxsq = 0 : sumysq = 0 : sumzsq = 0
        summodpt = 0

        '***calculem sumatoris***
        For i = 1 To vx1.Count - 1
            ' di = escollits(i)
            sumyz = sumyz + ((vy1(i)) - vy1.Average) * ((vz1(i)) - vz1.Average)
            sumxz = sumxz + ((vx1(i)) - vx1.Average) * ((vz1(i)) - vz1.Average)
            sumxy = sumxy + ((vx1(i)) - vx1.Average) * ((vy1(i)) - vy1.Average)

            sumxsq = sumxsq + Math.Pow(((vx1(i)) - vx1.Average), 2)
            sumysq = sumysq + Math.Pow(((vy1(i)) - vy1.Average), 2)
            sumzsq = sumzsq + Math.Pow(((vz1(i)) - vz1.Average), 2)

            '***aquest es pels eigenvalues***
            '***calculo l'arrel del modul xq vull el sumatori dls quadrats dls moduls***
            modpt = Math.Pow((vx1(i) - vx1.Average), 2) + Math.Pow((vy1(i) - vy1.Average), 2) + Math.Pow((vz1(i) - vz1.Average), 2)
            summodpt = summodpt + modpt
        Next i
        '***Ara ve el càlcul***

        Dim n As Integer = 3
        Dim a(3, 3) As Double
        Dim d(3) As Double
        Dim V(3, 3) As Double
        Dim b(3) As Double
        Dim zz(3) As Double
        Dim sm As Double, g As Double, h As Double, s As Double, t As Double, p As Double
        'redim c As Double
        Dim tau As Double, tresh As Double, theta As Double
        Dim Nrot As Integer
        'redim i As Integer
        Dim j As Integer, k As Integer
        Dim ip As Integer, iq As Integer
        Dim prop4 As String

        a(1, 1) = sumxsq
        a(2, 2) = sumysq
        a(3, 3) = sumzsq
        a(1, 2) = sumxy
        a(2, 1) = sumxy
        a(1, 3) = sumxz
        a(3, 1) = sumxz
        a(2, 3) = sumyz
        a(3, 2) = sumyz


        For ip = 1 To n
            For iq = 1 To n
                V(ip, iq) = 0
            Next iq
            V(ip, ip) = 1
        Next ip
        For ip = 1 To n
            b(ip) = a(ip, ip)
            d(ip) = b(ip)
            zz(ip) = 0
        Next ip
        Nrot = 0
        For i = 1 To 50
            sm = 0
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    sm = sm + Math.Abs(a(ip, iq))
                Next iq
            Next ip
            If sm = 0 Then GoTo LINE123
            If i < 4 Then
                tresh = 0.2 * sm / n ^ 2
            Else
                tresh = 0
            End If
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    g = 100 * Math.Abs(a(ip, iq))
                    If i > 4 And (Math.Abs(d(ip)) + g) = Math.Abs(d(ip)) And (Math.Abs(d(iq)) + g) = Math.Abs(d(iq)) Then
                        a(ip, iq) = 0
                    ElseIf Math.Abs(a(ip, iq)) > tresh Then
                        h = d(iq) - d(ip)
                        If (Math.Abs(h) + g) = Math.Abs(h) Then
                            t = a(ip, iq) / h
                        Else
                            theta = 0.5 * h / a(ip, iq)
                            t = 1 / (Math.Abs(theta) + Math.Sqrt(1 + theta ^ 2))
                            If theta < 0 Then t = -t
                        End If
                        c = 1 / Math.Sqrt(1 + Math.Pow(t, 2))
                        s = t * c
                        tau = s / (1 + c)
                        h = t * a(ip, iq)
                        zz(ip) = zz(ip) - h
                        zz(iq) = zz(iq) + h
                        d(ip) = d(ip) - h
                        d(iq) = d(iq) + h
                        a(ip, iq) = 0
                        For j = 1 To (ip - 1)
                            g = a(j, ip)
                            h = a(j, iq)
                            a(j, ip) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (ip + 1) To (iq - 1)
                            g = a(ip, j)
                            h = a(j, iq)
                            a(ip, j) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (iq + 1) To n
                            g = a(ip, j)
                            h = a(iq, j)
                            a(ip, j) = g - s * (h + g * tau)
                            a(iq, j) = h + s * (g - h * tau)
                        Next j
                        For j = 1 To n
                            g = V(j, ip)
                            h = V(j, iq)
                            V(j, ip) = g - s * (h + g * tau)
                            V(j, iq) = h + s * (g - h * tau)
                        Next j
                        Nrot = Nrot + 1
                    End If
                Next iq
            Next ip
            For ip = 1 To n
                b(ip) = b(ip) + zz(ip)
                d(ip) = b(ip)
                zz(ip) = 0
            Next ip
        Next i

        'ret = MbeMessageBox("50 iterations overpassed", 2048)

LINE123:

        '***ara ordenem***

        For i = 1 To n - 1
            k = i
            p = d(i)
            For j = i + 1 To n
                If d(j) > p Then
                    k = j
                    p = d(j)
                End If
            Next j
            If k <> i Then
                d(k) = d(i)
                d(i) = p
                For j = 1 To n
                    p = V(j, i)
                    V(j, i) = V(j, k)
                    V(j, k) = p
                Next j
            End If
        Next i

        '***parem si la matriu d'eigenvectors és la identitat (per exemple si mesurem cabussament d'isolínies)***
        'If V(1, 1) = 0 And V(2, 2) = 0 And V(3, 3) = 0 Then
        'ret = MbeMessageBox("Solution not possible with current eigenvector algorithm", 2048)
        '    Exit Sub
        'End If

        'Dim ll As Double, mm As Double, nn As Double
        'Dim B1 As Double, a1 As Double

        '***volem el vector 3 (criteri Woodcock (1977))***
        '***redrecem el vector per a què pugi***
        Dim prop1 As Double, prop2 As Double
        If V(3, 3) < 0 Then
            AA = -V(1, 3)
            BB = -V(2, 3)
            CC = -V(3, 3)
        Else
            AA = V(1, 3)
            BB = V(2, 3)
            CC = V(3, 3)
        End If
        'afegit
        If V(3, 3) < 0 Then
            Vec1 = -V(1, 1)
            Vec2 = -V(2, 1)
            Vec3 = -V(3, 1)
        Else
            Vec1 = V(1, 1)
            Vec2 = V(2, 1)
            Vec3 = V(3, 1)
        End If
        'afegit



        prop1 = Math.Log(d(1) / d(2))
        prop2 = Math.Log(d(2) / d(3))
        prop3 = Math.Log(d(1) / d(3)) 'Aixo es la M
        If AA = 0 And BB = 1 And CC = 0 Then prop3 = 10
        If AA = 0 And BB = 0 And CC = 1 Then prop3 = 10
        If AA = 1 And BB = 0 And CC = 0 Then prop3 = 10
        prop4 = Str(prop3)
        If prop4 = "Infinito" Then prop3 = 1035
        kapa = prop1 / prop2  ' Això es la K
    End Sub
    Sub meandirectionsperpendicular()
        Vec1b = 0
        Vec2b = 0
        Vec3b = 0
        Dim unitari As Double
        unitari = Math.Sqrt(Math.Pow(vx1.Sum, 2) + Math.Pow(vy1.Sum, 2) + Math.Pow(vz1.Sum, 2))
        Vec1 = vx1.Sum / unitari
        Vec2 = vy1.Sum / unitari
        Vec3 = vz1.Sum / unitari
    End Sub
    Sub areaUM()
        Dim rfile2 As String
        Dim contadorSet As Integer = 0
        Dim mummy1 As Double
        Dim mummy2 As Integer
        Dim mummy As String
        Dim setname(0) As String
        Dim num As Integer = 0
        Dim i As Integer = 0
        Dim ii As Integer = 0
        Dim n As Integer = -1
        Dim openFileDialog1 As New OpenFileDialog()
        Dim openFileDialog2 As New OpenFileDialog()
        openFileDialog2.Multiselect = True
        '******Fi dimensionament*********
        FileOpen(3, Form10.TextBox1.Text + "Area_MU.txt", OpenMode.Output)
        '******obrir fitxer projeccio**************
        openFileDialog2.Title = "Calculate Area From Morphology File"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        For Each rfile2 In openFileDialog2.FileNames
            FileOpen(2, rfile2, OpenMode.Input)
            cx1.Clear()
            cy1.Clear()
            cz1.Clear()
            vx1.Clear()
            vy1.Clear()
            vz1.Clear()
            dipdir1.Clear()
            dip1.Clear()
            M1.Clear()
            K1.Clear()
            Population1.Clear()
            Number1.Clear()
            Rugosity1.Clear()
            Wide1.Clear()
            Long1.Clear()
            Area1.Clear()
            Set1a.Clear()
            xmean = 0
            ymean = 0
            zmean = 0
            On Error GoTo ErrorHandler
            mummy = LineInput(2)
            Do While Not EOF(2)
                Input(2, mummy1)
                cx1.Add(mummy1)
                Input(2, mummy1)
                cy1.Add(mummy1)
                Input(2, mummy1)
                cz1.Add(mummy1)
                Input(2, mummy1)
                vx1.Add(mummy1)
                Input(2, mummy1)
                vy1.Add(mummy1)
                Input(2, mummy1)
                vz1.Add(mummy1)
                Input(2, mummy1)
                dipdir1.Add(mummy1)
                Input(2, mummy1)
                dip1.Add(mummy1)
                Input(2, mummy1)
                M1.Add(mummy1)
                Input(2, mummy1)
                K1.Add(mummy1)
                Input(2, mummy2)
                Population1.Add(mummy2)
                Input(2, mummy2)
                Number1.Add(mummy2)
                Input(2, mummy1)
                Rugosity1.Add(mummy1)
                Input(2, mummy1)
                Wide1.Add(mummy1)
                Input(2, mummy1)
                Long1.Add(mummy1)
                Input(2, mummy1)
                Area1.Add(mummy1)
                Input(2, mummy)
                Set1a.Add(mummy)
            Loop
            ReDim Preserve puntcontactex(vx1.Count - 1)
            ReDim Preserve puntcontactey(vx1.Count - 1)
            ReDim Preserve puntcontactez(vx1.Count - 1)
            FileClose(2)
            'nom del filtxer
            Dim Position1a As Integer
            Dim Position2a As Integer
            Dim setnumer2 As String
            Dim nom As String
            Position1a = InStrRev(rfile2, "\")
            Position2a = InStrRev(rfile2, ".")
            nom = rfile2.Substring(Position1a, ((Position2a - 1) - Position1a))
            '
            ' fisherBingham test
            Dim dif As Double
            Dim dif1 As Double
            For i = 0 To dipdir1.Count - 1
                dif = Math.Abs(dipdir1(i) - 360)
                dif1 = dipdir1(0) - dif
                If dif1 > 100 Then bipolar = True
            Next
            'End Fisher Bingham Test

            Select Case bipolar
                Case True
                    vectorsperpendicular() ' Principal Mean direction
                Case False
                    meandirectionsperpendicular() ' Mean Direction
            End Select
            'calcul de la mitja preferent. Input vx1(selection), vy1(selection), vz1(selection) output vec1,vec2,vec3
            puntmitja() ' input cx1,cy1,cz1,selection.lenght, output xmean, ymean, zmean
            calculateDipdir(Vec1, Vec2, Vec3)
            orienpla1 = dirfunc
            pendpla1 = dipfunc
            ProjCentrPLa()
            rotationAbun()
            'vectorlineas()
            'plans()
            PrintLine(3, nom)
            areadensabun()
            PrintLine(3, "")
            area3()
        Next (rfile2)
        FileClose(3)
        openFileDialog2.Multiselect = False
        Exit Sub
ErrorHandler:
    End Sub
    Sub rotationAbun()
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        Dim xa, ya, za As Double
        o = 0
        p = 0
        k = -(((180 - orienpla1) * Math.PI) / 180)

        ReDim Preserve puntcontactexr(vx1.Count - 1)
        ReDim Preserve puntcontacteyr(vy1.Count - 1)
        ReDim Preserve puntcontactezr(vz1.Count - 1)
        'Coeficients
        ang(1) = Math.Cos(p) * Math.Cos(k)
        ang(2) = -Math.Cos(p) * Math.Sin(k)
        ang(3) = Math.Sin(p)
        ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
        ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
        ang(6) = -Math.Sin(o) * Math.Cos(p)
        ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
        ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
        ang(9) = Math.Cos(o) * Math.Cos(p)

        'Matriu M
        For i = 0 To vx1.Count - 1
            xa = puntcontactex(i) - puntcontactex.Average
            ya = puntcontactey(i) - puntcontactey.Average
            za = puntcontactez(i) - puntcontactez.Average
            puntcontactexr(i) = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3)))
            puntcontacteyr(i) = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6)))
            puntcontactezr(i) = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9)))
            'PrintLine(3, Format(puntcontactex(i), "0.00"), Format(puntcontactey(i), "0.00"), Format(puntcontactez(i), "0.00"))
            'PrintLine(3, Format(puntcontactexr(selection(i)), "0.00"), Format(puntcontacteyr(selection(i)), "0.00"), Format(puntcontactezr(selection(i)), "0.00"))

        Next
        o = (((180 - pendpla1) * Math.PI) / 180)
        p = 0
        k = 0

        'Coeficients
        ang(1) = Math.Cos(p) * Math.Cos(k)
        ang(2) = -Math.Cos(p) * Math.Sin(k)
        ang(3) = Math.Sin(p)
        ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
        ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
        ang(6) = -Math.Sin(o) * Math.Cos(p)
        ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
        ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
        ang(9) = Math.Cos(o) * Math.Cos(p)

        'Matriu M
        For i = 0 To vx1.Count - 1
            xa = puntcontactexr(i)
            ya = puntcontacteyr(i)
            za = puntcontactezr(i)
            puntcontactexr(i) = ((xa * ang(1)) + (ya * ang(2)) + (za * ang(3)))
            puntcontacteyr(i) = ((xa * ang(4)) + (ya * ang(5)) + (za * ang(6)))
            puntcontactezr(i) = ((xa * ang(7)) + (ya * ang(8)) + (za * ang(9)))
            puntcontactexr(i) = puntcontactexr(i) + puntcontactex.Average
            puntcontacteyr(i) = puntcontacteyr(i) + puntcontactey.Average
            puntcontactezr(i) = puntcontactezr(i) + puntcontactez.Average
            ' PrintLine(3, puntcontactexr(i), puntcontacteyr(i), puntcontactezr(i))
        Next
    End Sub
    Sub areadensabun()
        Dim radio As Double
        Dim Px1, Px2, Px3, Psx1 As Double
        Dim Py1, Py2, Py3, Psy1 As Double
        Dim areatotal As Double
        Dim dist1b(2) As Double
        Dim puntescollit As Double
        Dim dist1(2) As Double
        areatotal = 0
        Dim valora As Integer
        Dim valorb As Integer
        Dim vecareai(), vecareaj(), vecareak() As Double
        Dim aziarea() As Double
        Dim aziarea2() As Double
        ReDim Preserve vecareai(vx1.Count - 1)
        ReDim Preserve vecareaj(vx1.Count - 1)
        ReDim Preserve vecareak(vx1.Count - 1)
        ReDim Preserve aziarea(vx1.Count - 1)
        ReDim Preserve aziarea2(vx1.Count - 1)
        'calcular la orientacio de cada punten relació a la xmean
        '  rotationAbun()
        For i = 0 To vx1.Count - 1
            Vec1 = puntcontactexr.Average - puntcontactexr(i) ' -
            Vec2 = puntcontacteyr.Average - puntcontacteyr(i) '- 
            Vec3 = puntcontactezr.Average - puntcontactezr(i) '- 
            Vec3 = 0
            calculateDipdir(Vec1, Vec2, Vec3)
            aziarea(i) = dirfunc
        Next
        Array.Copy(aziarea, aziarea2, aziarea.Length)
        Array.Sort(aziarea2)
        Dim areatotal1 As Double
        For i = 1 To vx1.Count - 1
            If i = vx1.Count - 1 Then
                valora = Array.IndexOf(aziarea, aziarea2(0))
                valorb = Array.IndexOf(aziarea, aziarea2(i - 1))
            Else
                valora = Array.IndexOf(aziarea, aziarea2(i - 1))
                valorb = Array.IndexOf(aziarea, aziarea2(i))
            End If
            dist1(0) = Math.Sqrt(Math.Pow(puntcontactexr(valora) - puntcontactexr.Average, 2) + Math.Pow(puntcontacteyr(valora) - puntcontacteyr.Average, 2) + Math.Pow(puntcontactezr(valora) - puntcontactezr.Average, 2))
            dist1(1) = Math.Sqrt(Math.Pow(puntcontactexr(valorb) - puntcontactexr(valora), 2) + Math.Pow(puntcontacteyr(valorb) - puntcontacteyr(valora), 2) + Math.Pow(puntcontactezr(valorb) - puntcontactezr(valora), 2))
            dist1(2) = Math.Sqrt(Math.Pow(puntcontactexr(valorb) - puntcontactexr.Average, 2) + Math.Pow(puntcontacteyr(valorb) - puntcontacteyr.Average, 2) + Math.Pow(puntcontactezr(valorb) - puntcontactezr.Average, 2))
            Array.Copy(dist1, dist1b, dist1.Length)
            Array.Sort(dist1b)
            puntescollit = Array.IndexOf(dist1, dist1b(2))
            Select Case puntescollit
                Case 0
                    Px1 = puntcontactexr(valorb) : Py1 = puntcontacteyr(valorb) ': Pz1 = puntcontactezr(valorb) 'pùnto a proyectar
                    Px2 = puntcontactexr(valora) : Py2 = puntcontacteyr(valora) ': Pz2 = puntcontactezr(valora) 'extremo linea
                    Px3 = puntcontactexr.Average : Py3 = puntcontacteyr.Average ': Pz3 = puntcontactezr.Average 'extremo linea
                Case 1
                    Px1 = puntcontactexr.Average : Py1 = puntcontacteyr.Average ': Pz1 = puntcontactezr.Average 'pùnto a proyectar
                    Px2 = puntcontactexr(valora) : Py2 = puntcontacteyr(valora) ': Pz2 = puntcontactezr(valora) 'extremo linea
                    Px3 = puntcontactexr(valorb) : Py3 = puntcontacteyr(valorb) ': Pz3 = puntcontactezr(valorb) 'extremo linea
                Case 2
                    Px1 = puntcontactexr(valora) : Py1 = puntcontacteyr(valora) ': Pz1 = puntcontactezr(valorb) 'pùnto a proyectar
                    Px2 = puntcontactexr.Average : Py2 = puntcontacteyr.Average ': Pz2 = puntcontactezr.Average 'extremo linea
                    Px3 = puntcontactexr(valorb) : Py3 = puntcontacteyr(valorb) ': Pz3 = puntcontactezr(valora) 'extremo linea
            End Select
            Dim aaa, bbb, ddd1, ddd2, ddd3, ddd4, ddd5, ddd6 As Double

            aaa = (Py3 - Py2) / (Px3 - Px2)
            bbb = (-(((Py3 - Py2) / (Px3 - Px2)) * Px3) + Py3)
            radio = Math.Abs((aaa * Px1) - Py1 + bbb) / Math.Sqrt((Math.Pow(aaa, 2)) + 1)
            ' repeticion
            ddd1 = 1 + (aaa * aaa)
            ddd2 = ((-2 * Px1) + (2 * aaa * bbb) - (2 * Py1 * aaa))
            ddd3 = (Px1 * Px1) + (bbb * bbb) + (-2 * Py1 * bbb) + (Py1 * Py1) - (Math.Pow(radio, 2))
            ' ddd4 = (Math.Pow(353188.337, 2) * ddd1) + (353188.337 * ddd2) + ddd3

            ' solución
            ddd4 = 4 * ddd1 * ddd3
            ddd5 = Math.Pow(ddd2, 2)
            If ddd5 > ddd4 Then ' a vegades no es tan precis i no encerta al secant cercle linea.
                ddd6 = Math.Sqrt(ddd5 - ddd4)
            Else
                ddd6 = Math.Sqrt(ddd4 - ddd5)
            End If
            Psx1 = (((-ddd2 + ddd6) / (2 * ddd1)) + ((-ddd2 - ddd6) / (2 * ddd1))) / 2
            Psy1 = (aaa * Psx1) + bbb
            Select Case puntescollit
                Case 0
                    dist1(1) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(2) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(1)) / 2) + ((radio * dist1(2)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(1), dist1(2), areatotal, areatotal1)
                Case 1
                    dist1(0) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(2) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(0)) / 2) + ((radio * dist1(2)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(0), dist1(2), areatotal, areatotal1)
                Case 2
                    dist1(0) = Math.Sqrt(Math.Pow(Psx1 - Px2, 2) + Math.Pow(Psy1 - Py2, 2))
                    dist1(1) = Math.Sqrt(Math.Pow(Psx1 - Px3, 2) + Math.Pow(Psy1 - Py3, 2))
                    areatotal1 = ((radio * dist1(0)) / 2) + ((radio * dist1(1)) / 2)
                    areatotal = areatotal + areatotal1
                    ' PrintLine(3, i, valora, valorb, dist1(0), dist1(1), areatotal, areatotal1)
            End Select
        Next
        ' PrintLine(3, "Surface area for density (m2):", TAB(40), Format(areatotal, "0.00"))
        ' PrintLine(3, "Fracture Density (#/m2):", TAB(40), Format(numberofplans / areatotal, "0.000"))

        PrintLine(3, "area:", Format(areatotal, "0.000"))
        ' mean6 = Format(numberofplans / areatotal, "0.000")
        Array.Resize(puntcontactex, Nothing)
        Array.Resize(puntcontactey, Nothing)
        Array.Resize(puntcontactez, Nothing)
        Array.Resize(puntcontactexr, Nothing)
        Array.Resize(puntcontacteyr, Nothing)
        Array.Resize(puntcontactezr, Nothing)
        Array.Resize(vecareai, Nothing)
        Array.Resize(vecareaj, Nothing)
        Array.Resize(vecareak, Nothing)
        Array.Resize(aziarea, Nothing)
        Array.Resize(aziarea2, Nothing)
    End Sub
    Sub ProjCentrPLa()
        D = -(Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean)
        For i = 0 To puntcontactex.Count - 1
            puntcontactex(i) = cx1.Item(i) - Vec1 * (((Vec1 * cx1.Item(i)) + (Vec2 * cy1.Item(i)) + (Vec3 * cz1.Item(i)) + D) / ((Math.Pow(Vec1, 2) + Math.Pow(Vec2, 2) + Math.Pow(Vec3, 2))))
            puntcontactey(i) = cy1.Item(i) - Vec2 * (((Vec1 * cx1.Item(i)) + (Vec2 * cy1.Item(i)) + (Vec3 * cz1.Item(i)) + D) / ((Math.Pow(Vec1, 2) + Math.Pow(Vec2, 2) + Math.Pow(Vec3, 2))))
            puntcontactez(i) = cz1.Item(i) - Vec3 * (((Vec1 * cx1.Item(i)) + (Vec2 * cy1.Item(i)) + (Vec3 * cz1.Item(i)) + D) / ((Math.Pow(Vec1, 2) + Math.Pow(Vec2, 2) + Math.Pow(Vec3, 2))))
            ' PrintLine(3, puntcontactex(i), puntcontactey(i), puntcontactez(i))
        Next
    End Sub
    Sub area3()
        Dim i As Integer
        Dim j As Integer
        Dim xnou(cx1.Count - 1) As Double
        Dim ynou(cx1.Count - 1) As Double
        Dim znou(cx1.Count - 1) As Double
        Dim radio(cx1.Count - 1) As Double
        Dim x(cx1.Count - 1) As Double
        Dim y(cx1.Count - 1) As Double
        Dim z(cx1.Count - 1) As Double
        Dim ang(9) As Double
        Dim o As Double
        Dim p As Double
        Dim k As Double
        'Dim o2 As Double
        Dim A3 As Double
        Dim B3 As Double
        Dim C3 As Double
        Dim max As Double
        Dim mix As Double
        Dim maz As Double
        Dim miz As Double
        Dim are As Double
        Dim distx As Double
        Dim distz As Double
        Dim aa1 As Double
        Dim bb1 As Double
        calculateDipdir(Vec1, Vec2, Vec3)
        orien = dirfunc
        pend = dipfunc
        ' calculdips()
        aa1 = orien
        bb1 = pend
        D = -(Vec1 * xmean) - (Vec2 * ymean) - (Vec3 * zmean)
        For i = 0 To cx1.Count - 1
            'projecció dels punts a un pla
            xnou(i) = cx1.Item(i) + Vec1 * ((-D - (Vec1 * cx1.Item(i)) - (Vec2 * cy1.Item(i)) - (Vec3 * cz1.Item(i))) / ((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))
            ynou(i) = cy1.Item(i) + Vec2 * ((-D - (Vec1 * cx1.Item(i)) - (Vec2 * cy1.Item(i)) - (Vec3 * cz1.Item(i))) / ((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))
            znou(i) = cz1.Item(i) + Vec3 * ((-D - (Vec1 * cx1.Item(i)) - (Vec2 * cy1.Item(i)) - (Vec3 * cz1.Item(i))) / ((Vec1 * Vec1) + (Vec2 * Vec2) + (Vec3 * Vec3)))
            'rotacio sobre omega amb el valor de ABC 010
            o = 0
            p = 0
            k = (orien * Math.PI) / 180
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            A3 = ((xnou(i) * ang(1)) + (ynou(i) * ang(2)) + (znou(i) * ang(3)))
            B3 = ((xnou(i) * ang(4)) + (ynou(i) * ang(5)) + (znou(i) * ang(6)))
            C3 = ((xnou(i) * ang(7)) + (ynou(i) * ang(8)) + (znou(i) * ang(9)))

            'rotacions2
            o = (pend * Math.PI) / 180
            p = 0
            k = 0
            'p2 = (k * 180) / Math.PI
            'rotacions
            ang(1) = Math.Cos(p) * Math.Cos(k)
            ang(2) = -Math.Cos(p) * Math.Sin(k)
            ang(3) = Math.Sin(p)
            ang(4) = (Math.Cos(o) * Math.Sin(k)) + (Math.Sin(o) * Math.Sin(p) * Math.Cos(k))
            ang(5) = (Math.Cos(o) * Math.Cos(k)) - (Math.Sin(o) * Math.Sin(p) * Math.Sin(k))
            ang(6) = -Math.Sin(o) * Math.Cos(p)
            ang(7) = (Math.Sin(o) * Math.Sin(k)) - (Math.Cos(o) * Math.Sin(p) * Math.Cos(k))
            ang(8) = (Math.Sin(o) * Math.Cos(k)) + (Math.Cos(o) * Math.Sin(p) * Math.Sin(k))
            ang(9) = Math.Cos(o) * Math.Cos(p)

            x(i) = ((A3 * ang(1)) + (B3 * ang(2)) + (C3 * ang(3))) '+ trasladacioX
            y(i) = ((A3 * ang(4)) + (B3 * ang(5)) + (C3 * ang(6))) '+ trasladacioY
            z(i) = ((A3 * ang(7)) + (B3 * ang(8)) + (C3 * ang(9))) '+ trasladacioZ
        Next i
        'buscar els extrems
        For j = 0 To cx1.Count - 1
            'PrintLine(2, Format(Form15.NumericUpDown5.Value + x(j), "0.0000"), Format(Form15.NumericUpDown5.Value + z(j), "0.0000"))
            If j = 1 Then
                max = x(j)
                maz = y(j)
                mix = x(j)
                miz = y(j)
            Else
                If x(j) >= max Then max = x(j)
                If x(j) <= mix Then mix = x(j)
                If y(j) >= maz Then maz = y(j)
                If y(j) <= miz Then miz = y(j)
            End If
        Next j
        distx = Math.Abs(max - mix)
        distz = Math.Abs(maz - miz)
        are = distx * distz
        'Distribuir en cel·les
        '1 dimensionar model
        Dim espaicella As Double
        Dim cellasx As Double
        Dim cellasy As Double
        Dim ad As Integer
        Dim ae As Integer
        Dim ad2 As Integer
        Dim ae2 As Integer
        Dim contador As Integer
        Dim referarea()() As Integer
        espaicella = (are / (cx1.Count - 1)) * 2.5
        'If espaicella < 0.02 Then espaicella = (are / seleccio) * 12.5
        If espaicella < 0.06 Then espaicella = 0.12
        cellasx = Math.Ceiling(distx / espaicella)
        cellasy = Math.Ceiling(distz / espaicella)
        ReDim referarea(cellasx + 2)
        For ad = 0 To cellasx + 2
            referarea(ad) = New Integer(cellasy + 2) {}
        Next ad
        '2 posar els punts a les cel·les

        For ad = 1 To cx1.Count - 1
            'Form1.ProgressBar1.Value = (d * 100) / (x.Length - 1)
            aa1 = (x(ad) - mix) / espaicella
            aa1 = Int(aa1) + 1
            bb1 = (y(ad) - miz) / espaicella
            bb1 = Int(bb1) + 1
            referarea(aa1)(bb1) = 1
        Next ad

        '3comprovar veins

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 3 Then referarea(ad)(ae) = 2
                contador = 0
            Next ae
        Next ad
        '4 comprovar veins per segona vegada

        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) = Nothing Then
                    For ad2 = -1 To 1
                        For ae2 = -1 To 1
                            If referarea(ad + ad2)(ae + ae2) = 1 Or referarea(ad + ad2)(ae + ae2) = 2 Then
                                contador = contador + 1
                            End If
                        Next ae2
                    Next ad2
                End If
                If contador >= 4 Then referarea(ad)(ae) = 3
                contador = 0
            Next ae
        Next ad
        ' 5 contar cel·les
        For ad = 1 To cellasx
            For ae = 1 To cellasy
                If referarea(ad)(ae) >= 1 Then
                    contador = contador + 1
                End If
            Next ae
        Next ad
        are = espaicella * espaicella * contador
        PrintLine(3, "area 2:", Format(are, "0.000"))
        'Fí de la distribució en cel·les
        are = 0
        contador = 0
        espaicella = 0
        ReDim referarea(Nothing)(Nothing)
        cellasy = 0
        cellasx = 0
    End Sub
    Sub P10()
        'obrir l'excel'parar en pruebas
       
        ' oExcel = CreateObject("Excel.Application")

        'oBook = oExcel.Workbooks.Add(Type.Missing)
        'hasta aqui activar
        Dim fileName As String
        fileName = "export" + jp + ".xls"
        finalpath1 = Form10.TextBox1.Text + fileName
        ' variables per impedancia
        Dim escolli As Boolean = False
        Dim escolli1 As Boolean = False
        Dim escolli2 As Boolean = False
        'Declaració de punts
        Dim PIx(,) As Double, PIy(,) As Double, PIz(,) As Double
        Dim xupp() As Double, yupp() As Double, zupp() As Double
        Dim xlow() As Double, ylow() As Double, zlow() As Double
        Dim dummy As String = ""
        Dim dummy1 As Double
        Dim openFileDialog2 As New OpenFileDialog()
        FileClose(3)
        FileOpen(3, Form10.TextBox1.Text + "Fracture_Abundance_Measures.txt", OpenMode.Output)
        FileOpen(4, Form10.TextBox1.Text + "Distributions.txt", OpenMode.Output)
        FileOpen(5, Form10.TextBox1.Text + "RQR.txt", OpenMode.Output)
        '******obrir fitxer properties**************
        openFileDialog2.Title = "Read ScanLine Properties"
        ' openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        'openFileDialog2.ShowDialog()
        On Error GoTo errorhandler
        ' FileOpen(1, openFileDialog2.FileName, OpenMode.Input)
        FileClose(1)
        FileOpen(1, direccioPropert, OpenMode.Input)
        Do Until EOF(1)
            ReDim Preserve name(mucount)
            ReDim Preserve SLvec1(mucount)
            ReDim Preserve SLvec2(mucount)
            ReDim Preserve SLvec3(mucount)
            ReDim Preserve vecSL1(mucount)
            ReDim Preserve vecSL2(mucount)
            ReDim Preserve vecSL3(mucount)
            ReDim Preserve xupp(mucount)
            ReDim Preserve yupp(mucount)
            ReDim Preserve zupp(mucount)
            ReDim Preserve xlow(mucount)
            ReDim Preserve ylow(mucount)
            ReDim Preserve zlow(mucount)
            ReDim Preserve xcmean1(mucount)
            ReDim Preserve ycmean1(mucount)
            ReDim Preserve zcmean1(mucount)
            ReDim Preserve xmean1(mucount)
            ReDim Preserve ymean1(mucount)
            ReDim Preserve zmean1(mucount)
            ReDim Preserve Hei(mucount)
            ReDim Preserve ext(mucount)
            ReDim Preserve are(mucount)
            ReDim Preserve vxwell(mucount)
            ReDim Preserve vywell(mucount)
            ReDim Preserve vzwell(mucount)
            Input(1, name(mucount))
            Input(1, dummy)
            Input(1, SLvec1(mucount))   'outcrop orientatio
            Input(1, SLvec2(mucount))
            Input(1, SLvec3(mucount))
            Input(1, xcmean1(mucount))   'outcrop and Scanline centroid
            Input(1, ycmean1(mucount))
            Input(1, zcmean1(mucount))
            Input(1, dummy)
            Input(1, vecSL1(mucount))   'Plane Scanline Orientation
            Input(1, vecSL2(mucount))
            Input(1, vecSL3(mucount))
            Input(1, xmean1(mucount))            'Plane Scanline Centroid
            Input(1, ymean1(mucount))
            Input(1, zmean1(mucount))
            Input(1, dummy)
            Input(1, dummy1)
            Input(1, dummy1)
            Input(1, dummy1)
            Input(1, xupp(mucount))     'Scanline Plane up centroid
            Input(1, yupp(mucount))
            Input(1, zupp(mucount))
            Input(1, dummy)
            Input(1, dummy1)
            Input(1, dummy1)
            Input(1, dummy1)
            Input(1, xlow(mucount))     'Scanline Plane low centroid
            Input(1, ylow(mucount))
            Input(1, zlow(mucount))
            Input(1, dummy)
            Input(1, Hei(mucount))      'Mechanical Unit height
            Input(1, dummy)
            Input(1, ext(mucount))      'Mechanical Unit Persistence
            Input(1, dummy)
            Input(1, are(mucount))      'Mechanical Unit Area
            ' es el vector de la linea del synthetic Well
            vxwell(mucount) = (SLvec2(mucount) * SLvec3(mucount)) - (SLvec3(mucount) * (-SLvec1(mucount))) ' - (Math.PI / 4)
            vywell(mucount) = (SLvec3(mucount) * SLvec2(mucount)) - (SLvec1(mucount) * SLvec3(mucount)) ' + (Math.PI / 6)
            vzwell(mucount) = (SLvec1(mucount) * (-SLvec1(mucount))) - (SLvec2(mucount) * SLvec2(mucount))           'Lectura de fractures i longitud de les fractures
            Input(1, dummy1)
            ReDim Preserve numsets1(contval + dummy1)
            ReDim Preserve nufrac1(contval + dummy1)
            ReDim Preserve nufrac2(contval + dummy1)
            ReDim Preserve sumats(contval + dummy1)
            For cont = 0 To (dummy1 - 1)
                contval += 1
                Input(1, numsets1(contval))
                Input(1, nufrac1(contval))
                Input(1, nufrac2(contval))
                Input(1, sumats(contval))
            Next
            Input(1, dummy)
            'Càlcul Ax+By+Cz+D=0 pels plans de bedding upp and low per U.M.
            ReDim Preserve Dsl(mucount)
            ReDim Preserve Dslupp(mucount)
            ReDim Preserve Dsllow(mucount)
            Dsl(mucount) = -(vecSL1(mucount) * xmean1(mucount)) - (vecSL2(mucount) * ymean1(mucount)) - (vecSL3(mucount) * zmean1(mucount))
            Dslupp(mucount) = -(vecSL1(mucount) * xupp(mucount)) - (vecSL2(mucount) * yupp(mucount)) - (vecSL3(mucount) * zupp(mucount))
            Dsllow(mucount) = -(vecSL1(mucount) * xlow(mucount)) - (vecSL2(mucount) * ylow(mucount)) - (vecSL3(mucount) * zlow(mucount))
            mucount += 1
        Loop
        mucount -= 1
        FileClose(1)
        ReDim seleccio(mucount, 0)
        ReDim areatotalUM(mucount)
        ReDim PIx(mucount, 0)
        ReDim PIy(mucount, 0)
        ReDim PIz(mucount, 0)
        ReDim seleccioupp(mucount, 0)
        ReDim selecciolow(mucount, 0)
        '******obrir fitxer Morphology Total**************
        Dim coordx, coordy, coordz As Double
        Dim vx, vy, vz As Double
        Dim azimu, pende, colineal, coplanar As Double
        Dim population, number As Integer
        Dim rugosity, lon, wide, areas As Double
        Dim fami As String = ""
        Dim ii(mucount) As Integer
        Dim dist1 As Double
        Dim dist2 As Double
        Dim dist3 As Double
        Dim dist4 As Double
        Dim dist1upp As Double
        Dim dist3upp As Double
        Dim dist4upp As Double
        Dim dist1low As Double
        Dim dist3low As Double
        Dim dist4low As Double
        Dim D1, D2, D2upp, D2low, D3 As Double
        ' openFileDialog2.Title = "Calculate P10 From M.U."
        ' openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        ' openFileDialog2.ShowDialog()
        Dim numfrac1 As Integer
        On Error GoTo errorhandler
        ' FileOpen(1, openFileDialog2.FileName, OpenMode.Input)
        FileClose(1)
        FileOpen(1, direccioMorpho, OpenMode.Input)
        Do Until EOF(1)
            numfrac1 += 1
            Input(1, coordx) 'x
            Input(1, coordy) 'y
            Input(1, coordz) 'z
            Input(1, vx) 'i
            Input(1, vy) 'j
            Input(1, vz) 'k
            Input(1, azimu) 'azi
            Input(1, pende) 'dip
            Input(1, colineal) 'M
            Input(1, coplanar) 'K
            Input(1, population) 'Population
            Input(1, number) 'Number
            Input(1, rugosity) 'Rugosity
            Input(1, lon) 'Long
            Input(1, wide) 'Wide
            Input(1, areas) 'Area
            Input(1, fami) 'Family
            If areas >= Form28.NumericUpDown3.Value Then
                ' Cálculo de la distancia dist1 entre el plano de bedding, bedding Upper i bedding Lowe y la fractura 
                ReDim orienSL(mucount)
                ReDim pendSL(mucount)
                escolli1 = False
                escolli2 = False
                For i = 0 To mucount 'per cada MU es comproba
                    escolli = False
                    escolli1 = False
                    escolli2 = False
                    ReDim Preserve puntintersecx(i)
                    ReDim Preserve puntintersecy(i)
                    ReDim Preserve puntintersecz(i)
                    ReDim Preserve puntintersecxupp(i)
                    ReDim Preserve puntintersecyupp(i)
                    ReDim Preserve puntinterseczupp(i)
                    ReDim Preserve puntintersecxlow(i)
                    ReDim Preserve puntintersecylow(i)
                    ReDim Preserve puntinterseczlow(i)
                    '******Distancia-Posicio entre el pla de bedding i el centroide
                    Dim vxlinea, vylinea, vzlinea, Dfracture, Plinx, Pliny, Plinz, tlinea As Double 'vector de la linea
                    '**Pla de bedding
                    ' Calcul de Ax+By+Cz+D=0
                    Dfracture = -(vx * coordx) - (vy * coordy) - (vz * coordz) 'vector fractura*posicio fractura pla, de fractura
                    ' Vector de la linea de interseccio
                    vxlinea = (vecSL2(i) * vz) - (vecSL3(i) * vy)
                    vylinea = (vecSL3(i) * vx) - (vecSL1(i) * vz)
                    vzlinea = (vecSL1(i) * vy) - (vecSL2(i) * vx)
                    ' Un punt de la recta
                    Pliny = ((-Dfracture * vecSL1(i)) + (vx * Dsl(i))) / ((-vx * vecSL2(i)) + (vy * vecSL1(i)))
                    Plinx = ((-vecSL2(i) * Pliny) - Dsl(i)) / vecSL1(i)
                    Plinz = 0
                    'Punt més proper al centroide del pla de fractura i la linea de intersecció
                    tlinea = ((((vxlinea * (coordx - Plinx) + ((vylinea * (coordy - Pliny))) + ((vzlinea * (coordz - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecx(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecy(i) = ((vylinea * tlinea) + Pliny)
                    puntintersecz(i) = ((vzlinea * tlinea) + Plinz)
                    '**Pla de bedding upper
                    Pliny = ((-Dfracture * vecSL1(i)) + (vx * Dslupp(i))) / ((-vx * vecSL2(i)) + (vy * vecSL1(i)))
                    Plinx = ((-vecSL2(i) * Pliny) - Dslupp(i)) / vecSL1(i)
                    Plinz = 0
                    tlinea = ((((vxlinea * (coordx - Plinx) + ((vylinea * (coordy - Pliny))) + ((vzlinea * (coordz - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecxupp(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecyupp(i) = ((vylinea * tlinea) + Pliny)
                    puntinterseczupp(i) = ((vzlinea * tlinea) + Plinz)
                    '**Pla de beddinglower
                    Pliny = ((-Dfracture * vecSL1(i)) + (vx * Dsllow(i))) / ((-vx * vecSL2(i)) + (vy * vecSL1(i)))
                    Plinx = ((-vecSL2(i) * Pliny) - Dsllow(i)) / vecSL1(i)
                    Plinz = 0
                    tlinea = ((((vxlinea * (coordx - Plinx) + ((vylinea * (coordy - Pliny))) + ((vzlinea * (coordz - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecxlow(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecylow(i) = ((vylinea * tlinea) + Pliny)
                    puntinterseczlow(i) = ((vzlinea * tlinea) + Plinz)
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding
                    'distancia total: centre de bedding al centroid de la fractura
                    dist2 = Math.Sqrt((Math.Pow((xmean1(i) - coordx), 2)) + (Math.Pow((ymean1(i) - coordy), 2)) + (Math.Pow((zmean1(i) - coordz), 2)))
                    'distancia vertical: pla de bedding al centroide
                    dist1 = Math.Abs((vecSL1(i) * coordx) + (vecSL2(i) * coordy) + (vecSL3(i) * coordz) + Dsl(i)) / Math.Sqrt((Math.Pow(vecSL1(i), 2)) + (Math.Pow(vecSL2(i), 2)) + (Math.Pow(vecSL3(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3 = Math.Sqrt((Math.Pow((xmean1(i) - puntintersecx(i)), 2)) + (Math.Pow((ymean1(i) - puntintersecy(i)), 2)) + (Math.Pow((zmean1(i) - puntintersecz(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4 = Math.Sqrt((Math.Pow((coordx - puntintersecx(i)), 2)) + (Math.Pow((coordy - puntintersecy(i)), 2)) + (Math.Pow((coordz - puntintersecz(i)), 2)))
                    If dist3 <= (ext(i) / 2) And (wide / 2) >= dist4 Then
                        seleccio(i, numfrac0) = numfrac0
                        escolli = True
                    End If
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding upper
                    'distancia vertical: pla de bedding al punt de intersecció
                    dist1upp = Math.Abs((vecSL1(i) * coordx) + (vecSL2(i) * coordy) + (vecSL3(i) * coordz) + Dslupp(i)) / Math.Sqrt((Math.Pow(vecSL1(i), 2)) + (Math.Pow(vecSL2(i), 2)) + (Math.Pow(vecSL3(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3upp = Math.Sqrt((Math.Pow((xupp(i) - puntintersecxupp(i)), 2)) + (Math.Pow((yupp(i) - puntintersecyupp(i)), 2)) + (Math.Pow((zupp(i) - puntinterseczupp(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4upp = Math.Sqrt((Math.Pow((coordx - puntintersecxupp(i)), 2)) + (Math.Pow((coordy - puntintersecyupp(i)), 2)) + (Math.Pow((coordz - puntinterseczupp(i)), 2)))
                    If escolli = True Then
                        If dist3upp <= (ext(i) / 2) And (wide / 2) >= dist4upp Then
                            escolli1 = True
                        End If
                    End If
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding lower
                    dist1low = Math.Abs((vecSL1(i) * coordx) + (vecSL2(i) * coordy) + (vecSL3(i) * coordz) + Dslupp(i)) / Math.Sqrt((Math.Pow(vecSL1(i), 2)) + (Math.Pow(vecSL2(i), 2)) + (Math.Pow(vecSL3(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3low = Math.Sqrt((Math.Pow((xlow(i) - puntintersecxlow(i)), 2)) + (Math.Pow((ylow(i) - puntintersecylow(i)), 2)) + (Math.Pow((zlow(i) - puntinterseczlow(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4low = Math.Sqrt((Math.Pow((coordx - puntintersecxlow(i)), 2)) + (Math.Pow((coordy - puntintersecylow(i)), 2)) + (Math.Pow((coordz - puntinterseczlow(i)), 2)))
                    If escolli = True Then
                        If dist3low <= (ext(i) / 2) And (wide / 2) >= dist4low Then
                            escolli2 = True
                        End If
                    End If
                    '******** Càlcul de l'area inscrita a l'area de la U.M. P22
                    'Sumatori dels inscrits amb els que fan contacte
                    'Inscrits sense contacte
                    'càlcul de les distancies 
                    Dim distpinpin, distupp, distlow As Double
                    distpinpin = Math.Sqrt((Math.Pow((puntintersecxupp(i) - puntintersecxlow(i)), 2)) + (Math.Pow((puntintersecyupp(i) - puntintersecylow(i)), 2)) + (Math.Pow((puntinterseczupp(i) - puntinterseczlow(i)), 2)))
                    ' distupp = Math.Sqrt((Math.Pow((puntintersecxupp(i) - coordx), 2)) + (Math.Pow((puntintersecyupp(i) - coordy), 2)) + (Math.Pow((puntinterseczupp(i) - coordz), 2)))
                    ' distlow = Math.Sqrt((Math.Pow((puntintersecxlow(i) - coordx), 2)) + (Math.Pow((puntintersecylow(i) - coordy), 2)) + (Math.Pow((puntinterseczlow(i) - coordz), 2)))
                    ReDim Preserve P22Area(mucount, nfp22)
                    ReDim Preserve P22Set(mucount, nfp22)
                    Select Case escolli1
                        Case False
                            Select Case escolli2
                                Case False
                                    If dist4upp < distpinpin And dist4low < distpinpin Then ' i esta a dintre i no talla
                                        If dist3 <= (ext(i) / 2) Then ' i a prop
                                            areatotalUM(i) = areatotalUM(i) + areas
                                            P22Area(i, nfp22) = areas
                                            P22Set(i, nfp22) = fami
                                            nfp22 += 1
                                        End If
                                    End If
                                Case True 'talla el low
                                    If dist3 <= (ext(i) / 2) Then ' i a prop
                                        areatotalUM(i) = areatotalUM(i) + ((((wide / 2) - dist4low) / wide) * areas)
                                        If areatotalUM(i) < 0 Then Stop
                                        P22Area(i, nfp22) = ((((wide / 2) - dist4low) / wide) * areas)
                                        P22Set(i, nfp22) = fami
                                        nfp22 += 1
                                    End If
                            End Select 'escolli2 

                        Case True
                            Select Case escolli2
                                Case False 'talls el upper
                                    If dist3 <= (ext(i) / 2) Then ' i a prop
                                        areatotalUM(i) = areatotalUM(i) + ((((wide / 2) - dist4upp) / wide) * areas)
                                        If areatotalUM(i) < 0 Then Stop
                                        P22Area(i, nfp22) = ((((wide / 2) - dist4upp) / wide) * areas)
                                        P22Set(i, nfp22) = fami
                                        nfp22 += 1
                                    End If
                                Case True 'talla els dos beddings
                                    If dist3 <= (ext(i) / 2) Then ' i a prop
                                        areatotalUM(i) = areatotalUM(i) + ((distpinpin / wide) * areas)

                                        P22Area(i, nfp22) = ((distpinpin / wide) * areas)
                                        P22Set(i, nfp22) = fami
                                        nfp22 += 1
                                    End If
                            End Select
                    End Select


                    '******Si estan escoolits són registrats
                    If escolli = True Then
                        ReDim Preserve x(numfrac0)
                        x(numfrac0) = coordx
                        ReDim Preserve y(numfrac0)
                        y(numfrac0) = coordy
                        ReDim Preserve z(numfrac0)
                        z(numfrac0) = coordz
                        ReDim Preserve vect1(numfrac0)
                        vect1(numfrac0) = vx
                        ReDim Preserve vect2(numfrac0)
                        vect2(numfrac0) = vy
                        ReDim Preserve vect3(numfrac0)
                        vect3(numfrac0) = vz
                        ReDim Preserve orientacio(numfrac0)
                        orientacio(numfrac0) = azimu
                        ReDim Preserve pendent(numfrac0)
                        pendent(numfrac0) = pende
                        ReDim Preserve M(numfrac0)
                        M(numfrac0) = colineal
                        ReDim Preserve K(numfrac0)
                        K(numfrac0) = coplanar
                        ReDim Preserve Populat(numfrac0)
                        Populat(numfrac0) = population
                        ReDim Preserve Nume(numfrac0)
                        Nume(numfrac0) = number
                        ReDim Preserve Roughness(numfrac0)
                        Roughness(numfrac0) = rugosity
                        ReDim Preserve Height(numfrac0)
                        Height(numfrac0) = lon
                        ReDim Preserve Wid(numfrac0)
                        Wid(numfrac0) = wide
                        ReDim Preserve Ar(numfrac0)
                        Ar(numfrac0) = areas
                        ReDim Preserve FracturSet(numfrac0)
                        FracturSet(numfrac0) = fami
                        ReDim Preserve impfrac(numfrac0)
                        If escolli1 = True And escolli2 = True Then
                            impfrac(numfrac0) = True
                        Else
                            impfrac(numfrac0) = False
                        End If
                        numfrac0 += 1
                        escolli = False
                        escolli1 = False
                        escolli2 = False
                        ReDim Preserve seleccio(mucount, numfrac0)
                        ReDim Preserve seleccioupp(mucount, numfrac0)
                        ReDim Preserve selecciolow(mucount, numfrac0)
                    End If
                    'calcular t dels pous sintectics
                    t = (-Dfracture - (vx * xcmean1(i)) - (vy * ycmean1(i)) - (vz * zcmean1(i))) / ((vx * vxwell(i)) + (vy * vywell(i)) + (vz * vzwell(i)))
                    ' punt de contacte amb el pla de fractura
                    pwellx = ((vxwell(i) * t) + xcmean1(i))
                    pwelly = ((vywell(i) * t) + ycmean1(i))
                    pwellz = ((vzwell(i) * t) + zcmean1(i))
                    ' If i = 0 Then PrintLine(3, Format(pwellx, "0.000"), Format(pwelly, "0.000"), Format(pwellz, "0.000"))

                    ' vector entre centroide i punt de pou.
                    Dim vfrawellx, vfrawelly, vfrawellz As Double
                    Dim ang, distwell, heifrac, lengfrac As Double
                    vfrawellx = coordx - pwellx
                    vfrawelly = coordy - pwelly
                    vfrawellz = coordz - pwellz
                    distwell = Math.Sqrt(Math.Pow(vfrawellx, 2) + Math.Pow(vfrawelly, 2) + Math.Pow(vfrawellz, 2))
                    ' If i = 0 Then PrintLine(3, Format(vfrawellx, "0.000"), Format(vfrawelly, "0.000"), Format(vfrawellz, "0.000"), Format(distwell, "0.000"))

                    ang = Math.Acos(Math.Abs(((vfrawellx * vx) + (vfrawelly * vy) + (vfrawellz * vz)) / (Math.Sqrt((vfrawellx * vfrawellx) + (vfrawelly * vfrawelly) + (vfrawellz * vfrawellz)) * Math.Sqrt((vx * vx) + (vy * vy) + (vz * vz)))))
                    Heifrac = distwell * Math.Sin(ang * Math.PI / 180)
                    lengfrac = distwell * Math.Cos(ang * Math.PI / 180)
                    ' PrintLine(3, Format(vfrawellx, "0.000"), Format(vfrawelly, "0.000"), Format(vfrawellz, "0.000"), Format(distwell, "0.000"))
                    If heifrac <= lon And lengfrac <= wide Then
                        'If i = 0 Then PrintLine(3, i, Format(vfrawellx, "0.000"), Format(vfrawelly, "0.000"), Format(vfrawellz, "0.000"), Format(distwell, "0.000"), Format(heifrac, "0.000"), Format(lengfrac, "0.000"), fami)
                        twell.Add(t)
                        twell1.Add(t)
                        pwx.Add(pwellx)
                        pwy.Add(pwelly)
                        pwz.Add(pwellz)
                        setw.Add(fami)
                        well.Add(i)
                    End If
                Next
            End If
            'Calcul del synthetic well
        Loop
        ' ******** Càlcul de la orientation of fracture Sets
        syntheticwell()
        orientations()
        ' oBook.SaveAs(finalpath1, XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, Type.Missing, Type.Missing, , XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing)
        ' oBook.Close(True, Type.Missing, Type.Missing)
        ' oExcel.Quit()
        MsgBox("Process Completed")
errorhandler:
        Exit Sub
    End Sub
    Sub orientations()

        Dim l As Integer
        Dim nu As Integer
        'assignacio de mecanical units and fracture sets
        ' Dim numsets As IEnumerable(Of String) = FracturSet.Distinct()
        ' numse = numsets.Count
        Dim areaSet(mucount, numsets.Count - 1)
        ReDim espai(numse)
        ReDim selfinal(mucount, numsets.Count - 1, numfrac0 - 1) ' selfinal(mu,fractureSet,index)
        ReDim vectorSLx(mucount), VectorSLy(mucount), VectorSLz(mucount)
        Dim maxfractur(((mucount + 1) * numsets.Count) - 1) As Integer
        Dim contadornuevo As Integer = 0
        Dim numfracimp(mucount, numsets.Count - 1) As Integer
        'numero de sets
        For i = 0 To mucount
            For j = 0 To numsets.Count - 1
                contadornuevo = 0
                For l = 0 To numfrac0 - 1
                    If seleccio(i, l) <> 0 And FracturSet(seleccio(i, l)) = numsets(j) Then
                        'If FracturSet(seleccio(i, l)) = numsets(j) Then 'Modificacio de l'original (If seleccio(i, l) <> 0 And FracturSet(seleccio(i, l)) = numsets(j) Then) 19-oct-2015
                        selfinal(i, j, contadornuevo) = seleccio(i, l)
                        If impfrac(l) = True Then numfracimp(i, j) += 1
                        contadornuevo += 1
                    End If
                Next
                maxfractur(nu) = contadornuevo
                nu += 1
                For ll = 0 To nfp22 - 1 'Modificacio 1/2 original ( For ll = 0 To nfp22) 13-oct-2015
                    If numsets(j) = P22Set(i, ll) Then
                        areaSet(i, j) = areaSet(i, j) + P22Area(i, ll)
                    End If
                Next
                If areaSet(i, j) = Nothing Then areaSet(i, j) = 0 'evita un 0
            Next
        Next
        'por fracture Set
        ReDim Preserve selfinal(mucount, numsets.Count - 1, maxfractur.Max - 1) ' selfinal(mu,fractureSet,index)
        Dim n As Integer
        Dim nfr As Integer
        nu = 0
        'Crear(Sheets)
       ' If mucount > -1 Then PrintLine(3, mucount, "Unidades Mecanicas")
        ' If mucount > -1 Then oSheet = oBook.Worksheets.Add(, , 2, )
        'Modificacio 2/2 original ( If mucount > 1 Then oSheet = oBook.Worksheets.Add(, , mucount - 1, )) 13-oct-2015
        '  For nn = 0 To mucount
        ' oSheet = oBook.Worksheets(nn + 2)
        ' oSheet.Name = name(nn)
        ' Next
        ' oSheet = oBook.Worksheets(1)
        ' oSheet.Name = "Results"
        ' oSheet = oBook.Worksheets(1)
        ' oSheet.Cells(1, 1) = "Mechanical Unit"
        ' oSheet.Cells(3, 1) = "Height (m):"
        ' oSheet.Cells(4, 1) = "Area (m2):"
        ' oSheet.Cells(5, 1) = "ScanLine Length (m):"
        ' oSheet.Cells(6, 1) = "ScanLine orientation:"
        ' oSheet.Cells(7, 1) = "Bedding:"
        ' oSheet.Cells(10, 1) = "Mechanical Unit"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 0) + 2) = "# Fractures:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 1) + 2) = "Set Orientation:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 2) + 2) = "Impedance Factor(%):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 3) + 2) = "Spacing Mean(m):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 4) + 2) = "Dev. Stand:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 5) + 2) = "Coef. Variation:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 6) + 2) = "Fracture Height(m):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 7) + 2) = "Fracture Length(m):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 8) + 2) = "Area Fracture (m2):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 9) + 2) = "P10:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 10) + 2) = "P11:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 11) + 2) = "P20:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 12) + 2) = "P21:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 13) + 2) = "P22:"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 14) + 2) = "P32(C13):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 15) + 2) = "P32(C23):"
        ' oSheet.Cells(9, ((numsets.Count + 1) * 16) + 2) = "FSR:"
        ' For j = 0 To numsets.Count - 1
        ' For imps = 0 To 16
        ' oSheet.Cells(11, (numsets.Count * imps) + 2 + imps + j) = numsets(j)
        ' Next

        ' oSheet.Cells(12 + mucount + 3, (j * 12) + 11) = "Spacing SL " + numsets(j)         ' de les distancies del ScanLine
        ' oSheet.Cells(12 + mucount + 3, (j * 12) + 8) = "Height SL " + numsets(j)       ' la longitud de l'ScanLine
        ' oSheet.Cells(12 + mucount + 3, (j * 12) + 5) = "Length SL " + numsets(j)      ' les amplades de l'ScanLine
        ' oSheet.Cells(12 + mucount + 3, (j * 12) + 2) = "Areas " + numsets(j)        'les àreas de l'ScanLine
        ' oSheet.Cells(12 + mucount + 3, (j * 12) + 1) = "Fracture # "
        ' Next
        For i = 0 To mucount
            chivato = False
            ' oSheet = oBook.Worksheets(1)
            ' oSheet.Cells(1, i + 2) = name(i)                                        'Nom de la Unitat Mecànica mana el i
            ' oSheet.Cells(i + 12, 1) = name(i)
            ' oSheet.Cells(3, i + 2) = CDbl(Format(Hei(i), "0.00"))                   'Potencia de la unitat mecànica 
            PrintLine(3, name(i), "Height(m): ", CDbl(Format(Hei(i), "0.00")))
            'oSheet.Cells(4, i + 2) = CDbl(Format(areatotalUM(i), "0.00"))           'Area Unitat Mecànica
            PrintLine(3, name(i), "Area(m2): ", CDbl(Format(areatotalUM(i), "0.00")))
            'oSheet.Cells(5, i + 2) = CDbl(Format(ext(i), "0.00"))                   'Longitud de la Unitat Mecànica
            PrintLine(3, name(i), "ScanLine_length(m): ", CDbl(Format(ext(i), "0.00")))
            Vec1 = vecSL1(i) : Vec2 = vecSL2(i) : Vec3 = vecSL3(i)
            calculateDipdir(Vec1, Vec2, Vec3)
            mean1 = dirfunc
            mean2 = dipfunc
            ' oSheet.Cells(7, i + 2) = Format(mean1, "0.0") + "/" + Format(mean2, "0.0")  'Bedding orientation
            PrintLine(3, name(i), "Bedding:", Format(mean1, "0.0") + "/" + Format(mean2, "0.0"))
            mu += 1
            contset = 0
            FracBySL = 0
            For j = 0 To numsets.Count - 1
                l = 0
                Select Case maxfractur(nu)
                    Case Is = 0
                        ReDim Preserve selection(0)
                    Case Is > 0
                        For n = 0 To maxfractur(nu) - 1
                            ReDim Preserve selection(l)
                            selection(l) = l
                            cx1.Add(x(selfinal(i, j, l)))
                            cy1.Add(y(selfinal(i, j, l)))
                            cz1.Add(z(selfinal(i, j, l)))
                            vx1.Add(vect1(selfinal(i, j, l)))
                            vy1.Add(vect2(selfinal(i, j, l)))
                            vz1.Add(vect3(selfinal(i, j, l)))
                            dipdir1.Add(orientacio(selfinal(i, j, l)))
                            dip1.Add(pendent(selfinal(i, j, l)))
                            M1.Add(M(selfinal(i, j, l)))
                            K1.Add(K(selfinal(i, j, l)))
                            Population1.Add(Populat(selfinal(i, j, l)))
                            Number1.Add(Nume(selfinal(i, j, l)))
                            Rugosity1.Add(Roughness(selfinal(i, j, l)))
                            Long1.Add(Height(selfinal(i, j, l)))
                            Wide1.Add(Wid(selfinal(i, j, l)))
                            Area1.Add(Ar(selfinal(i, j, l)))
                            Set1a.Add(FracturSet(selfinal(i, j, l)))
                            l += 1
                            nfr += 1
                        Next
                End Select
                'mana el i de UM
                ' oSheet.Cells(12 + i, 2 + j) = maxfractur(nu)     'Número de fractures per Set
                PrintLine(3, "0", "Fracturesperset:", maxfractur(nu))
                ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 8) + 2 + j) = CDbl(Format(areaSet(i, j), "0.00"))                     ' Sumatori de les fractures a la Unitat Mecànica
                PrintLine(3, "8", "AreaFracture(m2):", CDbl(Format(areaSet(i, j), "0.00")))
                ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 13) + 2 + j) = CDbl(Format(areaSet(i, j) / areatotalUM(i), "0.00"))    ' P22
                PrintLine(3, "13", "P22", CDbl(Format(areaSet(i, j) / areatotalUM(i), "0.00")))
                'orientacions
                'Afegit abril2020 en sustitucio de "fisherBingham()"
                If maxfractur(nu) <> 0 Then fisherBingham()
                ' fisherBingham()
                Select Case bipolar
                    Case True
                        Preferentdirections()
                        mean1 = dirfunc
                        mean2 = dipfunc
                        Select Case indat
                            Case False
                                '  oSheet.Cells(12 + i, ((numsets.Count + 1) * 1) + 2 + j) = Format(mean1, "0.0") + "/" + Format(mean2, "0.0") 'Orientació dels Sets
                                PrintLine(3, "1", "Orient1:", Format(mean1, "0.0") + "/" + Format(mean2, "0.0"))
                            Case True
                                '     oSheet.Cells(12 + i, ((numsets.Count + 1) * 1) + 2 + j) = "n/a" 'Orientació dels Sets
                                PrintLine(3, "1", "n/a")
                                indat = False
                        End Select
                        Dim imp As Double
                        imp = numfracimp(i, j)
                        If numfracimp(i, j) = 0 Then
                            imp = 0
                        Else
                            imp = (numfracimp(i, j) / maxfractur(nu)) * 100
                        End If
                        ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 2) + 2 + j) = CDbl(Format(imp, "0.0"))                                      ' Impedancia de cada Set
                        PrintLine(3, "2", "Imp", CDbl(Format(imp, "0.0")))
                    Case False
                        meandirections()
                        mean1 = dirfunc
                        mean2 = dipfunc
                        Select Case selection.Length
                            Case Is = 0
                            Case Is >= 1
                                ' If dipdir1.Count >= 1 Then oSheet.Cells(12 + i, ((numsets.Count + 1) * 1) + 2 + j) = Format(mean1, "0.0") + "/" + Format(mean2, "0.0") 'Orientació dels Sets
                                If dipdir1.Count >= 1 Then PrintLine(3, "1", "Set_Orientation3", Format(mean1, "0.0") + "/" + Format(mean2, "0.0")) 'Orientació dels Sets

                        End Select
                        Dim imp As Double
                        imp = numfracimp(i, j)
                        If numfracimp(i, j) = 0 Then
                            imp = 0
                        Else
                            imp = (numfracimp(i, j) / maxfractur(nu)) * 100
                        End If
                        '  oSheet.Cells(12 + i, ((numsets.Count + 1) * 2) + 2 + j) = CDbl(Format(imp, "0.0"))                                      ' Impedancia de cada Set
                        PrintLine(3, "2", "imp", CDbl(Format(imp, "0.0")))
                End Select
                nu += 1
                'Valor del promig
                valori = Vec1
                valorj = Vec2
                valork = Vec3
                'Calcul ScanLine Orientation
                vectorSLx(i) = (vecSL2(i) * SLvec3(i)) - (vecSL3(i) * SLvec2(i))
                VectorSLy(i) = (vecSL3(i) * SLvec1(i)) - (vecSL1(i) * SLvec3(i))
                VectorSLz(i) = (vecSL1(i) * SLvec2(i)) - (vecSL2(i) * SLvec1(i))
                Vec1 = vectorSLx(i) : Vec2 = VectorSLy(i) : Vec3 = VectorSLz(i)
                calculateDipdir(Vec1, Vec2, Vec3)
                orienSL(i) = dirfunc
                pendSL(i) = dipfunc
                ' oSheet.Cells(6, i + 2) = Format(90 - pendSL(i), "0.0") + "/" + Format(orienSL(i), "0.0")            ' Orientació de l'ScanLine
                ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 10) + 2 + j) = CDbl(Format(Long1.Sum / ext(i), "0.00"))        'P11
                PrintLine(3, "17", "ScL_Ori:", Format(90 - pendSL(i), "0.0") + "/" + Format(orienSL(i), "0.0"))
                PrintLine(3, "10", "P11:", CDbl(Format(Long1.Sum / ext(i), "0.00")))
                'ubicacion C13)
                CalculC13()
                indice = i
                FracBySL = FracBySL + selection.Length
                spacing()
                dipdir1.Clear()
                dip1.Clear()
                vx1.Clear()
                vy1.Clear()
                vz1.Clear()
                cx1.Clear()
                cy1.Clear()
                cz1.Clear()
                M1.Clear()
                K1.Clear()
                Population1.Clear()
                Number1.Clear()
                Wide1.Clear()
                Long1.Clear()
                Area1.Clear()
                Rugosity1.Clear()
                Set1a.Clear()
                contset += 1
                'la correcta es numsets(j) del primer MU, numsets.count
                Dim val As Integer
                val = Array.IndexOf(numsets1, numsets(j))
                If val = -1 Then
                    Stop
                Else
                    ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 11) + 2 + j) = CDbl(Format(nufrac1(val) / areatotalUM(i), "0.00"))       'P20
                    PrintLine(3, "11", "P20:", CDbl(Format(nufrac1(val) / areatotalUM(i), "0.00")))
                    ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 12) + 2 + j) = CDbl(Format(sumats(val) / areatotalUM(i), "0.00"))        'P21
                    PrintLine(3, "12", "P21:", CDbl(Format(sumats(val) / areatotalUM(i), "0.00")))
                    ' oSheet.Cells(12 + i, ((numsets.Count + 1) * 15) + 2 + j) = CDbl(Format((sumats(val) / areatotalUM(i)) * C23, "0.00")) 'P32c13
                    PrintLine(3, "15", "P32c23", CDbl(Format((sumats(val) / areatotalUM(i)) * C23, "0.00")))
                    numsets1(val) = ""
                End If
            Next
            t1.Clear()
            Pintx.Clear()
            Pinty.Clear()
            Pintz.Clear()
            FracBySL = 0
            ' Fractures by section, potser no coincideix a P10 perque l'origen no és exactament el mateix
            Dim jj, distsecind2, contfra, contfrast, contfraend As Integer
            Dim distsec, distsecind As Double
            Dim section As Integer = 1
            Dim numsections As Integer = 1
            ReDim Preserve ttotal(nf - 1)
            ReDim Preserve Settotal(nf - 1)
            Dim settotalarray() As Object = numsets.ToArray
            Dim ttotal2(ttotal.Count - 1) As Double
            Array.Copy(ttotal, ttotal2, nf)
            Array.Sort(ttotal2)
            contfrast = Array.IndexOf(ttotal, ttotal2(0)) : contfraend = Array.IndexOf(ttotal, ttotal2(ttotal2.Count - 1))
            distsec = Math.Sqrt((Math.Pow((Prectax.Item(contfrast) - Prectax.Item(contfraend)), 2)) + (Math.Pow((Prectay.Item(contfrast) - Prectay.Item(contfraend)), 2)) + (Math.Pow((Prectaz.Item(contfrast) - Prectaz.Item(contfraend)), 2)))
            numsections = Math.Truncate(distsec / Form28.NumericUpDown4.Value) + 1
            Dim result(numsets.Count - 1, numsections) As Integer
            For n = 1 To ttotal2.Count - 1
                contfra = Array.IndexOf(ttotal, ttotal2(n))
                distsecind = Math.Sqrt((Math.Pow((Prectax.Item(contfra) - Prectax.Item(contfrast)), 2)) + (Math.Pow((Prectay.Item(contfra) - Prectay.Item(contfrast)), 2)) + (Math.Pow((Prectaz.Item(contfra) - Prectaz.Item(contfrast)), 2)))
                distsecind2 = Math.Truncate(distsecind) + 1
                jj = Array.IndexOf(settotalarray, Settotal(contfra))
                result(jj, distsecind2 - 1) += 1
            Next
            jj = Array.IndexOf(settotalarray, Settotal(contfrast))
            result(jj, 1) += 1
            ' oSheet = oBook.Worksheets(i + 2)
            PrintLine(5, "Book:", i + 2, name(i), "# Section", "# Fractures", "Synt Well", "Length", "RQD Total", "Fractures", name(i))
            ' oSheet.Cells(1, 1) = name(i)

            ' oSheet.Cells(2, 2) = "# Section"

            ' oSheet.Cells(2, 3) = "# Fractures"

            ' oSheet.Cells(numsections + 8, 1) = "Synt Well"           'Synthetyc well

            ' oSheet.Cells(numsections + 8, 2) = "Length"             'Synthetyc well

            ' oSheet.Cells(numsections + 8, 3) = "RQD Total"                'Synthetyc well

            ' oSheet.Cells(numsections + 8, 4) = "Fractures"          'Synthetyc well

            ' oSheet.Cells(numsections + 9, 1) = name(i)                                   'Synthetyc well
            PrintLine(5, name(i), CDbl(Format(sumatoritotal(i), "0.00")), CDbl(Format(RQD(i), FracIndex(i))))
            ' oSheet.Cells(numsections + 9, 2) = CDbl(Format(sumatoritotal(i), "0.00"))    'Synthetyc well

            ' oSheet.Cells(numsections + 9, 3) = CDbl(Format(RQD(i), "0.00"))                                   'Synthetyc well

            ' oSheet.Cells(numsections + 9, 4) = FracIndex(i)                              'Synthetyc well
            Dim sumat As Integer
            For se = 0 To numsets.Count - 1
                ' oSheet.Cells(2, se + 3) = numsets(se)
                PrintLine(5, numsets(se))
                For li = 0 To numsections - 1
                    ' oSheet.Cells(li + 3, se + 3) = result(se, li)
                    ' oSheet.Cells(li + 3, 2) = li + 1
                    PrintLine(5, result(se, li), li + 1)
                    sumat = result(se, li) + sumat
                Next
                ' oSheet.Cells((numsections) + 4, se + 3) = sumat
                PrintLine(5, sumat)
                sumat = 0
            Next
            ' oSheet.Cells((numsections) + 4, 1) = "Total"
            PrintLine(5, "Total")
            Dim esp As Double = 0

            'Synthetyc Wells
            Dim memoria As Integer
            Dim chivato5 As Boolean = False
            Dim chivato6 As Boolean = False
            Dim tram As Integer = -1
            Dim sumato As Double = 0
            Dim subtram As Integer = 0
            Dim subtram1 As Integer = 0
            Dim sumvalorrqd As Double = 0
            Dim sumaRQD As Double = 0
            For se = 0 To ((log.Length) / (mucount + 1)) - 1 Step 1
                ' If i = 10 Then Stop
                esp = log(i, se)
                If FracIndex(i) = 0 Then esp = -1
                If chivato5 = True And esp = 0 Then esp = -1
                Select Case esp
                    Case Is = 0
                        tram += 1
                        subtram += 1
                        ' oSheet.Cells(numsections + 11 + subtram - 1, 1) = tram
                        ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl("0.00")
                        PrintLine(5, tram, CDbl("0.00"))
                        If FracIndex(i) > 1 Then
                            ' oSheet.Cells(numsections + 11 + subtram - 1, 3) = CDbl("100.0")
                            PrintLine(5, CDbl("100.0"))
                        Else
                            ' oSheet.Cells(numsections + 11 + subtram - 1, 3) = CDbl("0.00")
                            PrintLine(5, CDbl("0.00"))
                        End If
                        ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                        PrintLine(5, Setlog(i, se))
                        chivato5 = True
                        memoria = subtram - 1
                    Case 0 To 0.1
                        sumaRQD = sumaRQD + esp
                        sumato = sumato + esp
                        Select Case sumato
                            Case Is < 1
                                subtram += 1
                                ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format(esp, "0.00"))
                                ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                PrintLine(5, CDbl(Format(esp, "0.00")), Setlog(i, se), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")))
                            Case Is > 1
                                subtram += 2
                                tram += 1
                                sumato += -1
                                ' oSheet.Cells(numsections + 11 + subtram - 1, 1) = tram
                                ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format((sumato), "0.00"))
                                ' oSheet.Cells(numsections + 11 + subtram - 1, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                PrintLine(5, tram, CDbl(Format((sumato), "0.00")), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")), Setlog(i, se))
                                sumaRQD = 0
                                memoria = subtram - 1
                        End Select
                    Case Is > 0.1
                        Select Case sumato
                            Case Is = 0
                                Select Case esp
                                    Case Is >= 1
                                        For sw = 0 To esp - 1 Step 1
                                            tram += 1
                                            subtram += 1
                                            ' oSheet.Cells(numsections + 11 + subtram, 1) = tram
                                            ' oSheet.Cells(numsections + 11 + subtram, 3) = CDbl("100.0")
                                            PrintLine(5, tram, CDbl("100.0"))
                                            memoria = subtram
                                        Next
                                        subtram += 1
                                        ' sumato = esp + sas
                                        sumato = esp - Math.Truncate(esp)
                                        ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format((sumato), "0.00"))
                                        ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                        ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                        PrintLine(5, CDbl(Format((sumato), "0.00")), Setlog(i, se), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")))
                                    Case Is < 1
                                        subtram += 1
                                        sumato = esp + sumato
                                        ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format((sumato), "0.00"))
                                        ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                        ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                        PrintLine(5, CDbl(Format((sumato), "0.00")), Setlog(i, se), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")))
                                End Select
                            Case Is > 0
                                Dim rest As Double
                                rest = 1 - sumato
                                If esp >= rest Then
                                    'llegar a 1
                                    tram += 1
                                    subtram += 1
                                    ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format(((1 - sumaRQD) * 100), "0.00"))
                                    ' oSheet.Cells(numsections + 11 + subtram, 1) = tram
                                    ' oSheet.Cells(numsections + 11 + subtram, 3) = CDbl("100.0")
                                    PrintLine(5, CDbl(Format(((1 - sumaRQD) * 100), "0.00")), tram, CDbl("100.0"))
                                    sumaRQD = 0
                                    sumato = sumato + esp - 1
                                    memoria = subtram
                                    'completar ciclo
                                    If sumato > 1 Then
                                        For sw = 1 To sumato Step 1
                                            tram += 1
                                            subtram += 1
                                            ' oSheet.Cells(numsections + 11 + subtram, 1) = tram
                                            ' oSheet.Cells(numsections + 11 + subtram, 3) = CDbl("100.0")
                                            PrintLine(5, tram, CDbl("100.0"))
                                            sumaRQD = 0
                                            memoria = subtram
                                            ' sas -= 1
                                        Next
                                    End If
                                    'resto
                                    subtram += 1
                                    ' sumato = sumato + sas
                                    sumato = sumato - Math.Truncate(sumato)
                                    ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format((sumato), "0.00"))
                                    ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                    ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                    PrintLine(5, CDbl(Format((sumato), "0.00")), Setlog(i, se), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")))
                                Else
                                    subtram += 1
                                    ' oSheet.Cells(numsections + 11 + subtram, 2) = CDbl(Format((esp), "0.00"))
                                    ' oSheet.Cells(numsections + 11 + subtram, 4) = Setlog(i, se)
                                    sumato = sumato + esp
                                    ' oSheet.Cells(numsections + 11 + memoria, 3) = CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0"))
                                    PrintLine(5, CDbl(Format((esp), "0.00")), Setlog(i, se), CDbl(Format((((sumato - sumaRQD) / sumato) * 100), "0.0")))
                                End If
                        End Select
                End Select
            Next
            Prectax.Clear()
            Prectay.Clear()
            Prectaz.Clear()
        Next
    End Sub
    Sub spacing()
        Dim d3 As Double
        Dim posrecBySet(selection.Length - 1) As Double
        Dim copyarray(selection.Length - 1) As Double
        Dim mean9 As Integer
        Dim dist(selection.Length - 1) As Double
        Dim vxlinea, vylinea, vzlinea, Dfracture, tlinea, Plinx, Pliny, Plinz As Double
        'Calcular la posicio de la recta 'Intersecció del pla de bedding i pla d'outcrop(VecSL1, VecSL2, VecSL3, SLvec1, SLvec2, SLvec3, xmean1, xmean2, xmean3) Vector i Punt
        'Calcular la posició a la recta SL de la obtinguda de la interseccio del pla de bedding i la fractura
        'ordenar els punts (associat el setnumber per P20)
        'Calcular distàncies. Mitja, desv standart, més frequent...
        nf = (t1.Count)
        ReDim Preserve ttotal(nf + selection.Length)
        ReDim Preserve Settotal(nf + selection.Length)
        Select Case selection.Length
            Case Is = 1
                If vx1.Count > 0 Then
                    Dim j As Integer = 0
                    j = 0
                    'aqui hi hauria d'anar els punts amb un resultat
                    'indice es al pla de bedding j es a la fractura
                    Dfracture = -(vx1(j) * cx1(j)) - (vy1(j) * cy1(j)) - (vz1(j) * cz1(j))
                    vxlinea = (vecSL2(indice) * vz1(j)) - (vecSL3(indice) * vy1(j))
                    vylinea = (vecSL3(indice) * vx1(j)) - (vecSL1(indice) * vz1(j))
                    vzlinea = (vecSL1(indice) * vy1(j)) - (vecSL2(indice) * vx1(j))
                    Pliny = (((-Dfracture * vecSL1(indice)) + (vx1(j) * Dsl(indice))) / ((-vx1(j) * vecSL2(indice)) + (vy1(j) * vecSL1(indice))))
                    Plinx = (((-vecSL2(indice) * Pliny) - Dsl(indice)) / vecSL1(indice))
                    Plinz = 0
                    'Punt més proper al centroide del pla de fractura i la linea de intersecció
                    tlinea = ((((vxlinea * (cx1(j) - Plinx) + ((vylinea * (cy1(j) - Pliny))) + ((vzlinea * (cz1(j) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    Pintx.Add((vxlinea * tlinea) + Plinx)
                    Pinty.Add((vylinea * tlinea) + Pliny)
                    Pintz.Add((vzlinea * tlinea) + Plinz)
                    'Posición a la recta SL del punt d'intersecció entre pla de fractura i bedding
                    t1.Add((((vectorSLx(indice) * (Pintx.Item(nf) - xmean1(indice)) + ((VectorSLy(indice) * (Pinty.Item(nf) - ymean1(indice)))) + ((VectorSLz(indice) * (Pintz.Item(nf) - zmean1(indice)))))) / ((vectorSLx(indice) * vectorSLx(indice)) + (VectorSLy(indice) * VectorSLy(indice)) + (VectorSLz(indice) * VectorSLz(indice)))))
                    ttotal(nf) = t1.Item(nf)
                    Settotal(nf) = Set1a.Item(j)
                    ' Settotal = Set1a.ToArray()
                    Prectax.Add((vectorSLx(indice) * t1.Item(nf)) + xmean1(indice))
                    Prectay.Add((VectorSLy(indice) * t1.Item(nf)) + ymean1(indice))
                    Prectaz.Add((VectorSLz(indice) * t1.Item(nf)) + zmean1(indice))
                    posrecBySet(j) = t1.Item(nf)
                    nf += 1
                End If
            Case Is > 1
                For j = 0 To selection.Length - 1
                    'indice es al pla de bedding j es a la fractura
                    Dfracture = -(vx1(j) * cx1(j)) - (vy1(j) * cy1(j)) - (vz1(j) * cz1(j))
                    vxlinea = (vecSL2(indice) * vz1(j)) - (vecSL3(indice) * vy1(j))
                    vylinea = (vecSL3(indice) * vx1(j)) - (vecSL1(indice) * vz1(j))
                    vzlinea = (vecSL1(indice) * vy1(j)) - (vecSL2(indice) * vx1(j))
                    Pliny = (((-Dfracture * vecSL1(indice)) + (vx1(j) * Dsl(indice))) / ((-vx1(j) * vecSL2(indice)) + (vy1(j) * vecSL1(indice))))
                    Plinx = (((-vecSL2(indice) * Pliny) - Dsl(indice)) / vecSL1(indice))
                    Plinz = 0
                    'Punt més proper al centroide del pla de fractura i la linea de intersecció
                    tlinea = ((((vxlinea * (cx1(j) - Plinx) + ((vylinea * (cy1(j) - Pliny))) + ((vzlinea * (cz1(j) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    Pintx.Add((vxlinea * tlinea) + Plinx)
                    Pinty.Add((vylinea * tlinea) + Pliny)
                    Pintz.Add((vzlinea * tlinea) + Plinz)
                    'Posición a la recta SL del punt d'intersecció entre pla de fractura i bedding
                    t1.Add((((vectorSLx(indice) * (Pintx.Item(nf) - xmean1(indice)) + ((VectorSLy(indice) * (Pinty.Item(nf) - ymean1(indice)))) + ((VectorSLz(indice) * (Pintz.Item(nf) - zmean1(indice)))))) / ((vectorSLx(indice) * vectorSLx(indice)) + (VectorSLy(indice) * VectorSLy(indice)) + (VectorSLz(indice) * VectorSLz(indice)))))
                    ttotal(nf) = t1.Item(nf)
                    Settotal(nf) = Set1a.Item(j)
                    ' Settotal = Set1a.ToArray()
                    Prectax.Add((vectorSLx(indice) * t1.Item(nf)) + xmean1(indice))
                    Prectay.Add((VectorSLy(indice) * t1.Item(nf)) + ymean1(indice))
                    Prectaz.Add((VectorSLz(indice) * t1.Item(nf)) + zmean1(indice))
                    posrecBySet(j) = t1.Item(nf)
                    nf += 1
                Next
        End Select

        'ordenar els punts (associat el setnumber per P20)
        Array.Copy(posrecBySet, copyarray, selection.Length)
        Array.Sort(posrecBySet)
        PrintLine(4, mucount, contset, "#Fractura", "Area:", "Length", "Height", "Spacing")
        Select Case selection.Length
            Case Is = 1

            Case Is > 1
                ' oSheet.Cells(12 + mucount + 4 + espai(contset), (contset * 12) + 8) = CDbl(Format(Wide1(0), "0.00"))        'Valors de la longitud de l'ScanLine
                '  PrintLine(3, "ScanlineLength:", CDbl(Format(Wide1(0), "0.00")))
                ' oSheet.Cells(12 + mucount + 4 + espai(contset), (contset * 12) + 5) = CDbl(Format(Long1(0), "0.00"))        'Valors de les amplades de l'ScanLine
                ' PrintLine(3, "ScanlineAmplada:", CDbl(Format(Long1(0), "0.00")))
                ' oSheet.Cells(12 + mucount + 4 + espai(contset), (contset * 12) + 2) = CDbl(Format(Area1(0), "0.00"))        'Valors de les àreas de l'ScanLine
                ' PrintLine(3, "ScanlineArea:", CDbl(Format(Area1(0), "0.00")))
                ' oSheet.Cells(12 + mucount + 4 + espai(contset), (contset * 12) + 1) = CDbl(Format(Nume(0), "0.00"))
                'PrintLine(3, "Scanline_Number:", CDbl(Format(Nume(0), "0.00")))
                PrintLine(4, mucount, contset, CDbl(Format(Nume(0), "0.00")), CDbl(Format(Area1(0), "0.00")), CDbl(Format(Long1(0), "0.00")), CDbl(Format(Wide1(0), "0.00")))
        End Select
        '  PrintLine(4, "#Fractura", "Area:", "Length", "Height", "Spacing")

        For iii = 0 To selection.Length - 1
            mean8 = Array.IndexOf(copyarray, posrecBySet(iii))
            Select Case iii
                Case 0
                    mean9 = mean8
                Case Is <> 0
                    'Calcular la distancia entre fractures continues, Pint i el següent, disancia entre el pla i el  punt
                    d3 = (vx1.Item(mean8) * Pintx.Item(mean8)) + (vy1.Item(mean8) * Pinty.Item(mean8)) + (vz1.Item(mean8) * Pintz.Item(mean8)) ' vx1 solament son de la selecció
                    dist(iii) = Math.Abs((vx1(mean8) * Pintx.Item(mean9)) + (vy1(mean8) * Pinty.Item(mean9)) + (vz1(mean8) * Pintz.Item(mean9)) - d3) / Math.Sqrt((Math.Pow(vx1(mean8), 2)) + (Math.Pow(vy1(mean8), 2)) + (Math.Pow(vz1(mean8), 2)))
                    mean9 = mean8
                    ' oSheet.Cells(12 + mucount + 4 + iii + espai(contset), (contset * 12) + 11) = CDbl(Format(dist(iii), "0.00"))         'Valors de les distancies del ScanLine
                    ' oSheet.Cells(12 + mucount + 4 + iii + espai(contset), (contset * 12) + 8) = CDbl(Format(Wide1(iii), "0.00"))        'Valors de la longitud de l'ScanLine
                    ' oSheet.Cells(12 + mucount + 4 + iii + espai(contset), (contset * 12) + 5) = CDbl(Format(Long1(iii), "0.00"))        'Valors de les amplades de l'ScanLine
                    ' oSheet.Cells(12 + mucount + 4 + iii + espai(contset), (contset * 12) + 2) = CDbl(Format(Area1(iii), "0.00"))        'Valors de les àreas de l'ScanLine
                    ' oSheet.Cells(12 + mucount + 4 + iii + espai(contset), (contset * 12) + 1) = CDbl(Format(Nume(iii), "0.00"))
                    PrintLine(4, mucount, contset, Nume(iii), Format(Area1(iii), "0.00"), Format(Long1(iii), "0.00"), Format(Wide1(iii), "0.00"), CDbl(Format(dist(iii), "0.00")))
            End Select
        Next
        espai(contset) = espai(contset) + selection.Length
        Select Case selection.Length
            Case Is <= 1
            Case Is > 1
                ' oSheet.Cells(12 + mu, ((numse + 1) * 3) + 2 + contset) = CDbl(Format(((dist.Sum) / (selection.Length - 1)), "0.00"))     'Promig de les distàncies
                PrintLine(3, "3", "PromigDist", CDbl(Format(((dist.Sum) / (selection.Length - 1)), "0.00")))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 16) + 2 + contset) = CDbl(Format((((dist.Sum) / (selection.Length - 1) / Hei(mu))), "0.00"))     'FSR
                PrintLine(3, "16", "FSR:", CDbl(Format((((dist.Sum) / (selection.Length - 1) / Hei(mu))), "0.00")))
        End Select
        'Calcul desv. stand
        Dim sumdist As Double
        For iii = 0 To selection.Length - 1
            sumdist = Math.Pow((dist(iii) - ((dist.Sum) / (selection.Length - 1))), 2) + sumdist
        Next
        Select Case selection.Length
            Case Is = 1
                If dipdir1.Count = 1 Then
                    ' oSheet.Cells(12 + mu, ((numse + 1) * 9) + 2 + contset) = CDbl(Format(1 / ext(indice), "0.00")) 'P10
                    PrintLine(3, "9", "P10:", CDbl(Format(1 / ext(indice), "0.00")))
                    ' oSheet.Cells(12 + mu, ((numse + 1) * 14) + 2 + contset) = CDbl(Format((1 / ext(indice)) * C13, "0.00")) 'P32c13
                    PrintLine(3, "14", "P32c13:", CDbl(Format((1 / ext(indice)) * C13, "0.00")))
                    ''''' oSheet.Cells(12 + mu, ((numse + 1) * 15) + 2 + contset) = CDbl(Format((1 / ext(indice)) * C23, "0.00")) 'P32c23
                    'oSheet.Cells(12 + mu, ((numse + 1) * 6) + 2 + contset) = CDbl(Format(Long1.Average, "0.00"))                                     'Amplada dels valors de l'ScanLine
                    PrintLine(3, "7", "Amplada", CDbl(Format(Long1.Average, "0.00")))
                    'oSheet.Cells(12 + mu, ((numse + 1) * 7) + 2 + contset) = CDbl(Format(Wide1.Average, "0.00"))
                    PrintLine(3, "6", "Height:", CDbl(Format(Wide1.Average, "0.00")))
                Else
                    'oSheet.Cells(12 + mu, ((numse + 1) * 9) + 2 + contset) = CDbl("0.00") 'P10
                    PrintLine(3, "9", "P10:", CDbl("0.00"))
                    'oSheet.Cells(12 + mu, ((numse + 1) * 14) + 2 + contset) = CDbl("0.00") 'P32c13
                    PrintLine(3, "14", "P32c13:", CDbl("0.00"))
                    ''''''   oSheet.Cells(12 + mu, ((numse + 1) * 15) + 2 + contset) = CDbl("0.00") 'P32c23
                End If
            Case Is > 1
                sumdist = (Math.Sqrt(sumdist / (selection.Length - 2)))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 4) + 2 + contset) = CDbl(Format(sumdist, "0.00"))                                        'Desviació standart de les distàncies
                PrintLine(3, "4", "Desv_Sta", CDbl(Format(sumdist, "0.00")))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 5) + 2 + contset) = CDbl(Format(sumdist / ((dist.Sum) / (selection.Length - 1)), "0.00"))   'Coeficient de variació de les distàncies
                PrintLine(3, "5", "CoefVar", CDbl(Format(sumdist / ((dist.Sum) / (selection.Length - 1)), "0.00")))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 6) + 2 + contset) = CDbl(Format(Long1.Average, "0.00"))                                     'Amplada dels valors de l'ScanLine
                PrintLine(3, "6", "FractureHeight(m)", CDbl(Format(Long1.Average, "0.00")))
                'oSheet.Cells(12 + mu, ((numse + 1) * 7) + 2 + contset) = CDbl(Format(Wide1.Average, "0.00"))                                     'Longitud dels valors de l'ScanLine
                PrintLine(3, "7", "FractureLength(m)", CDbl(Format(Wide1.Average, "0.00")))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 9) + 2 + contset) = CDbl(Format(selection.Length / ext(indice), "0.00"))               'P10
                PrintLine(3, "9", "P10", CDbl(Format(selection.Length / ext(indice), "0.00")))
                ' oSheet.Cells(12 + mu, ((numse + 1) * 14) + 2 + contset) = CDbl(Format((selection.Length / ext(indice)) * C13, "0.00")) 'P32c13
                PrintLine(3, "14", "P32c13", CDbl(Format((selection.Length / ext(indice)) * C13, "0.00")))
                '''''''''''' oSheet.Cells(12 + mu, ((numse + 1) * 15) + 2 + contset) = CDbl(Format((selection.Length / ext(indice)) * C23, "0.00")) 'P32c13
        End Select
    End Sub
    Sub CalculC13()
        'Pasar a cosenos directores
        Dim producto, cosdir_i, cosdir_j, cosdir_k As Double
        Dim sum_i, sum_j, sum_k As Double
        Dim ArithMean_i, ArithMean_j, ArithMean_k As Double
        Dim R, Fisher_K, ro As Double
        If selection.Length > 1 Then
            For i = 0 To selection.Length - 1
                producto = Math.Sqrt((Math.Pow(vx1(selection(i)), 2)) + (Math.Pow(vy1(selection(i)), 2)) + (Math.Pow(vz1(selection(i)), 2)))
                cosdir_i = vx1(selection(i)) / producto
                cosdir_j = vy1(selection(i)) / producto
                cosdir_k = vz1(selection(i)) / producto
                sum_i = sum_i + cosdir_i
                sum_j = sum_j + cosdir_j
                sum_k = sum_k + cosdir_k
            Next i
            ArithMean_i = sum_i / seleccio.Length
            ArithMean_j = sum_j / seleccio.Length
            ArithMean_k = sum_k / seleccio.Length
            ' R = Math.Sqrt((Math.Pow(sum_i, 2)) + (Math.Pow(sum_j, 2)) + (Math.Pow(sum_k, 2)))
            R = Math.Sqrt((Math.Pow(ArithMean_i, 2)) + (Math.Pow(ArithMean_j, 2)) + (Math.Pow(ArithMean_k, 2)))

            Fisher_K = (1 / (1 - R))
            Select Case Fisher_K
                Case Is >= 0.65
                    'angulo entre scanline-set orientation
                    ro = Math.Acos(Math.Abs(((valori * Vec1) + (valorj * Vec2) + (valork * Vec3)) / (Math.Sqrt(Math.Pow(valori, 2) + Math.Pow(valorj, 2) + Math.Pow(valork, 2)) * Math.Sqrt(Math.Pow(Vec1, 2) + Math.Pow(Vec2, 2) + Math.Pow(Vec3, 2)))))
                    'C13
                    Dim vala, valb, valc, vald As Double
                    vala = (0.1247 * Math.Log(Fisher_K)) + 0.0507
                    valb = (-0.1655 * Math.Log(Fisher_K)) + 2.0951
                    valc = (-0.0551 * Math.Log(Fisher_K)) + 0.5988
                    C13 = 1 / (vala * Math.Cos(valb * ro) + valc)
                    'C23
                    vala = (0.1064 * Math.Log(Fisher_K)) + 0.0351
                    valb = (-0.1376 * Math.Log(Fisher_K)) + 2.1745
                    valc = (-0.0771 * Math.Log(Fisher_K)) + 0.8112
                    vald = (0.1064 * Math.Log(Fisher_K)) + 0.0351
                    C23 = 1 / (vala * Math.Sin((valb * ro) - (vald * (Math.PI / 2))) + valc)
                Case Is < 0.65
                    C13 = 2
                    C23 = 4 / Math.PI
            End Select
        Else
            C13 = 0
            C23 = 0
        End If
    End Sub
    Sub syntheticwell()
        ReDim log(mucount, twell.Count - 1)
        ReDim Setlog(mucount, twell.Count - 1)
        '  Dim countfrac As Integer
        ReDim sumatoritotal(mucount)
        Dim sumatoriparcial(mucount) As Double
        ReDim RQD(mucount)
        ReDim FracIndex(mucount)
        ' Dim twell1 As New List(Of Double)
        Dim SynWell(mucount, twell.Count) As Integer 'modificat
        Dim distwell As Double
        ' Dim valor0 As Integer
        Dim sec As Double
        Dim sec2 As Integer
        ' twell1 = twell
        twell1.Sort()
        'ordenats
        For ordre = 0 To twell.Count - 1
            sec = twell1.Item(ordre)
            ' sec2 = twell.IndexOf(sec, ordre) 'sec2 es el valor
            sec2 = twell.IndexOf(sec, 0)
            SynWell(well.Item(sec2), ordre) = sec2 + 1
        Next
        ' RQD
        Dim valor As Integer = 0
        Dim ordre2 As Integer = 0
        Dim primerpunt As Integer
        For ordre = 0 To mucount
            valor = 0
            For ordre2 = 0 To twell.Count
                sec2 = SynWell(ordre, ordre2)
                Select Case sec2
                    Case Is = 0
                        'nada
                    Case Is > 0
                        Select Case valor
                            Case Is = 0
                                'primer valor
                                log(ordre, valor) = 0
                                Setlog(ordre, valor) = setw.Item(sec2 - 1)
                                primerpunt = sec2 - 1
                                valor += 1
                            Case Is > 0
                                distwell = Math.Sqrt(Math.Pow((pwx.Item(primerpunt) - pwx.Item(sec2 - 1)), 2) + Math.Pow((pwy.Item(primerpunt) - pwy.Item(sec2 - 1)), 2) + Math.Pow((pwz.Item(primerpunt) - pwz.Item(sec2 - 1)), 2))
                                sumatoritotal(ordre) = sumatoritotal(ordre) + distwell
                                If distwell > 0.1 Then sumatoriparcial(ordre) = sumatoriparcial(ordre) + distwell
                                log(ordre, valor) = distwell
                                Setlog(ordre, valor) = setw.Item(sec2 - 1)
                                valor += 1
                                primerpunt = sec2 - 1
                        End Select
                End Select
            Next
            If valor > 0 Then
                If sumatoriparcial(ordre) > sumatoritotal(ordre) Then sumatoriparcial(ordre) = sumatoritotal(ordre)
                If sumatoriparcial(ordre) <> 0 Then
                    RQD(ordre) = (sumatoriparcial(ordre) / sumatoritotal(ordre)) * 100
                Else
                    RQD(ordre) = 0
                End If
            Else
                RQD(ordre) = -1
            End If
            FracIndex(ordre) = valor
        Next
    End Sub
    Private Function cond(ByVal s As String) As Boolean

        ' AndAlso prevents evaluation of the second Boolean
        ' expression if the string is so short that an error
        ' would occur.
        If s = "Set4" Then
            Return True
        Else
            Return False
        End If
    End Function
    Sub distribution()
        Dim fileName As String
        Dim mummy1 As Double
        Dim mummy2 As Integer
        Dim mummy As String
        Dim rfile2 As String = ""
        FileClose(2)
        openFileDialog4.Multiselect = True
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog4.Title = "Calculate Distributions From Morphology File"
        openFileDialog4.InitialDirectory = Form10.TextBox1.Text
        openFileDialog4.ShowDialog()
        'Dim openFileDialog1 As New OpenFileDialog()
        '  openFileDialog2.Multiselect = True
        '******Fi dimensionament*********
        FileOpen(3, Form10.TextBox1.Text + "Distribution_Result.txt", OpenMode.Output)
        '******obrir fitxer projeccio**************
        ' openFileDialog2.Title = "Calculate SpaceLine From Morphology File"
        ' openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        ' openFileDialog2.ShowDialog()
        PrintLine(3, "Dip_Direction", "Dip", "Fisher_Constant", "Num.of_fract", "Radius_Confidence_5%", "Av._Area", "Total_Area", "Av._Length", "Av._height")
        For Each rfile2 In openFileDialog4.FileNames
            'obre el fitxer de morphology i ho afegeix a list of T
            FileOpen(2, rfile2, OpenMode.Input)
            cx1.Clear()
            cy1.Clear()
            cz1.Clear()
            vx1.Clear()
            vy1.Clear()
            vz1.Clear()
            dipdir1.Clear()
            dip1.Clear()
            M1.Clear()
            K1.Clear()
            Population1.Clear()
            Number1.Clear()
            Rugosity1.Clear()
            Wide1.Clear()
            Long1.Clear()
            Area1.Clear()
            Set1a.Clear()
            Set2a.Clear()
            useful.Clear()
            xmean = 0
            ymean = 0
            zmean = 0
            On Error GoTo ErrorHandler
            mummy = LineInput(2)
            Do While Not EOF(2)
                Input(2, mummy1)
                cx1.Add(mummy1)
                Input(2, mummy1)
                cy1.Add(mummy1)
                Input(2, mummy1)
                cz1.Add(mummy1)
                Input(2, mummy1)
                vx1.Add(mummy1)
                Input(2, mummy1)
                vy1.Add(mummy1)
                Input(2, mummy1)
                vz1.Add(mummy1)
                Input(2, mummy1)
                dipdir1.Add(mummy1)
                Input(2, mummy1)
                dip1.Add(mummy1)
                Input(2, mummy1)
                M1.Add(mummy1)
                Input(2, mummy1)
                K1.Add(mummy1)
                Input(2, mummy2)
                Population1.Add(mummy2)
                Input(2, mummy2)
                Number1.Add(mummy2)
                Input(2, mummy1)
                Rugosity1.Add(mummy1)
                Input(2, mummy1)
                Wide1.Add(mummy1)
                Input(2, mummy1)
                Long1.Add(mummy1)
                Input(2, mummy1)
                Area1.Add(mummy1)
                Input(2, mummy)
                Set1a.Add(mummy)
            Loop
            PrintLine(3, rfile2)
            bipolar = False
            Dim dif As Double
            Dim dif1 As Double
            calculateDipdir(vx1.Average, vy1.Average, vz1.Average)
            ' dif1 = dirfunc
            dif = dipfunc
            If Math.Abs(dip1.Average - dif) > 25 Then bipolar = True
            Select Case bipolar
                Case True
                    vectorsperpendicular() ' Principal Mean direction
                Case False
                    meandirectionsperpendicular() ' Mean Direction
            End Select
            'lectura del bedding
            Vec1SL = Vec1
            Vec2SL = Vec2
            Vec3SL = Vec3
            Dim minim(2) As Double
            calculateDipdir(Vec1, Vec2, Vec3)
            orienpla1 = dirfunc
            pendpla1 = dipfunc
            'Calcul de la K Fisher

            Dim Conf5, conf25 As Double
            Dim producto, cosdir_i, cosdir_j, cosdir_k As Double
            producto = 0 : cosdir_i = 0 : cosdir_j = 0 : cosdir_k = 0
            Dim sum_i, sum_j, sum_k As Double
            sum_i = 0 : sum_j = 0 : sum_k = 0
            Dim ArithMean_i, ArithMean_j, ArithMean_k As Double
            ArithMean_i = 0 : ArithMean_j = 0 : ArithMean_k = 0
            Dim R, Fisher_K, ro As Double
            R = 0 : Fisher_K = 0
            For i = 0 To dipdir1.Count - 1
                producto = Math.Sqrt((Math.Pow(vx1(i), 2)) + (Math.Pow(vy1(i), 2)) + (Math.Pow(vz1(i), 2)))
                cosdir_i = vx1(i) / producto
                cosdir_j = vy1(i) / producto
                cosdir_k = vz1(i) / producto
                sum_i = sum_i + cosdir_i
                sum_j = sum_j + cosdir_j
                sum_k = sum_k + cosdir_k
            Next i
            ArithMean_i = sum_i '/ (dipdir1.Count)
            ArithMean_j = sum_j '/ (dipdir1.Count)
            ArithMean_k = sum_k '/ (dipdir1.Count)
            R = Math.Sqrt((Math.Pow(ArithMean_i, 2)) + (Math.Pow(ArithMean_j, 2)) + (Math.Pow(ArithMean_k, 2)))
            Fisher_K = (dipdir1.Count - 1) / (dipdir1.Count - R)
            Conf5 = ((Math.Acos(1 - (((dipdir1.Count - R) * 0.45422) / R))) * 360) / (2 * Math.PI)
            ' Fisher_K = (1 / (1 - R))
            PrintLine(3, "")
            PrintLine(3, Format(dirfunc, "0.00"), Format(dipfunc, "0.00"), Format(Fisher_K, "0.00"), dipdir1.Count, Format(Conf5, "0.00"), Format(Area1.Average, "0.00"), Format(Area1.Sum, "0.00"), Format(Long1.Average, "0.00"), Format(Wide1.Average, "0.00"))
            Dim res As Double
            Dim espw As Integer

            Dim espl As Integer
            Dim espa As Integer
            ' Distributions Length
            Wide1.Average()
            espw = Math.Truncate(Wide1.Max / 0.1)
            Dim widefreq(espw) As Integer
            'Distributions Height
            Long1.Average()
            espl = Math.Truncate(Long1.Max / 0.1)
            Dim longfreq(espl) As Integer
            'Distributions Area
            Area1.Average()
            espa = Math.Truncate(Area1.Max / 0.1)
            Dim areafreq(espa) As Integer
            For ii = 0 To dipdir1.Count - 1
                res = Math.Truncate(Wide1(ii) / 0.1)
                widefreq(res) += 1
                res = Math.Truncate(Long1(ii) / 0.1)
                longfreq(res) += 1
                res = Math.Truncate(Area1(ii) / 0.1)
                areafreq(res) += 1
            Next
            PrintLine(3, "")
            PrintLine(3, "Length")
            For ii = 0 To espw
                PrintLine(3, 0.1 * ii, Format((widefreq(ii) * 100 / dipdir1.Count), "0.00"))
            Next
            PrintLine(3, "")
            PrintLine(3, "Height")
            For ii = 0 To espl
                PrintLine(3, 0.1 * ii, Format((longfreq(ii) * 100 / dipdir1.Count), "0.00"))
            Next
            PrintLine(3, "")
            PrintLine(3, "Area")
            For ii = 0 To espa
                PrintLine(3, 0.1 * ii, Format((areafreq(ii) * 100 / dipdir1.Count), "0.00"))
            Next
            FileClose(2)
            PrintLine(3, "")
        Next
        FileClose(3)
errorhandler:
    End Sub

End Module
