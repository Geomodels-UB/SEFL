﻿Public Class Form16
    Public zoomx As Integer = 250
    Public zoomy As Integer
    Public radi As Integer
    Public radi2 As Single
    Private ejx As Integer = 360
    Private ejy As Integer = 91
    Private maxvalue As Single
    Private minvalue As Single
    Private marc(360, 90) As Integer
    Public formGraphics As System.Drawing.Graphics
    Public formeGraphics As System.Drawing.Graphics
    Public aper As Boolean
    Public conta As Integer
    Public pas As Boolean
    Dim poi As Point
    Public prval2 As Boolean = True
    Public azi As Double
    Public di As Double
    Public i As Double
    Public j As Double
    Public k As Double
    Private Sub Form13_click(ByVal sender As Object, ByVal e As MouseEventArgs) Handles Me.Click
        Dim coopoint As New Point
        Dim cx As Double
        Dim cx1 As Double
        Dim cy As Double
        Dim cy1 As Double
        formGraphics = Me.CreateGraphics()
        cx = ((-1 * e.X) + (zoomx + radi2)) / radi2
        cy = ((-1 * e.Y) + (zoomy + radi2)) / radi2
        cx1 = Math.Atan(cy / cx)
        cx1 = (cx1 * 180) / Math.PI
        cy1 = 90 - ((Math.Sqrt((cx * cx) + (cy * cy))) * 90)
        If cx < 0 Then cx1 = 90 + cx1
        If cx > 0 Then cx1 = cx1 + 270
        If cy1 < 0 Then cy1 = 0
        Label8.Text = Format(cx1, "0.000")
        Label9.Text = Format(cy1, "0.000")
        Label10.Text = 90 - Format(cy1, "0.000")
        If cx1 >= 180 Then Label11.Text = Format(-180 + cx1, "0.000")
        If cx1 < 180 Then Label11.Text = Format(cx1 + 180, "0.000")
        If aper = True Then
            If conta = 0 Then
                poi.X = e.X
                poi.Y = e.Y
            End If
            If conta > 0 Then
                formGraphics.DrawLine(Pens.Black, e.X, e.Y, poi.X, poi.Y)
            End If
            poi.X = e.X
            poi.Y = e.Y
            conta = conta + 1
            PrintLine(15, Label11.Text, Label10.Text)
        End If
        If prval2 = True Then
            azi = Label11.Text
            di = Label10.Text
        End If
        'primer parell
        If prval2 = True Then
            azi = (azi * Math.PI) / 180
            di = (di * Math.PI) / 180
            i = Math.Sin(azi)
            j = Math.Cos(azi)
            k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
            If k > 100000 Then k = 99999.999999999
            If azi = 0 And di = 0 Then
                i = 0
                j = 0
                k = 0
            End If
            prval2 = False
        End If
    End Sub

    Private Sub Form13_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        'Private Sub Form13_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Paint
        formGraphics = Me.CreateGraphics()
        'zoomx = 250
        zoomy = 50
        radi = 600
        radi2 = radi / 2
        formGraphics.FillEllipse(Brushes.White, zoomx, zoomy, radi + 0, radi + 0)
        formGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy, zoomx + radi2, zoomy - 20)
        formGraphics.DrawLine(Pens.Black, zoomx + radi2 - 10, zoomy + radi2, zoomx + radi2 + 10, zoomy + radi2)
        formGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy + radi2 - 10, zoomx + radi2, zoomy + radi2 + 10)


    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim xf As Double
        Dim yf As Double
        Dim zf As Double
        Dim vect1 As Double
        Dim vect2 As Double
        Dim vect3 As Double
        Dim dirf As Double
        Dim pendf As Double
        Dim mf As Double
        Dim kf As Double
        Dim nf As Integer
        Dim intenf As Integer
        Dim rf As Integer
        Dim gf As Integer
        Dim vf As Integer
        Dim a As Integer
        Dim b As Integer
        Dim c As Integer
        Dim d As Integer
        Dim nx As Double
        Dim ny As Double
        Dim x1 As Double
        Dim y1 As Double
        Dim z1 As Double
        Dim ta As Double
        Dim td As Double
        Dim valu As Single
        Dim difere As Single
        Dim ccolor As Brush
        Dim pasos As Integer
        Dim points As Point
        formGraphics = Me.CreateGraphics()
        Dim openFileDialog1 As New OpenFileDialog()
        openFileDialog1.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(1, openFileDialog1.FileName, OpenMode.Input)
        maxvalue = 0
        minvalue = 0
        Do Until EOF(1)
            If RadioButton1.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
            End If
            If RadioButton2.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, intenf)
            End If
            If RadioButton3.Checked = True Then
                Input(1, xf)
                Input(1, yf)
                Input(1, zf)
                Input(1, vect1)
                Input(1, vect2)
                Input(1, vect3)
                Input(1, dirf)
                Input(1, pendf)
                Input(1, mf)
                Input(1, kf)
                Input(1, nf)
                Input(1, rf)
                Input(1, gf)
                Input(1, vf)
            End If
            If RadioButton4.Checked = True Then
                Input(1, ejx)
                Input(1, ejy)
                Input(1, marc(ejx, ejy))
                If marc(ejx, ejy) >= maxvalue Then maxvalue = marc(ejx, ejy)
                If ejx = 360 Then marc(360, ejy) = marc(360, ejy) + marc(0, ejy)
            End If
        Loop
        pas = True
        NumericUpDown21.Value = maxvalue
        NumericUpDown22.Value = minvalue
        '       NumericUpDown1.Value = minvalue
        If CheckBox1.Checked = True Then
            maxvalue = NumericUpDown21.Value
            minvalue = NumericUpDown22.Value
        End If
        difere = maxvalue - minvalue
        pasos = maxvalue / 10
        pasos = difere / 10
        NumericUpDown2.Value = Math.Abs(pasos)
        NumericUpDown3.Value = Math.Abs(pasos) + 1
        NumericUpDown4.Value = 2 * (Math.Abs(pasos))
        NumericUpDown5.Value = 2 * (Math.Abs(pasos)) + 1
        NumericUpDown6.Value = 3 * (Math.Abs(pasos))
        NumericUpDown7.Value = (3 * (Math.Abs(pasos))) + 1
        NumericUpDown8.Value = 4 * (Math.Abs(pasos))
        NumericUpDown9.Value = (4 * (Math.Abs(pasos))) + 1
        NumericUpDown10.Value = 5 * (Math.Abs(pasos))
        NumericUpDown11.Value = (5 * (Math.Abs(pasos))) + 1
        NumericUpDown12.Value = 6 * (Math.Abs(pasos))
        NumericUpDown13.Value = (6 * (Math.Abs(pasos))) + 1
        NumericUpDown14.Value = 7 * (Math.Abs(pasos))
        NumericUpDown15.Value = (7 * (Math.Abs(pasos))) + 1
        NumericUpDown16.Value = 8 * (Math.Abs(pasos))
        NumericUpDown17.Value = (8 * (Math.Abs(pasos))) + 1
        NumericUpDown18.Value = 9 * (Math.Abs(pasos))
        NumericUpDown19.Value = (9 * (Math.Abs(pasos))) + 1
        NumericUpDown20.Value = maxvalue
        FileClose(1)
errorhandler:
        Exit Sub
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        aper = True
        Dim saveFileDialog5 As New SaveFileDialog()
        saveFileDialog5.ShowDialog()
        On Error GoTo errorhandler
        FileOpen(15, saveFileDialog5.FileName, OpenMode.Output)
errorhandler:
        Exit Sub

    End Sub


    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim MyDialog As New ColorDialog()
        ' Keeps the user from selecting a custom color.
        MyDialog.AllowFullOpen = False
        ' Allows the user to get help. (The default is false.)
        MyDialog.ShowHelp = True
        ' Sets the initial color select to the current text color,
        MyDialog.Color = Button4.BackColor

        ' Update the text box color if the user clicks OK 
        If (MyDialog.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            Button4.BackColor = MyDialog.Color
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim MyDialog As New ColorDialog()
        ' Keeps the user from selecting a custom color.
        MyDialog.AllowFullOpen = False
        ' Allows the user to get help. (The default is false.)
        MyDialog.ShowHelp = True
        ' Sets the initial color select to the current text color,
        MyDialog.Color = Button5.BackColor

        ' Update the text box color if the user clicks OK 
        If (MyDialog.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            Button5.BackColor = MyDialog.Color
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dim MyDialog As New ColorDialog()
        ' Keeps the user from selecting a custom color.
        MyDialog.AllowFullOpen = False
        ' Allows the user to get help. (The default is false.)
        MyDialog.ShowHelp = True
        ' Sets the initial color select to the current text color,
        MyDialog.Color = Button6.BackColor

        ' Update the text box color if the user clicks OK 
        If (MyDialog.ShowDialog() = Windows.Forms.DialogResult.OK) Then
            Button6.BackColor = MyDialog.Color
        End If
    End Sub




    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        FileClose(6)

        Dim nx As Double
        Dim ny As Double
        Dim x1 As Double
        Dim y1 As Double
        Dim z1 As Double
        Dim ta As Double
        Dim td As Double
        Dim difere As Single
        Dim pasos As Integer
        Dim points As Point
        Dim con As Integer
        Dim con2 As Integer
        Dim ps1 As Integer
        Dim ps2 As Integer
        ps1 = 5
        ps2 = 5
        formeGraphics = Me.CreateGraphics()
        'zoomx = 250
        zoomy = 50
        radi = 600
        radi2 = radi / 2
        formeGraphics.FillEllipse(Brushes.White, zoomx, zoomy, radi + 0, radi + 0)
        If CheckBox1.Checked = False Then
            NumericUpDown21.Value = maxvalue
            NumericUpDown22.Value = minvalue
            '   NumericUpDown1.Value = minvalue
        End If
        If CheckBox1.Checked = True Then
            maxvalue = NumericUpDown21.Value
            minvalue = NumericUpDown22.Value
            difere = maxvalue - minvalue
            pasos = maxvalue / 10
            pasos = difere / 10
            NumericUpDown2.Value = Math.Abs(pasos)
            NumericUpDown3.Value = Math.Abs(pasos) + 1
            NumericUpDown4.Value = 2 * (Math.Abs(pasos))
            NumericUpDown5.Value = 2 * (Math.Abs(pasos)) + 1
            NumericUpDown6.Value = 3 * (Math.Abs(pasos))
            NumericUpDown7.Value = (3 * (Math.Abs(pasos))) + 1
            NumericUpDown8.Value = 4 * (Math.Abs(pasos))
            NumericUpDown9.Value = (4 * (Math.Abs(pasos))) + 1
            NumericUpDown10.Value = 5 * (Math.Abs(pasos))
            NumericUpDown11.Value = (5 * (Math.Abs(pasos))) + 1
            NumericUpDown12.Value = 6 * (Math.Abs(pasos))
            NumericUpDown13.Value = (6 * (Math.Abs(pasos))) + 1
            NumericUpDown14.Value = 7 * (Math.Abs(pasos))
            NumericUpDown15.Value = (7 * (Math.Abs(pasos))) + 1
            NumericUpDown16.Value = 8 * (Math.Abs(pasos))
            NumericUpDown17.Value = (8 * (Math.Abs(pasos))) + 1
            NumericUpDown18.Value = 9 * (Math.Abs(pasos))
            NumericUpDown19.Value = (9 * (Math.Abs(pasos))) + 1
            NumericUpDown20.Value = maxvalue
        End If
        For con = 1 To 360
            For con2 = 0 To 89
                ta = (con - 180) * (Math.PI / 180)
                td = (90 - con2) * (Math.PI / 180)
                z1 = -(Math.Sin(td))
                x1 = Math.Cos(td) * Math.Cos(ta)
                y1 = Math.Cos(td) * Math.Sin(ta)
                nx = 1 * (y1 * Math.Sqrt(1 / (1 - z1)))
                ny = -1 * (x1 * Math.Sqrt(1 / (1 - z1)))
                points.X = radi2 * nx + zoomx + radi2 - 2
                points.Y = radi2 * ny + zoomy + radi2 - 2
                '  If pas = True And con = 360 Then marc(360, con2) = marc(360, con2) + marc(0, con2)
                ' If con = 360 Then
                ' If marc Then
                ' End If
                pas = False
                Select Case marc(con, con2)
                    Case NumericUpDown1.Value To NumericUpDown2.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Lime, points.X, points.Y, ps1, ps2)
                        ' Me.CreateGraphics.Dispose()
                    Case NumericUpDown3.Value To NumericUpDown4.Value
                        Me.CreateGraphics.FillEllipse(Brushes.GreenYellow, points.X, points.Y, ps1, ps2)
                        'Me.CreateGraphics.Dispose()
                    Case NumericUpDown5.Value To NumericUpDown6.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Yellow, points.X, points.Y, ps1, ps2)
                        ' Me.CreateGraphics.Dispose()
                    Case NumericUpDown7.Value To NumericUpDown8.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Orange, points.X, points.Y, ps1, ps2)
                        '  Me.CreateGraphics.Dispose()
                    Case NumericUpDown9.Value To NumericUpDown10.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Red, points.X, points.Y, ps1, ps2)
                        ' Me.CreateGraphics.Dispose()
                    Case NumericUpDown11.Value To NumericUpDown12.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Fuchsia, points.X, points.Y, ps1, ps2)
                        '  Me.CreateGraphics.Dispose()
                    Case NumericUpDown13.Value To NumericUpDown14.Value
                        Me.CreateGraphics.FillEllipse(Brushes.DarkViolet, points.X, points.Y, ps1, ps2)
                        '  Me.CreateGraphics.Dispose()
                    Case NumericUpDown15.Value To NumericUpDown16.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Blue, points.X, points.Y, ps1, ps2)
                        ' Me.CreateGraphics.Dispose()
                    Case NumericUpDown17.Value To NumericUpDown18.Value
                        Me.CreateGraphics.FillEllipse(Brushes.LightSkyBlue, points.X, points.Y, ps1, ps2)
                        'Me.CreateGraphics.Dispose()
                    Case NumericUpDown19.Value To NumericUpDown20.Value
                        Me.CreateGraphics.FillEllipse(Brushes.Cyan, points.X, points.Y, ps1, ps2)
                        'Me.CreateGraphics.Dispose()
                    Case Else
                        con = con
                End Select
            Next con2
        Next con
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy, zoomx + radi2, zoomy - 20)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2 - 10, zoomy + radi2, zoomx + radi2 + 10, zoomy + radi2)
        formeGraphics.DrawLine(Pens.Black, zoomx + radi2, zoomy + radi2 - 10, zoomx + radi2, zoomy + radi2 + 10)
        'formeGraphics.Dispose()
errorhandler:
        Exit Sub
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        aper = False
        FileClose(15)
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Form13_Load_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        FileClose(15)
        aper = False
    End Sub

    Private Sub Form13_Move(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Move

    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        zoomx = zoomx + 100
    End Sub

    Private Sub Button14_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Button14.Paint

    End Sub

    Private Sub Form13_Paint(ByVal sender As Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Me.Paint

    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        Dim i2 As Double
        Dim j2 As Double
        Dim k2 As Double
        Dim azi2 As Double
        Dim di2 As Double
        Dim ang As Double
        If prval2 = False Then
            azi2 = Label11.Text
            di2 = Label10.Text
            azi2 = (azi2 * Math.PI) / 180
            di2 = (di2 * Math.PI) / 180
            i2 = Math.Sin(azi2)
            j2 = Math.Cos(azi2)
            k2 = Math.Sqrt(((i2 * i2) + (j2 * j2)) / (Math.Tan(di2) * (Math.Tan(di2))))
            If k2 > 100000 Then k2 = 99999.999999999
            If azi2 = 0 And di2 = 0 Then
                i2 = 0
                j2 = 0
                k2 = 0
            End If
            prval2 = True
        End If
        ang = Math.Acos(Math.Abs(((i * i2) + (j * j2) + (k * k2)) / (Math.Sqrt((i * i) + (j * j) + (k * k)) * Math.Sqrt((i2 * i2) + (j2 * j2) + (k2 * k2)))))
        ang = (ang * 180) / Math.PI
        Label12.Text = Format(ang, "0.00")

    End Sub
End Class
