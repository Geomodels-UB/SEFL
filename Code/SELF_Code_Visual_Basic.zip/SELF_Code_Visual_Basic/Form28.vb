﻿Public Class Form28

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ScanlinefromMorphology()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        openFileDialog4.Multiselect = True
        '******Fi dimensionament*********
        '******obrir fitxer projeccio**************
        openFileDialog4.Title = "Calculate SpaceLine From Morphology File"
        openFileDialog4.InitialDirectory = Form10.TextBox1.Text
        openFileDialog4.ShowDialog()
        TextBox4.Text = openFileDialog4.FileName
    End Sub

    Private Sub Form28_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        i = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            i = 0
            j = 0
            k = 0
        End If
        TextBox1.Text = i
        TextBox2.Text = j
        TextBox3.Text = k
    End Sub

    Private Sub NumericUpDown1_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles NumericUpDown1.ValueChanged
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        i = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            i = 0
            j = 0
            k = 0
        End If
        TextBox1.Text = i
        TextBox2.Text = j
        TextBox3.Text = k
    End Sub

    Private Sub NumericUpDown2_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles NumericUpDown2.ValueChanged
        Dim i As Double
        Dim j As Double
        Dim k As Double
        Dim azi As Double
        Dim di As Double

        azi = Me.NumericUpDown1.Value
        di = Me.NumericUpDown2.Value
        azi = (azi * Math.PI) / 180
        di = (di * Math.PI) / 180
        i = Math.Sin(azi)
        j = Math.Cos(azi)
        k = Math.Sqrt(((i * i) + (j * j)) / (Math.Tan(di) * (Math.Tan(di))))
        If k > 100000 Then k = 99999.999999999
        If azi = 0 And di = 0 Then
            i = 0
            j = 0
            k = 0
        End If
        TextBox1.Text = i
        TextBox2.Text = j
        TextBox3.Text = k
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        P10()

    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Dim openFileDialog2 As New OpenFileDialog()
        '******obrir fitxer properties**************
        openFileDialog2.Title = "Read ScanLine Properties"
        openFileDialog2.InitialDirectory = Form10.TextBox1.Text
        openFileDialog2.ShowDialog()
        TextBox6.Text = openFileDialog2.FileName
        direccioPropert = openFileDialog2.FileName
        openFileDialog2.InitialDirectory = TextBox6.Text
        Button3.Enabled = True
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim openFileDialog5 As New OpenFileDialog()
        Dim dummy As Double
        Dim dummy1 As Integer
        Dim conta As Integer = 0
        Dim fami As String = ""
        '******obrir fitxer projeccio**************
        openFileDialog5.Title = "Read Morphology File"
        openFileDialog5.InitialDirectory = Form10.TextBox1.Text
        openFileDialog5.ShowDialog()
        TextBox5.Text = openFileDialog5.FileName
        direccioMorpho = openFileDialog5.FileName
        FileOpen(1, openFileDialog5.FileName, OpenMode.Input)
        Do Until EOF(1)
            Input(1, dummy) 'x
            Input(1, dummy) 'y
            Input(1, dummy) 'z
            Input(1, dummy) 'i
            Input(1, dummy) 'j
            Input(1, dummy) 'k
            Input(1, dummy) 'azi
            Input(1, dummy) 'dip
            Input(1, dummy) 'M
            Input(1, dummy) 'K
            Input(1, dummy1) 'Population
            Input(1, dummy1) 'Number
            Input(1, dummy) 'Rugosity
            Input(1, dummy) 'Long
            Input(1, dummy) 'Wide
            Input(1, dummy) 'Area
            Input(1, fami) 'Family
            ReDim Preserve FracturSet(conta)
            FracturSet(conta) = fami
            conta += 1
        Loop
        Array.Sort(FracturSet)
        ' Dim numsets As IEnumerable(Of String) = FracturSet.Distinct()
        Dim numa As Integer
        numsets = FracturSet.Distinct()
        numse = numsets.Count
        ReDim FracturSet(0)
        If TextBox4.Text <> "" And TextBox5.Text <> "" Then Button1.Enabled = True
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Me.Close()
        Form9.Show()
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Form30.Show()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Prova()
    End Sub
End Class