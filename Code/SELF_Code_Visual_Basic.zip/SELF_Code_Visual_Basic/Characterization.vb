﻿Imports System
Imports System.IO
Imports Microsoft.Office.Interop

Module Characterization
    Dim finalpath1 As String
    Public myPoints() As String
    Public FS() As String
    Public dlg As New System.Windows.Forms.OpenFileDialog()
    Public infoReader1, infoReader2, inforeader3 As System.IO.FileInfo
    Public CSV_FileName1, CSV_FileName2 As String
    Public Cxt, Cyt, Czt, vector_it, vector_jt, vector_kt As New List(Of Double)
    Public orient, pendt, M1t, K1t, Populationt As New List(Of Double)
    Public Numbert, Rugosityt, Widet, Longt, Areat, Pointscx, Pointscy, Pointscz, MUnumber, MUtemporal As New List(Of Double)
    Public Cxtemp, Cytemp, Cztemp, orientemp, vector_itemp, vector_jtemp, vector_ktemp As New List(Of Double)
    Public PointsName As New List(Of String)
    Public PointsAzi, PointsBed, Pointsi, Pointsj, Pointsk As New List(Of Double)
    Public FracturSett As New List(Of String)
    Public Set2t, MUt As New List(Of Integer)
    Public Usefult As New List(Of Boolean)
    Public statust As Integer
    Public FraMUset(,) As Integer
    Public indi As Integer
    Public stateUM As Boolean
    Public oldCI As System.Globalization.CultureInfo
    Public oldCI2 As System.Globalization.CultureInfo
    Public x_out, y_out, z_out, i_out, j_out, k_out As New List(Of Double)
    Public oExcel As Excel.Application
    Public oBook As Excel.Workbook
    Public oSheet As Excel.Worksheet
    Public pxSL(), pySL(), pzSL() As Double
    Public pxSLtemp(), pySLtemp(), pzSLtemp() As Double
    Public HeightMU(), ExtensionMU(), AreaMU(), sumat() As Double
    Public seleccio2(,) As Integer
    Public seleccio4(,) As Boolean
    Public P22Area(,) As Double
    Public P22Set(,) As String
    Public nfp22 As Integer
    Public areatotalUM() As Double
    Dim vxwell(), vywell(), vzwell() As Double
    Dim pwellx, pwelly, pwellz As Double
    Public pwx, pwy, pwz, well As New List(Of Double)
    Public setw As New List(Of String)
    Public impfrac(), impSupfrac(), impInffrac() As Boolean
    Dim orienSL() As Double
    Dim pendSL() As Double
    Public twell As New List(Of Double)
    Public twell1 As New List(Of Double)
    Public log(,) As Double
    Public Setlog(,) As String
    Public NumeroDeSets As Integer



    Public Sub readCSVPoints1()
        Dim inputRecord As String = Nothing
        Dim LastNonEmpty As Integer = -1
        'lectura fitxers fractures
        Dim inReader As StreamReader = File.OpenText(CSV_FileName1)
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            logbytes = inputRecord.Length + logbytes
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                Cxt.Add(CDbl(myPoints(0).Trim))
                Cyt.Add(CDbl(myPoints(1).Trim))
                Czt.Add(CDbl(myPoints(2).Trim))
                vector_it.Add(CDbl(myPoints(3).Trim))
                vector_jt.Add(CDbl(myPoints(4).Trim))
                vector_kt.Add(CDbl(myPoints(5).Trim))
                orient.Add(CDbl(myPoints(6).Trim))
                pendt.Add(CDbl(myPoints(7).Trim))
                M1t.Add(CDbl(myPoints(8).Trim))
                K1t.Add(CDbl(myPoints(9).Trim))
                Populationt.Add(CDbl(myPoints(10).Trim))
                Numbert.Add(CDbl(myPoints(11).Trim))
                Rugosityt.Add(CDbl(myPoints(12).Trim))
                Widet.Add(CDbl(myPoints(13).Trim)) 'Es la longitut, length
                Longt.Add(CDbl(myPoints(14).Trim))  'Es la alçada, height
                Areat.Add(CDbl(myPoints(15).Trim))
                FracturSett.Add(CStr(myPoints(16).Trim))
                Set2t.Add(0)
                MUt.Add(0)
                Usefult.Add(False)
            End If
            LastNonEmpty = -1
            inputRecord = inReader.ReadLine()
        End While

        ' averigüem el número de families
        FS = FracturSett.ToArray()
        numsets = FS.Distinct()
        numse = numsets.Count
        Form32.TextBox6.Text = numse
        FS = Nothing
        Form32.TextBox14.Text = Cxt.count
        MsgBox("Fractures loaded")
        'conta es el número de fractures
    End Sub
    Public Sub readCSVPoints2() '(ByVal CSV_FileName2 As String)
        logbytes = 0
        Dim inputRecord As String = Nothing
        Dim LastNonEmpty As Integer = -1
        Dim inReader As StreamReader = File.OpenText(CSV_FileName2)
        Dim carro1, carro2 As Double
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            logbytes = inputRecord.Length + logbytes
            If inputRecord.Contains(" ") Then
                myPoints = inputRecord.Split
                For i As Integer = 0 To myPoints.Length - 1
                    If myPoints(i) <> "" Then
                        LastNonEmpty += 1
                        myPoints(LastNonEmpty) = myPoints(i)
                    End If
                Next i
                If stateUM = True Then Form32.ListBox1.Items.Add(inputRecord)
                PointsName.Add(myPoints(0).Trim)
                Pointscx.Add(CDbl(myPoints(1).Trim))
                Pointscy.Add(CDbl(myPoints(2).Trim))
                Pointscz.Add(CDbl(myPoints(3).Trim))
                PointsAzi.Add(CDbl(myPoints(4).Trim))
                PointsBed.Add(CDbl(myPoints(5).Trim))

                carro1 = Math.Pow(CDbl(myPoints(6).Trim), 2) + Math.Pow(CDbl(myPoints(7).Trim), 2) + Math.Pow(CDbl(myPoints(8).Trim), 2)
                carro2 = Math.Sqrt(carro1)

                Pointsi.Add(CDbl(myPoints(6).Trim) / carro2)
                Pointsj.Add(CDbl(myPoints(7).Trim) / carro2)
                Pointsk.Add(CDbl(myPoints(8).Trim) / carro2)
                '  Pointsi.Add(CDbl(myPoints(6).Trim))
                '  Pointsj.Add(CDbl(myPoints(7).Trim))
                '  Pointsk.Add(CDbl(myPoints(8).Trim))

            End If
            LastNonEmpty = -1
            inputRecord = inReader.ReadLine()
        End While
        MsgBox("Planes Position loaded")
    End Sub
    Sub cal_Punt_mitg()
        ' Dim x_out, y_out, z_out, i_out, j_out, k_out As New List(Of Double)
        FraMUset = Nothing
        Dim pmx, pmy, pmz As Double
        Dim vit, vjt, vkt As Double
        Dim vri, vrj, vrk As Double
        Dim D As Double
        Dim t1(Pointscx.Count - 1), t1b(Pointscx.Count - 1), t2(Pointscx.Count - 1), t2b(Pointscx.Count - 1), t3(Cxt.Count - 1) As Double
        'vector pla de Bedding
        vit = CDbl(Form32.TextBox3.Text)
        vjt = CDbl(Form32.TextBox4.Text)
        vkt = CDbl(Form32.TextBox5.Text)
        'Punt de la recta
        pmx = Pointscx.Average
        pmy = Pointscy.Average
        pmz = Pointscz.Average
        'vector de la recta
        vri = 0
        vrj = 0
        vrk = 1
        'Recta vertical per tallar els plans, si es inferior al número de plans no els talla i passem a horitzontal
        For i = 0 To Pointscx.Count - 1
            D = -(vit * Pointscx(i)) - (vjt * Pointscy(i)) - (vkt * Pointscz(i))
            t1(i) = (-D - (vit * pmx) - (vjt * pmy) - (vkt * pmz)) / ((vit * vri) + (vjt * vrj) + (vkt * vrk))
        Next
        If t1(0) = Nothing Then
            vri = 1
            vrj = 1
            vrk = 0
            For i = 0 To Pointscx.Count - 1
                D = -(vit * Pointscx(i)) - (vjt * Pointscy(i)) - (vkt * Pointscz(i))
                t1(i) = (-D - (vit * pmx) - (vjt * pmy) - (vkt * pmz)) / ((vit * vri) + (vjt * vrj) + (vkt * vrk))
            Next
        End If
        Form32.ProgressBar1.Value = 10
        Form32.ProgressBar1.Refresh()
        'ordenar t1 de menor a pequeño i asignar nombre de la UM
        Array.Copy(t1, t1b, t1.Length)
        Array.Sort(t1b)
        ' dimensionar la variable donde esta MU por set, t.count numse
        FraMUset = Nothing
        ReDim FraMUset(t1.Count, CDbl(numse - 1))

        Dim ordre As Integer
        Dim numero As Integer
        Dim numeroMax As Integer = 0
        Dim SLup, SLdw As Integer
        Dim SLdist(Cxt.Count - 1), D1 As Double
        Dim Dist0MU(Cxt.Count - 1), DistnMU(Cxt.Count - 1) As Double ' aqui es calcula el gruix de cada MU amb els punts que defineixen les UM i els plans paral·lels al bedding
        For indi = 0 To Cxt.Count - 1      'aqui se mira cada fractura
            For ii = 0 To Pointscx.Count - 1    'Por cada UM
                D = -(vit * Pointscx(ii)) - (vjt * Pointscy(ii)) - (vkt * Pointscz(ii))
                t2(ii) = (-D - (vit * Cxt(indi)) - (vjt * Cyt(indi)) - (vkt * Czt(indi))) / ((vit * vri) + (vjt * vrj) + (vkt * vrk))
                ' t2(ii) = ((vit * (Cxt(indi) - Pointscx(ii))) + (vjt * (Cyt(indi) - Pointscy(ii))) + (vkt * (Czt(indi) - Pointscz(ii)))) / ((vit * vit) + (vjt * vjt) + (vkt * vkt))  ' se calcula la recta fractura-cada UM
                t2b(ii) = Math.Abs(t2(ii)) 'Se le quita el signo a la recta fractura-UM
            Next
            ' Aquí s'ubica la fractura en la seva UM. s'ha calculat i s'ha de quedar amb la menor tenint en compte el sentit
            ordre = Array.IndexOf(t2b, t2b.Min) 'obtencion de la más pequeña sin signo, se mira cual es la de arriba y la de abajo y se ubica
            If Math.Sign(t2(ordre)) < 0 And ordre > 0 Then ordre += 1 'math.sign: less 0: -1; 0=0; greater 0; 1
            Select Case FracturSett(indi)
                Case "Set_I"
                    numero = 0
                Case "Set_II"
                    numero = 1
                Case "Set_III"
                    numero = 2
                Case "Set_IV"
                    numero = 3
                Case "Set_V"
                    numero = 4
                Case "Set_VI"
                    numero = 5
                Case "Set_VII"
                    numero = 6
                Case "Set_VIII"
                    numero = 7
                Case Else
                    numero = 8
            End Select
            If numero > numeroMax Then numeroMax = numero
            FraMUset(ordre, numero) += 1
            '  añadir un campo con la UM (integer)
            Set2t.Item(indi) = numero
            MUt.Item(indi) = ordre
            'scanlines de arriba y de abajo
            t3(indi) = ((vit * (Cxt(indi) - pmx)) + (vjt * (Cyt(indi) - pmy)) + (vkt * (Czt(indi) - pmz))) / ((vit * vit) + (vjt * vjt) + (vkt * vkt))  ' se calcula la recta fractura-cada UM
        Next
        Form32.ProgressBar1.Value = 40
        Form32.ProgressBar1.Refresh()
        Dim SLtop, SLbot As Boolean
        Dim sl, slu, sld As Integer
        'Calcul dels Scanlines Quatre scenaris: factures contingudes en els límits establerts, que sobrepasi per adalt, per abaix, o per les dues
        Dim n As Integer
        For n = 0 To numeroMax ' aqui es mira si han fractures sobre el primer límit superior
            If FraMUset(0, n) > 0 Then
                SLtop = True
            End If
        Next
        For n = 0 To numeroMax ' aqui es mira si han fractures sota el darrer límit inferior
            If FraMUset(Pointscx.Count, n) > 0 Then
                SLbot = True
            End If
        Next
        If SLtop = True Then slu = slu + 2
        If SLbot = True Then sld = sld + 2
        sl = slu + sld + (Pointscx.Count - 1) + (Pointscx.Count - 1)
        Form32.ProgressBar1.Value = 60
        Form32.ProgressBar1.Refresh()
        ' Dim pxSLtemp(sl), pySLtemp(sl), pzSLtemp(sl) As Double 'es dimensionen els plans
        ReDim Preserve pxSLtemp(sl)
        ReDim Preserve pySLtemp(sl)
        ReDim Preserve pzSLtemp(sl)



        If SLtop = True Then
            SLup = Array.IndexOf(t3, t3.Max) 'els punts són Cxt(SLup), Cyt(SLup), Czt(SLup)
            pxSLtemp(0) = Cxt(SLup)
            pySLtemp(0) = Cyt(SLup)
            pzSLtemp(0) = Czt(SLup)
        End If
        If SLbot = True Then
            SLdw = Array.IndexOf(t3, t3.Min) 'els punts són Cxt(SLdw), Cyt(SLdw), Czt(SLdw)
            pxSLtemp(sl) = Cxt(SLdw)
            pySLtemp(sl) = Cyt(SLdw)
            pzSLtemp(sl) = Czt(SLdw)
        End If

        'Calcul dels Scanlines intermitjos
        Dim t1c As Double
        For i = 0 To Pointscx.Count - 1
            pxSLtemp((i * 2) + slu) = (t1(i) * vri) + pmx
            pySLtemp((i * 2) + slu) = (t1(i) * vrj) + pmy
            pzSLtemp((i * 2) + slu) = (t1(i) * vrk) + pmz

            If i < Pointscx.Count - 1 Then
                t1c = t1(i) - ((t1(i) - t1(i + 1)) / 2)
                pxSLtemp((i * 2) + slu + 1) = (t1c * vri) + pmx
                pySLtemp((i * 2) + slu + 1) = (t1c * vrj) + pmy
                pzSLtemp((i * 2) + slu + 1) = (t1c * vrk) + pmz
            End If
        Next
        If SLtop = True Then
            pxSLtemp(1) = (pxSLtemp(0) + pxSLtemp(2)) / 2
            pySLtemp(1) = (pySLtemp(0) + pySLtemp(2)) / 2
            pzSLtemp(1) = (pzSLtemp(0) + pzSLtemp(2)) / 2
        End If

        If SLbot = True Then
            pxSLtemp(sl - 1) = pxSLtemp(sl) + (pxSLtemp(sl) - pxSLtemp(sl - 2)) / 2
            pySLtemp(sl - 1) = pySLtemp(sl) + (pySLtemp(sl) - pySLtemp(sl - 2)) / 2
            pzSLtemp(sl - 1) = pzSLtemp(sl) + (pzSLtemp(sl) - pzSLtemp(sl - 2)) / 2
        End If
        Dim origen1, origen2 As Integer
        ReDim Preserve HeightMU((Pointscx.Count - 2) + (slu / 2) + (sld / 2)) ' aqui es calcula el gruix de cada MU amb els punts que defineixen les UM i els plans paral·lels al bedding

        'alçada del primer extrainterval MU
        If SLtop = True Then
            D1 = -(vit * Cxt(SLup)) - (vjt * Cyt(SLup)) - (vkt * Czt(SLup))
            HeightMU(0) = ((Math.Abs((vit * Pointscx.Item(0)) + (vjt * Pointscy.Item(0)) + (vkt * Pointscz.Item(0)) + D1)) / (Math.Sqrt((Math.Pow(vit, 2)) + (Math.Pow(vjt, 2)) + (Math.Pow(vkt, 2)))))
            origen1 = 1
            'PointsName.Add("MU_" & (PointsName.Count))
        End If
        'alçada del darrer extrainterval MU
        If SLbot = True Then
            D1 = -(vit * Cxt(SLdw)) - (vjt * Cyt(SLdw)) - (vkt * Czt(SLdw))
            HeightMU(HeightMU.Count - 1) = ((Math.Abs((vit * Pointscx.Item(Pointscx.Count - 1)) + (vjt * Pointscy.Item(Pointscx.Count - 1)) + (vkt * Pointscz.Item(Pointscx.Count - 1)) + D1)) / (Math.Sqrt((Math.Pow(vit, 2)) + (Math.Pow(vjt, 2)) + (Math.Pow(vkt, 2)))))
            origen2 = 1
        End If
        'alçades dels intervals MU
        For i = 0 To Pointscx.Count - 2  '***********PROBLEM
            D1 = -(vit * Pointscx.Item(i + 1)) - (vjt * Pointscy.Item(i + 1)) - (vkt * Pointscz.Item(i + 1))
            HeightMU(origen1 + i) = ((Math.Abs((vit * Pointscx.Item(i)) + (vjt * Pointscy.Item(i)) + (vkt * Pointscz.Item(i)) + D1)) / (Math.Sqrt((Math.Pow(vit, 2)) + (Math.Pow(vjt, 2)) + (Math.Pow(vkt, 2)))))
        Next
        ReDim Preserve ExtensionMU((Pointscx.Count - 1) + slu + sld)
        ReDim Preserve AreaMU((Pointscx.Count - 1) + slu + sld)

        Form32.ProgressBar1.Value = 75
        Form32.ProgressBar1.Refresh()




        Dim NumFracSet((((Pointscx.Count - 1) + slu + sld) * numse) - 1), NumFrac2((((Pointscx.Count - 1) + slu + sld) * numse) - 1) As Double
        ReDim Preserve sumat((((Pointscx.Count - 1) + slu + sld) * numse) - 1)
        'Calcular la orientación del afloramiento en cada UM
        For ii = 0 To ((Pointscx.Count - 1) + (slu / 2) + (sld / 2)) - 1    ' número de UM
            For iii = 0 To Cxt.Count - 1     'número de fractures
                If MUt(iii) = ii Then   'es mira la seva UM
                    NumFracSet((ii * numse) + Set2t(iii)) += 1
                    If Areat((ii * numse) + Set2t(iii)) >= CDbl(Form32.NumericUpDown3.Value) Then
                        Cxtemp.Add(Cxt(iii))
                        Cytemp.Add(Cyt(iii))
                        Cztemp.Add(Czt(iii))
                        orientemp.Add(orient(iii))
                        vector_itemp.Add(vector_it(iii))
                        vector_jtemp.Add(vector_jt(iii))
                        vector_ktemp.Add(vector_kt(iii))
                        sumat((ii * numse) + Set2t(iii)) = sumat((ii * numse) + Set2t(iii)) + Longt(iii)
                        NumFrac2((ii * numse) + Set2t(iii)) += 1
                    End If
                End If
            Next


            Dim dif, dif1 As Double
            If Cxtemp.Count <> 0 Then
                xmean = Cxtemp.Average
                ymean = Cytemp.Average
                zmean = Cztemp.Average
                For i = 0 To orientemp.Count - 1
                    dif = Math.Abs(orientemp(i) - 360)
                    dif1 = orientemp(0) - dif
                    If dif1 > 100 Then bipolar = True
                Next
                'End Fisher Bingham Test
                'Calcul de la orientació
                Select Case bipolar
                    Case True
                        vectorotcrop(vector_itemp, vector_jtemp, vector_ktemp) ' Principal Mean direction
                    Case False
                        meandir(vector_itemp, vector_jtemp, vector_ktemp) ' Mean Direction
                End Select
                'ExtensionMU(ii) = Math.Sqrt(Math.Pow((Cxtemp.Max - Cxtemp.Min), 2) + Math.Pow((Cytemp.Max - Cytemp.Min), 2) + Math.Pow((Cztemp.Max - Cztemp.Min), 2))
                ExtensionMU(ii) = 1
                AreaMU(ii) = HeightMU(ii) * ExtensionMU(ii)
                x_out.Add(xmean)
                y_out.Add(ymean)
                z_out.Add(zmean)
                i_out.Add(Vec1)
                j_out.Add(Vec2)
                k_out.Add(Vec3)
                Cxtemp.Clear()
                Cytemp.Clear()
                Cztemp.Clear()
                orientemp.Clear()
                vector_itemp.Clear()
                vector_jtemp.Clear()
                vector_ktemp.Clear()
            Else                        'MU que no tienen fracturas
                x_out.Add(Cxt.Average) 'a cegues
                y_out.Add(Cyt.Average)
                z_out.Add(Czt.Average)
                i_out.Add(Vec1)
                j_out.Add(Vec2)
                k_out.Add(Vec3)
            End If
        Next
        Form32.ProgressBar1.Value = 90
        Form32.ProgressBar1.Refresh()
        'PrintFileTemporal
        FileOpen(2, Form10.TextBox1.Text + "MU_Properties_internal.txt", OpenMode.Output) 'sortida
        ' mucount = ((Pointscx.Count - 2) + (slu / 2) + (sld / 2))
        mucount = ((Pointscx.Count - 1) + (slu / 2) + (sld / 2))
        ReDim Preserve pxSL(mucount)
        ReDim Preserve pySL(mucount)
        ReDim Preserve pzSL(mucount)

        ReDim Preserve Dsl(mucount)
        ReDim Preserve Dslupp(mucount)
        ReDim Preserve Dsllow(mucount)
        ReDim Preserve vxwell(mucount)
        ReDim Preserve vywell(mucount)
        ReDim Preserve vzwell(mucount)
        For i = 0 To (mucount - 1) - origen2
            '     For i = 0 To ((Pointscx.Count - 2) + (slu / 2) + (sld / 2))
            PrintLine(2, PointsName(i))
            PrintLine(2, "Outcrop orientation")
            PrintLine(2, Format(i_out.Item(i), "0.0000"), Format(j_out.Item(i), "0.0000"), Format(k_out.Item(i), "0.0000"), Format(x_out.Item(i), "0.0000"), Format(y_out.Item(i), "0.000"), Format(z_out.Item(i), "0.000"))
            PrintLine(2, "ScanLine")
            PrintLine(2, Pointsi.Item(i), Pointsj.Item(i), Pointsk.Item(i), pxSLtemp((i * 2) + 1), pySLtemp((i * 2) + 1), pzSLtemp((i * 2) + 1))
            Dsl(i) = -(Pointsi.Item(i) * pxSLtemp((i * 2) + 1)) - (Pointsj.Item(i) * pySLtemp((i * 2) + 1)) - (Pointsk.Item(i) * pzSLtemp((i * 2) + 1))
            pxSL(i) = pxSLtemp((i * 2) + 1) : pySL(i) = pySLtemp((i * 2) + 1) : pzSL(i) = pzSLtemp((i * 2) + 1)
            PrintLine(2, "SL(Upper)")
            PrintLine(2, Pointsi.Item(i), Pointsj.Item(i), Pointsk.Item(i), pxSLtemp(i * 2), pySLtemp(i * 2), pzSLtemp(i * 2))
            Dslupp(i) = -(Pointsi.Item(i) * pxSLtemp(i * 2)) - (Pointsj.Item(i) * pySLtemp(i * 2)) - (Pointsk.Item(i) * pzSLtemp(i * 2))

            PrintLine(2, "SL(Lower)")
            PrintLine(2, Pointsi.Item(i), Pointsj.Item(i), Pointsk.Item(i), pxSLtemp((i * 2) + 2), pySLtemp((i * 2) + 2), pzSLtemp((i * 2) + 2))
            Dsllow(i) = -(Pointsi.Item(i) * pxSLtemp((i * 2) + 2)) - (Pointsj.Item(i) * pySLtemp((i * 2) + 2)) - (Pointsk.Item(i) * pzSLtemp((i * 2) + 2))

            PrintLine(2, "Height")
            PrintLine(2, HeightMU(i))
            PrintLine(2, "Extension")
            PrintLine(2, ExtensionMU(i))
            PrintLine(2, "Area")
            PrintLine(2, AreaMU(i))
            PrintLine(2, numsets.Count)
            For ii = 0 To numsets.Count - 1
                PrintLine(2, numsets(ii))
                PrintLine(2, FraMUset(i, ii), NumFrac2((i * (numsets.Count)) + ii), sumat((i * (numsets.Count)) + ii))
            Next
            PrintLine(2, " ")

            vxwell(i) = (j_out.Item(i) * k_out.Item(i)) - (k_out.Item(i) * (-i_out.Item(i))) ' - (Math.PI / 4)
            vywell(i) = (k_out.Item(i) * j_out.Item(i)) - (i_out.Item(i) * k_out.Item(i)) ' + (Math.PI / 6)
            vzwell(i) = (i_out.Item(i) * (-i_out.Item(i))) - (i_out.Item(i) * j_out.Item(i))           'Lectura de fractures i longitud de les fractures

        Next
        If sld > 0 Then
            PointsName.Add("New_UM")
            PrintLine(2, PointsName(PointsName.Count - 1))
            PrintLine(2, "Outcrop orientation")
            PrintLine(2, Format(i_out.Item(PointsName.Count - 1), "0.0000"), Format(j_out.Item(PointsName.Count - 1), "0.0000"), Format(k_out.Item(PointsName.Count - 1), "0.0000"), Format(x_out.Item(PointsName.Count - 1), "0.0000"), Format(y_out.Item(PointsName.Count - 1), "0.000"), Format(z_out.Item(PointsName.Count - 1), "0.000"))
            PrintLine(2, "ScanLine") '****************Comprobar points i, s'ha d'afegir un registre
            PrintLine(2, Pointsi.Item(0), Pointsj.Item(0), Pointsk.Item(0), pxSLtemp((PointsName.Count - 1 * 2) + 1), pySLtemp((PointsName.Count - 1 * 2) + 1), pzSLtemp((PointsName.Count - 1 * 2) + 1))
            Dsl(Pointsi.Count - 1) = -(Pointsi.Item(0) * pxSLtemp(((PointsName.Count - 1) * 2) + 1)) - (Pointsj.Item(0) * pySLtemp(((PointsName.Count - 1) * 2) + 1)) - (Pointsk.Item(0) * pzSLtemp(((PointsName.Count - 1) * 2) + 1))
            pxSL(mucount - origen2) = pxSLtemp(((PointsName.Count - 1) * 2) + 1) : pySL(mucount - origen2) = pySLtemp(((PointsName.Count - 1) * 2) + 1) : pzSL(mucount - origen2) = pzSLtemp(((PointsName.Count - 1) * 2) + 1)
            PrintLine(2, "SL(Upper)")
            PrintLine(2, Pointsi.Item(0), Pointsj.Item(0), Pointsk.Item(0), pxSLtemp((PointsName.Count - 1) * 2), pySLtemp((PointsName.Count - 1) * 2), pzSLtemp((PointsName.Count - 1) * 2))
            Dslupp(Pointsi.Count - 1) = -(Pointsi.Item(0) * pxSLtemp((PointsName.Count - 1) * 2)) - (Pointsj.Item(0) * pySLtemp((PointsName.Count - 1) * 2)) - (Pointsk.Item(0) * pzSLtemp((PointsName.Count - 1) * 2))

            PrintLine(2, "SL(Lower)")
            PrintLine(2, Pointsi.Item(0), Pointsj.Item(0), Pointsk.Item(0), pxSLtemp(((PointsName.Count - 1) * 2) + 2), pySLtemp(((PointsName.Count - 1) * 2) + 2), pzSLtemp(((PointsName.Count - 1) * 2) + 2))
            Dsllow(Pointsi.Count - 1) = -(Pointsi.Item(0) * pxSLtemp(((PointsName.Count - 1) * 2) + 2)) - (Pointsj.Item(0) * pySLtemp(((PointsName.Count - 1) * 2) + 2)) - (Pointsk.Item(0) * pzSLtemp(((PointsName.Count - 1) * 2) + 2))

            PrintLine(2, "Height")
            PrintLine(2, HeightMU(HeightMU.Count - 1))
            PrintLine(2, "Extension")
            PrintLine(2, ExtensionMU(HeightMU.Count - 1))
            PrintLine(2, "Area")
            PrintLine(2, AreaMU(HeightMU.Count - 1))
            PrintLine(2, numsets.Count)
            For ii = 0 To numsets.Count - 1
                PrintLine(2, numsets(ii))
                PrintLine(2, FraMUset(PointsName.Count - 1, ii), NumFrac2((PointsName.Count - 1 * (numsets.Count)) + ii), sumat((PointsName.Count - 1 * (numsets.Count)) + ii))
            Next
            PrintLine(2, " ")

            vxwell(PointsName.Count - 1) = (j_out.Item(PointsName.Count - 1) * k_out.Item(PointsName.Count - 1)) - (k_out.Item(PointsName.Count - 1) * (-i_out.Item(PointsName.Count - 1))) ' - (Math.PI / 4)
            vywell(PointsName.Count - 1) = (k_out.Item(PointsName.Count - 1) * j_out.Item(PointsName.Count - 1)) - (i_out.Item(PointsName.Count - 1) * k_out.Item(PointsName.Count - 1)) ' + (Math.PI / 6)
            vzwell(PointsName.Count - 1) = (i_out.Item(PointsName.Count - 1) * (-i_out.Item(PointsName.Count - 1))) - (i_out.Item(PointsName.Count - 1) * j_out.Item(PointsName.Count - 1))           'Lectura de fractures i longitud de les fractures


            Pointscx.Add(pxSL((PointsName.Count - 1 * 2) + 1))
            Pointscy.Add(pySL((PointsName.Count - 1 * 2) + 1))
            Pointscz.Add(pzSL((PointsName.Count - 1 * 2) + 1))
            ' PointsAzi.Add(CDbl(myPoints(4).Trim))
            '  PointsBed.Add(CDbl(myPoints(5).Trim))
            Pointsi.Add(Pointsi.Item(0))
            Pointsj.Add(Pointsj.Item(0))
            Pointsk.Add(Pointsk.Item(0))








        End If

        FileClose(2)
        ' MsgBox("Planes Position loaded")


    End Sub
    Sub FromDXTtoMorphology()
        logbytes = 0
        Dim inputRecord As String = Nothing
        Dim LastNonEmpty As Integer = -1
        Dim inReader As StreamReader = File.OpenText(CSV_FileName2)
        Dim cadena As String = ""
        Dim pos As Integer
        Dim fractursett2 As New List(Of String)
        cadena = CSV_FileName2

        If Form15.CheckBox1.Checked = False Then
            cadena = Form15.TextBox1.Text
            FileOpen(2, Form10.TextBox1.Text + "morphometry_" + cadena + ".txt", OpenMode.Output) 'sortida
        Else
            pos = InStrRev(CSV_FileName2, "\")
            cadena = Mid(CSV_FileName2, pos + 1, Len(CSV_FileName2) - pos - 4)
            ' cadena = Mid(CSV_FileName2, pos + 1, Len(CSV_FileName2) - pos)
            FileOpen(2, Form10.TextBox1.Text + "morphometry_" + cadena + ".txt", OpenMode.Output) 'sortida
            FileOpen(3, Form10.TextBox1.Text + "morphometry_" + cadena + "_Bedding" + ".txt", OpenMode.Output) 'sortida
            ' cadena = CSV_FileName2
        End If
        '  FileOpen(2, Form10.TextBox1.Text + "morphometry_" + cadena + ".txt", OpenMode.Output) 'sortida
        If Form15.CheckBox4.Checked = True Then
            PrintLine(2, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Length", "Height", "Area", "Set")
            PrintLine(3, "X", "Y", "Z", "A", "B", "C", "Azimuth", "Dip", "M", "K", "Population", "Number", "Rugosity", "Length", "Height", "Area", "Set")
        End If
        seleccio = 0
        intens2 = 2
        inputRecord = inReader.ReadLine()
        While (inputRecord IsNot Nothing)
            logbytes = inputRecord.Length + logbytes
            Select Case inputRecord
                Case "VERTEX"
                    ReDim Preserve x(seleccio)
                    ReDim Preserve y(seleccio)
                    ReDim Preserve z(seleccio)
                    ReDim Preserve escollits(seleccio)
                    inputRecord = inReader.ReadLine()
                    inputRecord = inReader.ReadLine()
                    FracturSett.Add(inputRecord)
                    inputRecord = inReader.ReadLine()
                    inputRecord = inReader.ReadLine()
                    x(seleccio) = (CDbl(inputRecord))
                    inputRecord = inReader.ReadLine()
                    inputRecord = inReader.ReadLine()
                    y(seleccio) = (CDbl(inputRecord))
                    inputRecord = inReader.ReadLine()
                    inputRecord = inReader.ReadLine()
                    z(seleccio) = (CDbl(inputRecord))
                    inputRecord = inReader.ReadLine()
                    inputRecord = inReader.ReadLine()
                    escollits(seleccio) = seleccio
                    If inputRecord = "SEQEND" Then
                        fractursett2.Add(FracturSett.Item(0))
                        attribdxf()
                        intens2 += 1
                        inputRecord = inReader.ReadLine()
                    End If

                    seleccio += 1
                Case "POLYGONE"

                Case Else
                    LastNonEmpty = -1
                    inputRecord = inReader.ReadLine()
            End Select
        End While
        FileClose(3)
        FileClose(2)
        FileClose(1)
        FS = fractursett2.ToArray()
        numsets = FS.Distinct()
        nSets = numsets.Count
        ' Form32.TextBox6.Text = numse
        MsgBox("DXF File loaded")
    End Sub


    Private Function AsignarSets(ByVal FracturSett() As String) As Integer

        Select Case FracturSett(indi)
            Case "Set_I" Or "SetI"
                Return 0
            Case "Set_II" Or "SetII"
                Return 1
            Case "Set_III" Or "SetIII"
                Return 2
            Case "Set_IV" Or "SetIV"
                Return 3
            Case "Set_V" Or "SetV"
                Return 4
            Case "Set_VI" Or "SetVI"
                Return 5
            Case "Set_VII" Or "SetVII"
                Return 6
            Case "Set_VIII" Or "SetVIII"
                Return 7
            Case Else
                Return 8
        End Select

    End Function


    Private Function vectorotcrop(ByVal vector_itemp As List(Of Double), vector_jtemp As List(Of Double), vector_ktemp As List(Of Double)) As Double
        '***variables necessàries per al càlcul dels moments d'inèrcia***
        Dim i As Integer
        Dim sumx As Double, sumy As Double, sumz As Double
        'Dim xmean As Double, ymean As Double, zmean As Double
        Dim sumyz As Double, sumxz As Double, sumxy As Double
        Dim sumxsq As Double, sumysq As Double, sumzsq As Double
        Dim summodpt As Double
        Dim modpt As Double
        Dim c As Double

        'Dim xmp As Double, ymp As Double, zmp As Double
        'Dim l As Double, m As Double
        'Dim modul As Double
        'Dim a1 As Double, B1 As Double
        sumx = 0 : sumy = 0 : sumz = 0
        '***calculem sumatoris***


        '***calculem promitjos***
        'xmean = vx1.Average
        'ymean = vy1.Average
        'zmean = vz1.Average

        sumyz = 0 : sumxz = 0 : sumxy = 0
        sumxsq = 0 : sumysq = 0 : sumzsq = 0
        summodpt = 0

        '***calculem sumatoris***
        For i = 1 To vector_itemp.Count - 1
            ' di = escollits(i)
            sumyz = sumyz + ((vector_jtemp(i)) - vector_jtemp.Average) * ((vector_ktemp(i)) - vector_ktemp.Average)
            sumxz = sumxz + ((vector_itemp(i)) - vector_itemp.Average) * ((vector_ktemp(i)) - vector_ktemp.Average)
            sumxy = sumxy + ((vector_itemp(i)) - vector_itemp.Average) * ((vector_jtemp(i)) - vector_jtemp.Average)

            sumxsq = sumxsq + Math.Pow(((vector_itemp(i)) - vector_itemp.Average), 2)
            sumysq = sumysq + Math.Pow(((vector_jtemp(i)) - vector_jtemp.Average), 2)
            sumzsq = sumzsq + Math.Pow(((vector_ktemp(i)) - vector_ktemp.Average), 2)

            '***aquest es pels eigenvalues***
            '***calculo l'arrel del modul xq vull el sumatori dls quadrats dls moduls***
            modpt = Math.Pow((vector_itemp(i) - vector_itemp.Average), 2) + Math.Pow((vector_jtemp(i) - vector_jtemp.Average), 2) + Math.Pow((vector_ktemp(i) - vector_ktemp.Average), 2)
            summodpt = summodpt + modpt
        Next i
        '***Ara ve el càlcul***

        Dim n As Integer = 3
        Dim a(3, 3) As Double
        Dim d(3) As Double
        Dim V(3, 3) As Double
        Dim b(3) As Double
        Dim zz(3) As Double
        Dim sm As Double, g As Double, h As Double, s As Double, t As Double, p As Double
        'redim c As Double
        Dim tau As Double, tresh As Double, theta As Double
        Dim Nrot As Integer
        'redim i As Integer
        Dim j As Integer, k As Integer
        Dim ip As Integer, iq As Integer
        Dim prop4 As String

        a(1, 1) = sumxsq
        a(2, 2) = sumysq
        a(3, 3) = sumzsq
        a(1, 2) = sumxy
        a(2, 1) = sumxy
        a(1, 3) = sumxz
        a(3, 1) = sumxz
        a(2, 3) = sumyz
        a(3, 2) = sumyz


        For ip = 1 To n
            For iq = 1 To n
                V(ip, iq) = 0
            Next iq
            V(ip, ip) = 1
        Next ip
        For ip = 1 To n
            b(ip) = a(ip, ip)
            d(ip) = b(ip)
            zz(ip) = 0
        Next ip
        Nrot = 0
        For i = 1 To 50
            sm = 0
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    sm = sm + Math.Abs(a(ip, iq))
                Next iq
            Next ip
            If sm = 0 Then GoTo LINE123
            If i < 4 Then
                tresh = 0.2 * sm / n ^ 2
            Else
                tresh = 0
            End If
            For ip = 1 To (n - 1)
                For iq = (ip + 1) To n
                    g = 100 * Math.Abs(a(ip, iq))
                    If i > 4 And (Math.Abs(d(ip)) + g) = Math.Abs(d(ip)) And (Math.Abs(d(iq)) + g) = Math.Abs(d(iq)) Then
                        a(ip, iq) = 0
                    ElseIf Math.Abs(a(ip, iq)) > tresh Then
                        h = d(iq) - d(ip)
                        If (Math.Abs(h) + g) = Math.Abs(h) Then
                            t = a(ip, iq) / h
                        Else
                            theta = 0.5 * h / a(ip, iq)
                            t = 1 / (Math.Abs(theta) + Math.Sqrt(1 + theta ^ 2))
                            If theta < 0 Then t = -t
                        End If
                        c = 1 / Math.Sqrt(1 + Math.Pow(t, 2))
                        s = t * c
                        tau = s / (1 + c)
                        h = t * a(ip, iq)
                        zz(ip) = zz(ip) - h
                        zz(iq) = zz(iq) + h
                        d(ip) = d(ip) - h
                        d(iq) = d(iq) + h
                        a(ip, iq) = 0
                        For j = 1 To (ip - 1)
                            g = a(j, ip)
                            h = a(j, iq)
                            a(j, ip) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (ip + 1) To (iq - 1)
                            g = a(ip, j)
                            h = a(j, iq)
                            a(ip, j) = g - s * (h + g * tau)
                            a(j, iq) = h + s * (g - h * tau)
                        Next j
                        For j = (iq + 1) To n
                            g = a(ip, j)
                            h = a(iq, j)
                            a(ip, j) = g - s * (h + g * tau)
                            a(iq, j) = h + s * (g - h * tau)
                        Next j
                        For j = 1 To n
                            g = V(j, ip)
                            h = V(j, iq)
                            V(j, ip) = g - s * (h + g * tau)
                            V(j, iq) = h + s * (g - h * tau)
                        Next j
                        Nrot = Nrot + 1
                    End If
                Next iq
            Next ip
            For ip = 1 To n
                b(ip) = b(ip) + zz(ip)
                d(ip) = b(ip)
                zz(ip) = 0
            Next ip
        Next i

        'ret = MbeMessageBox("50 iterations overpassed", 2048)

LINE123:

        '***ara ordenem***

        For i = 1 To n - 1
            k = i
            p = d(i)
            For j = i + 1 To n
                If d(j) > p Then
                    k = j
                    p = d(j)
                End If
            Next j
            If k <> i Then
                d(k) = d(i)
                d(i) = p
                For j = 1 To n
                    p = V(j, i)
                    V(j, i) = V(j, k)
                    V(j, k) = p
                Next j
            End If
        Next i

        '***parem si la matriu d'eigenvectors és la identitat (per exemple si mesurem cabussament d'isolínies)***
        'If V(1, 1) = 0 And V(2, 2) = 0 And V(3, 3) = 0 Then
        'ret = MbeMessageBox("Solution not possible with current eigenvector algorithm", 2048)
        '    Exit Sub
        'End If

        'Dim ll As Double, mm As Double, nn As Double
        'Dim B1 As Double, a1 As Double

        '***volem el vector 3 (criteri Woodcock (1977))***
        '***redrecem el vector per a què pugi***
        Dim prop1 As Double, prop2 As Double
        If V(3, 3) < 0 Then
            AA = -V(1, 3)
            BB = -V(2, 3)
            CC = -V(3, 3)
        Else
            AA = V(1, 3)
            BB = V(2, 3)
            CC = V(3, 3)
        End If
        'afegit
        If V(3, 3) < 0 Then
            Vec1 = -V(1, 1)
            Vec2 = -V(2, 1)
            Vec3 = -V(3, 1)
        Else
            Vec1 = V(1, 1)
            Vec2 = V(2, 1)
            Vec3 = V(3, 1)
        End If
        'afegit

        Return Vec1
        Return Vec2
        Return Vec3

        prop1 = Math.Log(d(1) / d(2))
        prop2 = Math.Log(d(2) / d(3))
        prop3 = Math.Log(d(1) / d(3)) 'Aixo es la M
        If AA = 0 And BB = 1 And CC = 0 Then prop3 = 10
        If AA = 0 And BB = 0 And CC = 1 Then prop3 = 10
        If AA = 1 And BB = 0 And CC = 0 Then prop3 = 10
        prop4 = Str(prop3)
        If prop4 = "Infinito" Then prop3 = 1035
        kapa = prop1 / prop2  ' Això es la K
    End Function


    Function meandir(ByVal vector_itemp As List(Of Double), vector_jtemp As List(Of Double), vector_ktemp As List(Of Double)) As Double
        Vec1b = 0
        Vec2b = 0
        Vec3b = 0
        Dim unitari As Double
        unitari = Math.Sqrt(Math.Pow(vector_itemp.Sum, 2) + Math.Pow(vector_jtemp.Sum, 2) + Math.Pow(vector_ktemp.Sum, 2))
        Vec1 = vector_itemp.Sum / unitari
        Vec2 = vector_jtemp.Sum / unitari
        Vec3 = vector_ktemp.Sum / unitari

        Return Vec1
        Return Vec2
        Return Vec3
    End Function
    Sub attribdxf()
        Dim cont As Integer = 1
        If Form15.CheckBox3.Checked = True Then
            azibedd = Form15.NumericUpDown8.Value
            dibedd = Form15.NumericUpDown9.Value
            pe = Form15.NumericUpDown9.Value
            azibedd = (azibedd * Math.PI) / 180
            dibedd = (dibedd * Math.PI) / 180
            vecibedd = Math.Sin(azibedd)
            vecjbedd = Math.Cos(azibedd)
            veckbedd = Math.Sqrt(((vecibedd * vecibedd) + (vecjbedd * vecjbedd)) / (Math.Tan(dibedd) * (Math.Tan(dibedd))))
            If veckbedd > 100000 Then veckbedd = 99999.999999999
            If azibedd = 0 And dibedd = 0 Then
                vecibedd = 0
                vecjbedd = 0
                veckbedd = 0
            End If
        Else
            vecibedd = 0
            vecjbedd = 0
            veckbedd = 0
        End If

        'final calcul de bedding
        '   For Each rfile In Form15.OpenFileDialog1.FileNames
        '  FileOpen(1, rfile, OpenMode.Input)
        Dim intens As Double
        Dim pas As Integer
        Dim intens1() As Double

        If seleccio = 1 Then
            xtremsup = x(seleccio)
            xtreminf = x(seleccio)
            ytremsup = y(seleccio)
            ytreminf = y(seleccio)
            ztremsup = z(seleccio)
            ztreminf = z(seleccio)
        End If

        If x(seleccio) = y(seleccio) And z(seleccio) = 0 Then '2
            x(seleccio) = x(seleccio - 1)
            y(seleccio) = y(seleccio - 1)
            z(seleccio) = z(seleccio - 1)
            seleccio = seleccio - 1

            intens2 = intens2 + 1
            pas = 0

            If seleccio >= Form15.NumericUpDown1.Value Then '1
                calculvectors()  'seleccio, escollits(), x(), y(), z()
                A = AA : B = BB : C = CC
                calculpendent()
                rugositat()
                'area()
                area2()
                seleccio = -1
            End If '1
            seleccio = -1
        End If '2

        If seleccio >= Form15.NumericUpDown1.Value Then
            escollits(seleccio) = seleccio
            calculvectors()
            A = AA : B = BB : C = CC
            calculpendent()
            If a1 < 0 Then a1 = 180 + a1
            rugositat()
            'area() 'substituït per area2
            area2()
        End If
        ' FileClose(2)
        ' FileClose(1)
        cont = cont + 1
        Array.Resize(x, Nothing)
        Array.Resize(y, Nothing)
        Array.Resize(z, Nothing)
        Array.Resize(escollits, Nothing)
        FracturSett.RemoveRange(0, FracturSett.Count)

        seleccio = -1
        ' MsgBox("Proces Completed")
        Exit Sub
ErrorHandler:
    End Sub

    Sub seleccionarfracturesSL()
        Form32.Label45.Text = "Analyzing Fractures (2/3)"
        Form32.Label45.Refresh()
        Dim fileName As String
        fileName = "export" + jp + ".xlsx"
        finalpath1 = Form10.TextBox1.Text + fileName
        ' variables per impedancia
        Dim escolli As Boolean = False
        Dim escolli1 As Boolean = False
        Dim escolli2 As Boolean = False
        'Declaració de punts
        Dim PIx(,) As Double, PIy(,) As Double, PIz(,) As Double
        Dim xupp() As Double, yupp() As Double, zupp() As Double
        Dim xlow() As Double, ylow() As Double, zlow() As Double

        'ja esta fet
        '   Dsl(mucount) = -(vecSL1(mucount) * xmean1(mucount)) - (vecSL2(mucount) * ymean1(mucount)) - (vecSL3(mucount) * zmean1(mucount))
        '   Dslupp(mucount) = -(vecSL1(mucount) * xupp(mucount)) - (vecSL2(mucount) * yupp(mucount)) - (vecSL3(mucount) * zupp(mucount))
        '  Dsllow(mucount) = -(vecSL1(mucount) * xlow(mucount)) - (vecSL2(mucount) * ylow(mucount)) - (vecSL3(mucount) * zlow(mucount))

        oldCI = System.Threading.Thread.CurrentThread.CurrentCulture
        System.Threading.Thread.CurrentThread.CurrentCulture =
    New System.Globalization.CultureInfo("en-US")
        oldCI2 = System.Threading.Thread.CurrentThread.CurrentCulture
        oExcel = CreateObject("Excel.Application")
        oBook = oExcel.Workbooks.Add(Type.Missing)
        oSheet = oBook.Sheets.Add(,, mucount + 1,)

        For nn = 0 To mucount - 1

            oSheet = oBook.Sheets(nn + 2)
            ' oSheet.Name = name(nn)
            oSheet.Name = PointsName.Item(nn)
        Next



        FileClose(1)


        ReDim seleccio2(mucount, 0)
        ReDim seleccio4(mucount, 0)
        ReDim areatotalUM(mucount)
        ReDim PIx(mucount, 0)
        ReDim PIy(mucount, 0)
        ReDim PIz(mucount, 0)
        ReDim seleccioupp(mucount, 0)
        ReDim seleccio3(mucount, 0)
        ReDim selecciolow(mucount, 0)
        '******obrir fitxer Morphology Total**************
        Dim coordx, coordy, coordz As Double
        Dim vx, vy, vz As Double
        Dim azimu, pende, colineal, coplanar As Double
        Dim population, number As Integer
        Dim rugosity, lon, wide, areas As Double
        Dim fami As String = ""
        Dim ii(mucount) As Integer
        Dim dist1 As Double
        Dim dist2 As Double
        Dim dist3 As Double
        Dim dist4 As Double
        Dim dist1upp As Double
        Dim dist3upp As Double
        Dim dist4upp As Double
        Dim dist1low As Double
        Dim dist3low As Double
        Dim dist4low As Double
        Dim D1, D2, D2upp, D2low, D3 As Double

        Dim numfrac1 As Integer
        On Error GoTo errorhandler

        Form32.ProgressBar1.Value = 0

        For nf = 0 To Cxt.Count - 1                                                                 '*****fractura , nf 

            numfrac1 += 1
            Form32.ProgressBar1.Value = CInt(((100 * numfrac1) - 5) / (Cxt.Count))
            Form32.ProgressBar1.Refresh()
            Dim areaoption As Double
            areaoption = Form32.NumericUpDown3.Value
            If areas >= areaoption Then
                ReDim orienSL(mucount - 1) ' Cálculo de la distancia dist1 entre el plano de SL, SLUp i SLLow y la fractura 
                ReDim pendSL(mucount - 1)
                escolli1 = False
                escolli2 = False
                Dim Dfracture As Double
                '**Pla de bedding' Calcul de Ax+By+Cz+D=0
                Dfracture = -(vector_it.Item(nf) * Cxt.Item(nf)) - (vector_jt.Item(nf) * Cyt.Item(nf)) - (vector_kt.Item(nf) * Czt.Item(nf)) 'vector fractura*posicio fractura pla, de fractura
                For i = 0 To mucount - 1 'per cada MU es comproba                                   '******** i Unitat Mecanica
                    escolli = False
                    escolli1 = False
                    escolli2 = False
                    ReDim Preserve puntintersecx(i)
                    ReDim Preserve puntintersecy(i)
                    ReDim Preserve puntintersecz(i)
                    ReDim Preserve puntintersecxupp(i)
                    ReDim Preserve puntintersecyupp(i)
                    ReDim Preserve puntinterseczupp(i)
                    ReDim Preserve puntintersecxlow(i)
                    ReDim Preserve puntintersecylow(i)
                    ReDim Preserve puntinterseczlow(i)

                    '******Distancia-Posicio entre el pla de bedding i el centroide
                    Dim vxlinea, vylinea, vzlinea, Plinx, Pliny, Plinz, tlinea As Double 'vector de la linea
                    ' Vector de la linea de interseccio
                    vxlinea = (Pointsj.Item(i) * vector_kt.Item(nf)) - (Pointsk.Item(i) * vector_jt.Item(nf))
                    vylinea = (Pointsk.Item(i) * vector_it.Item(nf)) - (Pointsi.Item(i) * vector_kt.Item(nf))
                    vzlinea = (Pointsi.Item(i) * vector_jt.Item(nf)) - (Pointsj.Item(i) * vector_it.Item(nf))
                    ' Un punt de la recta
                    Pliny = ((-Dfracture * Pointsi.Item(i)) + (vector_it.Item(nf) * Dsl(i))) / ((-vector_it.Item(nf) * Pointsj.Item(i)) + (vector_jt.Item(nf) * Pointsi.Item(i)))
                    Plinx = ((-Pointsj.Item(i) * Pliny) - Dsl(i)) / Pointsi.Item(i)
                    Plinz = 0
                    'Punt més proper al centroide del pla de fractura i la linea de intersecció
                    tlinea = ((((vxlinea * (Cxt.Item(nf) - Plinx) + ((vylinea * (Cyt.Item(nf) - Pliny))) + ((vzlinea * (Czt.Item(nf) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecx(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecy(i) = ((vylinea * tlinea) + Pliny)
                    puntintersecz(i) = ((vzlinea * tlinea) + Plinz)
                    '**Pla de bedding upper
                    Pliny = ((-Dfracture * Pointsi.Item(i)) + (vector_it.Item(nf) * Dslupp(i))) / ((-vector_it.Item(nf) * Pointsj.Item(i)) + (vector_jt.Item(nf) * Pointsi.Item(i)))
                    Plinx = ((-Pointsj.Item(i) * Pliny) - Dslupp(i)) / Pointsi.Item(i)
                    Plinz = 0
                    tlinea = ((((vxlinea * (Cxt.Item(nf) - Plinx) + ((vylinea * (Cyt.Item(nf) - Pliny))) + ((vzlinea * (Czt.Item(nf) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecxupp(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecyupp(i) = ((vylinea * tlinea) + Pliny)
                    puntinterseczupp(i) = ((vzlinea * tlinea) + Plinz)
                    '**Pla de beddinglower
                    Pliny = ((-Dfracture * Pointsi.Item(i)) + (vector_it.Item(nf) * Dsllow(i))) / ((-vector_it.Item(nf) * Pointsj.Item(i)) + (vector_jt.Item(nf) * Pointsi.Item(i)))
                    Plinx = ((-Pointsj.Item(i) * Pliny) - Dsllow(i)) / Pointsi.Item(i)
                    Plinz = 0
                    tlinea = ((((vxlinea * (Cxt.Item(nf) - Plinx) + ((vylinea * (Cyt.Item(nf) - Pliny))) + ((vzlinea * (Czt.Item(nf) - Plinz))))) / ((vxlinea * vxlinea) + (vylinea * vylinea) + (vzlinea * vzlinea))))
                    puntintersecxlow(i) = ((vxlinea * tlinea) + Plinx)
                    puntintersecylow(i) = ((vylinea * tlinea) + Pliny)
                    puntinterseczlow(i) = ((vzlinea * tlinea) + Plinz)
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding
                    'distancia total: centre de bedding al centroid de la fractura
                    dist2 = Math.Sqrt((Math.Pow((pxSLtemp((i * 2) + 1) - Cxt.Item(nf)), 2)) + (Math.Pow((pySLtemp((i * 2) + 1) - Cyt.Item(nf)), 2)) + (Math.Pow((pzSLtemp((i * 2) + 1) - Czt.Item(nf)), 2)))
                    'distancia vertical: pla de bedding al centroide
                    dist1 = Math.Abs((Pointsi.Item(i) * Cxt.Item(nf)) + (Pointsj.Item(i) * Cyt.Item(nf)) + (Pointsk.Item(i) * Czt.Item(nf)) + Dsl(i)) / Math.Sqrt((Math.Pow(Pointsi.Item(i), 2)) + (Math.Pow(Pointsj.Item(i), 2)) + (Math.Pow(Pointsk.Item(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3 = Math.Sqrt((Math.Pow((pxSLtemp((i * 2) + 1) - puntintersecx(i)), 2)) + (Math.Pow((pySLtemp((i * 2) + 1) - puntintersecy(i)), 2)) + (Math.Pow((pzSLtemp((i * 2) + 1) - puntintersecz(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4 = Math.Sqrt((Math.Pow((Cxt.Item(nf) - puntintersecx(i)), 2)) + (Math.Pow((Cyt.Item(nf) - puntintersecy(i)), 2)) + (Math.Pow((Czt.Item(nf) - puntintersecz(i)), 2)))
                    If (Widet.Item(nf) / 2) >= dist4 Then   'esta dins els limits de la fractura i SL?
                        '   If dist3 <= (ExtensionMU(i) * 30) And (Widet.Item(nf) / 2) >= dist4 Then   'esta dins els limits de la fractura i SL?
                        seleccio2(i, numfrac0) = nf
                        seleccio4(i, numfrac0) = True
                        escolli = True
                    End If
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding upper
                    'distancia vertical: pla de bedding al punt de intersecció
                    dist1upp = Math.Abs((Pointsi.Item(i) * Cxt.Item(nf)) + (Pointsj.Item(i) * Cyt.Item(nf)) + (Pointsk.Item(i) * Czt.Item(nf)) + Dslupp(i)) / Math.Sqrt((Math.Pow(Pointsi.Item(i), 2)) + (Math.Pow(Pointsj.Item(i), 2)) + (Math.Pow(Pointsk.Item(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3upp = Math.Sqrt((Math.Pow((pxSLtemp(i * 2) - puntintersecxupp(i)), 2)) + (Math.Pow((pySLtemp(i * 2) - puntintersecyupp(i)), 2)) + (Math.Pow((pzSLtemp(i * 2) - puntinterseczupp(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4upp = Math.Sqrt((Math.Pow((Cxt.Item(nf) - puntintersecxupp(i)), 2)) + (Math.Pow((Cyt.Item(nf) - puntintersecyupp(i)), 2)) + (Math.Pow((Czt.Item(nf) - puntinterseczupp(i)), 2)))
                    If escolli = True Then
                        ' If dist3upp <= (ExtensionMU(i) * 30) And (Widet.Item(nf) / 2) >= dist4upp Then
                        If (Widet.Item(nf) / 2) >= dist4upp Then
                            escolli1 = True
                        End If
                    End If
                    '****** Comprobar si aquesta distancia esta per sota de la mitat Hei, Ext des de xmean, ymean, zmean del Bedding lower
                    dist1low = Math.Abs((Pointsi.Item(i) * Cxt.Item(nf)) + (Pointsj.Item(i) * Cyt.Item(nf)) + (Pointsk.Item(i) * Czt.Item(nf)) + Dslupp(i)) / Math.Sqrt((Math.Pow(Pointsi.Item(i), 2)) + (Math.Pow(Pointsj.Item(i), 2)) + (Math.Pow(Pointsk.Item(i), 2)))
                    'distancia horitzontal: centre de bedding al punt de intersecció
                    dist3low = Math.Sqrt((Math.Pow((pxSLtemp((i * 2) + 2) - puntintersecxlow(i)), 2)) + (Math.Pow((pySLtemp((i * 2) + 2) - puntintersecylow(i)), 2)) + (Math.Pow((pzSLtemp((i * 2) + 2) - puntinterseczlow(i)), 2)))
                    'distancia vertical:  Centroide al punt de intersecció
                    dist4low = Math.Sqrt((Math.Pow((Cxt.Item(nf) - puntintersecxlow(i)), 2)) + (Math.Pow((Cyt.Item(nf) - puntintersecylow(i)), 2)) + (Math.Pow((Czt.Item(nf) - puntinterseczlow(i)), 2)))
                    If escolli = True Then
                        '  If dist3low <= (ExtensionMU(i) * 30) And (Widet.Item(nf) / 2) >= dist4low Then
                        If (Widet.Item(nf) / 2) >= dist4low Then
                            escolli2 = True
                        End If
                    End If
                    '******** Càlcul de l'area inscrita a l'area de la U.M. P22
                    'Sumatori dels inscrits amb els que fan contacte
                    'Inscrits sense contacte
                    'càlcul de les distancies 
                    Dim distpinpin, distupp, distlow As Double
                    distpinpin = Math.Sqrt((Math.Pow((puntintersecxupp(i) - puntintersecxlow(i)), 2)) + (Math.Pow((puntintersecyupp(i) - puntintersecylow(i)), 2)) + (Math.Pow((puntinterseczupp(i) - puntinterseczlow(i)), 2)))
                    ' distupp = Math.Sqrt((Math.Pow((puntintersecxupp(i) - coordx), 2)) + (Math.Pow((puntintersecyupp(i) - coordy), 2)) + (Math.Pow((puntinterseczupp(i) - coordz), 2)))
                    ' distlow = Math.Sqrt((Math.Pow((puntintersecxlow(i) - coordx), 2)) + (Math.Pow((puntintersecylow(i) - coordy), 2)) + (Math.Pow((puntinterseczlow(i) - coordz), 2)))
                    ReDim Preserve P22Area(mucount, nfp22)
                    ReDim Preserve P22Set(mucount, nfp22)
                    Select Case escolli1
                        Case False
                            Select Case escolli2   ''''''''''****************EXT....
                                Case False
                                    If dist4upp < distpinpin And dist4low < distpinpin Then ' i esta a dintre i no talla
                                        ' If dist3 <= (ExtensionMU(i) * 30) Then ' i a prop
                                        areatotalUM(i) = areatotalUM(i) + Areat.Item(nf)
                                        P22Area(i, nfp22) = Areat.Item(nf)
                                        P22Set(i, nfp22) = FracturSett.Item(nf)
                                        nfp22 += 1
                                        ' End If
                                    End If
                                Case True 'talla el low
                                    '  If dist3 <= (ExtensionMU(i) * 30) Then ' i a prop
                                    areatotalUM(i) = areatotalUM(i) + ((((Widet.Item(nf) / 2) - dist4low) / Widet.Item(nf)) * Areat.Item(nf))
                                    If areatotalUM(i) < 0 Then Stop
                                    P22Area(i, nfp22) = ((((Widet.Item(nf) / 2) - dist4low) / Widet.Item(nf)) * Areat.Item(nf))
                                    P22Set(i, nfp22) = FracturSett.Item(nf)
                                    nfp22 += 1
                                    ' End If
                            End Select 'escolli2 

                        Case True
                            Select Case escolli2
                                Case False 'talls el upper
                                    '  If dist3 <= (ExtensionMU(i) * 30) Then ' i a prop
                                    areatotalUM(i) = areatotalUM(i) + ((((Widet.Item(nf) / 2) - dist4upp) / Widet.Item(nf)) * Areat.Item(nf))
                                    If areatotalUM(i) < 0 Then Stop
                                    P22Area(i, nfp22) = ((((Widet.Item(nf) / 2) - dist4upp) / Widet.Item(nf)) * Areat.Item(nf))
                                    P22Set(i, nfp22) = FracturSett.Item(nf)
                                    nfp22 += 1
                                   ' End If
                                Case True 'talla els dos beddings
                                    ' If dist3 <= (ExtensionMU(i) * 30) Then ' i a prop
                                    areatotalUM(i) = areatotalUM(i) + ((distpinpin / Widet.Item(nf)) * Areat.Item(nf))

                                    P22Area(i, nfp22) = ((distpinpin / Widet.Item(nf)) * Areat.Item(nf))
                                    P22Set(i, nfp22) = FracturSett.Item(nf)
                                    nfp22 += 1
                                    ' End If
                            End Select
                    End Select

                    '******Si estan escoolits són registrats
                    If escolli = True Then
                        ReDim Preserve x(nf)
                        x(nf) = Cxt.Item(nf)
                        ReDim Preserve y(nf)
                        y(nf) = Cyt.Item(nf)
                        ReDim Preserve z(nf)
                        z(nf) = Czt.Item(nf)
                        ReDim Preserve vect1(nf)
                        vect1(nf) = vector_it.Item(nf)
                        ReDim Preserve vect2(nf)
                        vect2(nf) = vector_jt.Item(nf)
                        ReDim Preserve vect3(nf)
                        vect3(nf) = vector_kt.Item(nf)
                        ReDim Preserve orientacio(nf)
                        orientacio(nf) = orient.Item(nf)
                        ReDim Preserve pendent(nf)
                        pendent(nf) = pendt.Item(nf)
                        ReDim Preserve M(nf)
                        M(nf) = M1t.Item(nf)
                        ReDim Preserve K(nf)
                        K(nf) = K1t.Item(nf)
                        ReDim Preserve Populat(nf)
                        Populat(nf) = Populationt.Item(nf)
                        ReDim Preserve Nume(nf)
                        Nume(nf) = Numbert.Item(nf)
                        ReDim Preserve Roughness(nf)
                        Roughness(nf) = Rugosityt.Item(nf)
                        ReDim Preserve Height(nf)
                        Height(nf) = Widet.Item(nf) 'fracture length
                        ReDim Preserve Wid(nf)
                        Wid(nf) = Longt.Item(nf) 'fracture height
                        ReDim Preserve Ar(nf)
                        Ar(nf) = Areat.Item(nf)
                        ReDim Preserve FracturSet(nf)
                        FracturSet(nf) = FracturSett.Item(nf)
                        ReDim Preserve impfrac(nf)
                        '  ReDim Preserve seleccioupp(mucount, numfrac0)   'si es una fractura seleccionada per l'SLupp, la UM i set
                        '  ReDim Preserve selecciolow(mucount, numfrac0)  'si es una fractura seleccionada per l'SLdw, la UM i set
                        '  ReDim Preserve impSupfrac(nf)


                        If escolli1 = True And escolli2 = True Then impfrac(nf) = True
                        If escolli1 = True And escolli2 = True Then seleccio3(i, numfrac0) = True
                        If escolli1 = True And escolli2 = False Then seleccioupp(i, numfrac0) = True
                        If escolli1 = False And escolli2 = True Then selecciolow(i, numfrac0) = True

                        numfrac0 += 1
                        escolli = False
                        escolli1 = False
                        escolli2 = False
                        ReDim Preserve seleccio2(mucount, numfrac0)    'si es una fractura seleccionada per l'SL, la UM i set 'altyernativa  ReDim Preserve seleccio2(mucount, numfrac0) 
                        ReDim Preserve seleccio3(mucount, numfrac0)
                        ReDim Preserve seleccio4(mucount, numfrac0)
                        ReDim Preserve seleccioupp(mucount, numfrac0)   'si es una fractura seleccionada per l'SLupp, la UM i set
                        ReDim Preserve selecciolow(mucount, numfrac0)  'si es una fractura seleccionada per l'SLdw, la UM i set
                    End If
                    escolli = False
                    escolli1 = False
                    escolli2 = False

                    'calcular t dels pous sintectics
                    t = (-Dfracture - (vector_it.Item(nf) * x_out.Item(i)) - (vector_jt.Item(nf) * y_out.Item(i)) - (vector_kt.Item(nf) * z_out.Item(i))) / ((vector_it.Item(nf) * vxwell(i)) + (vector_jt.Item(nf) * vywell(i)) + (vector_kt.Item(nf) * vzwell(i)))
                    ' punt de contacte amb el pla de fractura
                    pwellx = ((vxwell(i) * t) + x_out.Item(i))
                    pwelly = ((vywell(i) * t) + y_out.Item(i))
                    pwellz = ((vzwell(i) * t) + z_out.Item(i))
                    ' If i = 0 Then PrintLine(3, Format(pwellx, "0.000"), Format(pwelly, "0.000"), Format(pwellz, "0.000"))

                    ' vector entre centroide i punt de pou.
                    Dim vfrawellx, vfrawelly, vfrawellz As Double
                    Dim ang, distwell, heifrac, lengfrac As Double
                    vfrawellx = Cxt.Item(nf) - pwellx
                    vfrawelly = Cyt.Item(nf) - pwelly
                    vfrawellz = Czt.Item(nf) - pwellz
                    distwell = Math.Sqrt(Math.Pow(vfrawellx, 2) + Math.Pow(vfrawelly, 2) + Math.Pow(vfrawellz, 2))

                    ang = Math.Acos(Math.Abs(((vfrawellx * vector_it.Item(nf)) + (vfrawelly * vector_jt.Item(nf)) + (vfrawellz * vector_kt.Item(nf))) / (Math.Sqrt((vfrawellx * vfrawellx) + (vfrawelly * vfrawelly) + (vfrawellz * vfrawellz)) * Math.Sqrt((vector_it.Item(nf) * vector_it.Item(nf)) + (vector_jt.Item(nf) * vector_jt.Item(nf)) + (vector_kt.Item(nf) * vector_kt.Item(nf))))))
                    heifrac = distwell * Math.Sin(ang * Math.PI / 180)
                    lengfrac = distwell * Math.Cos(ang * Math.PI / 180)

                    If heifrac <= Longt.Item(nf) And lengfrac <= Widet.Item(nf) Then

                        twell.Add(t)
                        twell1.Add(t)
                        pwx.Add(pwellx)
                        pwy.Add(pwelly)
                        pwz.Add(pwellz)
                        setw.Add(fami)
                        well.Add(i)
                    End If
                Next
                'Càlcul de l'extensió del SL





            End If
            'Calcul del synthetic well
        Next 'de les fractures
        Form32.ProgressBar1.Value = 100
        Form32.ProgressBar1.Refresh()
        syntheticwell()
        Form32.ProgressBar1.Value = 100
        Form32.ProgressBar1.Refresh()
        Form32.Label45.Text = "Calculate Abundance (3/3)"
        orientations()
        ' Form32.ProgressBar1.Value = 100

        ' Form32.ProgressBar1.Refresh()

        System.Threading.Thread.CurrentThread.CurrentCulture = oldCI2

        oBook.SaveAs(finalpath1)

        System.Threading.Thread.CurrentThread.CurrentCulture = oldCI ' reemplaza el anterior

        oExcel.Quit()
        MsgBox("Process Completed")
errorhandler:
        Exit Sub
    End Sub
End Module
